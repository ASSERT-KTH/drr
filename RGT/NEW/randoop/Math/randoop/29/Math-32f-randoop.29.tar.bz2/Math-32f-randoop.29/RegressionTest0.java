import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray2 = new float[] {};
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray2);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getSize();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane3 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane4 = polygonsSet1.intersection(euclidean2DSubHyperplane3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector4 = null;
        try {
            double double5 = vector3D3.distance1(euclidean3DVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(7.896296018268069E13d, vector2D1, (double) (short) -1, vector2D3, (double) '#', vector2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.geometry.euclidean.threed.Line line0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Line line1 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double[] doubleArray6 = new double[] { ' ', 0L, 0.0d, ' ', (-1), '#' };
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (32 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        float float2 = org.apache.commons.math3.util.FastMath.max(10.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, 10.0d, (double) 10.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 110.0d + "'", double4 == 110.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 'a', (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (byte) 10, (double) (byte) 100, (double) (short) 100, (double) (byte) -1, (double) 10.0f, (double) ' ', (double) 100.0f, (double) '#');
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4720.0d + "'", double8 == 4720.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection2 = null;
        try {
            boolean boolean4 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray0, orderDirection2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double2 = org.apache.commons.math3.util.FastMath.max(10.0d, 110.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 110.0d + "'", double2 == 110.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 100, (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math3.util.Precision.round((-1.0d), (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D3, vector3D9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.util.MathUtils.checkFinite(100.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (short) 0, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 110.0d, 4720.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(1.4E-45f, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane1 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.660700274874677d + "'", double0 == 0.660700274874677d);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (byte) 100);
        double[][] doubleArray5 = null;
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray4, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.geom.AffineTransform affineTransform0 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform1 = org.apache.commons.math3.geometry.euclidean.twod.Line.getTransform(affineTransform0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.401298464324817E-45d + "'", double1 == 1.401298464324817E-45d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) '#', 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math3.util.FastMath.cos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        long long1 = org.apache.commons.math3.util.FastMath.round(Double.NaN);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector1 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add(euclidean2DVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1L, (double) (short) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        double double3 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray1);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        try {
            double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (byte) 100, (double) (-1.0f), 0.660700274874677d, (double) 0L, (double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-100.0d) + "'", double6 == (-100.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double6 = vector3D5.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj11 = null;
        boolean boolean12 = vector3D10.equals(obj11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getDelta();
        double double18 = vector3D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D5.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D1, vector3D10);
        try {
            double double21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D0, vector3D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09966370236491838d + "'", double17 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 99.0d + "'", double20 == 99.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.660700274874677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 1, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float2 = org.apache.commons.math3.util.Precision.round((float) ' ', (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.660700274874677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.geometry.partitioning.Side side0 = org.apache.commons.math3.geometry.partitioning.Side.HYPER;
        org.junit.Assert.assertTrue("'" + side0 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side0.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj19 = null;
        boolean boolean20 = vector3D18.equals(obj19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double25 = vector3D24.getDelta();
        double double26 = vector3D18.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D13.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        double double28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D4, vector3D18);
        try {
            double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D0, vector3D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.09966370236491838d + "'", double25 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4478350516631948d + "'", double28 == 1.4478350516631948d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.geometry.partitioning.Side side0 = org.apache.commons.math3.geometry.partitioning.Side.MINUS;
        org.junit.Assert.assertTrue("'" + side0 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side0.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((-100.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        int int3 = org.apache.commons.math3.util.MathUtils.hash(doubleArray2);
        double double4 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray2);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) (byte) 100);
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 1, (float) (short) 10, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(6, (int) 'a');
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = null;
        try {
            double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (short) -1, (-100.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000000000000002d) + "'", double2 == (-1.0000000000000002d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(2.2250738585072014E-308d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double double1 = vector3D0.getNorm();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double[] doubleArray0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray2);
        try {
            double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double4 = vector3D3.getDelta();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5474944974040916d + "'", double4 == 1.5474944974040916d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        java.lang.Number number3 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (byte) 100, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray8 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int9 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray8);
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, (double) (-1.0f), 0.660700274874677d, (double) '#', 1.4478350516631948d, 4.9E-324d, (double) (short) 1, 1.401298464324817E-45d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 22.124509620613694d + "'", double8 == 22.124509620613694d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.geometry.partitioning.Side side0 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        org.junit.Assert.assertTrue("'" + side0 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side0.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector23 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = plane21.toSubSpace(euclidean3DVector23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        double double6 = vector2D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform11 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane12 = subPlane9.applyTransform(euclidean3DTransform11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.Space space10 = vector3D7.getSpace();
        org.junit.Assert.assertNotNull(space10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 1, 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getSize();
        double double3 = polygonsSet1.getBoundarySize();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane4 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane5 = polygonsSet1.intersection(euclidean2DSubHyperplane4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.geometry.euclidean.twod.Line line0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Line line1 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double13 = vector3D12.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj18 = null;
        boolean boolean19 = vector3D17.equals(obj18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getDelta();
        double double25 = vector3D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D12.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D3, vector3D17);
        double[] doubleArray28 = vector3D17.toArray();
        double[] doubleArray29 = new double[] {};
        int int30 = org.apache.commons.math3.util.MathUtils.hash(doubleArray29);
        try {
            double double31 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray28, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.09966370236491838d + "'", double24 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4478350516631948d + "'", double27 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable3, objArray6);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 100.00001f, objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 30.0f, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7966988750916414E-8d + "'", double2 == 2.7966988750916414E-8d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math3.util.FastMath.log(6.283185307179586d, 1.5474944974040916d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23757691836609945d + "'", double2 == 0.23757691836609945d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D0, vector3D4);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 0L, 4.9E-324d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double[] doubleArray0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray2);
        double[] doubleArray4 = new double[] {};
        int int5 = org.apache.commons.math3.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane9.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane11 = subPlane10.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion12 = euclidean3DAbstractSubHyperplane11.getRemainingRegion();
        int[] intArray15 = new int[] {};
        int[] intArray22 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int23 = org.apache.commons.math3.util.MathArrays.distance1(intArray15, intArray22);
        org.apache.commons.math3.geometry.partitioning.Side side24 = org.apache.commons.math3.geometry.partitioning.Side.PLUS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { euclidean2DRegion12, false, 1.0f, intArray22, side24 };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray25);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane11);
        org.junit.Assert.assertNotNull(euclidean2DRegion12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + side24 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side24.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple1 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion11 = euclidean3DAbstractSubHyperplane10.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform12 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane13 = euclidean3DAbstractSubHyperplane10.applyTransform(euclidean3DTransform12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(euclidean2DRegion11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math3.util.FastMath.log(2.220446049250313E-16d, 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.1761977896489369d) + "'", double2 == (-0.1761977896489369d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        double double5 = vector3D3.getAlpha();
        double double6 = vector3D3.getNormSq();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.009999666686665238d + "'", double5 == 0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10101.0d + "'", double6 == 10101.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane4, euclidean1DRegion5);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane7 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane7, euclidean1DRegion8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane10 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane10, euclidean1DRegion11);
        double double13 = subOrientedPoint12.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane14 = subOrientedPoint12.getHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList15 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        boolean boolean16 = euclidean1DSubHyperplaneList15.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint2);
        boolean boolean17 = euclidean1DSubHyperplaneList15.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint6);
        boolean boolean18 = euclidean1DSubHyperplaneList15.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        boolean boolean19 = euclidean1DSubHyperplaneList15.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint12);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet20 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.5403023058681398d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.9999999958776927d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999958776927d + "'", double2 == 0.9999999958776927d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray2 = new double[] { 0.09966370236491838d, (short) 1 };
        int int3 = org.apache.commons.math3.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { 0L, 35.0f, (-0.1761977896489369d), (byte) 1, 10.0f };
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray2, doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 890547225 + "'", int3 == 890547225);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = plane8.getPointAt(vector2D11, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28);
        org.apache.commons.math3.geometry.partitioning.Side side31 = subPlane20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane9, plane30, plane32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertTrue("'" + side31 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side31.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.578388440339d + "'", double1 == 5729.578388440339d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.Side side5 = subOrientedPoint2.side(euclidean1DHyperplane4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 30.0f, vector3D1);
        org.junit.Assert.assertNotNull(vector3D1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getY();
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector18 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D15.subtract(euclidean3DVector18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane3 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint5 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane3, euclidean1DRegion4);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = subOrientedPoint5.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane7 = subOrientedPoint5.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane8 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane8, euclidean1DRegion9);
        double double11 = subOrientedPoint10.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane12 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion13 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane12, euclidean1DRegion13);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion15 = subOrientedPoint14.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane16 = subOrientedPoint14.copySelf();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList17 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        boolean boolean18 = euclidean1DSubHyperplaneList17.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint2);
        boolean boolean19 = euclidean1DSubHyperplaneList17.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane7);
        boolean boolean20 = euclidean1DSubHyperplaneList17.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint10);
        boolean boolean21 = euclidean1DSubHyperplaneList17.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane16);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DRegion6);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DRegion15);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        java.lang.String str5 = vector3D3.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D3.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.negate();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{100; 1; 10}" + "'", str5.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D4);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector8 = null;
        try {
            double double9 = vector3D4.distanceInf(euclidean3DVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (-1.0f), 2.718281828459045d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 1.401298464324817E-45d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 890547225, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 890547225L + "'", long2 == 890547225L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 890547225L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.949656954695495d + "'", double1 == 8.949656954695495d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10.0f, 0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree8 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree1, spaceBSPTree2, (java.lang.Object) double7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28);
        org.apache.commons.math3.geometry.partitioning.Side side31 = subPlane20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        boolean boolean32 = plane10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertTrue("'" + side31 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side31.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, euclidean1DRegion6);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion8 = subOrientedPoint7.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane9 = subOrientedPoint7.copySelf();
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane10 = euclidean1DAbstractSubHyperplane4.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
        org.junit.Assert.assertNull(euclidean1DRegion8);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D9.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = null;
        try {
            double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D9, vector3D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 1072693248);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        try {
            org.apache.commons.math3.geometry.partitioning.Region.Location location3 = intervalsSet1.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.Space space2 = vector2D0.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double5 = vector2D4.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet8 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector9 = polygonsSet8.getBarycenter();
        double double10 = vector2D6.dotProduct(euclidean2DVector9);
        double double11 = vector2D6.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray13 = vector2D12.toArray();
        double double14 = vector2D12.getNorm();
        double double15 = vector2D12.getX();
        double double16 = vector2D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        double double17 = vector2D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double18 = vector2D4.getX();
        double double19 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double20 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        double double3 = intervalsSet2.getInf();
        double double4 = intervalsSet2.getInf();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.660700274874677d + "'", double3 == 0.660700274874677d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.660700274874677d + "'", double4 == 0.660700274874677d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math3.util.FastMath.rint(2.7966988750916414E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 10, Double.NEGATIVE_INFINITY };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection13, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = nonMonotonicSequenceException15.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection17 = nonMonotonicSequenceException15.getDirection();
        try {
            boolean boolean20 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection17, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        java.text.NumberFormat numberFormat1 = null;
        try {
            java.lang.String str2 = vector3D0.toString(numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, euclidean1DRegion6);
        double double8 = subOrientedPoint7.getSize();
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane9 = subOrientedPoint2.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long1 = org.apache.commons.math3.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1047993141977928d + "'", double1 == 1.1047993141977928d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) 1, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector2 = polygonsSet1.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = polygonsSet1.buildNew(euclidean2DBSPTree3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double6 = vector2D5.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector8 = polygonsSet7.getBarycenter();
        double double9 = vector2D5.dotProduct(euclidean2DVector8);
        double double10 = vector2D5.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        double double13 = vector2D11.getNorm();
        double double14 = vector2D11.getX();
        double double15 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        try {
            org.apache.commons.math3.geometry.partitioning.Region.Location location16 = polygonsSet4.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DVector2);
        org.junit.Assert.assertNotNull(polygonsSet4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.009999666686665238d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double13 = vector3D12.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj18 = null;
        boolean boolean19 = vector3D17.equals(obj18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getDelta();
        double double25 = vector3D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D12.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D3, vector3D17);
        double[] doubleArray28 = vector3D17.toArray();
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.09966370236491838d + "'", double24 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4478350516631948d + "'", double27 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = null;
        try {
            double double45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D0, vector1D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0L, 22.124509620613694d, (double) 0.0f, 0.660700274874677d, 0.0d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(22.124509620613694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.703669803527209d + "'", double1 == 4.703669803527209d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        java.lang.String str5 = vector3D3.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D3.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D3.scalarMultiply((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{100; 1; 10}" + "'", str5.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector29 = polyhedronsSet28.getBarycenter();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
        org.junit.Assert.assertNotNull(euclidean3DVector29);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 10L, 1.0000000000000002d, 1.7453292519943295d, 0.660700274874677d, 0.0d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.15313951653947d + "'", double6 == 11.15313951653947d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double22 = vector3D21.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj27 = null;
        boolean boolean28 = vector3D26.equals(obj27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double33 = vector3D32.getDelta();
        double double34 = vector3D26.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D21.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        double double36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D12, vector3D26);
        double double37 = vector3D7.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D26.normalize();
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.09966370236491838d + "'", double33 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4478350516631948d + "'", double36 == 1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D38);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = plane11.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20);
        org.apache.commons.math3.geometry.partitioning.Side side23 = subPlane12.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double29 = vector3D28.getDelta();
        java.lang.String str30 = vector3D28.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double37 = vector3D36.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj42 = null;
        boolean boolean43 = vector3D41.equals(obj42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double48 = vector3D47.getDelta();
        double double49 = vector3D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D36.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        double double51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D32, vector3D41);
        plane22.reset(vector3D31, vector3D32);
        double double53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D2, vector3D32);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(subPlane12);
        org.junit.Assert.assertTrue("'" + side23 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side23.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.09966370236491838d + "'", double29 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{100; 1; 10}" + "'", str30.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.09966370236491838d + "'", double48 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 99.0d + "'", double51 == 99.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 100.0d + "'", double53 == 100.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29100619138474915d) + "'", double1 == (-0.29100619138474915d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getY();
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double22 = vector3D15.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = segment8.getEnd();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) dimensionMismatchException5);
        int int7 = dimensionMismatchException5.getDimension();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector2 = polygonsSet1.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = polygonsSet1.buildNew(euclidean2DBSPTree3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree5 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = polygonsSet4.buildNew(euclidean2DBSPTree5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray8 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment15 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D7, vector2D9, line14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = segment15.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine17 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray19 = vector2D18.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray21 = vector2D20.toArray();
        double double22 = vector2D20.getNorm();
        double double23 = vector2D20.getX();
        double double24 = vector2D20.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment26 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D18, vector2D20, line25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = segment26.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment26);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane29 = subLine17.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine28);
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane30 = polygonsSet4.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DVector2);
        org.junit.Assert.assertNotNull(polygonsSet4);
        org.junit.Assert.assertNotNull(polygonsSet6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane29);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) ' ', 0.0f, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        double double21 = subPlane9.getSize();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        double double5 = vector3D3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math3.util.FastMath.abs(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint2.copySelf();
        try {
            boolean boolean5 = euclidean1DAbstractSubHyperplane4.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = subOrientedPoint2.getHyperplane();
        try {
            boolean boolean5 = subOrientedPoint2.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space> spaceRegionFactory0 = new org.apache.commons.math3.geometry.partitioning.RegionFactory<org.apache.commons.math3.geometry.Space>();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) '4', (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.072693248E9d + "'", double1 == 1.072693248E9d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        boolean boolean8 = nonMonotonicSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        double double3 = vector2D1.getNorm();
        double double4 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray7 = vector2D6.toArray();
        double double8 = vector2D6.getNorm();
        boolean boolean9 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment11 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D1, vector2D6, line10);
        double double12 = vector2D6.getNormInf();
        java.text.NumberFormat numberFormat13 = null;
        java.lang.String str14 = vector2D6.toString(numberFormat13);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{(Infinity); (Infinity)}" + "'", str14.equals("{(Infinity); (Infinity)}"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.Space space2 = vector1D1.getSpace();
        java.lang.String str3 = vector1D1.toString();
        java.text.NumberFormat numberFormat4 = null;
        try {
            java.lang.String str5 = vector1D1.toString(numberFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{35}" + "'", str3.equals("{35}"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = null;
        try {
            double double2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D0, vector2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(1.401298464324817E-45d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.401298464324817E-45d + "'", double2 == 1.401298464324817E-45d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = subOrientedPoint2.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform5 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane6 = subOrientedPoint2.applyTransform(euclidean1DTransform5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.apache.commons.math3.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double2 = org.apache.commons.math3.util.Precision.round(1.0000000000000002d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 100, (int) (byte) 10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = plane27.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane27);
        boolean boolean30 = plane18.isSimilarTo(plane29);
        boolean boolean31 = plane9.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double51 = vector3D50.getDelta();
        java.lang.String str52 = vector3D50.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D46, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D50, (double) 0.0f, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj62 = null;
        boolean boolean63 = vector3D61.equals(obj62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double69 = vector3D68.getDelta();
        java.lang.String str70 = vector3D68.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D68.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D38, 0.09966370236491838d, vector3D50, 6.283185307179586d, vector3D61, (double) 100L, vector3D68);
        try {
            plane32.reset(vector3D33, vector3D61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.09966370236491838d + "'", double51 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{100; 1; 10}" + "'", str52.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.09966370236491838d + "'", double69 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{100; 1; 10}" + "'", str70.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D72);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getDelta();
        java.lang.String str18 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D16, (double) 0.0f, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj28 = null;
        boolean boolean29 = vector3D27.equals(obj28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        java.lang.String str36 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D34.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D4, 0.09966370236491838d, vector3D16, 6.283185307179586d, vector3D27, (double) 100L, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D45, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double58 = vector3D57.getDelta();
        java.lang.String str59 = vector3D57.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D53, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D57, (double) 0.0f, vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj69 = null;
        boolean boolean70 = vector3D68.equals(obj69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getDelta();
        java.lang.String str77 = vector3D75.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D75.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D45, 0.09966370236491838d, vector3D57, 6.283185307179586d, vector3D68, (double) 100L, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D4.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D80);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09966370236491838d + "'", double17 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{100; 1; 10}" + "'", str18.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{100; 1; 10}" + "'", str36.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.09966370236491838d + "'", double58 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{100; 1; 10}" + "'", str59.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.09966370236491838d + "'", double76 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{100; 1; 10}" + "'", str77.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D81);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        double double3 = intervalsSet2.getInf();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet2.copySelf();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector5 = intervalsSet2.getBarycenter();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.660700274874677d + "'", double3 == 0.660700274874677d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(euclidean1DVector5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(false);
        try {
            double double4 = intervalsSet1.getSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DBSPTree3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree3);
        try {
            boolean boolean5 = polygonsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        float float2 = org.apache.commons.math3.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) '#', (double) (short) 0, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane11 = subPlane10.copySelf();
        boolean boolean12 = subPlane10.isEmpty();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 1072693248, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269331E9f + "'", float2 == 1.07269331E9f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet7.buildNew(euclidean1DBSPTree9);
        try {
            java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList11 = intervalsSet10.asList();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intervalsSet10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.009999666686665238d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(1.4478350516631948d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        java.text.NumberFormat numberFormat19 = null;
        java.lang.String str20 = vector1D18.toString(numberFormat19);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{(NaN)}" + "'", str20.equals("{(NaN)}"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) -1, (float) ' ', 1.4E-45f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) '4', 890547225L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        double double5 = vector2D3.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.negate();
        double double9 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D1, Double.POSITIVE_INFINITY, vector2D3, 2.718281828459045d, vector2D11);
        boolean boolean14 = vector2D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D11, vector2D15);
        double double17 = vector2D15.getNorm1();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass7 = nonMonotonicSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        double double2 = vector2D0.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.negate();
        double double6 = vector2D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        java.lang.String str7 = vector2D5.toString();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.0d, 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double12 = vector3D11.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj17 = null;
        boolean boolean18 = vector3D16.equals(obj17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double23 = vector3D22.getDelta();
        double double24 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        double double27 = vector3D26.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double32 = vector3D31.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj37 = null;
        boolean boolean38 = vector3D36.equals(obj37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double43 = vector3D42.getDelta();
        double double44 = vector3D36.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D31.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D26, vector3D45);
        java.text.NumberFormat numberFormat47 = null;
        try {
            java.lang.String str48 = vector3D46.toString(numberFormat47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.09966370236491838d + "'", double23 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 200.0d + "'", double27 == 200.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.09966370236491838d + "'", double43 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.geometry.partitioning.utilities.AVLTree<org.apache.commons.math3.util.MathArrays.OrderDirection> orderDirectionAVLTree0 = new org.apache.commons.math3.geometry.partitioning.utilities.AVLTree<org.apache.commons.math3.util.MathArrays.OrderDirection>();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet7.buildNew(euclidean1DBSPTree9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D12, (double) 30.0f, vector1D14, 0.09966370236491838d, vector1D16, (double) 100L, vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D21, (double) 30.0f, vector1D23, 0.09966370236491838d, vector1D25, (double) 100L, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.partitioning.Region.Location location30 = intervalsSet7.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intervalsSet10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + location30 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location30.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double16 = vector2D15.getX();
        double double17 = vector2D15.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double19 = vector2D18.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D18.negate();
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double24 = vector2D23.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D13, Double.POSITIVE_INFINITY, vector2D15, 2.718281828459045d, vector2D23);
        double double26 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector27 = null;
        try {
            double double28 = vector2D15.distanceInf(euclidean2DVector27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D13);
        double double16 = vector3D13.getZ();
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.09966370236491838d + "'", double14 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double19 = vector3D18.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj24 = null;
        boolean boolean25 = vector3D23.equals(obj24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        double double31 = vector3D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D18.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D9, vector3D23);
        double[] doubleArray34 = vector3D23.toArray();
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray34);
        int int36 = org.apache.commons.math3.util.MathUtils.hash(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4478350516631948d + "'", double33 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1941080993) + "'", int36 == (-1941080993));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (-33553471), 10.0d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 0, (int) (byte) -1);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet8 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray9 = polygonsSet8.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable6, (java.lang.Object[]) vector2DArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 1.0000000000000002d, (java.lang.Object[]) vector2DArray9);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException3, localizable4, (java.lang.Object[]) vector2DArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2DArray9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform24 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion25 = polyhedronsSet23.applyTransform(euclidean3DTransform24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        java.lang.String str31 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D29.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Line line34 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane35 = polyhedronsSet23.firstIntersection(vector3D29, line34);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{100; 1; 10}" + "'", str31.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane35);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable2, objArray5);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray5);
        try {
            java.lang.String str8 = nullArgumentException7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj24 = null;
        boolean boolean25 = vector3D23.equals(obj24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        double double31 = vector3D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double36 = vector3D35.getY();
        double double37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D23, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D35.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = null;
        try {
            line19.reset(vector3D35, vector3D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) '#', 890547225);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane3 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        boolean boolean8 = orientedPoint7.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint7, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        try {
            org.apache.commons.math3.geometry.partitioning.Side side13 = subOrientedPoint2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 1.0f, (double) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math3.util.FastMath.tan(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane8.getNormal();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(vector3D11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math3.util.FastMath.min(99.0d, 1.5474944974040916d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5474944974040916d + "'", double2 == 1.5474944974040916d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double18 = vector3D17.getDelta();
        java.lang.String str19 = vector3D17.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D17, (double) 0.0f, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double36 = vector3D35.getDelta();
        java.lang.String str37 = vector3D35.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D35.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D5, 0.09966370236491838d, vector3D17, 6.283185307179586d, vector3D28, (double) 100L, vector3D35);
        try {
            double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D0, vector3D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.09966370236491838d + "'", double18 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{100; 1; 10}" + "'", str19.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.09966370236491838d + "'", double36 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{100; 1; 10}" + "'", str37.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D39);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double19 = vector3D18.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj24 = null;
        boolean boolean25 = vector3D23.equals(obj24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        double double31 = vector3D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D18.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D9, vector3D23);
        double[] doubleArray34 = vector3D23.toArray();
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray34);
        double[] doubleArray36 = new double[] {};
        int int37 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray39);
        double[] doubleArray44 = new double[] { ' ', (byte) 10, Double.NEGATIVE_INFINITY };
        double double45 = org.apache.commons.math3.util.MathArrays.distance(doubleArray36, doubleArray44);
        try {
            double double46 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray34, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4478350516631948d + "'", double33 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        double double18 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        double double19 = vector1D7.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D21, (double) 30.0f, vector1D23, 0.09966370236491838d, vector1D25, (double) 100L, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D30, (double) 30.0f, vector1D32, 0.09966370236491838d, vector1D34, (double) 100L, vector1D36);
        double double38 = vector1D27.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D36.negate();
        double double40 = vector1D7.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space> spaceBoundaryAttribute2 = new org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceSubHyperplane1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) dimensionMismatchException6);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) dimensionMismatchException3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection12, false);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException14);
        boolean boolean16 = nonMonotonicSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane23 = plane21.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane33 = plane32.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D41);
        org.apache.commons.math3.geometry.partitioning.Side side44 = subPlane33.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D48, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane54 = plane53.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet55 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray56 = polygonsSet55.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane57 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane53, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double62 = vector3D61.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj67 = null;
        boolean boolean68 = vector3D66.equals(obj67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double73 = vector3D72.getDelta();
        double double74 = vector3D66.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D61.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line77 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D66, vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = plane53.intersection(line77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane21, plane43, plane53);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane23);
        org.junit.Assert.assertNotNull(subPlane33);
        org.junit.Assert.assertTrue("'" + side44 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side44.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(subPlane54);
        org.junit.Assert.assertNotNull(vector2DArray56);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.09966370236491838d + "'", double73 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNull(vector3D79);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.Space space2 = vector1D1.getSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = vector1D1.scalarMultiply((double) 100.0f);
        java.text.NumberFormat numberFormat5 = null;
        try {
            java.lang.String str6 = vector1D4.toString(numberFormat5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertNotNull(vector1D4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (-100), 2.718281828459045d, 1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6022545099258423d + "'", double3 == 1.6022545099258423d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1024.0f) + "'", float2 == (-1024.0f));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.1761977896489369d), (double) 35.0f);
        double double3 = vector3D2.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(8.949656954695495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane10 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.Side side11 = subLine9.side(euclidean2DHyperplane10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        double double9 = vector1D1.getNormInf();
        boolean boolean10 = vector1D1.isInfinite();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getDelta();
        java.lang.String str18 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D16, (double) 0.0f, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj28 = null;
        boolean boolean29 = vector3D27.equals(obj28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        java.lang.String str36 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D34.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D4, 0.09966370236491838d, vector3D16, 6.283185307179586d, vector3D27, (double) 100L, vector3D34);
        org.apache.commons.math3.geometry.Space space40 = vector3D39.getSpace();
        double double41 = vector3D39.getNorm();
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09966370236491838d + "'", double17 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{100; 1; 10}" + "'", str18.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{100; 1; 10}" + "'", str36.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(space40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.2045243279927856E12d + "'", double41 == 4.2045243279927856E12d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.7966988750916414E-8d, (java.lang.Number) 52L, (int) (short) -1, orderDirection3, false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = spaceBSPTree0.getPlus();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree3 = spaceBSPTree2.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree.LeafMerger<org.apache.commons.math3.geometry.Space> spaceLeafMerger4 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = spaceBSPTree0.merge(spaceBSPTree2, spaceLeafMerger4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(spaceBSPTree1);
        org.junit.Assert.assertNull(spaceBSPTree3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 0, (-0.99999994f), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D0.scalarMultiply((-478.5692967842504d));
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        java.lang.String str20 = vector3D8.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{100; 1; 10}" + "'", str20.equals("{100; 1; 10}"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform5 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane6 = subOrientedPoint2.applyTransform(euclidean1DTransform5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        try {
            java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList47 = subLine21.getSegments();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform24 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion25 = polyhedronsSet23.applyTransform(euclidean3DTransform24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = plane35.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double38 = vector2D37.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet39 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector40 = polygonsSet39.getBarycenter();
        double double41 = vector2D37.dotProduct(euclidean2DVector40);
        double double42 = vector2D37.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray44 = vector2D43.toArray();
        double double45 = vector2D43.getNorm();
        double double46 = vector2D43.getX();
        double double47 = vector2D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = vector2D48.getX();
        double double50 = vector2D48.getY();
        double double51 = vector2D37.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = plane36.getPointAt(vector2D37, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet54 = plane36.wholeSpace();
        boolean boolean55 = polyhedronsSet23.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double61 = vector3D60.getDelta();
        java.lang.String str62 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D56, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation64 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet65 = polyhedronsSet23.rotate(vector3D60, rotation64);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion25);
        org.junit.Assert.assertNotNull(plane36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.NEGATIVE_INFINITY + "'", double49 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.NEGATIVE_INFINITY + "'", double50 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(polyhedronsSet54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.09966370236491838d + "'", double61 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "{100; 1; 10}" + "'", str62.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(polyhedronsSet65);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.2949673E11f + "'", float2 == 4.2949673E11f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(11013.232920103323d, 4.2045243279927856E12d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.4E-45f, (java.lang.Number) 1.401298464324817E-45d, (int) 'a');
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float[] floatArray3 = new float[] { ' ', 1, 0 };
        float[] floatArray9 = new float[] { 1, 100L, (short) 0, 100L, '4' };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(floatArray3, floatArray9);
        float[] floatArray14 = new float[] { 100, 6, (short) 0 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray3, floatArray14);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList8 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet9 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray10 = polygonsSet9.getVertices();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException11 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, (java.lang.Object[]) vector2DArray10);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, (java.lang.Object[]) vector2DArray10);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) euclidean2DVector3, localizable5, (java.lang.Object[]) vector2DArray10);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2DArray10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        boolean boolean19 = vector1D18.isInfinite();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        int int3 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) dimensionMismatchException6);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) dimensionMismatchException3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection12, false);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException14);
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathIllegalStateException0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane33 = subPlane32.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane34 = subPlane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane33);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree35 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) subPlane9);
        java.lang.Object obj36 = spaceBSPTree35.getAttribute();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane33);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane34);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj22 = null;
        boolean boolean23 = vector3D21.equals(obj22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        double double29 = vector3D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line32 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D21, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane8.intersection(line32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double47 = vector3D46.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj52 = null;
        boolean boolean53 = vector3D51.equals(obj52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double58 = vector3D57.getDelta();
        double double59 = vector3D51.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D46.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        double double61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D37, vector3D51);
        double double62 = line32.getAbscissa(vector3D51);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.09966370236491838d + "'", double58 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.4478350516631948d + "'", double61 == 1.4478350516631948d);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.09966370236491838d, (double) (-1024.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1024.0d) + "'", double2 == (-1024.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (-1024.0f), 4.2045243279927856E12d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-1941080993));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(1.5474944974040916d, (double) (-100));
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = null;
        try {
            boolean boolean4 = intervalsSet2.isEmpty(euclidean1DBSPTree3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1023.6665581008151d + "'", double1 == 1023.6665581008151d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 1.07269331E9f, 0.09966370236491838d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double51 = vector3D50.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj56 = null;
        boolean boolean57 = vector3D55.equals(obj56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double62 = vector3D61.getDelta();
        double double63 = vector3D55.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D50.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        double double65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D41, vector3D55);
        double double66 = vector3D36.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet67 = polyhedronsSet28.translate(vector3D36);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree69 = polyhedronsSet67.getTree(true);
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.09966370236491838d + "'", double62 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.4478350516631948d + "'", double65 == 1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet67);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree69);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane2 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet1.intersection(euclidean3DSubHyperplane2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        boolean boolean10 = vector1D0.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math3.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-33553471), 10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(2.718281828459045d, 572.9577951308232d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-478.5692967842504d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7321143589386432d) + "'", double1 == (-1.7321143589386432d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = plane18.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane20 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane19);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane20);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable2, objArray5);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray5);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathArithmeticException7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector4 = polygonsSet3.getBarycenter();
        double double5 = vector2D1.dotProduct(euclidean2DVector4);
        double double6 = vector2D1.getNormSq();
        double double7 = vector2D1.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        boolean boolean17 = vector2D14.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D9, vector2D14, line18);
        double double20 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment22 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D1, line21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane41 = plane40.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane42 = subPlane41.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane52 = plane51.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane51);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane54 = subPlane41.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane63 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D58, vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane64 = plane63.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane65 = subPlane64.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane66 = subPlane41.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane65);
        boolean boolean67 = vector2D25.equals((java.lang.Object) subPlane41);
        try {
            double double68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D0, vector2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(subPlane41);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane42);
        org.junit.Assert.assertNotNull(subPlane52);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane54);
        org.junit.Assert.assertNotNull(subPlane64);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane65);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D42, (double) 30.0f, vector1D44, 0.09966370236491838d, vector1D46, (double) 100L, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D49, vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line19.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj57 = null;
        boolean boolean58 = vector3D56.equals(obj57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getDelta();
        double double64 = vector3D56.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D62.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D71, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D71);
        line19.reset(vector3D62, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = line19.pointAt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.09966370236491838d + "'", double63 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D80);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        boolean boolean18 = vector3D17.isNaN();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        double double9 = intervalsSet7.getSize();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 31.339299725125322d + "'", double9 == 31.339299725125322d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double double4 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray6 = vector2D5.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection10, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray6, orderDirection10, false);
        double[] doubleArray15 = new double[] {};
        int int16 = org.apache.commons.math3.util.MathUtils.hash(doubleArray15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray18 = vector3D17.toArray();
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray18);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray18, orderDirection20, true);
        double[] doubleArray23 = new double[] {};
        int int24 = org.apache.commons.math3.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray26 = vector3D25.toArray();
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray23, doubleArray26);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection28 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray26, orderDirection28, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray31 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection10, orderDirection20, orderDirection28 };
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection37 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection37, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray33, orderDirection37, false);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray31, orderDirection37, false);
        try {
            boolean boolean45 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray0, orderDirection37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(orderDirectionArray31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection37.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double2 = org.apache.commons.math3.util.Precision.round(1.5860134523134298E15d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5860134523134298E15d + "'", double2 == 1.5860134523134298E15d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6098494453571889d) + "'", double1 == (-0.6098494453571889d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9);
        try {
            org.apache.commons.math3.geometry.partitioning.Region.Location location12 = polyhedronsSet1.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math3.util.FastMath.signum(1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj22 = null;
        boolean boolean23 = vector3D21.equals(obj22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        double double29 = vector3D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line32 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D21, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane8.intersection(line32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double35 = line32.distance(vector3D34);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math3.util.FastMath.acos(4720.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = plane18.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane20 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane30 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D45, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D54, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane60 = plane59.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane61 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane59);
        boolean boolean62 = plane50.isSimilarTo(plane61);
        boolean boolean63 = plane41.isSimilarTo(plane50);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane64 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane73 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D68, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane74 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane83 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D78, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane92 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D87, vector3D91);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane93 = plane92.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane94 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane92);
        boolean boolean95 = plane83.isSimilarTo(plane94);
        boolean boolean96 = plane74.isSimilarTo(plane83);
        boolean boolean97 = plane64.isSimilarTo(plane83);
        plane31.reset(plane83);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane99 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane83);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane19);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane20);
        org.junit.Assert.assertNotNull(subPlane30);
        org.junit.Assert.assertNotNull(subPlane60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(subPlane93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane99);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D9.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double19 = vector3D18.getDelta();
        java.lang.String str20 = vector3D18.toString();
        double double21 = vector3D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        double double22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D13, vector3D14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.09966370236491838d + "'", double19 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{100; 1; 10}" + "'", str20.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 110.0d + "'", double21 == 110.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.0d + "'", double22 == 99.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 0, 0.0f, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        double double5 = vector2D3.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.negate();
        double double9 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D1, Double.POSITIVE_INFINITY, vector2D3, 2.718281828459045d, vector2D11);
        boolean boolean14 = vector2D11.isInfinite();
        boolean boolean15 = vector2D11.isNaN();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(1.5860134523134298E15d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.930067261567149E14d + "'", double2 == 7.930067261567149E14d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane47 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet50 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine51 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane47, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet50);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = subLine33.intersection(subLine51, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 0, 1.07269331E9f, 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D8.normalize();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj22 = null;
        boolean boolean23 = vector3D21.equals(obj22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        double double29 = vector3D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line32 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D21, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane8.intersection(line32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double38 = vector3D37.getDelta();
        double double39 = vector3D37.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = null;
        try {
            plane8.reset(vector3D37, vector3D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.09966370236491838d + "'", double38 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.009999666686665238d + "'", double39 == 0.009999666686665238d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-100.0d), 0.0d, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-1.7321143589386432d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-99.24284240119243d) + "'", double1 == (-99.24284240119243d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        double double5 = vector3D3.getAlpha();
        boolean boolean6 = vector3D3.isInfinite();
        double double7 = vector3D3.getNormSq();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.009999666686665238d + "'", double5 == 0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10101.0d + "'", double7 == 10101.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane3 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = orientedPoint7.copySelf();
        try {
            org.apache.commons.math3.geometry.partitioning.Side side9 = subOrientedPoint2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane3);
        org.junit.Assert.assertNotNull(orientedPoint8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(11013.232920103323d, 31.339299725125322d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.23292010332d + "'", double2 == 11013.23292010332d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(8.949656954695495d, 1023.6665581008151d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0927837451120071d + "'", double1 == 0.0927837451120071d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.9999999958776927d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double double2 = vector2D0.getNorm();
        double double3 = vector2D0.getX();
        double double4 = vector2D0.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        double double8 = vector2D6.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double10 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D9.negate();
        double double12 = vector2D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D0.add(200.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        java.lang.String str14 = vector2D13.toString();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{(Infinity); (Infinity)}" + "'", str14.equals("{(Infinity); (Infinity)}"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int2 = org.apache.commons.math3.util.FastMath.max((-100), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane28 = plane27.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane27);
        boolean boolean30 = plane18.isSimilarTo(plane29);
        boolean boolean31 = plane9.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane61 = plane60.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane60);
        boolean boolean63 = plane51.isSimilarTo(plane62);
        boolean boolean64 = plane42.isSimilarTo(plane51);
        boolean boolean65 = plane32.isSimilarTo(plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = plane32.getOrigin();
        org.junit.Assert.assertNotNull(subPlane28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(subPlane61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(vector3D66);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = orientedPoint3.wholeSpace();
        org.junit.Assert.assertNotNull(intervalsSet4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math3.util.FastMath.log10(5.240252676230739E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.280647771556916d) + "'", double1 == (-12.280647771556916d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        double double57 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D44.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line60 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D49, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double65 = vector3D64.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj70 = null;
        boolean boolean71 = vector3D69.equals(obj70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getDelta();
        double double77 = vector3D69.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D64.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line80 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D69, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = line60.intersection(line80);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D89 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D83, (double) 30.0f, vector1D85, 0.09966370236491838d, vector1D87, (double) 100L, vector1D89);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D90, vector1D91);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = line60.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double94 = line39.distance(line60);
        org.apache.commons.math3.geometry.euclidean.threed.Line line95 = line60.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Line line96 = line60.revert();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.09966370236491838d + "'", double76 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNull(vector3D81);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertNotNull(vector1D87);
        org.junit.Assert.assertNotNull(vector1D89);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line95);
        org.junit.Assert.assertNotNull(line96);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray3 = polygonsSet2.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) vector2DArray3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException8 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException11 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException8.addSuppressed((java.lang.Throwable) dimensionMismatchException11);
        mathIllegalStateException5.addSuppressed((java.lang.Throwable) dimensionMismatchException8);
        mathIllegalStateException4.addSuppressed((java.lang.Throwable) mathIllegalStateException5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException18 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException21 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException18.addSuppressed((java.lang.Throwable) dimensionMismatchException21);
        mathIllegalStateException15.addSuppressed((java.lang.Throwable) dimensionMismatchException18);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection27 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection27, false);
        mathIllegalStateException15.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException29);
        mathIllegalStateException4.addSuppressed((java.lang.Throwable) mathIllegalStateException15);
        org.junit.Assert.assertNotNull(vector2DArray3);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(0.0d, 22.124509620613694d);
        double double3 = interval2.getUpper();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.124509620613694d + "'", double3 == 22.124509620613694d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane10 = subLine9.getHyperplane();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(euclidean2DHyperplane10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.6098494453571889d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-34.94179935736104d) + "'", double1 == (-34.94179935736104d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        double double7 = vector3D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double23 = vector3D18.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        double double24 = vector3D18.getNormInf();
        double double25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D0, vector3D18);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 110.0d + "'", double7 == 110.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.2290500999999993E7d + "'", double23 == 2.2290500999999993E7d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5.240252676230739E-13d + "'", double24 == 5.240252676230739E-13d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.000000000000512d + "'", double25 == 1.000000000000512d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = null;
        try {
            double double10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D7, vector3D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 1, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 10, Double.NEGATIVE_INFINITY };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray8);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double51 = vector3D50.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj56 = null;
        boolean boolean57 = vector3D55.equals(obj56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double62 = vector3D61.getDelta();
        double double63 = vector3D55.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D50.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        double double65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D41, vector3D55);
        double double66 = vector3D36.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet67 = polyhedronsSet28.translate(vector3D36);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector68 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D36.add(euclidean3DVector68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.09966370236491838d + "'", double62 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.4478350516631948d + "'", double65 == 1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet67);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane11 = subPlane10.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane39.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane39);
        boolean boolean42 = plane30.isSimilarTo(plane41);
        boolean boolean43 = plane21.isSimilarTo(plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane30);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane45 = subPlane10.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        double double46 = subPlane10.getSize();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane11);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        double double3 = intervalsSet2.getInf();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet2.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = intervalsSet2.buildNew(euclidean1DBSPTree5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D8, true);
        boolean boolean11 = orientedPoint10.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        boolean boolean16 = intervalsSet2.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.660700274874677d + "'", double3 == 0.660700274874677d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((-1024.0f), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1024.0f + "'", float2 == 1024.0f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double3 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector5 = polygonsSet4.getBarycenter();
        double double6 = vector2D2.dotProduct(euclidean2DVector5);
        double double7 = vector2D2.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        double double12 = vector2D2.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double13 = vector2D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double15 = vector2D14.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.negate();
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D14);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector18 = null;
        try {
            double double19 = vector2D0.dotProduct(euclidean2DVector18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(31.339299725125322d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.039177082708076E13d + "'", double1 == 2.039177082708076E13d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(4.703669803527209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998357752337024d + "'", double1 == 0.9998357752337024d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = plane18.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane20 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = plane18.getOrigin();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane19);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane20);
        org.junit.Assert.assertNotNull(vector3D21);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = orientedPoint3.copySelf();
        boolean boolean16 = orientedPoint15.isDirect();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(orientedPoint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        double double3 = vector2D1.getNorm();
        double double4 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray7 = vector2D6.toArray();
        double double8 = vector2D6.getNorm();
        boolean boolean9 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment11 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D1, vector2D6, line10);
        double double12 = vector2D6.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double15 = vector2D14.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double17 = vector2D16.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet18 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector19 = polygonsSet18.getBarycenter();
        double double20 = vector2D16.dotProduct(euclidean2DVector19);
        double double21 = vector2D16.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray23 = vector2D22.toArray();
        double double24 = vector2D22.getNorm();
        double double25 = vector2D22.getX();
        double double26 = vector2D16.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        double double27 = vector2D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        double double28 = vector2D14.getX();
        double double29 = vector2D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D6, vector2D13);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray4 = vector2D3.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection8, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection8, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 100.00001f, 6, orderDirection8, false);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray4 = vector2D3.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection8, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection8, false);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray16);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray16, orderDirection18, true);
        double[] doubleArray21 = new double[] {};
        int int22 = org.apache.commons.math3.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray24 = vector3D23.toArray();
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray21, doubleArray24);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray24, orderDirection26, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray29 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection8, orderDirection18, orderDirection26 };
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray31 = vector2D30.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection35 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection35, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray31, orderDirection35, false);
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray29, orderDirection35, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 0.3796077390275217d, (int) (byte) 10, orderDirection35, false);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(orderDirectionArray29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getDelta();
        java.lang.String str18 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D16, (double) 0.0f, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj28 = null;
        boolean boolean29 = vector3D27.equals(obj28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        java.lang.String str36 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D34.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D4, 0.09966370236491838d, vector3D16, 6.283185307179586d, vector3D27, (double) 100L, vector3D34);
        org.apache.commons.math3.geometry.Space space40 = vector3D39.getSpace();
        java.text.NumberFormat numberFormat41 = null;
        try {
            java.lang.String str42 = vector3D39.toString(numberFormat41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09966370236491838d + "'", double17 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{100; 1; 10}" + "'", str18.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{100; 1; 10}" + "'", str36.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(space40);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = orientedPoint3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint19 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D17, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint20 = orientedPoint19.copySelf();
        boolean boolean21 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(orientedPoint15);
        org.junit.Assert.assertNotNull(orientedPoint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj19 = null;
        boolean boolean20 = vector3D18.equals(obj19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double25 = vector3D24.getDelta();
        double double26 = vector3D18.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D13.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line29 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double34 = vector3D33.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getDelta();
        double double46 = vector3D38.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D33.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line49 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = line29.intersection(line49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D54, vector3D58);
        double double60 = vector3D58.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = line49.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        double double62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D7, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D66, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj81 = null;
        boolean boolean82 = vector3D80.equals(obj81);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double87 = vector3D86.getDelta();
        double double88 = vector3D80.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = vector3D75.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D80);
        double double90 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D66, vector3D80);
        double[] doubleArray91 = vector3D80.toArray();
        double double92 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D7, vector3D80);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.09966370236491838d + "'", double25 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.09966370236491838d + "'", double45 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNull(vector3D50);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10101.0d + "'", double60 == 10101.0d);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.09966370236491838d + "'", double87 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.4478350516631948d + "'", double90 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        java.lang.String str6 = vector2D0.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double8 = vector2D7.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet9 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector10 = polygonsSet9.getBarycenter();
        double double11 = vector2D7.dotProduct(euclidean2DVector10);
        double double12 = vector2D7.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D7.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double19 = vector2D18.getX();
        double double20 = vector2D18.getY();
        double double21 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        boolean boolean22 = vector2D18.isNaN();
        double double23 = vector2D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str6.equals("{(-Infinity); (-Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform3 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion4 = polygonsSet1.applyTransform(euclidean2DTransform3);
        double double5 = euclidean2DAbstractRegion4.getSize();
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree3 = intervalsSet1.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane4, euclidean1DRegion5);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane7 = subOrientedPoint6.copySelf();
        double double8 = subOrientedPoint6.getSize();
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane9 = intervalsSet1.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(euclidean1DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math3.util.FastMath.log10(1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.030475546991784d + "'", double1 == 9.030475546991784d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-1.0d), (-100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.888609052210118E-31d) + "'", double2 == (-7.888609052210118E-31d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion3 = polygonsSet1.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = null;
        try {
            boolean boolean5 = polygonsSet1.isEmpty(euclidean2DBSPTree4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        double double7 = vector3D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj12 = null;
        boolean boolean13 = vector3D11.equals(obj12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double18 = vector3D17.getDelta();
        double double19 = vector3D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D0, vector3D17);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 110.0d + "'", double7 == 110.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.09966370236491838d + "'", double18 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 99.508793581271d + "'", double20 == 99.508793581271d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane23 = plane21.wholeHyperplane();
        boolean boolean24 = subPlane23.isEmpty();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = plane34.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj40 = null;
        boolean boolean41 = vector3D39.equals(obj40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        double double47 = vector3D39.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = plane35.translate(vector3D48);
        org.apache.commons.math3.geometry.partitioning.Side side51 = subPlane23.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane35);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plane35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(plane50);
        org.junit.Assert.assertTrue("'" + side51 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side51.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        java.lang.String str6 = vector2D0.toString();
        boolean boolean7 = vector2D0.isNaN();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str6.equals("{(-Infinity); (-Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector2 = polygonsSet1.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = polygonsSet1.buildNew(euclidean2DBSPTree3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree5 = null;
        try {
            boolean boolean6 = polygonsSet1.isEmpty(euclidean2DBSPTree5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DVector2);
        org.junit.Assert.assertNotNull(polygonsSet4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1023.6665581008151d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306943617238488d + "'", double1 == 9.306943617238488d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        java.text.NumberFormat numberFormat1 = null;
        try {
            java.lang.String str2 = vector1D0.toString(numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-1.0d), (double) 1.07269331E9f, 890547225);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 1, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double[] doubleArray3 = new double[] {};
        int int4 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray3);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple6 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray3);
        double[] doubleArray7 = new double[] {};
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray7);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple10 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray7);
        int int11 = orderedTuple6.compareTo(orderedTuple10);
        double[] doubleArray12 = new double[] {};
        int int13 = org.apache.commons.math3.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple15 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray12);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math3.util.MathUtils.hash(doubleArray16);
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray16);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple19 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray16);
        int int20 = orderedTuple15.compareTo(orderedTuple19);
        int int21 = orderedTuple6.compareTo(orderedTuple15);
        double[] doubleArray22 = new double[] {};
        int int23 = org.apache.commons.math3.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray22);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple25 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray22);
        double[] doubleArray26 = new double[] {};
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple29 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray26);
        int int30 = orderedTuple25.compareTo(orderedTuple29);
        double[] doubleArray31 = new double[] {};
        int int32 = org.apache.commons.math3.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray31);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple34 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray31);
        double[] doubleArray35 = new double[] {};
        int int36 = org.apache.commons.math3.util.MathUtils.hash(doubleArray35);
        double double37 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray35);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple38 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray35);
        int int39 = orderedTuple34.compareTo(orderedTuple38);
        int int40 = orderedTuple25.compareTo(orderedTuple34);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple[] orderedTupleArray41 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple[] { orderedTuple6, orderedTuple34 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection45 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection45, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection48 = nonMonotonicSequenceException47.getDirection();
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderedTupleArray41, orderDirection48, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException52 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.99822295029797d, (java.lang.Number) 100.0f, 1, orderDirection48, true);
        java.lang.Number number53 = nonMonotonicSequenceException52.getArgument();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(orderedTupleArray41);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection48.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 2.99822295029797d + "'", number53.equals(2.99822295029797d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = null;
        try {
            boolean boolean30 = plane10.isSimilarTo(plane29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-100), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(2.2250738585072014E-308d, (double) 1072693248, 0.0d, 1023.6665581008151d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.3868217043219823E-299d + "'", double4 == 2.3868217043219823E-299d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = line39.getDirection();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        double double3 = vector2D1.getNorm();
        double double4 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D5.negate();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray5 = polygonsSet4.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 1.0000000000000002d, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) vector2DArray5);
        org.junit.Assert.assertNotNull(vector2DArray5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray4 = new double[] {};
        int int5 = org.apache.commons.math3.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple7 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray4);
        int int8 = orderedTuple3.compareTo(orderedTuple7);
        double[] doubleArray9 = new double[] {};
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray9);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple12 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray9);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple16 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray13);
        int int17 = orderedTuple12.compareTo(orderedTuple16);
        int int18 = orderedTuple3.compareTo(orderedTuple12);
        double[] doubleArray19 = new double[] {};
        int int20 = org.apache.commons.math3.util.MathUtils.hash(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple22 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray19);
        double[] doubleArray23 = new double[] {};
        int int24 = org.apache.commons.math3.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray23);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple26 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray23);
        int int27 = orderedTuple22.compareTo(orderedTuple26);
        double[] doubleArray28 = new double[] {};
        int int29 = org.apache.commons.math3.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray28);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple31 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray28);
        double[] doubleArray32 = new double[] {};
        int int33 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray32);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple35 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray32);
        int int36 = orderedTuple31.compareTo(orderedTuple35);
        int int37 = orderedTuple22.compareTo(orderedTuple31);
        double[] doubleArray38 = new double[] {};
        int int39 = org.apache.commons.math3.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray38);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple41 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray38);
        int int42 = orderedTuple22.compareTo(orderedTuple41);
        int int43 = orderedTuple12.compareTo(orderedTuple41);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(99.508793581271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.50879358127101d + "'", double1 == 99.50879358127101d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D11, (double) 30.0f, vector1D13, 0.09966370236491838d, vector1D15, (double) 100L, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        double double20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D18);
        double double21 = vector1D0.getNorm();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(35.000004f, (float) (-33553471), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane47 = subLine21.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double50 = vector2D49.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double52 = vector2D51.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet53 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector54 = polygonsSet53.getBarycenter();
        double double55 = vector2D51.dotProduct(euclidean2DVector54);
        double double56 = vector2D51.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray58 = vector2D57.toArray();
        double double59 = vector2D57.getNorm();
        double double60 = vector2D57.getX();
        double double61 = vector2D51.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double62 = vector2D49.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double63 = vector2D49.getX();
        double double64 = vector2D48.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = vector2D48.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray72 = vector2D71.toArray();
        double double73 = vector2D71.getNorm();
        double double74 = vector2D71.getX();
        double double75 = vector2D71.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = line70.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane77 = subLine21.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
        org.junit.Assert.assertNull(euclidean2DHyperplane47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.NEGATIVE_INFINITY + "'", double50 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + Double.POSITIVE_INFINITY + "'", double73 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + Double.POSITIVE_INFINITY + "'", double75 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D76);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        boolean boolean7 = vector3D4.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getDelta();
        java.lang.String str15 = vector3D13.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D9, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double21 = vector3D20.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj26 = null;
        boolean boolean27 = vector3D25.equals(obj26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double32 = vector3D31.getDelta();
        double double33 = vector3D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D20.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, vector3D4, 2.7966988750916414E-8d, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = null;
        try {
            double double38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D36, vector3D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.09966370236491838d + "'", double14 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{100; 1; 10}" + "'", str15.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.09966370236491838d + "'", double32 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double12 = vector3D11.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj17 = null;
        boolean boolean18 = vector3D16.equals(obj17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double23 = vector3D22.getDelta();
        double double24 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        java.text.NumberFormat numberFormat27 = null;
        try {
            java.lang.String str28 = vector3D26.toString(numberFormat27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.09966370236491838d + "'", double23 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(4.3022336555707305E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector4 = polygonsSet3.getBarycenter();
        double double5 = vector2D1.dotProduct(euclidean2DVector4);
        double double6 = vector2D1.getNormSq();
        double double7 = vector2D1.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        boolean boolean17 = vector2D14.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D9, vector2D14, line18);
        double double20 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment22 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D1, line21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D1.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        double double26 = vector2D24.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double29 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet30 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector31 = polygonsSet30.getBarycenter();
        double double32 = vector2D28.dotProduct(euclidean2DVector31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D24.add(2.2250738585072014E-308d, euclidean2DVector31);
        double double34 = vector2D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.NEGATIVE_INFINITY + "'", double26 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray4 = polygonsSet3.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) vector2DArray4);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 52, (java.lang.Object[]) vector2DArray4);
        java.lang.Number number7 = notFiniteNumberException6.getArgument();
        java.lang.Number number8 = notFiniteNumberException6.getArgument();
        org.junit.Assert.assertNotNull(vector2DArray4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 52 + "'", number7.equals(52));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 52 + "'", number8.equals(52));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = nullArgumentException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getX();
        double double27 = vector2D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = null;
        try {
            boolean boolean30 = line22.contains(vector2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.9999999958776927d, 1.072693248E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.322329545209301E-10d + "'", double2 == 9.322329545209301E-10d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7165256995489035d + "'", double1 == 1.7165256995489035d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        double double18 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D16, true);
        java.lang.String str21 = vector1D16.toString();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity)}" + "'", str21.equals("{(Infinity)}"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane3 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        boolean boolean8 = orientedPoint7.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D10, true);
        boolean boolean13 = orientedPoint12.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet16);
        boolean boolean18 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12);
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane19 = subOrientedPoint2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getX();
        double double27 = vector2D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray31 = vector2D30.toArray();
        double double32 = vector2D30.getNorm();
        double double33 = vector2D30.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray36 = vector2D35.toArray();
        double double37 = vector2D35.getNorm();
        boolean boolean38 = vector2D35.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment40 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D30, vector2D35, line39);
        line22.translateToPoint(vector2D30);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getBoundarySize();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = orientedPoint8.wholeSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(intervalsSet15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform23 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane24 = subLine10.applyTransform(euclidean2DTransform23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double3 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector5 = polygonsSet4.getBarycenter();
        double double6 = vector2D2.dotProduct(euclidean2DVector5);
        double double7 = vector2D2.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        double double12 = vector2D2.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double13 = vector2D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        double double14 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D0.getZero();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.NEGATIVE_INFINITY + "'", double14 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double9 = vector2D8.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector11 = polygonsSet10.getBarycenter();
        double double12 = vector2D8.dotProduct(euclidean2DVector11);
        double double13 = vector2D8.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        double double17 = vector2D14.getX();
        double double18 = vector2D8.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double19 = vector2D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double20 = vector2D6.getX();
        double double21 = vector2D5.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D5.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray29 = vector2D28.toArray();
        double double30 = vector2D28.getNorm();
        double double31 = vector2D28.getX();
        double double32 = vector2D28.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = line27.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray43 = vector2D42.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray45 = vector2D44.toArray();
        double double46 = vector2D44.getNorm();
        double double47 = vector2D44.getX();
        double double48 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line49 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment50 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D42, vector2D44, line49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = segment50.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine52 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = segment50.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double60 = vector2D59.getX();
        double double61 = vector2D59.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = vector2D62.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D62.negate();
        double double65 = vector2D59.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double68 = vector2D67.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D57, Double.POSITIVE_INFINITY, vector2D59, 2.718281828459045d, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double72 = vector2D71.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = vector2D71.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = vector2D71.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray78 = vector2D77.toArray();
        double double79 = vector2D77.getNorm();
        double double80 = vector2D77.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D77);
        double double82 = vector2D77.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double85 = vector2D84.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = vector2D84.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = vector2D84.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-100), vector2D67, 1.5707963267948966d, vector2D74, (double) '#', vector2D77, (double) 890547225L, vector2D87);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D89 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.660700274874677d, vector2D28, 201.7156361224559d, vector2D40, 2.99822295029797d, vector2D53, (double) 100.00001f, vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D1, (double) 4.2949673E11f, vector2D40);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.NEGATIVE_INFINITY + "'", double68 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.NEGATIVE_INFINITY + "'", double72 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.POSITIVE_INFINITY + "'", double79 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.POSITIVE_INFINITY + "'", double80 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + Double.POSITIVE_INFINITY + "'", double82 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.NEGATIVE_INFINITY + "'", double85 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertNotNull(vector2D87);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj10 = null;
        boolean boolean11 = vector3D9.equals(obj10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getDelta();
        double double17 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double22 = vector3D21.getY();
        double double23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D9, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21);
        double double25 = vector3D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D0.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.09966370236491838d + "'", double16 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1190346870425511E-15d + "'", double1 == 1.1190346870425511E-15d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8171205928321397d + "'", double1 == 1.8171205928321397d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((-1024.0d), 1.6022545099258423d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-33553471), 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33553471 + "'", int2 == 33553471);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D46, (double) 30.0f, vector1D48, 0.09966370236491838d, vector1D50, (double) 100L, vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D53, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D0.add(110.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D59, (double) 30.0f, vector1D61, 0.09966370236491838d, vector1D63, (double) 100L, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D68, (double) 30.0f, vector1D70, 0.09966370236491838d, vector1D72, (double) 100L, vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = vector1D65.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D75);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = vector1D56.add((-0.6098494453571889d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D75);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertNotNull(vector1D77);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        double double6 = vector2D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        boolean boolean16 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment18 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D8, vector2D13, line17);
        double double19 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 0, (float) (short) 0, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(2.7966988750916414E-8d, (-0.6098494453571889d), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 402.4287934927351d + "'", double1 == 402.4287934927351d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        float float1 = org.apache.commons.math3.util.FastMath.abs(30.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 30.0f + "'", float1 == 30.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double58 = vector2D57.getX();
        double double59 = vector2D57.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double61 = vector2D60.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D60.negate();
        double double63 = vector2D57.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double66 = vector2D65.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D55, Double.POSITIVE_INFINITY, vector2D57, 2.718281828459045d, vector2D65);
        line45.reset(vector2D53, vector2D65);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.NEGATIVE_INFINITY + "'", double58 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.NEGATIVE_INFINITY + "'", double66 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int8 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray16 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray9, intArray16);
        try {
            int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double15 = vector2D14.getX();
        double double16 = vector2D14.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double18 = vector2D17.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.negate();
        double double20 = vector2D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D12, Double.POSITIVE_INFINITY, vector2D14, 2.718281828459045d, vector2D22);
        boolean boolean25 = vector2D22.isInfinite();
        boolean boolean27 = vector2D22.equals((java.lang.Object) true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = vector2D29.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector32 = polygonsSet31.getBarycenter();
        double double33 = vector2D29.dotProduct(euclidean2DVector32);
        double double34 = vector2D29.getNormSq();
        double double35 = vector2D29.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double43 = vector2D42.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double45 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet46 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector47 = polygonsSet46.getBarycenter();
        double double48 = vector2D44.dotProduct(euclidean2DVector47);
        double double49 = vector2D44.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray51 = vector2D50.toArray();
        double double52 = vector2D50.getNorm();
        double double53 = vector2D50.getX();
        double double54 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        double double55 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double56 = vector2D42.getX();
        double double57 = vector2D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(10101.0d, vector2D22, 11013.232920103323d, vector2D29, Double.NEGATIVE_INFINITY, vector2D39, 1.0d, vector2D42);
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = vector2D39.scalarMultiply((-7.888609052210118E-31d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = vector2D62.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet64 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector65 = polygonsSet64.getBarycenter();
        double double66 = vector2D62.dotProduct(euclidean2DVector65);
        double double67 = vector2D61.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.NEGATIVE_INFINITY + "'", double56 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.POSITIVE_INFINITY + "'", double67 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane21 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane22 = subPlane21.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D45, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane51 = plane50.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane52 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane50);
        boolean boolean53 = plane41.isSimilarTo(plane52);
        boolean boolean54 = plane32.isSimilarTo(plane41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane41);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane56 = subPlane21.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = plane41.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = plane41.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = plane41.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = plane41.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = plane41.getU();
        org.apache.commons.math3.geometry.euclidean.threed.Line line62 = plane9.intersection(plane41);
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(subPlane21);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane56);
        org.junit.Assert.assertNotNull(plane57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNull(line62);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform3 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion4 = polygonsSet1.applyTransform(euclidean2DTransform3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree6 = euclidean2DAbstractRegion4.getTree(false);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion7 = euclidean2DAbstractRegion4.copySelf();
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion4);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree6);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion7);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.Space space1 = vector3D0.getSpace();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isNaN();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(space1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = subOrientedPoint2.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = orientedPoint8.copySelf();
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane11 = subOrientedPoint2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(orientedPoint10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray5 = polygonsSet4.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform6 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion7 = polygonsSet4.applyTransform(euclidean2DTransform6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree9 = euclidean2DAbstractRegion7.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree9);
        boolean boolean11 = polygonsSet1.isEmpty(euclidean2DBSPTree9);
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(vector2DArray5);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion7);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        double double57 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D44.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line60 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D49, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double65 = vector3D64.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj70 = null;
        boolean boolean71 = vector3D69.equals(obj70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getDelta();
        double double77 = vector3D69.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D64.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line80 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D69, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = line60.intersection(line80);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D89 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D83, (double) 30.0f, vector1D85, 0.09966370236491838d, vector1D87, (double) 100L, vector1D89);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D90, vector1D91);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = line60.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double94 = line39.distance(line60);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector95 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D96 = line39.toSubSpace(euclidean3DVector95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.09966370236491838d + "'", double76 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNull(vector3D81);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertNotNull(vector1D87);
        org.junit.Assert.assertNotNull(vector1D89);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D46, (double) 30.0f, vector1D48, 0.09966370236491838d, vector1D50, (double) 100L, vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D53, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D0.add(110.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        double double57 = vector1D56.getNorm1();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.POSITIVE_INFINITY + "'", double57 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, 99.508793581271d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double26 = vector3D25.getDelta();
        java.lang.String str27 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D21, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double34 = vector3D33.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getDelta();
        double double46 = vector3D38.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D33.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D29, vector3D38);
        plane19.reset(vector3D28, vector3D29);
        double double50 = vector3D29.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        double double78 = vector3D77.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double83 = vector3D82.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj88 = null;
        boolean boolean89 = vector3D87.equals(obj88);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double94 = vector3D93.getDelta();
        double double95 = vector3D87.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D93);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D96 = vector3D82.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D97 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D77, vector3D96);
        double double98 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D29, vector3D96);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.09966370236491838d + "'", double26 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{100; 1; 10}" + "'", str27.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.09966370236491838d + "'", double45 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 99.0d + "'", double48 == 99.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 200.0d + "'", double78 == 200.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.09966370236491838d + "'", double94 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D96);
        org.junit.Assert.assertNotNull(vector3D97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector4 = polygonsSet3.getBarycenter();
        double double5 = vector2D1.dotProduct(euclidean2DVector4);
        double double6 = vector2D1.getNormSq();
        double double7 = vector2D1.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        boolean boolean17 = vector2D14.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D9, vector2D14, line18);
        double double20 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment22 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D1, line21);
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D1.toString(numberFormat23);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str24.equals("{(-Infinity); (-Infinity)}"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int[] intArray1 = new int[] { 0 };
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        int[] intArray3 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), 100.00001f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.Space space2 = vector2D0.getSpace();
        boolean boolean3 = vector2D0.isNaN();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double15 = vector2D14.getX();
        double double16 = vector2D14.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double18 = vector2D17.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.negate();
        double double20 = vector2D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D12, Double.POSITIVE_INFINITY, vector2D14, 2.718281828459045d, vector2D22);
        boolean boolean25 = vector2D22.isInfinite();
        boolean boolean27 = vector2D22.equals((java.lang.Object) true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = vector2D29.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector32 = polygonsSet31.getBarycenter();
        double double33 = vector2D29.dotProduct(euclidean2DVector32);
        double double34 = vector2D29.getNormSq();
        double double35 = vector2D29.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double43 = vector2D42.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double45 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet46 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector47 = polygonsSet46.getBarycenter();
        double double48 = vector2D44.dotProduct(euclidean2DVector47);
        double double49 = vector2D44.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray51 = vector2D50.toArray();
        double double52 = vector2D50.getNorm();
        double double53 = vector2D50.getX();
        double double54 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        double double55 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double56 = vector2D42.getX();
        double double57 = vector2D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(10101.0d, vector2D22, 11013.232920103323d, vector2D29, Double.NEGATIVE_INFINITY, vector2D39, 1.0d, vector2D42);
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = vector2D39.scalarMultiply((-7.888609052210118E-31d));
        org.apache.commons.math3.geometry.Space space62 = vector2D61.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.NEGATIVE_INFINITY + "'", double56 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(space62);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        double double11 = euclidean3DAbstractSubHyperplane10.getSize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane21 = plane20.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane22 = subPlane21.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane31);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane34 = subPlane21.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane44 = plane43.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane45 = subPlane44.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane46 = subPlane21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane45);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree47 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) subPlane21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D50, (double) 30.0f, vector1D52, 0.09966370236491838d, vector1D54, (double) 100L, vector1D56);
        double double58 = vector1D48.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane67 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D62, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane68 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane77 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D72, vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane86 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D81, vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane87 = plane86.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane88 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane86);
        boolean boolean89 = plane77.isSimilarTo(plane88);
        boolean boolean90 = plane68.isSimilarTo(plane77);
        boolean boolean91 = vector1D48.equals((java.lang.Object) plane77);
        org.apache.commons.math3.geometry.partitioning.Side side92 = subPlane21.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane77);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane93 = euclidean3DAbstractSubHyperplane10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane21);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(subPlane21);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane34);
        org.junit.Assert.assertNotNull(subPlane44);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + side92 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side92.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane93);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.99999f + "'", float2 == 99.99999f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray3, orderDirection5, true);
        double double8 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray3);
        double[] doubleArray9 = null;
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray3, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 10L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(100.0d, 9.0d, 4.703669803527209d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        double double13 = polygonsSet10.getSize();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        double double53 = line45.getAngle();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.7853981633974483d + "'", double53 == 0.7853981633974483d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.401298464324817E-45d + "'", double1 == 1.401298464324817E-45d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 1);
        int int6 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (-1L), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane21 = subPlane20.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane30.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane30);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane33 = subPlane20.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane43 = plane42.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane44 = subPlane43.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane45 = subPlane20.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane44);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree46 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) subPlane20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D49, (double) 30.0f, vector1D51, 0.09966370236491838d, vector1D53, (double) 100L, vector1D55);
        double double57 = vector1D47.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D61, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane67 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D71, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane85 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D80, vector3D84);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane86 = plane85.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane87 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane85);
        boolean boolean88 = plane76.isSimilarTo(plane87);
        boolean boolean89 = plane67.isSimilarTo(plane76);
        boolean boolean90 = vector1D47.equals((java.lang.Object) plane76);
        org.apache.commons.math3.geometry.partitioning.Side side91 = subPlane20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane76);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane92 = subPlane10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane20);
        boolean boolean93 = subPlane20.isEmpty();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane21);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane33);
        org.junit.Assert.assertNotNull(subPlane43);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane44);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + side91 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side91.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math3.util.FastMath.signum(8.949656954695495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        double double2 = vector2D0.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double5 = vector2D4.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector7 = polygonsSet6.getBarycenter();
        double double8 = vector2D4.dotProduct(euclidean2DVector7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D0.add(2.2250738585072014E-308d, euclidean2DVector7);
        double double10 = vector2D0.getX();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.000000000000512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348158455d + "'", double1 == 1.5430806348158455d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) 1072693248, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        double[] doubleArray9 = vector2D2.toArray();
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (∞ >= ∞)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree3 = spaceBSPTree2.getParent();
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree1, spaceBSPTree3, (java.lang.Object) 1.000000000000512d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(spaceBSPTree3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        java.lang.Class<?> wildcardClass11 = subLine10.getClass();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double14 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double16 = vector2D15.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet17 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector18 = polygonsSet17.getBarycenter();
        double double19 = vector2D15.dotProduct(euclidean2DVector18);
        double double20 = vector2D15.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray22 = vector2D21.toArray();
        double double23 = vector2D21.getNorm();
        double double24 = vector2D21.getX();
        double double25 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double26 = vector2D13.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double27 = vector2D13.getX();
        double double28 = vector2D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D12.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray36 = vector2D35.toArray();
        double double37 = vector2D35.getNorm();
        double double38 = vector2D35.getX();
        double double39 = vector2D35.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = line34.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double43 = vector2D42.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double45 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet46 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector47 = polygonsSet46.getBarycenter();
        double double48 = vector2D44.dotProduct(euclidean2DVector47);
        double double49 = vector2D44.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray51 = vector2D50.toArray();
        double double52 = vector2D50.getNorm();
        double double53 = vector2D50.getX();
        double double54 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        double double55 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double56 = vector2D42.getX();
        double double57 = vector2D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = vector2D41.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line63 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double66 = vector2D65.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double68 = vector2D67.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet69 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector70 = polygonsSet69.getBarycenter();
        double double71 = vector2D67.dotProduct(euclidean2DVector70);
        double double72 = vector2D67.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray74 = vector2D73.toArray();
        double double75 = vector2D73.getNorm();
        double double76 = vector2D73.getX();
        double double77 = vector2D67.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        double double78 = vector2D65.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double79 = vector2D65.getX();
        double double80 = vector2D64.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D64.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line86 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D64, vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray88 = vector2D87.toArray();
        double double89 = vector2D87.getNorm();
        double double90 = vector2D87.getX();
        double double91 = vector2D87.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = line86.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        boolean boolean93 = line63.isParallelTo(line86);
        boolean boolean94 = line34.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line63);
        try {
            org.apache.commons.math3.geometry.partitioning.Side side95 = subLine10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.NEGATIVE_INFINITY + "'", double14 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.NEGATIVE_INFINITY + "'", double56 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.NEGATIVE_INFINITY + "'", double66 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.NEGATIVE_INFINITY + "'", double68 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector70);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.POSITIVE_INFINITY + "'", double72 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + Double.POSITIVE_INFINITY + "'", double75 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + Double.POSITIVE_INFINITY + "'", double76 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + Double.POSITIVE_INFINITY + "'", double77 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.NEGATIVE_INFINITY + "'", double79 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + Double.POSITIVE_INFINITY + "'", double89 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + Double.POSITIVE_INFINITY + "'", double90 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + Double.POSITIVE_INFINITY + "'", double91 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        double[] doubleArray9 = vector2D2.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double11 = vector2D10.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.negate();
        double[] doubleArray13 = vector2D12.toArray();
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray13);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D11, (double) 30.0f, vector1D13, 0.09966370236491838d, vector1D15, (double) 100L, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D27, (double) 30.0f, vector1D29, 0.09966370236491838d, vector1D31, (double) 100L, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D37, (double) 30.0f, vector1D39, 0.09966370236491838d, vector1D41, (double) 100L, vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D46, (double) 30.0f, vector1D48, 0.09966370236491838d, vector1D50, (double) 100L, vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D22, 1.0d, vector1D24, 1.4478350516631948d, vector1D33, 4720.0d, vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D60, (double) 30.0f, vector1D62, 0.09966370236491838d, vector1D64, (double) 100L, vector1D66);
        double double68 = vector1D58.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D18.add((double) 35.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D69);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = subOrientedPoint2.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane5 = subOrientedPoint2.copySelf();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane4);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D3, (double) 30.0f, vector1D5, 0.09966370236491838d, vector1D7, (double) 100L, vector1D9);
        double double11 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        java.text.NumberFormat numberFormat12 = null;
        java.lang.String str13 = vector1D10.toString(numberFormat12);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{(NaN)}" + "'", str13.equals("{(NaN)}"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math3.util.FastMath.sin((-1.0000000000000002d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078966d) + "'", double1 == (-0.8414709848078966d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 0L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj10 = null;
        boolean boolean11 = vector3D9.equals(obj10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getDelta();
        double double17 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D4.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D9, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double25 = vector3D24.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj30 = null;
        boolean boolean31 = vector3D29.equals(obj30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double36 = vector3D35.getDelta();
        double double37 = vector3D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D24.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = line20.intersection(line40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D43, (double) 30.0f, vector1D45, 0.09966370236491838d, vector1D47, (double) 100L, vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D50, vector1D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = line20.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj58 = null;
        boolean boolean59 = vector3D57.equals(obj58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double64 = vector3D63.getDelta();
        double double65 = vector3D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D63.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane77 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D72, vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D72);
        line20.reset(vector3D63, vector3D72);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane80 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.09966370236491838d + "'", double16 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.09966370236491838d + "'", double36 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNull(vector3D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.09966370236491838d + "'", double64 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = orientedPoint3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        double double17 = vector1D16.getNorm1();
        boolean boolean18 = vector1D16.isNaN();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(orientedPoint15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        java.lang.String str5 = vector3D3.toString();
        boolean boolean6 = vector3D3.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{100; 1; 10}" + "'", str5.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.1368683772161603E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000001137d + "'", double1 == 1.0000000000001137d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.geometry.partitioning.Side side0 = org.apache.commons.math3.geometry.partitioning.Side.BOTH;
        org.junit.Assert.assertTrue("'" + side0 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side0.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet7.buildNew(euclidean1DBSPTree9);
        try {
            double double11 = intervalsSet10.getInf();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intervalsSet10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane9);
        plane11.revertSelf();
        org.junit.Assert.assertNotNull(plane10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree13 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet14 = polygonsSet10.buildNew(euclidean2DBSPTree13);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree16 = polygonsSet10.getTree(false);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertNotNull(polygonsSet14);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree16);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.6022545099258423d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double double22 = plane19.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane19.getOrigin();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9949879346007117d + "'", double22 == 0.9949879346007117d);
        org.junit.Assert.assertNotNull(vector3D23);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double37 = vector3D36.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30, vector3D36);
        double double39 = plane21.getOffset(plane38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = plane38.getV();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.09966370236491838d + "'", double37 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-478.5692967842504d) + "'", double39 == (-478.5692967842504d));
        org.junit.Assert.assertNotNull(vector3D40);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        float float2 = org.apache.commons.math3.util.FastMath.max(30.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.5440211108893698d), (double) 52, (double) 100L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((-1.0000000000000002d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080634815244d + "'", double1 == 1.543080634815244d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        java.lang.String str18 = vector3D3.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{100; 1; 10}" + "'", str18.equals("{100; 1; 10}"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) ' ', (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = line20.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double37 = vector3D36.getDelta();
        java.lang.String str38 = vector3D36.toString();
        boolean boolean39 = vector3D36.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double53 = vector3D52.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj58 = null;
        boolean boolean59 = vector3D57.equals(obj58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double64 = vector3D63.getDelta();
        double double65 = vector3D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D52.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D45.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D36.subtract((double) (byte) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        try {
            line21.reset(vector3D22, vector3D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(line20);
        org.junit.Assert.assertNotNull(line21);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.09966370236491838d + "'", double37 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{100; 1; 10}" + "'", str38.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.09966370236491838d + "'", double64 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        double double2 = vector2D0.getY();
        double double3 = vector2D0.getNorm1();
        org.apache.commons.math3.geometry.Space space4 = vector2D0.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(space4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection5, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection5, false);
        double[] doubleArray10 = new double[] {};
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray10);
        double[] doubleArray14 = new double[] {};
        int int15 = org.apache.commons.math3.util.MathUtils.hash(doubleArray14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray17 = vector2D16.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection21, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray17, orderDirection21, false);
        int int26 = org.apache.commons.math3.util.MathUtils.hash(doubleArray17);
        double double27 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray14, doubleArray17);
        try {
            double double28 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray1, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-33553471) + "'", int26 == (-33553471));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (short) 10, 1.4478350516631948d, 4720.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2552581120362447d + "'", double3 == 1.2552581120362447d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (-33553471), (int) 'a');
    }
}

