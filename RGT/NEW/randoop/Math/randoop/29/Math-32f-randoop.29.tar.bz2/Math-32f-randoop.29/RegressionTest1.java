import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj10 = null;
        boolean boolean11 = vector3D9.equals(obj10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getDelta();
        double double17 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D4.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D0, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj24 = null;
        boolean boolean25 = vector3D23.equals(obj24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        double double31 = vector3D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double36 = vector3D35.getY();
        double double37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D23, vector3D35);
        double double38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D0, vector3D23);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.09966370236491838d + "'", double16 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 99.0d + "'", double19 == 99.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.0d + "'", double38 == 99.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane33 = subPlane32.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane34 = subPlane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane33);
        double double35 = euclidean3DAbstractSubHyperplane33.getSize();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane33);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 52L, (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane22 = plane21.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.partitioning.Side side33 = subPlane22.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane32);
        org.apache.commons.math3.geometry.partitioning.Side side34 = subPlane12.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane32);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertNotNull(subPlane22);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + side34 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side34.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray11 = polygonsSet10.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet10);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList13 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet14 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray15 = polygonsSet14.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion17 = polygonsSet14.applyTransform(euclidean2DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree19 = euclidean2DAbstractRegion17.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet20 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree19);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet21 = polygonsSet10.buildNew(euclidean2DBSPTree19);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector2DArray11);
        org.junit.Assert.assertNotNull(vector2DArray15);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion17);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree19);
        org.junit.Assert.assertNotNull(polygonsSet21);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.util.MathUtils.checkFinite(9.306943617238488d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = plane37.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane39 = subPlane38.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane48 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane49 = plane48.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane48);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane51 = subPlane38.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane50);
        boolean boolean52 = plane10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane50);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet53 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57, vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation63 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet64 = polyhedronsSet53.rotate(vector3D61, rotation63);
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
        org.junit.Assert.assertNotNull(subPlane38);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane39);
        org.junit.Assert.assertNotNull(subPlane49);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(polyhedronsSet53);
        org.junit.Assert.assertNotNull(polyhedronsSet64);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = orientedPoint3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = orientedPoint8.copySelf();
        boolean boolean11 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = orientedPoint8.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.Space space15 = vector1D14.getSpace();
        java.lang.String str16 = vector1D14.toString();
        double double17 = vector1D12.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.junit.Assert.assertNotNull(orientedPoint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(orientedPoint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(space15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{35}" + "'", str16.equals("{35}"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray3 = new double[] {};
        int int4 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray3);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane47 = subLine21.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform48 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane49 = subLine21.applyTransform(euclidean2DTransform48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
        org.junit.Assert.assertNull(euclidean2DHyperplane47);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection5, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection5, false);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (∞ >= ∞)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-33553471) + "'", int10 == (-33553471));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet28 = plane10.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = plane37.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet39 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray40 = polygonsSet39.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane41 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane37, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj51 = null;
        boolean boolean52 = vector3D50.equals(obj51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double57 = vector3D56.getDelta();
        double double58 = vector3D50.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D45.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line61 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D50, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = plane37.intersection(line61);
        plane10.reset(plane37);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane64 = plane10.copySelf();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(polyhedronsSet28);
        org.junit.Assert.assertNotNull(subPlane38);
        org.junit.Assert.assertNotNull(vector2DArray40);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.09966370236491838d + "'", double57 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(plane64);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 341642467 + "'", int1 == 341642467);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 33553471, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33553471L + "'", long2 == 33553471L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane18 = plane17.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane17);
        boolean boolean20 = plane8.isSimilarTo(plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane30 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray32 = polygonsSet31.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane33 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane29, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet31);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree34 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet35 = polygonsSet31.buildNew(euclidean2DBSPTree34);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane36 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet31);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion37 = polygonsSet31.copySelf();
        org.junit.Assert.assertNotNull(subPlane18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(subPlane30);
        org.junit.Assert.assertNotNull(vector2DArray32);
        org.junit.Assert.assertNotNull(polygonsSet35);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion37);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D4);
        java.text.NumberFormat numberFormat11 = null;
        try {
            java.lang.String str12 = vector3D4.toString(numberFormat11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane11 = subPlane10.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane39.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane39);
        boolean boolean42 = plane30.isSimilarTo(plane41);
        boolean boolean43 = plane21.isSimilarTo(plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane30);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane45 = subPlane10.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = plane30.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D50, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double60 = vector3D59.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj65 = null;
        boolean boolean66 = vector3D64.equals(obj65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double71 = vector3D70.getDelta();
        double double72 = vector3D64.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D59.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D64);
        double double74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D50, vector3D64);
        boolean boolean75 = plane46.contains(vector3D50);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane11);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane45);
        org.junit.Assert.assertNotNull(plane46);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.09966370236491838d + "'", double71 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.4478350516631948d + "'", double74 == 1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        java.lang.String str5 = vector3D3.toString();
        boolean boolean6 = vector3D3.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double13 = vector3D12.getDelta();
        java.lang.String str14 = vector3D12.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D8, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double20 = vector3D19.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj25 = null;
        boolean boolean26 = vector3D24.equals(obj25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double31 = vector3D30.getDelta();
        double double32 = vector3D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D19.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D3.subtract((double) (byte) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        java.lang.String str36 = vector3D35.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{100; 1; 10}" + "'", str5.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.09966370236491838d + "'", double13 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{100; 1; 10}" + "'", str14.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.09966370236491838d + "'", double31 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{100; 1; 10}" + "'", str36.equals("{100; 1; 10}"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection5, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection5, false);
        double[] doubleArray10 = new double[] {};
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection14 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        try {
            boolean boolean17 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray10, orderDirection14, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet0 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray1 = polygonsSet0.getVertices();
        boolean boolean2 = polygonsSet0.isEmpty();
        org.junit.Assert.assertNotNull(vector2DArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math3.util.FastMath.floor(4.2045243279927856E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.204524327992E12d + "'", double1 == 4.204524327992E12d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getX();
        double double27 = vector2D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector29 = null;
        try {
            double double30 = vector1D28.distance1(euclidean1DVector29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D19, (double) 30.0f, vector1D21, 0.09966370236491838d, vector1D23, (double) 100L, vector1D25);
        double double27 = vector1D16.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D25.negate();
        double double29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D3, vector1D25);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = segment8.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane12 = subLine11.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        double double17 = vector2D15.getNorm();
        double double18 = vector2D15.getX();
        double double19 = vector2D15.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment21 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D13, vector2D15, line20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = segment21.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = subLine23.getHyperplane();
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = subLine11.intersection(subLine23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNull(euclidean2DHyperplane12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNull(euclidean2DHyperplane24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double15 = vector2D14.getX();
        double double16 = vector2D14.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double18 = vector2D17.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.negate();
        double double20 = vector2D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D12, Double.POSITIVE_INFINITY, vector2D14, 2.718281828459045d, vector2D22);
        boolean boolean25 = vector2D22.isInfinite();
        boolean boolean27 = vector2D22.equals((java.lang.Object) true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = vector2D29.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector32 = polygonsSet31.getBarycenter();
        double double33 = vector2D29.dotProduct(euclidean2DVector32);
        double double34 = vector2D29.getNormSq();
        double double35 = vector2D29.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double43 = vector2D42.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double45 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet46 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector47 = polygonsSet46.getBarycenter();
        double double48 = vector2D44.dotProduct(euclidean2DVector47);
        double double49 = vector2D44.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray51 = vector2D50.toArray();
        double double52 = vector2D50.getNorm();
        double double53 = vector2D50.getX();
        double double54 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        double double55 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double56 = vector2D42.getX();
        double double57 = vector2D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(10101.0d, vector2D22, 11013.232920103323d, vector2D29, Double.NEGATIVE_INFINITY, vector2D39, 1.0d, vector2D42);
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double61 = vector2D60.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet62 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector63 = polygonsSet62.getBarycenter();
        double double64 = vector2D60.dotProduct(euclidean2DVector63);
        double double65 = vector2D60.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray67 = vector2D66.toArray();
        double double68 = vector2D66.getNorm();
        double double69 = vector2D66.getX();
        double double70 = vector2D60.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray72 = vector2D71.toArray();
        double double73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D60, vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = vector2D9.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray76 = vector2D75.toArray();
        double double77 = vector2D75.getNorm();
        double double78 = vector2D75.getX();
        double double79 = vector2D75.getNorm();
        double double80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D75);
        org.apache.commons.math3.geometry.Space space81 = vector2D75.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.NEGATIVE_INFINITY + "'", double56 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.POSITIVE_INFINITY + "'", double68 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + Double.POSITIVE_INFINITY + "'", double73 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + Double.POSITIVE_INFINITY + "'", double77 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.POSITIVE_INFINITY + "'", double79 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space81);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double12 = vector3D11.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj17 = null;
        boolean boolean18 = vector3D16.equals(obj17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double23 = vector3D22.getDelta();
        double double24 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane36 = plane35.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane37 = plane35.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D41, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane47 = plane46.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane56 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55);
        org.apache.commons.math3.geometry.partitioning.Side side58 = subPlane47.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double64 = vector3D63.getDelta();
        java.lang.String str65 = vector3D63.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D59, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double72 = vector3D71.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj77 = null;
        boolean boolean78 = vector3D76.equals(obj77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double83 = vector3D82.getDelta();
        double double84 = vector3D76.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D71.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        double double86 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D67, vector3D76);
        plane57.reset(vector3D66, vector3D67);
        org.apache.commons.math3.geometry.partitioning.Side side88 = subPlane37.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double93 = vector3D92.getDelta();
        java.lang.String str94 = vector3D92.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D96 = vector3D92.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane97 = plane57.translate(vector3D96);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D98 = plane57.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D99 = vector3D4.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D98);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.09966370236491838d + "'", double23 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(subPlane36);
        org.junit.Assert.assertNotNull(subPlane37);
        org.junit.Assert.assertNotNull(subPlane47);
        org.junit.Assert.assertTrue("'" + side58 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side58.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.09966370236491838d + "'", double64 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{100; 1; 10}" + "'", str65.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.09966370236491838d + "'", double83 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 99.0d + "'", double86 == 99.0d);
        org.junit.Assert.assertTrue("'" + side88 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side88.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.09966370236491838d + "'", double93 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "{100; 1; 10}" + "'", str94.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D96);
        org.junit.Assert.assertNotNull(plane97);
        org.junit.Assert.assertNotNull(vector3D98);
        org.junit.Assert.assertNotNull(vector3D99);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        double double3 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray1);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        double[] doubleArray8 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[] doubleArray11 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[] doubleArray14 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[] doubleArray17 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[] doubleArray20 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[] doubleArray23 = new double[] { 2.718281828459045d, 402.4287934927351d };
        double[][] doubleArray24 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17, doubleArray20, doubleArray23 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray1, doubleArray24);
        org.apache.commons.math3.exception.MathInternalError mathInternalError26 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.5403023058681398d, 9.030475546991784d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.030475546991784d + "'", double2 == 9.030475546991784d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D18.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D21, (double) 30.0f, vector1D23, 0.09966370236491838d, vector1D25, (double) 100L, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D30, (double) 30.0f, vector1D32, 0.09966370236491838d, vector1D34, (double) 100L, vector1D36);
        double double38 = vector1D27.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D36.negate();
        double double40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D19, vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D19.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D44, (double) 30.0f, vector1D46, 0.09966370236491838d, vector1D48, (double) 100L, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D53, (double) 30.0f, vector1D55, 0.09966370236491838d, vector1D57, (double) 100L, vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = vector1D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D42.getZero();
        double double64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D41, vector1D63);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane33 = subPlane32.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane34 = subPlane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane33);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree35 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) subPlane9);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane36 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform37 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane38 = euclidean3DAbstractSubHyperplane36.applyTransform(euclidean3DTransform37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane33);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane34);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane36);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        boolean boolean11 = subPlane9.isEmpty();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion3 = subOrientedPoint2.getRemainingRegion();
        double double4 = subOrientedPoint2.getSize();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) subOrientedPoint2);
        org.junit.Assert.assertNull(euclidean1DRegion3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        java.lang.String str29 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27, (double) 0.0f, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D15, 0.09966370236491838d, vector3D27, 6.283185307179586d, vector3D38, (double) 100L, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        plane9.reset(vector3D45, vector3D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double80 = vector2D79.getX();
        double double81 = vector2D79.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double83 = vector2D82.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D82.negate();
        double double85 = vector2D79.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane9.getPointAt(vector2D79, (double) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Line line88 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = plane9.intersection(line88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{100; 1; 10}" + "'", str29.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.NEGATIVE_INFINITY + "'", double80 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.NEGATIVE_INFINITY + "'", double81 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + Double.NEGATIVE_INFINITY + "'", double83 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D87);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.5403023058681398d, 0.9999999958776927d);
        double double3 = vector3D2.getY();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2779289460922468d + "'", double3 == 0.2779289460922468d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        double double18 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D20, (double) 30.0f, vector1D22, 0.09966370236491838d, vector1D24, (double) 100L, vector1D26);
        double double28 = vector1D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D35, (double) 30.0f, vector1D37, 0.09966370236491838d, vector1D39, (double) 100L, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D45, (double) 30.0f, vector1D47, 0.09966370236491838d, vector1D49, (double) 100L, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D54, (double) 30.0f, vector1D56, 0.09966370236491838d, vector1D58, (double) 100L, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D30, 1.0d, vector1D32, 1.4478350516631948d, vector1D41, 4720.0d, vector1D61);
        double double64 = vector1D7.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1941080993), (float) 890547225L, (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = plane32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double35 = vector2D34.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet36 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector37 = polygonsSet36.getBarycenter();
        double double38 = vector2D34.dotProduct(euclidean2DVector37);
        double double39 = vector2D34.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray41 = vector2D40.toArray();
        double double42 = vector2D40.getNorm();
        double double43 = vector2D40.getX();
        double double44 = vector2D34.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double46 = vector2D45.getX();
        double double47 = vector2D45.getY();
        double double48 = vector2D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = plane33.getPointAt(vector2D34, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double52 = vector2D51.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet53 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector54 = polygonsSet53.getBarycenter();
        double double55 = vector2D51.dotProduct(euclidean2DVector54);
        double double56 = vector2D51.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray58 = vector2D57.toArray();
        double double59 = vector2D57.getNorm();
        double double60 = vector2D57.getX();
        double double61 = vector2D51.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = vector2D62.getX();
        double double64 = vector2D62.getY();
        double double65 = vector2D51.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        double double66 = vector2D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D34.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double70 = vector2D69.getX();
        double double71 = vector2D69.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double74 = vector2D73.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet75 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector76 = polygonsSet75.getBarycenter();
        double double77 = vector2D73.dotProduct(euclidean2DVector76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D69.add(2.2250738585072014E-308d, euclidean2DVector76);
        double double79 = vector2D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(plane33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.NEGATIVE_INFINITY + "'", double47 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.NEGATIVE_INFINITY + "'", double64 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.NEGATIVE_INFINITY + "'", double70 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.NEGATIVE_INFINITY + "'", double71 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.NEGATIVE_INFINITY + "'", double74 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (-33553471));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getDelta();
        java.lang.String str18 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D16, (double) 0.0f, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj28 = null;
        boolean boolean29 = vector3D27.equals(obj28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        java.lang.String str36 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D34.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D4, 0.09966370236491838d, vector3D16, 6.283185307179586d, vector3D27, (double) 100L, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj44 = null;
        boolean boolean45 = vector3D43.equals(obj44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double50 = vector3D49.getDelta();
        double double51 = vector3D43.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getY();
        double double57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D43, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D55.scalarMultiply(0.0d);
        double double60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D39, vector3D59);
        double double61 = vector3D59.getNorm1();
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09966370236491838d + "'", double17 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{100; 1; 10}" + "'", str18.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{100; 1; 10}" + "'", str36.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.09966370236491838d + "'", double50 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 4.3022336555707305E12d + "'", double60 == 4.3022336555707305E12d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane18 = plane17.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane17);
        boolean boolean20 = plane8.isSimilarTo(plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane30 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane32 = subPlane31.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane61 = plane60.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane60);
        boolean boolean63 = plane51.isSimilarTo(plane62);
        boolean boolean64 = plane42.isSimilarTo(plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane65 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane51);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane66 = subPlane31.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane51);
        boolean boolean67 = plane8.isSimilarTo(plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D71, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double81 = vector3D80.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj86 = null;
        boolean boolean87 = vector3D85.equals(obj86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double92 = vector3D91.getDelta();
        double double93 = vector3D85.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D91);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D94 = vector3D80.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D85);
        double double95 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D71, vector3D85);
        double[] doubleArray96 = vector3D85.toArray();
        double double97 = plane51.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D98 = plane51.getU();
        org.junit.Assert.assertNotNull(subPlane18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(subPlane30);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane32);
        org.junit.Assert.assertNotNull(subPlane61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.09966370236491838d + "'", double92 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.4478350516631948d + "'", double95 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + (-478.5692967842504d) + "'", double97 == (-478.5692967842504d));
        org.junit.Assert.assertNotNull(vector3D98);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.1368683772161603E-13d, (-0.1761977896489369d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.1368683772161603E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = subLine21.intersection(subLine44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        java.text.NumberFormat numberFormat10 = null;
        java.lang.String str11 = vector2D9.toString(numberFormat10);
        org.apache.commons.math3.geometry.Space space12 = vector2D9.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{(Infinity); (Infinity)}" + "'", str11.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(space12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int8 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray7);
        int[] intArray10 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7, 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        double double5 = vector2D3.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.negate();
        double double9 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D1, Double.POSITIVE_INFINITY, vector2D3, 2.718281828459045d, vector2D11);
        double double14 = vector2D3.getNorm();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 1);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(2.2250738585072014E-308d, (-1024.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(4.703669803527209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7411097928541999d + "'", double1 == 1.7411097928541999d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = line39.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Line line42 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double47 = vector3D46.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj52 = null;
        boolean boolean53 = vector3D51.equals(obj52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double58 = vector3D57.getDelta();
        double double59 = vector3D51.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D46.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line62 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D51, vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double67 = vector3D66.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj72 = null;
        boolean boolean73 = vector3D71.equals(obj72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double78 = vector3D77.getDelta();
        double double79 = vector3D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = vector3D66.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line82 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D71, vector3D81);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = line62.intersection(line82);
        double double84 = line39.distance(line62);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.09966370236491838d + "'", double58 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.09966370236491838d + "'", double78 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNull(vector3D83);
        org.junit.Assert.assertEquals((double) double84, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane11 = subLine10.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform12 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane13 = subLine10.applyTransform(euclidean2DTransform12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNull(euclidean2DHyperplane11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getPrevious();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonicSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.896296018268069E13d + "'", number6.equals(7.896296018268069E13d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable4, objArray7);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, objArray7);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 11.15313951653947d, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = notFiniteNumberException10.getContext();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform24 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion25 = polyhedronsSet23.applyTransform(euclidean3DTransform24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = plane35.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double38 = vector2D37.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet39 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector40 = polygonsSet39.getBarycenter();
        double double41 = vector2D37.dotProduct(euclidean2DVector40);
        double double42 = vector2D37.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray44 = vector2D43.toArray();
        double double45 = vector2D43.getNorm();
        double double46 = vector2D43.getX();
        double double47 = vector2D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double49 = vector2D48.getX();
        double double50 = vector2D48.getY();
        double double51 = vector2D37.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = plane36.getPointAt(vector2D37, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet54 = plane36.wholeSpace();
        boolean boolean55 = polyhedronsSet23.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet54);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree56 = null;
        try {
            boolean boolean57 = polyhedronsSet23.isEmpty(euclidean3DBSPTree56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion25);
        org.junit.Assert.assertNotNull(plane36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.NEGATIVE_INFINITY + "'", double49 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.NEGATIVE_INFINITY + "'", double50 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(polyhedronsSet54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(euclidean3DBSPTree0);
        try {
            boolean boolean2 = polyhedronsSet1.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double29 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet30 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector31 = polygonsSet30.getBarycenter();
        double double32 = vector2D28.dotProduct(euclidean2DVector31);
        double double33 = vector2D28.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        double double36 = vector2D34.getNorm();
        double double37 = vector2D34.getX();
        double double38 = vector2D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double40 = vector2D39.getX();
        double double41 = vector2D39.getY();
        double double42 = vector2D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        double double43 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        boolean boolean44 = vector2D11.isNaN();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.NEGATIVE_INFINITY + "'", double41 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getX();
        double double27 = vector2D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double31 = vector2D30.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double33 = vector2D32.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet34 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector35 = polygonsSet34.getBarycenter();
        double double36 = vector2D32.dotProduct(euclidean2DVector35);
        double double37 = vector2D32.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray39 = vector2D38.toArray();
        double double40 = vector2D38.getNorm();
        double double41 = vector2D38.getX();
        double double42 = vector2D32.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double43 = vector2D30.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double44 = vector2D30.getX();
        double double45 = vector2D29.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D29.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D29, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double54 = vector2D53.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double56 = vector2D55.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet57 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector58 = polygonsSet57.getBarycenter();
        double double59 = vector2D55.dotProduct(euclidean2DVector58);
        double double60 = vector2D55.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray62 = vector2D61.toArray();
        double double63 = vector2D61.getNorm();
        double double64 = vector2D61.getX();
        double double65 = vector2D55.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        double double66 = vector2D53.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double67 = vector2D53.getX();
        double double68 = vector2D52.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = vector2D52.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line74 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, vector2D73);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray76 = vector2D75.toArray();
        double double77 = vector2D75.getNorm();
        double double78 = vector2D75.getX();
        double double79 = vector2D75.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = line74.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        boolean boolean81 = line51.isParallelTo(line74);
        boolean boolean82 = line22.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line51);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet83 = line22.wholeSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.POSITIVE_INFINITY + "'", double41 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.NEGATIVE_INFINITY + "'", double44 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.NEGATIVE_INFINITY + "'", double54 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.NEGATIVE_INFINITY + "'", double56 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + Double.POSITIVE_INFINITY + "'", double77 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.POSITIVE_INFINITY + "'", double79 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(polygonsSet83);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getSize();
        java.lang.Class<?> wildcardClass3 = polygonsSet1.getClass();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray4 = polygonsSet1.getVertices();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(vector2DArray4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        double double9 = vector1D8.getX();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector2 = polygonsSet1.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = polygonsSet1.buildNew(euclidean2DBSPTree3);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList5 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList5);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector7 = polygonsSet6.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet9 = polygonsSet6.buildNew(euclidean2DBSPTree8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree10 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet11 = polygonsSet9.buildNew(euclidean2DBSPTree10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree12 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = polygonsSet11.buildNew(euclidean2DBSPTree12);
        try {
            boolean boolean14 = polygonsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DVector2);
        org.junit.Assert.assertNotNull(polygonsSet4);
        org.junit.Assert.assertNotNull(euclidean2DVector7);
        org.junit.Assert.assertNotNull(polygonsSet9);
        org.junit.Assert.assertNotNull(polygonsSet11);
        org.junit.Assert.assertNotNull(polygonsSet13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.junit.Assert.assertNotNull(vector1D0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray3, orderDirection5, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        java.lang.String str17 = vector2D1.toString();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str17.equals("{(-Infinity); (-Infinity)}"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28);
        org.apache.commons.math3.geometry.partitioning.Side side31 = subPlane20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double37 = vector3D36.getDelta();
        java.lang.String str38 = vector3D36.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        double double57 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D44.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        double double59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D40, vector3D49);
        plane30.reset(vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane69 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D64, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane70 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = plane70.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane72 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane10, plane30, plane70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = plane10.getNormal();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector75 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D74.crossProduct(euclidean3DVector75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertTrue("'" + side31 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side31.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.09966370236491838d + "'", double37 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{100; 1; 10}" + "'", str38.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 99.0d + "'", double59 == 99.0d);
        org.junit.Assert.assertNotNull(plane71);
        org.junit.Assert.assertNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane18 = plane17.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane17);
        boolean boolean20 = plane8.isSimilarTo(plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane30 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray32 = polygonsSet31.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane33 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane29, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet31);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree34 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet35 = polygonsSet31.buildNew(euclidean2DBSPTree34);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane36 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet31);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList37 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet38 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray39 = polygonsSet38.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform40 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion41 = polygonsSet38.applyTransform(euclidean2DTransform40);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree43 = euclidean2DAbstractRegion41.getTree(false);
        boolean boolean44 = polygonsSet31.isEmpty(euclidean2DBSPTree43);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet45 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree43);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet46 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree43);
        org.junit.Assert.assertNotNull(subPlane18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(subPlane30);
        org.junit.Assert.assertNotNull(vector2DArray32);
        org.junit.Assert.assertNotNull(polygonsSet35);
        org.junit.Assert.assertNotNull(vector2DArray39);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion41);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.Space space3 = vector1D2.getSpace();
        java.lang.String str4 = vector1D2.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(11013.23292010332d, vector1D2, 11013.23292010332d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D9, (double) 30.0f, vector1D11, 0.09966370236491838d, vector1D13, (double) 100L, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D18, (double) 30.0f, vector1D20, 0.09966370236491838d, vector1D22, (double) 100L, vector1D24);
        double double26 = vector1D15.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double27 = vector1D6.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.junit.Assert.assertNotNull(space3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{35}" + "'", str4.equals("{35}"));
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int1 = org.apache.commons.math3.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = plane18.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane20 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane30 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane29.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane32 = subPlane31.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane61 = plane60.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane60);
        boolean boolean63 = plane51.isSimilarTo(plane62);
        boolean boolean64 = plane42.isSimilarTo(plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane65 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane51);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane66 = subPlane31.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane67 = plane51.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = plane51.getOrigin();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane69 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane78 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D73, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane79 = plane78.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane80 = subPlane79.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion81 = euclidean3DAbstractSubHyperplane80.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane82 = subPlane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane80);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane19);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane20);
        org.junit.Assert.assertNotNull(subPlane30);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane32);
        org.junit.Assert.assertNotNull(subPlane61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane66);
        org.junit.Assert.assertNotNull(plane67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane69);
        org.junit.Assert.assertNotNull(subPlane79);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane80);
        org.junit.Assert.assertNotNull(euclidean2DRegion81);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane82);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.Space space17 = vector2D0.getSpace();
        boolean boolean18 = vector2D0.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(2.718281828459045d, (double) 52);
        double double3 = interval2.getLower();
        double double4 = interval2.getUpper();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.718281828459045d + "'", double3 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-12.280647771556916d), (double) 1.07269331E9f, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane3 = subOrientedPoint2.copySelf();
        double double4 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, euclidean1DRegion6);
        double double8 = subOrientedPoint7.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane9 = subOrientedPoint7.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane10 = subOrientedPoint7.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        boolean boolean15 = orientedPoint14.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint19 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D17, true);
        boolean boolean20 = orientedPoint19.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet23 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint19, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet23);
        boolean boolean25 = orientedPoint14.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint19);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = orientedPoint14.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint27 = orientedPoint14.wholeHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList28 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        boolean boolean29 = euclidean1DSubHyperplaneList28.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint2);
        boolean boolean30 = euclidean1DSubHyperplaneList28.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane10);
        boolean boolean31 = euclidean1DSubHyperplaneList28.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint27);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet32 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(euclidean1DHyperplane9);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(orientedPoint26);
        org.junit.Assert.assertNotNull(subOrientedPoint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(2.718281828459045d, (double) 52);
        double double3 = interval2.getLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 49.28171817154095d + "'", double3 == 49.28171817154095d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D48, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane54 = plane53.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane55 = plane53.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane56 = subPlane55.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane65 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D60, vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane75 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D70, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane84 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D79, vector3D83);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane85 = plane84.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane86 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane84);
        boolean boolean87 = plane75.isSimilarTo(plane86);
        boolean boolean88 = plane66.isSimilarTo(plane75);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane89 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane75);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane90 = subPlane55.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane75);
        boolean boolean91 = plane29.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane75);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(subPlane54);
        org.junit.Assert.assertNotNull(subPlane55);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane56);
        org.junit.Assert.assertNotNull(subPlane85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.7453292519943295d, 1.401298464324817E-45d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double18 = vector3D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double34 = vector3D33.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D27);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.2290500999999993E7d + "'", double18 == 2.2290500999999993E7d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.09966370236491838d + "'", double34 == 0.09966370236491838d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.6098494453571889d), 201.7156361224559d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        int int5 = org.apache.commons.math3.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple7 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray4);
        double[] doubleArray8 = new double[] {};
        int int9 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple11 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray8);
        int int12 = orderedTuple7.compareTo(orderedTuple11);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple16 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray13);
        double[] doubleArray17 = new double[] {};
        int int18 = org.apache.commons.math3.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple20 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray17);
        int int21 = orderedTuple16.compareTo(orderedTuple20);
        int int22 = orderedTuple7.compareTo(orderedTuple16);
        double[] doubleArray23 = new double[] {};
        int int24 = org.apache.commons.math3.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray23);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple26 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray23);
        double[] doubleArray27 = new double[] {};
        int int28 = org.apache.commons.math3.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple30 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray27);
        int int31 = orderedTuple26.compareTo(orderedTuple30);
        double[] doubleArray32 = new double[] {};
        int int33 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray32);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple35 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray32);
        double[] doubleArray36 = new double[] {};
        int int37 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray36);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple39 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray36);
        int int40 = orderedTuple35.compareTo(orderedTuple39);
        int int41 = orderedTuple26.compareTo(orderedTuple35);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple[] orderedTupleArray42 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple[] { orderedTuple7, orderedTuple35 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection46 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException48 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection46, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection49 = nonMonotonicSequenceException48.getDirection();
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderedTupleArray42, orderDirection49, false);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException2, localizable3, (java.lang.Object[]) orderedTupleArray42);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(orderedTupleArray42);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection46.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection49.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double6 = vector2D5.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector8 = polygonsSet7.getBarycenter();
        double double9 = vector2D5.dotProduct(euclidean2DVector8);
        double double10 = vector2D5.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        double double13 = vector2D11.getNorm();
        double double14 = vector2D11.getX();
        double double15 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double16 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double17 = vector2D3.getX();
        double double18 = vector2D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D2.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double29 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet30 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector31 = polygonsSet30.getBarycenter();
        double double32 = vector2D28.dotProduct(euclidean2DVector31);
        double double33 = vector2D28.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        double double36 = vector2D34.getNorm();
        double double37 = vector2D34.getX();
        double double38 = vector2D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double39 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        double double40 = vector2D26.getX();
        double double41 = vector2D25.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D25.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D25, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getX();
        double double52 = vector2D48.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = line47.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        boolean boolean54 = line24.isParallelTo(line47);
        org.apache.commons.math3.geometry.partitioning.Side side55 = polygonsSet1.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray58 = vector2D57.toArray();
        double double59 = vector2D57.getNorm();
        double double60 = vector2D57.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray63 = vector2D62.toArray();
        double double64 = vector2D62.getNorm();
        boolean boolean65 = vector2D62.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment67 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D57, vector2D62, line66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = segment67.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine69 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment67);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane70 = polygonsSet1.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine69);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + side55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side55.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(euclidean2DSubHyperplane70);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = segment8.getEnd();
        double double12 = vector2D11.getNormInf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion21 = subPlane9.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform22 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane23 = subPlane9.applyTransform(euclidean3DTransform22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(euclidean2DRegion21);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getDelta();
        java.lang.String str6 = vector3D4.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D4.scalarMultiply((double) ' ');
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09966370236491838d + "'", double5 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{100; 1; 10}" + "'", str6.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.0000000000001137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459354d + "'", double1 == 2.718281828459354d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = nonMonotonicSequenceException5.getContext();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 341642467, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D7, (double) 30.0f, vector1D9, 0.09966370236491838d, vector1D11, (double) 100L, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D17, (double) 30.0f, vector1D19, 0.09966370236491838d, vector1D21, (double) 100L, vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D26, (double) 30.0f, vector1D28, 0.09966370236491838d, vector1D30, (double) 100L, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = vector1D23.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D2, 1.0d, vector1D4, 1.4478350516631948d, vector1D13, 4720.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D38, (double) 30.0f, vector1D40, 0.09966370236491838d, vector1D42, (double) 100L, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D48, (double) 30.0f, vector1D50, 0.09966370236491838d, vector1D52, (double) 100L, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D57, (double) 30.0f, vector1D59, 0.09966370236491838d, vector1D61, (double) 100L, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = vector1D54.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = vector1D65.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D68, (double) 30.0f, vector1D70, 0.09966370236491838d, vector1D72, (double) 100L, vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D81 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D77, (double) 30.0f, vector1D79, 0.09966370236491838d, vector1D81, (double) 100L, vector1D83);
        double double85 = vector1D74.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D83);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = vector1D83.negate();
        double double87 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D66, vector1D86);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = vector1D66.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D89 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.0000000000000002d, vector1D35, 1.1190346870425511E-15d, vector1D38, (double) '#', vector1D88);
        java.lang.Object obj90 = null;
        boolean boolean91 = vector1D35.equals(obj90);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertNotNull(vector1D81);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertEquals((double) double85, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertEquals((double) double87, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(1.4478350516631948d, (-12.280647771556916d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) dimensionMismatchException6);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) dimensionMismatchException3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection12, false);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException14);
        java.lang.Number number16 = nonMonotonicSequenceException14.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 7.896296018268069E13d + "'", number16.equals(7.896296018268069E13d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.7453292519943295d, 1.401298464324817E-45d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double18 = vector3D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        double double20 = vector3D13.getZ();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.2290500999999993E7d + "'", double18 == 2.2290500999999993E7d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.240252676230739E-13d + "'", double20 == 5.240252676230739E-13d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) dimensionMismatchException6);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) dimensionMismatchException3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection12, false);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException14);
        int int16 = nonMonotonicSequenceException14.getIndex();
        int int17 = nonMonotonicSequenceException14.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D42, (double) 30.0f, vector1D44, 0.09966370236491838d, vector1D46, (double) 100L, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D49, vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line19.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj57 = null;
        boolean boolean58 = vector3D56.equals(obj57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getDelta();
        double double64 = vector3D56.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D62.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane76 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D71, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D71);
        line19.reset(vector3D62, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = line19.pointAt((-0.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.09966370236491838d + "'", double63 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D80);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int[] intArray1 = new int[] { 0 };
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        int[] intArray4 = new int[] { 0 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        int int6 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray14 = new int[] { '#', (byte) -1, (short) 100, (-1), (byte) 0, 1072693248 };
        int int15 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray14);
        try {
            double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.23757691836609945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6241957552445865d) + "'", double1 == (-0.6241957552445865d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math3.util.FastMath.floor(1.1047993141977928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable5, objArray8);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math3.exception.MathArithmeticException(localizable3, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) 11.15313951653947d, objArray8);
        java.lang.Throwable[] throwableArray12 = notFiniteNumberException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray12);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray5 = polygonsSet4.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 52, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) vector2DArray5);
        org.junit.Assert.assertNotNull(vector2DArray5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        boolean boolean15 = orientedPoint14.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint19 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D17, true);
        boolean boolean20 = orientedPoint19.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet23 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint19, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet23);
        boolean boolean25 = orientedPoint14.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint19);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = orientedPoint14.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = orientedPoint26.getLocation();
        double double28 = vector1D27.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D35, (double) 30.0f, vector1D37, 0.09966370236491838d, vector1D39, (double) 100L, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D45, (double) 30.0f, vector1D47, 0.09966370236491838d, vector1D49, (double) 100L, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D54, (double) 30.0f, vector1D56, 0.09966370236491838d, vector1D58, (double) 100L, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D30, 1.0d, vector1D32, 1.4478350516631948d, vector1D41, 4720.0d, vector1D61);
        double double64 = vector1D27.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1023.6665581008151d, vector1D2, 0.9999999958776927d, vector1D27);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(orientedPoint26);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 35.0d + "'", double28 == 35.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        java.lang.String str29 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27, (double) 0.0f, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D15, 0.09966370236491838d, vector3D27, 6.283185307179586d, vector3D38, (double) 100L, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        plane9.reset(vector3D45, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D77.normalize();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector81 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D79.add((double) 1.0f, euclidean3DVector81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{100; 1; 10}" + "'", str29.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D79);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) dimensionMismatchException6);
        mathIllegalStateException0.addSuppressed((java.lang.Throwable) dimensionMismatchException3);
        int int9 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        double double57 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D44.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line60 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D49, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double65 = vector3D64.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj70 = null;
        boolean boolean71 = vector3D69.equals(obj70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getDelta();
        double double77 = vector3D69.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D64.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line80 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D69, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = line60.intersection(line80);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D89 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D83, (double) 30.0f, vector1D85, 0.09966370236491838d, vector1D87, (double) 100L, vector1D89);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D90, vector1D91);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = line60.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        double double94 = line39.distance(line60);
        org.apache.commons.math3.geometry.euclidean.threed.Line line95 = line39.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Line line96 = line39.revert();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.09966370236491838d + "'", double76 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNull(vector3D81);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertNotNull(vector1D87);
        org.junit.Assert.assertNotNull(vector1D89);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line95);
        org.junit.Assert.assertNotNull(line96);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math3.util.FastMath.asin(7.930067261567149E14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(99.508793581271d, (-0.29100619138474915d));
        double double3 = interval2.getUpper();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.29100619138474915d) + "'", double3 == (-0.29100619138474915d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double2 = org.apache.commons.math3.util.Precision.round(49.28171817154095d, (-100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        java.lang.String str5 = vector3D3.toString();
        boolean boolean6 = vector3D3.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane7 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{100; 1; 10}" + "'", str5.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double17 = vector3D16.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj22 = null;
        boolean boolean23 = vector3D21.equals(obj22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        double double29 = vector3D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D7, vector3D21);
        double[] doubleArray32 = vector3D21.toArray();
        try {
            double double33 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray2, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.4478350516631948d + "'", double31 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(9.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane47 = subLine21.getHyperplane();
        try {
            java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList48 = subLine21.getSegments();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
        org.junit.Assert.assertNull(euclidean2DHyperplane47);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) 0, (-1023));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023) + "'", int2 == (-1023));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform24 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion25 = polyhedronsSet23.applyTransform(euclidean3DTransform24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane34 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = plane35.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj41 = null;
        boolean boolean42 = vector3D40.equals(obj41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double47 = vector3D46.getDelta();
        double double48 = vector3D40.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D46.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = plane36.translate(vector3D49);
        org.apache.commons.math3.geometry.partitioning.Side side52 = polyhedronsSet23.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane36);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion53 = polyhedronsSet23.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57, vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane63 = plane62.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane64 = subPlane63.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane73 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D68, vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane74 = plane73.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane75 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane73);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane76 = subPlane63.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane75);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane77 = plane75.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Side side78 = polyhedronsSet23.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane75);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion25);
        org.junit.Assert.assertNotNull(plane36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.09966370236491838d + "'", double47 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(plane51);
        org.junit.Assert.assertTrue("'" + side52 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side52.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion53);
        org.junit.Assert.assertNotNull(subPlane63);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane64);
        org.junit.Assert.assertNotNull(subPlane74);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane76);
        org.junit.Assert.assertNotNull(subPlane77);
        org.junit.Assert.assertTrue("'" + side78 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side78.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        float float1 = org.apache.commons.math3.util.FastMath.abs(35.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(110.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079738368 + "'", int1 == 1079738368);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getY();
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D15);
        boolean boolean18 = vector3D15.isInfinite();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        double double6 = vector2D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        boolean boolean16 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment18 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D8, vector2D13, line17);
        double double19 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D0.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double22 = vector2D21.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet23 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector24 = polygonsSet23.getBarycenter();
        double double25 = vector2D21.dotProduct(euclidean2DVector24);
        double double26 = vector2D21.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray28 = vector2D27.toArray();
        double double29 = vector2D27.getNorm();
        double double30 = vector2D27.getX();
        double double31 = vector2D21.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D32);
        double double35 = vector2D20.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable3, objArray6);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 0, localizable1, objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray5 = polygonsSet4.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) vector2DArray5);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) vector2DArray5);
        org.junit.Assert.assertNotNull(vector2DArray5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet13 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector14 = polygonsSet13.getBarycenter();
        double double15 = vector2D11.dotProduct(euclidean2DVector14);
        double double16 = vector2D11.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray18 = vector2D17.toArray();
        double double19 = vector2D17.getNorm();
        double double20 = vector2D17.getX();
        double double21 = vector2D11.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double23 = vector2D22.getX();
        double double24 = vector2D22.getY();
        double double25 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane10.getPointAt(vector2D11, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        boolean boolean29 = vector3D27.equals((java.lang.Object) vector3D28);
        double double30 = vector3D27.getAlpha();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double21 = vector3D20.getY();
        double double22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D8, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20);
        double double24 = vector3D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        double double25 = vector3D3.getNorm();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.50373127401788d + "'", double25 == 100.50373127401788d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = line22.getPointAt(vector1D53, 2.718281828459354d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D4, (double) 30.0f, vector1D6, 0.09966370236491838d, vector1D8, (double) 100L, vector1D10);
        double double12 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((-0.29100619138474915d), vector1D11);
        double double14 = vector1D11.getNorm1();
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 890547225, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 890547225L + "'", long2 == 890547225L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D13, (double) 30.0f, vector1D15, 0.09966370236491838d, vector1D17, (double) 100L, vector1D19);
        double double21 = vector1D11.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D44, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane50 = plane49.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane49);
        boolean boolean52 = plane40.isSimilarTo(plane51);
        boolean boolean53 = plane31.isSimilarTo(plane40);
        boolean boolean54 = vector1D11.equals((java.lang.Object) plane40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D57, (double) 30.0f, vector1D59, 0.09966370236491838d, vector1D61, (double) 100L, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D64, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = vector1D11.add(110.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D65);
        boolean boolean68 = vector1D65.isInfinite();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D71, (double) 30.0f, vector1D73, 0.09966370236491838d, vector1D75, (double) 100L, vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D80, (double) 30.0f, vector1D82, 0.09966370236491838d, vector1D84, (double) 100L, vector1D86);
        double double88 = vector1D77.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D86);
        double double89 = vector1D77.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D8, (double) (-1.0f), vector1D65, 1.0000000000000002d, vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = vector1D91.normalize();
        double double93 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D8, vector1D92);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertEquals((double) double88, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + Double.POSITIVE_INFINITY + "'", double89 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane46 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion47 = subLine33.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion48 = subLine33.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane46);
        org.junit.Assert.assertNotNull(euclidean1DRegion47);
        org.junit.Assert.assertNotNull(euclidean1DRegion48);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(99.508793581271d, (-0.29100619138474915d));
        double double3 = interval2.getLower();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.508793581271d + "'", double3 == 99.508793581271d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getX();
        double double27 = vector2D23.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line22.wholeHyperplane();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(subLine29);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        long long1 = org.apache.commons.math3.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double double2 = vector2D0.getNorm();
        double double3 = vector2D0.getX();
        boolean boolean4 = vector2D0.isInfinite();
        java.lang.String str5 = vector2D0.toString();
        double[] doubleArray6 = vector2D0.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{(Infinity); (Infinity)}" + "'", str5.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        java.lang.String str29 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27, (double) 0.0f, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D15, 0.09966370236491838d, vector3D27, 6.283185307179586d, vector3D38, (double) 100L, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        plane9.reset(vector3D45, vector3D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double80 = vector2D79.getX();
        double double81 = vector2D79.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double83 = vector2D82.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D82.negate();
        double double85 = vector2D79.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane9.getPointAt(vector2D79, (double) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = plane9.getV();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{100; 1; 10}" + "'", str29.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.NEGATIVE_INFINITY + "'", double80 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.NEGATIVE_INFINITY + "'", double81 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + Double.NEGATIVE_INFINITY + "'", double83 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(vector3D88);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D4, true);
        boolean boolean7 = orientedPoint6.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint11 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D13, true);
        boolean boolean16 = orientedPoint15.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = orientedPoint24.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D27, true);
        boolean boolean30 = orientedPoint29.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = orientedPoint29.copySelf();
        boolean boolean32 = orientedPoint24.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint29);
        org.apache.commons.math3.geometry.partitioning.Side side33 = intervalsSet19.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint29);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree35 = intervalsSet19.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = intervalsSet10.buildNew(euclidean1DBSPTree35);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet37 = intervalsSet2.buildNew(euclidean1DBSPTree35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(orientedPoint25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(orientedPoint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree35);
        org.junit.Assert.assertNotNull(intervalsSet36);
        org.junit.Assert.assertNotNull(intervalsSet37);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 35L, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999996f + "'", float2 == 34.999996f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-1023), 33553471);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1023 + "'", int2 == 1023);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(11.15313951653947d, 1.7165256995489035d, Double.NEGATIVE_INFINITY, 0.0d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D42, (double) 30.0f, vector1D44, 0.09966370236491838d, vector1D46, (double) 100L, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D49, vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line19.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D53.normalize();
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D50, vector1D53);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.POSITIVE_INFINITY + "'", double55 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double5 = vector3D4.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj10 = null;
        boolean boolean11 = vector3D9.equals(obj10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getDelta();
        double double17 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D4.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double37 = vector3D36.getDelta();
        java.lang.String str38 = vector3D36.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D36, (double) 0.0f, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj48 = null;
        boolean boolean49 = vector3D47.equals(obj48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double55 = vector3D54.getDelta();
        java.lang.String str56 = vector3D54.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D54.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D24, 0.09966370236491838d, vector3D36, 6.283185307179586d, vector3D47, (double) 100L, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj64 = null;
        boolean boolean65 = vector3D63.equals(obj64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double70 = vector3D69.getDelta();
        double double71 = vector3D63.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double76 = vector3D75.getY();
        double double77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D63, vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D75.scalarMultiply(0.0d);
        double double80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D59, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double86 = vector3D85.getDelta();
        java.lang.String str87 = vector3D85.toString();
        org.apache.commons.math3.geometry.Space space88 = vector3D85.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D18, (double) (short) 1, vector3D79, (double) (byte) 1, vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane90 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D89);
        double double91 = vector3D89.getNormSq();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.09966370236491838d + "'", double16 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.09966370236491838d + "'", double37 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{100; 1; 10}" + "'", str38.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.09966370236491838d + "'", double55 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{100; 1; 10}" + "'", str56.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.09966370236491838d + "'", double70 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 4.3022336555707305E12d + "'", double80 == 4.3022336555707305E12d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.09966370236491838d + "'", double86 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "{100; 1; 10}" + "'", str87.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(space88);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 10101.0d + "'", double91 == 10101.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-478.5692967842504d), 0.0927837451120071d, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 0, (int) (byte) -1);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj19 = null;
        boolean boolean20 = vector3D18.equals(obj19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double25 = vector3D24.getDelta();
        double double26 = vector3D18.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D13.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line29 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double34 = vector3D33.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getDelta();
        double double46 = vector3D38.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D33.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line49 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = line29.intersection(line49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D54, vector3D58);
        double double60 = vector3D58.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = line49.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        double double62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D7, vector3D58);
        double double63 = vector3D58.getY();
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.09966370236491838d + "'", double25 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.09966370236491838d + "'", double45 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNull(vector3D50);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10101.0d + "'", double60 == 10101.0d);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        java.lang.String str29 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27, (double) 0.0f, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D15, 0.09966370236491838d, vector3D27, 6.283185307179586d, vector3D38, (double) 100L, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        plane9.reset(vector3D45, vector3D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double80 = vector2D79.getX();
        double double81 = vector2D79.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double83 = vector2D82.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D82.negate();
        double double85 = vector2D79.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane9.getPointAt(vector2D79, (double) (byte) 10);
        java.text.NumberFormat numberFormat88 = null;
        java.lang.String str89 = vector2D79.toString(numberFormat88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = vector2D79.normalize();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{100; 1; 10}" + "'", str29.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.NEGATIVE_INFINITY + "'", double80 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.NEGATIVE_INFINITY + "'", double81 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + Double.NEGATIVE_INFINITY + "'", double83 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str89.equals("{(-Infinity); (-Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D90);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float2 = org.apache.commons.math3.util.FastMath.min(100.00001f, 1.4E-45f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(0.0d, 22.124509620613694d);
        double double3 = interval2.getLower();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree4 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) double3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double16 = vector2D15.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D15.negate();
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = plane28.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double31 = vector2D30.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet32 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector33 = polygonsSet32.getBarycenter();
        double double34 = vector2D30.dotProduct(euclidean2DVector33);
        double double35 = vector2D30.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D30.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double42 = vector2D41.getX();
        double double43 = vector2D41.getY();
        double double44 = vector2D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = plane29.getPointAt(vector2D30, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double48 = vector2D47.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet49 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector50 = polygonsSet49.getBarycenter();
        double double51 = vector2D47.dotProduct(euclidean2DVector50);
        double double52 = vector2D47.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray54 = vector2D53.toArray();
        double double55 = vector2D53.getNorm();
        double double56 = vector2D53.getX();
        double double57 = vector2D47.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double59 = vector2D58.getX();
        double double60 = vector2D58.getY();
        double double61 = vector2D47.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        double double62 = vector2D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        double double64 = vector2D63.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(51.99999999999999d, vector2D63);
        double double66 = vector2D63.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray68 = vector2D67.toArray();
        double double69 = vector2D67.getNorm();
        double double70 = vector2D67.getX();
        double double71 = vector2D67.getNorm();
        double double72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D63, vector2D67);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(plane29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.NEGATIVE_INFINITY + "'", double42 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.POSITIVE_INFINITY + "'", double55 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.POSITIVE_INFINITY + "'", double57 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.POSITIVE_INFINITY + "'", double71 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.POSITIVE_INFINITY + "'", double72 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1076101120, 4.641588833612779d, (double) 100.00001f, (double) '4', 0.0d, 0.23757691836609945d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.994824142430602E9d + "'", double6 == 4.994824142430602E9d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = segment8.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine12 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = segment8.getStart();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long1 = org.apache.commons.math3.util.FastMath.round(4.703669803527209d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999969540041d + "'", double1 == 0.999999969540041d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(35.000004f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.000004f + "'", float2 == 35.000004f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray0);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double19 = vector3D18.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj24 = null;
        boolean boolean25 = vector3D23.equals(obj24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        double double31 = vector3D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D18.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D9, vector3D23);
        double[] doubleArray34 = vector3D23.toArray();
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray34);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4478350516631948d + "'", double33 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = plane32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double35 = vector2D34.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet36 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector37 = polygonsSet36.getBarycenter();
        double double38 = vector2D34.dotProduct(euclidean2DVector37);
        double double39 = vector2D34.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray41 = vector2D40.toArray();
        double double42 = vector2D40.getNorm();
        double double43 = vector2D40.getX();
        double double44 = vector2D34.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double46 = vector2D45.getX();
        double double47 = vector2D45.getY();
        double double48 = vector2D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = plane33.getPointAt(vector2D34, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double52 = vector2D51.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet53 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector54 = polygonsSet53.getBarycenter();
        double double55 = vector2D51.dotProduct(euclidean2DVector54);
        double double56 = vector2D51.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray58 = vector2D57.toArray();
        double double59 = vector2D57.getNorm();
        double double60 = vector2D57.getX();
        double double61 = vector2D51.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double63 = vector2D62.getX();
        double double64 = vector2D62.getY();
        double double65 = vector2D51.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        double double66 = vector2D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D34.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = line22.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double69 = vector2D67.getY();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(plane33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.NEGATIVE_INFINITY + "'", double47 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.NEGATIVE_INFINITY + "'", double64 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double13 = vector3D12.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj18 = null;
        boolean boolean19 = vector3D17.equals(obj18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getDelta();
        double double25 = vector3D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D12.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D3, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = plane28.getV();
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.09966370236491838d + "'", double24 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4478350516631948d + "'", double27 == 1.4478350516631948d);
        org.junit.Assert.assertNotNull(vector3D29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D0.toString(numberFormat23);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str24.equals("{(-Infinity); (-Infinity)}"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288292537319899d + "'", double1 == 5.288292537319899d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D13, true);
        boolean boolean16 = orientedPoint15.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D18, true);
        boolean boolean21 = orientedPoint20.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        boolean boolean26 = orientedPoint15.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint20);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint27 = orientedPoint15.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = orientedPoint27.getLocation();
        double double29 = vector1D28.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D36, (double) 30.0f, vector1D38, 0.09966370236491838d, vector1D40, (double) 100L, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D46, (double) 30.0f, vector1D48, 0.09966370236491838d, vector1D50, (double) 100L, vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D55, (double) 30.0f, vector1D57, 0.09966370236491838d, vector1D59, (double) 100L, vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D52.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D31, 1.0d, vector1D33, 1.4478350516631948d, vector1D42, 4720.0d, vector1D62);
        double double65 = vector1D28.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = vector1D2.add((double) (byte) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.Space space69 = vector1D68.getSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = vector1D68.scalarMultiply((double) 100.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = vector1D2.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(orientedPoint27);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 35.0d + "'", double29 == 35.0d);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(space69);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D72);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double5 = vector2D4.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet8 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector9 = polygonsSet8.getBarycenter();
        double double10 = vector2D6.dotProduct(euclidean2DVector9);
        double double11 = vector2D6.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray13 = vector2D12.toArray();
        double double14 = vector2D12.getNorm();
        double double15 = vector2D12.getX();
        double double16 = vector2D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        double double17 = vector2D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double18 = vector2D4.getX();
        double double19 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D3.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double28 = vector2D27.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double30 = vector2D29.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet31 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector32 = polygonsSet31.getBarycenter();
        double double33 = vector2D29.dotProduct(euclidean2DVector32);
        double double34 = vector2D29.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray36 = vector2D35.toArray();
        double double37 = vector2D35.getNorm();
        double double38 = vector2D35.getX();
        double double39 = vector2D29.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double40 = vector2D27.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        double double41 = vector2D27.getX();
        double double42 = vector2D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D26.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line48 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray50 = vector2D49.toArray();
        double double51 = vector2D49.getNorm();
        double double52 = vector2D49.getX();
        double double53 = vector2D49.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = line48.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        boolean boolean55 = line25.isParallelTo(line48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line56 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line25);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine57 = line56.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Side side58 = polygonsSet1.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line56);
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.NEGATIVE_INFINITY + "'", double41 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(subLine57);
        org.junit.Assert.assertTrue("'" + side58 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side58.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double6 = vector2D5.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector8 = polygonsSet7.getBarycenter();
        double double9 = vector2D5.dotProduct(euclidean2DVector8);
        double double10 = vector2D5.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        double double13 = vector2D11.getNorm();
        double double14 = vector2D11.getX();
        double double15 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double16 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double17 = vector2D3.getX();
        double double18 = vector2D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D2.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double29 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet30 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector31 = polygonsSet30.getBarycenter();
        double double32 = vector2D28.dotProduct(euclidean2DVector31);
        double double33 = vector2D28.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        double double36 = vector2D34.getNorm();
        double double37 = vector2D34.getX();
        double double38 = vector2D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double39 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        double double40 = vector2D26.getX();
        double double41 = vector2D25.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D25.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D25, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getX();
        double double52 = vector2D48.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = line47.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        boolean boolean54 = line24.isParallelTo(line47);
        org.apache.commons.math3.geometry.partitioning.Side side55 = polygonsSet1.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line24);
        line24.revertSelf();
        double double57 = line24.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray59 = vector2D58.toArray();
        double double60 = vector2D58.getNorm();
        boolean boolean61 = vector2D58.isNaN();
        double double62 = line24.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D69, (double) 30.0f, vector1D71, 0.09966370236491838d, vector1D73, (double) 100L, vector1D75);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D81 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D79, (double) 30.0f, vector1D81, 0.09966370236491838d, vector1D83, (double) 100L, vector1D85);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D94 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D95 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D88, (double) 30.0f, vector1D90, 0.09966370236491838d, vector1D92, (double) 100L, vector1D94);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D96 = vector1D85.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D95);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D97 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10.0f, vector1D64, 1.0d, vector1D66, 1.4478350516631948d, vector1D75, 4720.0d, vector1D95);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D99 = line24.getPointAt(vector1D97, 9.306943617238488d);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + side55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side55.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.9269908169872414d + "'", double57 == 3.9269908169872414d);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertNotNull(vector1D81);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertNotNull(vector1D94);
        org.junit.Assert.assertNotNull(vector1D96);
        org.junit.Assert.assertNotNull(vector2D99);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D3, (double) 30.0f, vector1D5, 0.09966370236491838d, vector1D7, (double) 100L, vector1D9);
        double double11 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        double double12 = vector1D10.getNormSq();
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.7853981633974483d, vector2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection4, false);
        int int7 = nonMonotonicSequenceException6.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonicSequenceException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection3, false);
        int int6 = nonMonotonicSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray7 = nonMonotonicSequenceException5.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = nonMonotonicSequenceException5.getContext();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = orientedPoint3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = orientedPoint3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D18, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint21 = orientedPoint20.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D23, true);
        boolean boolean26 = orientedPoint25.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint27 = orientedPoint25.copySelf();
        boolean boolean28 = orientedPoint20.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray31 = vector2D30.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D32.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment38 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D30, vector2D32, line37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = segment38.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine40 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment38);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane41 = subLine40.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion42 = subLine40.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint43 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, euclidean1DRegion42);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane44 = subOrientedPoint16.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = orientedPoint25.copySelf();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(orientedPoint15);
        org.junit.Assert.assertNotNull(subOrientedPoint16);
        org.junit.Assert.assertNotNull(orientedPoint21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(orientedPoint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNull(euclidean2DHyperplane41);
        org.junit.Assert.assertNotNull(euclidean1DRegion42);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane44);
        org.junit.Assert.assertNotNull(orientedPoint45);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(7.896296018268069E13d, 4720.0d, 9.306943617238488d, 99.508793581271d, (double) 4.2949673E11f, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.7270517206225376E17d + "'", double6 == 3.7270517206225376E17d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        boolean boolean9 = orientedPoint8.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        boolean boolean14 = orientedPoint3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = orientedPoint3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = orientedPoint3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D18, true);
        boolean boolean21 = orientedPoint20.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree26 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = intervalsSet24.buildNew(euclidean1DBSPTree26);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint28 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(orientedPoint15);
        org.junit.Assert.assertNotNull(subOrientedPoint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(intervalsSet27);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion2 = polyhedronsSet0.applyTransform(euclidean3DTransform1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double8 = vector3D7.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj13 = null;
        boolean boolean14 = vector3D12.equals(obj13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double19 = vector3D18.getDelta();
        double double20 = vector3D12.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D7.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double40 = vector3D39.getDelta();
        java.lang.String str41 = vector3D39.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D39, (double) 0.0f, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj51 = null;
        boolean boolean52 = vector3D50.equals(obj51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double58 = vector3D57.getDelta();
        java.lang.String str59 = vector3D57.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D57.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D27, 0.09966370236491838d, vector3D39, 6.283185307179586d, vector3D50, (double) 100L, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj67 = null;
        boolean boolean68 = vector3D66.equals(obj67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double73 = vector3D72.getDelta();
        double double74 = vector3D66.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double79 = vector3D78.getY();
        double double80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D66, vector3D78);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D78.scalarMultiply(0.0d);
        double double83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D62, vector3D82);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double89 = vector3D88.getDelta();
        java.lang.String str90 = vector3D88.toString();
        org.apache.commons.math3.geometry.Space space91 = vector3D88.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D21, (double) (short) 1, vector3D82, (double) (byte) 1, vector3D88);
        org.apache.commons.math3.geometry.partitioning.Region.Location location93 = euclidean3DAbstractRegion2.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D88);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.09966370236491838d + "'", double19 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.09966370236491838d + "'", double40 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{100; 1; 10}" + "'", str41.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.09966370236491838d + "'", double58 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{100; 1; 10}" + "'", str59.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.09966370236491838d + "'", double73 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 4.3022336555707305E12d + "'", double83 == 4.3022336555707305E12d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.09966370236491838d + "'", double89 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "{100; 1; 10}" + "'", str90.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(space91);
        org.junit.Assert.assertTrue("'" + location93 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location93.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (-1L), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray6 = polygonsSet5.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, (java.lang.Object[]) vector2DArray6);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 52, (java.lang.Object[]) vector2DArray6);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 52, (java.lang.Object[]) vector2DArray6);
        org.junit.Assert.assertNotNull(vector2DArray6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line22);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine54 = line53.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double56 = vector2D55.getX();
        double double57 = vector2D55.getNormInf();
        double double58 = line53.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(subLine54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion11 = euclidean3DAbstractSubHyperplane10.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane21 = plane20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane22 = plane20.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane23 = subPlane22.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane33 = plane32.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane34 = subPlane33.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane44 = plane43.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane43);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane46 = subPlane33.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D50, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane56 = plane55.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane57 = plane55.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D61, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane67 = plane66.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane68 = subPlane67.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane77 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D72, vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane78 = plane77.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane87 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D82, vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane88 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D86);
        org.apache.commons.math3.geometry.partitioning.Side side89 = subPlane78.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane88);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList90 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        boolean boolean91 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane10);
        boolean boolean92 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane22);
        boolean boolean93 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane33);
        boolean boolean94 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane57);
        boolean boolean95 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane68);
        boolean boolean96 = euclidean3DSubHyperplaneList90.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane78);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet97 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList90);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree99 = polyhedronsSet97.getTree(false);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(euclidean2DRegion11);
        org.junit.Assert.assertNotNull(subPlane21);
        org.junit.Assert.assertNotNull(subPlane22);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(subPlane33);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane34);
        org.junit.Assert.assertNotNull(subPlane44);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane46);
        org.junit.Assert.assertNotNull(subPlane56);
        org.junit.Assert.assertNotNull(subPlane57);
        org.junit.Assert.assertNotNull(subPlane67);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane68);
        org.junit.Assert.assertNotNull(subPlane78);
        org.junit.Assert.assertTrue("'" + side89 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side89.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree99);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double15 = vector3D10.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double21 = vector3D20.getDelta();
        java.lang.String str22 = vector3D20.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D16, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj33 = null;
        boolean boolean34 = vector3D32.equals(obj33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double39 = vector3D38.getDelta();
        double double40 = vector3D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D27.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        double double43 = vector3D42.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double48 = vector3D47.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj53 = null;
        boolean boolean54 = vector3D52.equals(obj53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double59 = vector3D58.getDelta();
        double double60 = vector3D52.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D47.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D42, vector3D61);
        double double63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D10, vector3D42);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.2290500999999993E7d + "'", double15 == 2.2290500999999993E7d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.09966370236491838d + "'", double21 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{100; 1; 10}" + "'", str22.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.09966370236491838d + "'", double39 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 200.0d + "'", double43 == 200.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.09966370236491838d + "'", double59 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.2922773962031897E-11d + "'", double63 == 1.2922773962031897E-11d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1023, (double) 0.0f, (double) 6L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double1 = vector3D0.getY();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        boolean boolean8 = orientedPoint7.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint7, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint16 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D14, true);
        boolean boolean17 = orientedPoint16.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet20 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint21 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint16, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D23, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = orientedPoint25.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint30 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        boolean boolean31 = orientedPoint30.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint32 = orientedPoint30.copySelf();
        boolean boolean33 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.partitioning.Side side34 = intervalsSet20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree36 = intervalsSet20.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet37 = intervalsSet11.buildNew(euclidean1DBSPTree36);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint38 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        double double39 = intervalsSet11.getSup();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(orientedPoint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(orientedPoint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + side34 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side34.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree36);
        org.junit.Assert.assertNotNull(intervalsSet37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 32.0d + "'", double39 == 32.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D4);
        double double11 = vector3D4.getAlpha();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.009090658665059818d) + "'", double11 == (-0.009090658665059818d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.2676506E31f + "'", float2 == 1.2676506E31f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj20 = null;
        boolean boolean21 = vector3D19.equals(obj20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double26 = vector3D25.getDelta();
        double double27 = vector3D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D14.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line30 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D19, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = plane40.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double43 = vector2D42.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet44 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector45 = polygonsSet44.getBarycenter();
        double double46 = vector2D42.dotProduct(euclidean2DVector45);
        double double47 = vector2D42.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getX();
        double double52 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double54 = vector2D53.getX();
        double double55 = vector2D53.getY();
        double double56 = vector2D42.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = plane41.getPointAt(vector2D42, 2.220446049250313E-16d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet59 = plane41.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane68 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D63, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane77 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D72, vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double82 = vector3D81.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj87 = null;
        boolean boolean88 = vector3D86.equals(obj87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double93 = vector3D92.getDelta();
        double double94 = vector3D86.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D92);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D95 = vector3D81.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D86);
        double double96 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D72, vector3D86);
        double double97 = vector3D67.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet98 = polyhedronsSet59.translate(vector3D67);
        plane8.reset(vector3D19, vector3D67);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.09966370236491838d + "'", double26 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(plane41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.NEGATIVE_INFINITY + "'", double54 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.NEGATIVE_INFINITY + "'", double55 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(polyhedronsSet59);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.09966370236491838d + "'", double93 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 1.4478350516631948d + "'", double96 == 1.4478350516631948d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet98);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane29);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet45 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray46 = polygonsSet45.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane47 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane29, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet45);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector2DArray46);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getDelta();
        double double5 = vector3D3.getAlpha();
        double[] doubleArray6 = vector3D3.toArray();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09966370236491838d + "'", double4 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.009999666686665238d + "'", double5 == 0.009999666686665238d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double6 = vector2D5.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector8 = polygonsSet7.getBarycenter();
        double double9 = vector2D5.dotProduct(euclidean2DVector8);
        double double10 = vector2D5.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        double double13 = vector2D11.getNorm();
        double double14 = vector2D11.getX();
        double double15 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double16 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double17 = vector2D3.getX();
        double double18 = vector2D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D2.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double29 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet30 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector31 = polygonsSet30.getBarycenter();
        double double32 = vector2D28.dotProduct(euclidean2DVector31);
        double double33 = vector2D28.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        double double36 = vector2D34.getNorm();
        double double37 = vector2D34.getX();
        double double38 = vector2D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double39 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        double double40 = vector2D26.getX();
        double double41 = vector2D25.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D25.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D25, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getX();
        double double52 = vector2D48.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = line47.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        boolean boolean54 = line24.isParallelTo(line47);
        org.apache.commons.math3.geometry.partitioning.Side side55 = polygonsSet1.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line24);
        line24.revertSelf();
        double double57 = line24.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet58 = line24.wholeSpace();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + side55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side55.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.9269908169872414d + "'", double57 == 3.9269908169872414d);
        org.junit.Assert.assertNotNull(polygonsSet58);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        double double2 = polygonsSet1.getSize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double5 = vector2D4.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet8 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector9 = polygonsSet8.getBarycenter();
        double double10 = vector2D6.dotProduct(euclidean2DVector9);
        double double11 = vector2D6.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray13 = vector2D12.toArray();
        double double14 = vector2D12.getNorm();
        double double15 = vector2D12.getX();
        double double16 = vector2D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        double double17 = vector2D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double18 = vector2D4.getX();
        double double19 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D3.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double double28 = vector2D26.getNorm();
        double double29 = vector2D26.getX();
        double double30 = vector2D26.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = line25.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double34 = vector2D33.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double36 = vector2D35.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet37 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector38 = polygonsSet37.getBarycenter();
        double double39 = vector2D35.dotProduct(euclidean2DVector38);
        double double40 = vector2D35.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray42 = vector2D41.toArray();
        double double43 = vector2D41.getNorm();
        double double44 = vector2D41.getX();
        double double45 = vector2D35.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        double double46 = vector2D33.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double47 = vector2D33.getX();
        double double48 = vector2D32.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = vector2D32.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line54 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double57 = vector2D56.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double59 = vector2D58.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet60 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector61 = polygonsSet60.getBarycenter();
        double double62 = vector2D58.dotProduct(euclidean2DVector61);
        double double63 = vector2D58.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray65 = vector2D64.toArray();
        double double66 = vector2D64.getNorm();
        double double67 = vector2D64.getX();
        double double68 = vector2D58.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        double double69 = vector2D56.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        double double70 = vector2D56.getX();
        double double71 = vector2D55.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = vector2D55.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line77 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D55, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray79 = vector2D78.toArray();
        double double80 = vector2D78.getNorm();
        double double81 = vector2D78.getX();
        double double82 = vector2D78.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = line77.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        boolean boolean84 = line54.isParallelTo(line77);
        boolean boolean85 = line25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line54);
        org.apache.commons.math3.geometry.partitioning.Side side86 = polygonsSet1.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line54);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.NEGATIVE_INFINITY + "'", double34 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.NEGATIVE_INFINITY + "'", double36 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.NEGATIVE_INFINITY + "'", double47 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.NEGATIVE_INFINITY + "'", double57 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.POSITIVE_INFINITY + "'", double67 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.POSITIVE_INFINITY + "'", double68 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.NEGATIVE_INFINITY + "'", double70 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.POSITIVE_INFINITY + "'", double80 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.POSITIVE_INFINITY + "'", double81 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + Double.POSITIVE_INFINITY + "'", double82 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + side86 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side86.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 99.99999f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        double double3 = subOrientedPoint2.getSize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, true);
        boolean boolean8 = orientedPoint7.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D10, true);
        boolean boolean13 = orientedPoint12.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet16);
        boolean boolean18 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint22 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D20, true);
        boolean boolean23 = orientedPoint22.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint27 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D25, true);
        boolean boolean28 = orientedPoint27.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint32 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint27, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet31);
        boolean boolean33 = orientedPoint22.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint27);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint34 = orientedPoint22.copySelf();
        boolean boolean35 = orientedPoint12.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint34);
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane36 = subOrientedPoint2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(orientedPoint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        double double16 = vector2D13.getX();
        double double17 = vector2D13.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D11, vector2D13, line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = segment19.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment19);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray26 = vector2D25.toArray();
        double double27 = vector2D25.getNorm();
        double double28 = vector2D25.getX();
        double double29 = vector2D25.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment31 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D23, vector2D25, line30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = segment31.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray37 = vector2D36.toArray();
        double double38 = vector2D36.getNorm();
        double double39 = vector2D36.getX();
        double double40 = vector2D36.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment42 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D34, vector2D36, line41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = segment42.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment42);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane45 = subLine33.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getX();
        double double52 = vector2D48.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment54 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D46, vector2D48, line53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = segment54.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine56 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray58 = vector2D57.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray60 = vector2D59.toArray();
        double double61 = vector2D59.getNorm();
        double double62 = vector2D59.getX();
        double double63 = vector2D59.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment65 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D57, vector2D59, line64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = segment65.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine67 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment65);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane68 = subLine56.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine67);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane69 = subLine44.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine56);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane70 = subLine21.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine44);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane68);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane69);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane70);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D3.scalarMultiply((double) (short) 100);
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D2, vector3D5);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(5729.578388440339d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5729.578388440339d + "'", double2 == 5729.578388440339d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(99.0d, (double) 30.0f, (double) 1079738368);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        double double6 = vector2D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        boolean boolean16 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment18 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D8, vector2D13, line17);
        double double19 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double21 = vector2D20.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet22 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector23 = polygonsSet22.getBarycenter();
        double double24 = vector2D20.dotProduct(euclidean2DVector23);
        double double25 = vector2D20.getNormSq();
        double double26 = vector2D20.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray29 = vector2D28.toArray();
        double double30 = vector2D28.getNorm();
        double double31 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray34 = vector2D33.toArray();
        double double35 = vector2D33.getNorm();
        boolean boolean36 = vector2D33.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment38 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D28, vector2D33, line37);
        double double39 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D13, vector2D20);
        boolean boolean41 = vector2D13.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.NEGATIVE_INFINITY + "'", double39 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1L), 1.4E-45f, (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane11 = subPlane10.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane39.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane39);
        boolean boolean42 = plane30.isSimilarTo(plane41);
        boolean boolean43 = plane21.isSimilarTo(plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane30);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane45 = subPlane10.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = plane30.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double48 = vector2D47.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet49 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector50 = polygonsSet49.getBarycenter();
        double double51 = vector2D47.dotProduct(euclidean2DVector50);
        double double52 = vector2D47.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray54 = vector2D53.toArray();
        double double55 = vector2D53.getNorm();
        double double56 = vector2D53.getX();
        double double57 = vector2D47.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double59 = vector2D58.getX();
        double double60 = vector2D58.getY();
        double double61 = vector2D47.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        boolean boolean62 = vector2D58.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = plane46.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane11);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane45);
        org.junit.Assert.assertNotNull(plane46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.POSITIVE_INFINITY + "'", double55 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.POSITIVE_INFINITY + "'", double57 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(vector3D63);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(10.0f, 0.0f, (-100));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(1.000000000000512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559559799d + "'", double1 == 0.7615941559559799d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D13, (double) 30.0f, vector1D15, 0.09966370236491838d, vector1D17, (double) 100L, vector1D19);
        double double21 = vector1D11.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D44, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane50 = plane49.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane51 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane49);
        boolean boolean52 = plane40.isSimilarTo(plane51);
        boolean boolean53 = plane31.isSimilarTo(plane40);
        boolean boolean54 = vector1D11.equals((java.lang.Object) plane40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D57, (double) 30.0f, vector1D59, 0.09966370236491838d, vector1D61, (double) 100L, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D64, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = vector1D11.add(110.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D65);
        boolean boolean68 = vector1D65.isInfinite();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D71, (double) 30.0f, vector1D73, 0.09966370236491838d, vector1D75, (double) 100L, vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D80, (double) 30.0f, vector1D82, 0.09966370236491838d, vector1D84, (double) 100L, vector1D86);
        double double88 = vector1D77.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D86);
        double double89 = vector1D77.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D8, (double) (-1.0f), vector1D65, 1.0000000000000002d, vector1D77);
        double double91 = vector1D90.getNormSq();
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertEquals((double) double88, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + Double.POSITIVE_INFINITY + "'", double89 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 7.896296018268069E13d, (int) 'a', orderDirection5, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection5, false);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (short) 100);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (byte) 0);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-33553471) + "'", int10 == (-33553471));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1, false };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f, localizable3, objArray6);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray6);
        org.apache.commons.math3.exception.MathInternalError mathInternalError9 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-100), (double) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D2, (double) 30.0f, vector1D4, 0.09966370236491838d, vector1D6, (double) 100L, vector1D8);
        double double10 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane39 = plane38.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane38);
        boolean boolean41 = plane29.isSimilarTo(plane40);
        boolean boolean42 = plane20.isSimilarTo(plane29);
        boolean boolean43 = vector1D0.equals((java.lang.Object) plane29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D46, (double) 30.0f, vector1D48, 0.09966370236491838d, vector1D50, (double) 100L, vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D53, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D0.add(110.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        org.apache.commons.math3.geometry.Space space57 = vector1D56.getSpace();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subPlane39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(space57);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, 5729.578388440339d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        double double3 = vector2D1.getNorm();
        double double4 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray7 = vector2D6.toArray();
        double double8 = vector2D6.getNorm();
        boolean boolean9 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment11 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D1, vector2D6, line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = segment11.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = segment11.getStart();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D14.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double19 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double34 = vector3D33.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double45 = vector3D44.getDelta();
        double double46 = vector3D38.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D33.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line49 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double54 = vector3D53.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj59 = null;
        boolean boolean60 = vector3D58.equals(obj59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double65 = vector3D64.getDelta();
        double double66 = vector3D58.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D53.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line69 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D58, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = line49.intersection(line69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane79 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D74, vector3D78);
        double double80 = vector3D78.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D81 = line69.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D78);
        double double82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D27, vector3D78);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D78.orthogonal();
        double double84 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D78);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.09966370236491838d + "'", double45 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.09966370236491838d + "'", double65 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNull(vector3D70);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 10101.0d + "'", double80 == 10101.0d);
        org.junit.Assert.assertNotNull(vector1D81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray4 = polygonsSet3.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, localizable2, (java.lang.Object[]) vector2DArray4);
        org.junit.Assert.assertNotNull(vector2DArray4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.1102230246251565E-16d, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        double double15 = vector3D10.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        double double16 = vector3D10.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane25 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double31 = vector3D30.getDelta();
        java.lang.String str32 = vector3D30.toString();
        boolean boolean33 = vector3D30.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double40 = vector3D39.getDelta();
        java.lang.String str41 = vector3D39.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double47 = vector3D46.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj52 = null;
        boolean boolean53 = vector3D51.equals(obj52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double58 = vector3D57.getDelta();
        double double59 = vector3D51.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D46.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D30.subtract((double) (byte) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double double64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D10, vector3D24);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.2290500999999993E7d + "'", double15 == 2.2290500999999993E7d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.240252676230739E-13d + "'", double16 == 5.240252676230739E-13d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.09966370236491838d + "'", double31 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{100; 1; 10}" + "'", str32.equals("{100; 1; 10}"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.09966370236491838d + "'", double40 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{100; 1; 10}" + "'", str41.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.09966370236491838d + "'", double58 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 6.4613869810159485E-12d + "'", double64 == 6.4613869810159485E-12d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = line39.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Line line42 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = line39.pointAt(0.009999666686665238d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double49 = vector3D48.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj54 = null;
        boolean boolean55 = vector3D53.equals(obj54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double60 = vector3D59.getDelta();
        double double61 = vector3D53.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double66 = vector3D65.getY();
        double double67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D53, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane68 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D65);
        double double69 = vector3D48.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = line39.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.09966370236491838d + "'", double49 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.09966370236491838d + "'", double60 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D70);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        double double5 = vector2D3.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double7 = vector2D6.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.negate();
        double double9 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double12 = vector2D11.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D1, Double.POSITIVE_INFINITY, vector2D3, 2.718281828459045d, vector2D11);
        boolean boolean14 = vector2D11.isInfinite();
        boolean boolean16 = vector2D11.equals((java.lang.Object) true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double19 = vector2D18.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double21 = vector2D20.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet22 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector23 = polygonsSet22.getBarycenter();
        double double24 = vector2D20.dotProduct(euclidean2DVector23);
        double double25 = vector2D20.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double double28 = vector2D26.getNorm();
        double double29 = vector2D26.getX();
        double double30 = vector2D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double31 = vector2D18.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double32 = vector2D18.getX();
        double double33 = vector2D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D17.scalarMultiply((-478.5692967842504d));
        double double36 = vector2D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.NEGATIVE_INFINITY + "'", double32 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = line20.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane30.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39);
        org.apache.commons.math3.geometry.partitioning.Side side42 = subPlane31.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double45 = vector2D44.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double47 = vector2D46.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet48 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector49 = polygonsSet48.getBarycenter();
        double double50 = vector2D46.dotProduct(euclidean2DVector49);
        double double51 = vector2D46.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray53 = vector2D52.toArray();
        double double54 = vector2D52.getNorm();
        double double55 = vector2D52.getX();
        double double56 = vector2D46.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        double double57 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        double double58 = vector2D44.getX();
        double double59 = vector2D43.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double60 = vector2D44.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = plane41.getPointAt(vector2D44, 1.401298464324817E-45d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D66, vector3D70);
        double double72 = vector3D70.getNormSq();
        line21.reset(vector3D62, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Line line74 = line21.revert();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(line20);
        org.junit.Assert.assertNotNull(line21);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertTrue("'" + side42 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side42.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.NEGATIVE_INFINITY + "'", double47 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.POSITIVE_INFINITY + "'", double55 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.NEGATIVE_INFINITY + "'", double58 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 10101.0d + "'", double72 == 10101.0d);
        org.junit.Assert.assertNotNull(line74);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8745129512124437d + "'", double1 == 0.8745129512124437d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int[] intArray1 = new int[] { 0 };
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        int[] intArray6 = new int[] { (byte) 10, (-100), 10 };
        double double7 = org.apache.commons.math3.util.MathArrays.distance(intArray2, intArray6);
        try {
            int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane10 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D14, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane20 = plane19.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane22 = subPlane9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane33 = subPlane32.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane34 = subPlane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane33);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree35 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) subPlane9);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane36 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane37 = subPlane9.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane38 = euclidean3DAbstractSubHyperplane37.copySelf();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(subPlane20);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane22);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane33);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane34);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane36);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane37);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet21 = plane19.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double39 = vector3D38.getDelta();
        java.lang.String str40 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D38, (double) 0.0f, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double57 = vector3D56.getDelta();
        java.lang.String str58 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D56.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D26, 0.09966370236491838d, vector3D38, 6.283185307179586d, vector3D49, (double) 100L, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double66 = vector3D65.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj71 = null;
        boolean boolean72 = vector3D70.equals(obj71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double77 = vector3D76.getDelta();
        double double78 = vector3D70.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D65.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line81 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Line line82 = line81.revert();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane83 = polyhedronsSet21.firstIntersection(vector3D61, line81);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector84 = polyhedronsSet21.getBarycenter();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(polyhedronsSet21);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.09966370236491838d + "'", double39 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{100; 1; 10}" + "'", str40.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.09966370236491838d + "'", double57 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{100; 1; 10}" + "'", str58.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.09966370236491838d + "'", double77 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(line82);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane83);
        org.junit.Assert.assertNotNull(euclidean3DVector84);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double1 = vector2D0.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet2 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector3 = polygonsSet2.getBarycenter();
        double double4 = vector2D0.dotProduct(euclidean2DVector3);
        double double5 = vector2D0.getNormSq();
        double double6 = vector2D0.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray9 = vector2D8.toArray();
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray14 = vector2D13.toArray();
        double double15 = vector2D13.getNorm();
        boolean boolean16 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment18 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D8, vector2D13, line17);
        double double19 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double21 = vector2D20.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet22 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector23 = polygonsSet22.getBarycenter();
        double double24 = vector2D20.dotProduct(euclidean2DVector23);
        double double25 = vector2D20.getNormSq();
        double double26 = vector2D20.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray29 = vector2D28.toArray();
        double double30 = vector2D28.getNorm();
        double double31 = vector2D28.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray34 = vector2D33.toArray();
        double double35 = vector2D33.getNorm();
        boolean boolean36 = vector2D33.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment38 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D28, vector2D33, line37);
        double double39 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D13, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D13.normalize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.NEGATIVE_INFINITY + "'", double39 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = vector3D3.equals(obj4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double10 = vector3D9.getDelta();
        double double11 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double16 = vector3D15.getY();
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D15.scalarMultiply(0.0d);
        double double20 = vector3D19.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.getZero();
        double[] doubleArray22 = vector3D19.toArray();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.09966370236491838d + "'", double10 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion2 = polyhedronsSet0.applyTransform(euclidean3DTransform1);
        double double3 = polyhedronsSet0.getSize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane13 = plane12.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21);
        org.apache.commons.math3.geometry.partitioning.Side side24 = subPlane13.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double30 = vector3D29.getDelta();
        java.lang.String str31 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D25, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double38 = vector3D37.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj43 = null;
        boolean boolean44 = vector3D42.equals(obj43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double49 = vector3D48.getDelta();
        double double50 = vector3D42.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D37.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        double double52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D33, vector3D42);
        plane23.reset(vector3D32, vector3D33);
        double double54 = vector3D33.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation55 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet56 = polyhedronsSet0.rotate(vector3D33, rotation55);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(subPlane13);
        org.junit.Assert.assertTrue("'" + side24 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side24.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.09966370236491838d + "'", double30 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{100; 1; 10}" + "'", str31.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.09966370236491838d + "'", double49 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 99.0d + "'", double52 == 99.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet56);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D1, (double) 30.0f, vector1D3, 0.09966370236491838d, vector1D5, (double) 100L, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D10, (double) 30.0f, vector1D12, 0.09966370236491838d, vector1D14, (double) 100L, vector1D16);
        double double18 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D21, (double) 30.0f, vector1D23, 0.09966370236491838d, vector1D25, (double) 100L, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D30, (double) 30.0f, vector1D32, 0.09966370236491838d, vector1D34, (double) 100L, vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D38.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint44 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D42, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = orientedPoint44.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint49 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D47, true);
        boolean boolean50 = orientedPoint49.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint51 = orientedPoint49.copySelf();
        boolean boolean52 = orientedPoint44.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = orientedPoint49.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1024.0f, vector1D39, (-0.1761977896489369d), vector1D53);
        double double55 = vector1D39.getX();
        double double56 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(orientedPoint45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(orientedPoint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double14 = vector3D13.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D13);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList16 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet17 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray18 = polygonsSet17.getVertices();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet17);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.09966370236491838d + "'", double14 == 0.09966370236491838d);
        org.junit.Assert.assertNotNull(vector2DArray18);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine53 = line22.wholeHyperplane();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(subLine53);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17);
        org.apache.commons.math3.geometry.partitioning.Side side20 = subPlane9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane19);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet21 = plane19.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double39 = vector3D38.getDelta();
        java.lang.String str40 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D34, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D38, (double) 0.0f, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj50 = null;
        boolean boolean51 = vector3D49.equals(obj50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double57 = vector3D56.getDelta();
        java.lang.String str58 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D56.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D26, 0.09966370236491838d, vector3D38, 6.283185307179586d, vector3D49, (double) 100L, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double66 = vector3D65.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj71 = null;
        boolean boolean72 = vector3D70.equals(obj71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double77 = vector3D76.getDelta();
        double double78 = vector3D70.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D65.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line81 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Line line82 = line81.revert();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane83 = polyhedronsSet21.firstIntersection(vector3D61, line81);
        double double84 = polyhedronsSet21.getSize();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertTrue("'" + side20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side20.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
        org.junit.Assert.assertNotNull(polyhedronsSet21);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.09966370236491838d + "'", double39 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{100; 1; 10}" + "'", str40.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.09966370236491838d + "'", double57 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{100; 1; 10}" + "'", str58.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.09966370236491838d + "'", double77 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(line82);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double24 = vector3D23.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = vector3D28.equals(obj29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double35 = vector3D34.getDelta();
        double double36 = vector3D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D23.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = line19.intersection(line39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D44, vector3D48);
        double double50 = vector3D48.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line39.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line39.getDirection();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.09966370236491838d + "'", double35 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 10101.0d + "'", double50 == 10101.0d);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector3D52);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = vector3D8.equals(obj9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double15 = vector3D14.getDelta();
        double double16 = vector3D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D3.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Line line19 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = line19.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = line19.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09966370236491838d + "'", double15 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(line20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector3D22);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.7453292519943295d, 1.401298464324817E-45d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = plane11.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane13 = plane11.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane14 = subPlane13.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane43 = plane42.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane42);
        boolean boolean45 = plane33.isSimilarTo(plane44);
        boolean boolean46 = plane24.isSimilarTo(plane33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane47 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane33);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane48 = subPlane13.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane33);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = plane33.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = plane33.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = plane33.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = plane33.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = plane33.getU();
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D2, vector3D53);
        org.junit.Assert.assertNotNull(subPlane12);
        org.junit.Assert.assertNotNull(subPlane13);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane14);
        org.junit.Assert.assertNotNull(subPlane43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane48);
        org.junit.Assert.assertNotNull(plane49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.995037190209989d + "'", double54 == 0.995037190209989d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>> euclidean2DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>>) euclidean2DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray2 = polygonsSet1.getVertices();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform3 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion4 = polygonsSet1.applyTransform(euclidean2DTransform3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree6 = euclidean2DAbstractRegion4.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree6);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform8 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractRegion9 = polygonsSet7.applyTransform(euclidean2DTransform8);
        org.junit.Assert.assertNotNull(vector2DArray2);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion4);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree6);
        org.junit.Assert.assertNotNull(euclidean2DAbstractRegion9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.scalarMultiply(1.5860134523134298E15d);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math3.util.FastMath.floor((-12.280647771556916d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.0d) + "'", double1 == (-13.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math3.util.FastMath.tan(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int[] intArray1 = new int[] { 0 };
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        int[] intArray4 = new int[] { 0 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        int int6 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray5);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2, 0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector4 = polygonsSet3.getBarycenter();
        double double5 = vector2D1.dotProduct(euclidean2DVector4);
        double double6 = vector2D1.getNormSq();
        double double7 = vector2D1.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        boolean boolean17 = vector2D14.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment19 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D9, vector2D14, line18);
        double double20 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment22 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D1, line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = segment22.getLine();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(line23);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = plane9.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double28 = vector3D27.getDelta();
        java.lang.String str29 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D23, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D27, (double) 0.0f, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = vector3D38.equals(obj39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double46 = vector3D45.getDelta();
        java.lang.String str47 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D45.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 890547225L, vector3D15, 0.09966370236491838d, vector3D27, 6.283185307179586d, vector3D38, (double) 100L, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double56 = vector3D55.getDelta();
        java.lang.String str57 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D51, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double63 = vector3D62.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        java.lang.Object obj68 = null;
        boolean boolean69 = vector3D67.equals(obj68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        double double74 = vector3D73.getDelta();
        double double75 = vector3D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        plane9.reset(vector3D45, vector3D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double80 = vector2D79.getX();
        double double81 = vector2D79.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double83 = vector2D82.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D82.negate();
        double double85 = vector2D79.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane9.getPointAt(vector2D79, (double) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = vector3D87.orthogonal();
        org.junit.Assert.assertNotNull(plane10);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.09966370236491838d + "'", double28 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{100; 1; 10}" + "'", str29.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.09966370236491838d + "'", double46 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{100; 1; 10}" + "'", str47.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.09966370236491838d + "'", double56 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{100; 1; 10}" + "'", str57.equals("{100; 1; 10}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.09966370236491838d + "'", double74 == 0.09966370236491838d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.NEGATIVE_INFINITY + "'", double80 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.NEGATIVE_INFINITY + "'", double81 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + Double.NEGATIVE_INFINITY + "'", double83 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(vector3D88);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        boolean boolean4 = orientedPoint3.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet7.buildNew(euclidean1DBSPTree9);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector11 = intervalsSet7.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D13, true);
        boolean boolean16 = orientedPoint15.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.660700274874677d, (double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = orientedPoint24.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) '#');
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D27, true);
        boolean boolean30 = orientedPoint29.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = orientedPoint29.copySelf();
        boolean boolean32 = orientedPoint24.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint29);
        org.apache.commons.math3.geometry.partitioning.Side side33 = intervalsSet19.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint29);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree35 = intervalsSet19.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = intervalsSet7.buildNew(euclidean1DBSPTree35);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intervalsSet10);
        org.junit.Assert.assertNotNull(euclidean1DVector11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(orientedPoint25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(orientedPoint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree35);
        org.junit.Assert.assertNotNull(intervalsSet36);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(110.0d, (double) (short) -1, 4720.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 100, (double) (short) 1, (double) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane8.wholeHyperplane();
        boolean boolean11 = subPlane10.isEmpty();
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (byte) -1, (double) (-33553471));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        double double4 = vector2D2.getNorm();
        double double5 = vector2D2.getX();
        double double6 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment8 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D2, line7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = segment8.getEnd();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = segment8.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment8);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane12 = subLine11.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray15 = vector2D14.toArray();
        double double16 = vector2D14.getNorm();
        double double17 = vector2D14.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.5474944974040916d, vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray20 = vector2D19.toArray();
        double double21 = vector2D19.getNorm();
        boolean boolean22 = vector2D19.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment24 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D14, vector2D19, line23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = segment24.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment24);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = subLine11.intersection(subLine26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNull(euclidean2DHyperplane12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(vector2D25);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(1.5474944974040916d, (double) (-100));
        double double3 = intervalsSet2.getSize();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-101.54749449740409d) + "'", double3 == (-101.54749449740409d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 890547225L, (float) 1023);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1023.0f + "'", float2 == 1023.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double2 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double4 = vector2D3.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector6 = polygonsSet5.getBarycenter();
        double double7 = vector2D3.dotProduct(euclidean2DVector6);
        double double8 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray10 = vector2D9.toArray();
        double double11 = vector2D9.getNorm();
        double double12 = vector2D9.getX();
        double double13 = vector2D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double14 = vector2D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        double double15 = vector2D1.getX();
        double double16 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D0.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double25 = vector2D24.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double27 = vector2D26.getX();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet28 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector29 = polygonsSet28.getBarycenter();
        double double30 = vector2D26.dotProduct(euclidean2DVector29);
        double double31 = vector2D26.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double double34 = vector2D32.getNorm();
        double double35 = vector2D32.getX();
        double double36 = vector2D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double37 = vector2D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double38 = vector2D24.getX();
        double double39 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D23.scalarMultiply((-478.5692967842504d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 0.0f, 1.0000000000000002d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double[] doubleArray47 = vector2D46.toArray();
        double double48 = vector2D46.getNorm();
        double double49 = vector2D46.getX();
        double double50 = vector2D46.getNorm();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        boolean boolean52 = line22.isParallelTo(line45);
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D55, (double) 30.0f, vector1D57, 0.09966370236491838d, vector1D59, (double) 100L, vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L, vector1D64, (double) 30.0f, vector1D66, 0.09966370236491838d, vector1D68, (double) 100L, vector1D70);
        double double72 = vector1D61.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D70);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint74 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D70, true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = line22.getPointAt(vector1D70, (double) (byte) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double81 = vector2D80.getX();
        double double82 = vector2D80.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double84 = vector2D83.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = vector2D83.negate();
        double double86 = vector2D80.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double double89 = vector2D88.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.5440211108893698d), vector2D78, Double.POSITIVE_INFINITY, vector2D80, 2.718281828459045d, vector2D88);
        boolean boolean91 = vector2D88.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D92 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double93 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D88, vector2D92);
        double double94 = vector2D92.getNorm();
        double double95 = vector2D76.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D92);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean2DVector29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + Double.NEGATIVE_INFINITY + "'", double81 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + Double.NEGATIVE_INFINITY + "'", double82 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + Double.NEGATIVE_INFINITY + "'", double84 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + Double.POSITIVE_INFINITY + "'", double86 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + Double.NEGATIVE_INFINITY + "'", double89 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(vector2D92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + Double.POSITIVE_INFINITY + "'", double93 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertEquals((double) double95, Double.NaN, 0);
    }
}

