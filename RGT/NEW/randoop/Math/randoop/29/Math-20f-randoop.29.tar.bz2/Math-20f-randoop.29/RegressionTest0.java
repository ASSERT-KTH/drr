import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (byte) 100, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_RANDOMGENERATOR;
        org.junit.Assert.assertNotNull(randomGenerator0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) (-1L), (double) (-1.0f), (double) 0, 0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = blockRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "hi!", "hi!", "", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix2.power((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray7 = new int[] {};
        try {
            mersenneTwister6.setSeed(intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) (short) 1, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray6 = new double[] { 10L, '4', 11013.232874703393d, 100.0f, '#', 10 };
        double[] doubleArray12 = new double[] { 100, 100.0d, 'a', 0, 100.0f };
        try {
            double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        double[] doubleArray9 = new double[] {};
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.distance(doubleArray8, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int[] intArray3 = new int[] { ' ', (byte) 0, (short) 10 };
        int[] intArray5 = new int[] { (short) 100 };
        try {
            int int6 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray3, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray0 = new double[] {};
        double[][] doubleArray1 = new double[][] { doubleArray0 };
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        try {
            double double21 = blockRealMatrix13.getEntry(97, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (short) 1, 0.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray15 = null;
        try {
            blockRealMatrix2.copySubMatrix((int) '4', 0, (int) (short) -1, 0, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        try {
            org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix10.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        double[] doubleArray24 = new double[] { ' ', (byte) -1, 0.0d, 10.0f };
        try {
            double[] doubleArray25 = blockRealMatrix10.operate(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double[] doubleArray4 = new double[] { 0, (-1.0d), (byte) 1, 0L };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector13.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector18.setEntry(0, (double) 10.0f);
        double double22 = arrayRealVector13.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector24);
        try {
            blockRealMatrix9.setRowVector((int) (byte) 10, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector14.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        double double23 = arrayRealVector14.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double24 = arrayRealVector14.getNorm();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector14.append(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector6.combine((double) ' ', (double) (byte) 1, realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 101");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double11 = arrayRealVector1.getNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector1.append(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector27.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        double double36 = arrayRealVector27.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, arrayRealVector27);
        try {
            arrayRealVector1.setSubVector(1, (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((-1.0d), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        int[] intArray16 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister(intArray16);
        int[] intArray18 = new int[] {};
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix10, intArray16, intArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        try {
            double double13 = blockRealMatrix10.getEntry((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float2 = org.apache.commons.math3.util.FastMath.min(100.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector23.setEntry(0, (double) 10.0f);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        int[] intArray21 = new int[] { 10, (byte) 100 };
        int[] intArray27 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix29 = blockRealMatrix10.getSubMatrix(intArray21, intArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) 10, 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSeparator();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        try {
            blockRealMatrix19.setColumnMatrix((int) ' ', (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor7, 0, (int) (short) 1, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed(1L);
        mersenneTwister6.setSeed((long) ' ');
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.23115483517811797d + "'", double0 == 0.23115483517811797d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        try {
            blockRealMatrix2.setColumnVector((int) (short) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 100.0f);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100.0f + "'", number2.equals(100.0f));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix13.getRowMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        double[] doubleArray14 = new double[] { 0, 'a', (byte) 0 };
        double[] doubleArray18 = new double[] { 0, 'a', (byte) 0 };
        double[] doubleArray22 = new double[] { 0, 'a', (byte) 0 };
        double[] doubleArray26 = new double[] { 0, 'a', (byte) 0 };
        double[] doubleArray30 = new double[] { 0, 'a', (byte) 0 };
        double[][] doubleArray31 = new double[][] { doubleArray14, doubleArray18, doubleArray22, doubleArray26, doubleArray30 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection10, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double26 = arrayRealVector16.getNorm();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector16.append(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector1.combineToSelf((-0.9999999999999999d), 3.831008000716577E22d, realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 101");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 97, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix19.add(blockRealMatrix22);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = blockRealMatrix6.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.RealVector realVector11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply(realVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = blockRealMatrix9.walkInOptimizedOrder(realMatrixPreservingVisitor11, (int) (byte) 100, (int) (byte) 1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("; ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = blockRealMatrix21.walkInOptimizedOrder(realMatrixChangingVisitor22, (int) (byte) 10, (int) (short) 1, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 10 after final row 1");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_MAXITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30000 + "'", int0 == 30000);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_ISACTIVECMA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (short) 0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix5.getRowMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealVector realVector9 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix5.preMultiply(realVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        try {
            org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector6.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        double[] doubleArray13 = blockRealMatrix10.getRow((int) (short) 1);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = cMAESOptimizer0.optimize((int) (byte) 0, multivariateFunction3, goalType4, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (short) 10, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        try {
            blockRealMatrix10.setEntry(10, (int) '4', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        double[] doubleArray19 = blockRealMatrix16.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray19);
        try {
            double[] doubleArray21 = blockRealMatrix2.preMultiply(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor19 = null;
        try {
            double double22 = arrayRealVector12.walkInOptimizedOrder(realVectorChangingVisitor19, (int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (short) -1, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix29.add(blockRealMatrix32);
        double double38 = blockRealMatrix37.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix10.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(2.718281828459045d, (double) (-1L), (double) 9.999999f, (double) (short) 10, (double) (byte) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1097.2817086347977d + "'", double6 == 1097.2817086347977d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (short) 100, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int1 = org.apache.commons.math3.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double[] doubleArray5 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        java.io.ObjectInputStream objectInputStream8 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray5, "", objectInputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 141.77799547179387d + "'", double6 == 141.77799547179387d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) '4');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_CHECKFEASABLECOUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector13.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix6.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        try {
            blockRealMatrix2.setRowMatrix((int) (short) 0, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector1.walkInOptimizedOrder(realVectorPreservingVisitor11, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = realMatrixFormat0.parse("", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1L), (float) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray5 = new double[] { 1.0f, 100.0f, 10.0d, (-0.9999999999999999d), (short) -1 };
        double[] doubleArray9 = new double[] { 1097.2817086347977d, 2.718281828459045d, 0.0d };
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix19.add(blockRealMatrix22);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double30 = blockRealMatrix27.walkInRowOrder(realMatrixChangingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix19.add(blockRealMatrix22);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix27);
        java.io.ObjectOutputStream objectOutputStream29 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27, objectOutputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix25.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix30, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector44.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, arrayRealVector44);
        double[] doubleArray49 = blockRealMatrix30.operate(doubleArray41);
        try {
            blockRealMatrix2.setColumn((int) (short) 0, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(52.0d, 10.0d, 0.0d, (double) (byte) 10, 0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 520.0d + "'", double6 == 520.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix9.getColumnVector(30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        try {
            double double22 = blockRealMatrix21.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x10) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray10);
        mersenneTwister6.clear();
        try {
            int int14 = mersenneTwister6.nextInt((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 10L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = blockRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = noDataException1.getContext();
        java.lang.Throwable[] throwableArray3 = noDataException1.getSuppressed();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) noDataException1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray15 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double16 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray15);
        try {
            double double17 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 141.77799547179387d + "'", double16 == 141.77799547179387d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix29.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix26.add(blockRealMatrix29);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix34, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix39.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix42);
        double[] doubleArray45 = blockRealMatrix42.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector48.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45, arrayRealVector48);
        double[] doubleArray53 = blockRealMatrix34.operate(doubleArray45);
        try {
            double double54 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (short) 1, (double) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        java.io.ObjectInputStream objectInputStream8 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) arrayRealVector1, "hi!", objectInputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.732511156817248d, 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.732511156817248d + "'", double2 == 3.732511156817248d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(30000, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix23, (int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math3.util.FastMath.log10(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5720011145449331d + "'", double1 == 0.5720011145449331d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { (-1.0d), 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (byte) 0, localizable3, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (short) 1, (java.lang.Object[]) doubleArray6);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 20 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math3.util.FastMath.atan(141.77799547179387d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5637431630493914d + "'", double1 == 1.5637431630493914d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(3.732511156817248d, (double) 30000, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (short) -1, 1.4E-45f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector11);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = null;
        try {
            boolean boolean18 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray8, orderDirection16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math3.util.FastMath.floor(520.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 520.0d + "'", double1 == 520.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.000004f + "'", float1 == 52.000004f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        try {
            blockRealMatrix18.addToEntry(10, (int) (short) 0, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor12, 0, (int) (byte) -1, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        double[] doubleArray21 = null;
        try {
            double[] doubleArray22 = blockRealMatrix18.operate(doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector2.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector7.setEntry(0, (double) 10.0f);
        double double11 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double double12 = arrayRealVector2.getNorm();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector2.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector2.mapSubtractToSelf(0.0d);
        double[] doubleArray17 = arrayRealVector2.toArray();
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) (short) 100, true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (short) 0, 0.0d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 10L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.apache.commons.math3.optimization.GoalType goalType1 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.apache.commons.math3.optimization.GoalType[] goalTypeArray2 = new org.apache.commons.math3.optimization.GoalType[] { goalType0, goalType1 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        try {
            boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray2, orderDirection3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType1 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType1.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_DIAGONALONLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("}", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(3.732511156817248d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray12);
        try {
            int int15 = multiDimensionMismatchException13.getExpectedDimension((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        try {
            blockRealMatrix5.setEntry((int) (byte) -1, (int) (short) 1, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = blockRealMatrix10.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) (short) 10, 0, 100, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 141.77799547179387d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.5720011145449331d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        int int11 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector14.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        double double23 = arrayRealVector14.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, false);
        double double31 = arrayRealVector14.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        try {
            blockRealMatrix2.setColumnVector(10, (org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer0.getStatisticsSigmaHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer0.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = blockRealMatrix12.walkInRowOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math3.util.FastMath.atan(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray5 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19);
        double[][] doubleArray21 = blockRealMatrix19.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 141.77799547179387d + "'", double6 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 52.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053128792867638d) + "'", double1 == (-6.053128792867638d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray13);
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) intArray13);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector1.mapToSelf(univariateFunction13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor0 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double1 = defaultRealMatrixPreservingVisitor0.end();
        defaultRealMatrixPreservingVisitor0.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        defaultRealMatrixPreservingVisitor0.visit((int) (short) -1, (int) (short) 100, 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 30000, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = blockRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix6.getRowVector((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix6, 13, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (13)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        try {
            double double24 = blockRealMatrix13.getEntry((int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0f));
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 100, (java.lang.Number) 1.0f, true);
        notPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooLargeException6);
        java.lang.Number number8 = numberIsTooLargeException6.getMax();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix21.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor30 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double31 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor30);
        defaultRealMatrixPreservingVisitor30.start(0, 0, (int) (byte) 100, (int) '#', 0, (int) (byte) 1);
        try {
            double double43 = blockRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor30, (int) (short) -1, 10, (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double double35 = arrayRealVector23.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        try {
            blockRealMatrix18.setRowVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.0d + "'", double35 == 10.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math3.util.FastMath.acos(520.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1L), Double.NEGATIVE_INFINITY, (double) (byte) 0, 1097.2817086347977d, Double.NaN, (double) 0.0f);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0f));
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = blockRealMatrix26.scalarMultiply((double) 0L);
        try {
            blockRealMatrix2.setRowMatrix(30000, realMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { (-1.0d), 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double5 = arrayRealVector3.walkInOptimizedOrder(realVectorPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double26 = blockRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor21, 100, (int) (byte) 100, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray5 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 141.77799547179387d + "'", double6 == 141.77799547179387d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 0L, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix33.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = blockRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor45 = null;
        try {
            double double50 = blockRealMatrix18.walkInOptimizedOrder(realMatrixPreservingVisitor45, 0, 0, (int) (byte) 100, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0f));
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 100, (java.lang.Number) 1.0f, true);
        notPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooLargeException6);
        boolean boolean8 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number9 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 1, 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.2676506E30f + "'", float2 == 1.2676506E30f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.NoDataException noDataException3 = new org.apache.commons.math3.exception.NoDataException(localizable2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = noDataException3.getContext();
        java.lang.Throwable[] throwableArray5 = noDataException3.getSuppressed();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 52.000004f, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "]" + "'", str1.equals("]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        double double35 = blockRealMatrix34.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix34.getSubMatrix(30000, 30000, 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 27.18281828459045d + "'", double35 == 27.18281828459045d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) (byte) 10, 1, orderDirection3, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        double[] doubleArray23 = null;
        try {
            blockRealMatrix18.setColumn((int) (byte) -1, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        double[][] doubleArray11 = null;
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection10, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        double[] doubleArray53 = blockRealMatrix50.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector56.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53, arrayRealVector56);
        try {
            blockRealMatrix18.setRow((int) (short) 100, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.add(blockRealMatrix14);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix19, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double[] doubleArray30 = blockRealMatrix27.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector33.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector33);
        double[] doubleArray38 = blockRealMatrix19.operate(doubleArray30);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition39 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1097.2817086347977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix5.getRowMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        int int2 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray10);
        mersenneTwister6.clear();
        boolean boolean13 = mersenneTwister6.nextBoolean();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector9.copy();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077936128 + "'", int1 == 1077936128);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        float float2 = org.apache.commons.math3.util.FastMath.max((-1.0f), (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (byte) -1, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 10.0f);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.5720011145449331d, (double) (short) 1, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber(",", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        boolean boolean1 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        boolean boolean7 = arrayRealVector1.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector1.unitVector();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        double[] doubleArray12 = arrayRealVector1.toArray();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getPrefix();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector11.mapDivide((double) (-1));
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor18 = null;
        try {
            double double19 = arrayRealVector11.walkInDefaultOrder(realVectorChangingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray0, 52.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix19.add(blockRealMatrix22);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = blockRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor29, (int) ' ', (int) (short) 1, (int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 1077936128);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int2 = org.apache.commons.math3.util.FastMath.min(13, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        int int1 = cMAESOptimizer0.getMaxEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        double double15 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11);
        int int29 = arrayRealVector28.getMaxIndex();
        double[] doubleArray30 = arrayRealVector28.getDataRef();
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair31 = cMAESOptimizer0.optimize((int) (byte) 0, multivariateFunction3, goalType4, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 30000, (java.lang.Number) (-1.0f));
        java.lang.Throwable[] throwableArray4 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 30000, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.String str5 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [30,000, -1] range" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: -1 out of [30,000, -1] range"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        boolean boolean7 = arrayRealVector1.isInfinite();
        double double8 = arrayRealVector1.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector1.mapDivide((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 1);
        incrementor1.resetCount();
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix47);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.5707963267948966d), (double) (short) 0, (double) 10L, (double) 1077936128);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.077936128E10d + "'", double4 == 1.077936128E10d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector27.setEntry(0, (double) 10.0f);
        double double31 = arrayRealVector22.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double double32 = arrayRealVector22.getNorm();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector22.mapSubtractToSelf((double) 1L);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18, realVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 30000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.802665441867374d) + "'", double1 == (-0.802665441867374d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapMultiplyToSelf(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_STOPFITNESS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) '4', (int) ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(1.077936128E10d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0779361279999998E10d + "'", double2 == 1.0779361279999998E10d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 13, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        defaultRealMatrixPreservingVisitor11.start(10, 13, 0, 30000, 97, (-127));
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.0779361279999998E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 13, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        try {
            double double15 = blockRealMatrix2.getEntry(30, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        arrayRealVector11.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector14.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        double double23 = arrayRealVector14.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double24 = arrayRealVector14.getNorm();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector14.append(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector11.add(realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 101");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) (short) 1, (double) 'a', 1.0779361279999998E10d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0455980441599998E12d + "'", double4 == 1.0455980441599998E12d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.5720011145449331d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24260312498277528d) + "'", double1 == (-0.24260312498277528d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray5 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector9.mapToSelf(univariateFunction10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 141.77799547179387d + "'", double6 == 141.77799547179387d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = blockRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor7, (-127), (-127), 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { (-1.0d), 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.exception.ZeroException zeroException5 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix53.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor56 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor56.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double64 = blockRealMatrix55.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor56);
        try {
            double double69 = blockRealMatrix18.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor56, 100, (int) (byte) 10, (int) (short) -1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int2 = org.apache.commons.math3.util.FastMath.max(13, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (byte) -1, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix23.getSubMatrix(30000, (int) (short) -1, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(0.0d, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix18.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix18.scalarAdd(1097.2817086347977d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix39.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix42);
        double[] doubleArray45 = blockRealMatrix42.getRow((int) (short) 1);
        blockRealMatrix27.setRow(0, doubleArray45);
        try {
            double[] doubleArray47 = blockRealMatrix18.preMultiply(doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 1L, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix13.walkInColumnOrder(realMatrixChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("}", "", "hi!");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(30000);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector1.mapDivide((double) (byte) 1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor15 = null;
        try {
            double double18 = arrayRealVector1.walkInOptimizedOrder(realVectorPreservingVisitor15, (int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -10 + "'", byte2 == (byte) -10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector25.copy();
        double[] doubleArray36 = arrayRealVector25.toArray();
        double[] doubleArray37 = array2DRowRealMatrix13.operate(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        double[][] doubleArray49 = blockRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = defaultRealMatrixPreservingVisitor52.end();
        defaultRealMatrixPreservingVisitor52.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double61 = array2DRowRealMatrix51.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = array2DRowRealMatrix13.multiply(array2DRowRealMatrix51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 10.0f, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("}", "", "hi!");
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse("}", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) -10, (float) 100, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector3.copy();
        double[] doubleArray14 = arrayRealVector3.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector1.append((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        boolean boolean16 = arrayRealVector1.isNaN();
        try {
            arrayRealVector1.addToEntry(1077936128, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        try {
            double[] doubleArray25 = array2DRowRealMatrix13.getRow((int) (byte) -10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat1.parse("org.apache.commons.math3.exception.OutOfRangeException: -1 out of [30,000, -1] range", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector12.mapMultiplyToSelf((double) '#');
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor45 = null;
        try {
            double double48 = arrayRealVector12.walkInOptimizedOrder(realVectorChangingVisitor45, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        try {
            double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, 0.9999999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        boolean boolean21 = blockRealMatrix18.isSquare();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = defaultRealMatrixPreservingVisitor22.end();
        defaultRealMatrixPreservingVisitor22.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double31 = blockRealMatrix18.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        int[] intArray32 = null;
        int[] intArray38 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister39 = new org.apache.commons.math3.random.MersenneTwister(intArray38);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister40 = new org.apache.commons.math3.random.MersenneTwister(intArray38);
        org.apache.commons.math3.exception.util.Localizable localizable41 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[][] doubleArray54 = blockRealMatrix52.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException56 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable41, (java.lang.Number) (short) 0, (java.lang.Object[]) doubleArray54);
        try {
            blockRealMatrix18.copySubMatrix(intArray32, intArray38, doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 100L, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.00001f + "'", float2 == 100.00001f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100, (double) ' ');
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor3, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.077936128E10d, (double) 9.999999f, (double) 52.000004f, 1.0d, 1.5574077246549023d, (double) 6490845983449753485L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0108893781963495E19d + "'", double6 == 1.0108893781963495E19d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[][] doubleArray2 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (short) 100, doubleArray2, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        boolean boolean21 = blockRealMatrix18.isSquare();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = defaultRealMatrixPreservingVisitor22.end();
        defaultRealMatrixPreservingVisitor22.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double31 = blockRealMatrix18.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(100);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix16.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.add(blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor35 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor35.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double43 = blockRealMatrix34.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        try {
            blockRealMatrix12.setRowMatrix(30000, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, (double) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(97, (int) (short) -1);
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector13.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, false);
        boolean boolean19 = arrayRealVector13.isInfinite();
        double double20 = arrayRealVector13.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = arrayRealVector11.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math3.util.FastMath.abs(1097.2817086347977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1097.2817086347977d + "'", double1 == 1097.2817086347977d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440203106881555d) + "'", double1 == (-0.5440203106881555d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        double[] doubleArray10 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        try {
            double[] doubleArray20 = blockRealMatrix13.getRow((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = blockRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor22, (int) (byte) 10, 0, 30000, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, false);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) 1.4E-45f);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector15.combine((double) '4', 1.1102230246251565E-14d, realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 200 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (int) (short) 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.5720011145449331d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5720011145449332d + "'", double1 == 0.5720011145449332d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix13.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray7 = new double[] { (-1), 1.5637431630493914d, 10L, 10L, 1.5637431630493914d, 27.18281828459045d };
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) ' ', doubleArray7);
        java.util.List<java.lang.Double> doubleList9 = cMAESOptimizer8.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleList9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector1.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        double[] doubleArray33 = blockRealMatrix30.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector24, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector1.append(arrayRealVector34);
        try {
            org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector34.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        try {
            double double61 = eigenDecomposition59.getRealEigenvalue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', (int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector4.setEntry(0, (double) 10.0f);
        double[] doubleArray13 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, doubleArray13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 105");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 141.77799547179387d + "'", double14 == 141.77799547179387d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-0.24260312498277528d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7845828333154817d + "'", double1 == 0.7845828333154817d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSuffix();
        java.text.NumberFormat numberFormat3 = realVectorFormat1.getFormat();
        java.lang.String str4 = realVectorFormat1.getPrefix();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        double double35 = blockRealMatrix33.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = blockRealMatrix33.transpose();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 27.18281828459045d + "'", double35 == 27.18281828459045d);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = blockRealMatrix2.scalarAdd((-6.053128792867638d));
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix48);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.subtract(realMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix18.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix18.scalarAdd(1097.2817086347977d);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = blockRealMatrix18.transpose();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor12.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double20 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        double[] doubleArray31 = blockRealMatrix11.preMultiply(doubleArray29);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double37 = blockRealMatrix11.walkInColumnOrder(realMatrixChangingVisitor32, (int) ' ', 0, 1077936128, (int) (byte) -10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 32 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 520.0d, number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix40);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix45.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix48.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor57 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double58 = blockRealMatrix48.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        double double59 = blockRealMatrix6.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor60 = null;
        try {
            double double65 = blockRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor60, 0, (int) (byte) 0, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        double[] doubleArray20 = blockRealMatrix17.getRow((int) (short) 1);
        blockRealMatrix2.setRow(0, doubleArray20);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor22 = null;
        try {
            double double27 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor22, (int) (byte) -10, 30, 30000, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 97, 1.0455980441599998E12d, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double[][] doubleArray19 = blockRealMatrix10.getData();
        int int20 = blockRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double34 = arrayRealVector22.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector38.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        double double47 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double48 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = arrayRealVector29.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector50 = blockRealMatrix10.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix54.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        double[] doubleArray60 = blockRealMatrix57.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray60);
        try {
            blockRealMatrix10.setRow(100, doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100, (double) ' ');
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf(0.5720011145449331d);
        try {
            java.lang.String str7 = realVectorFormat1.format(realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double[][] doubleArray19 = blockRealMatrix10.getData();
        int int20 = blockRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double34 = arrayRealVector22.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector38.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        double double47 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double48 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = arrayRealVector29.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector50 = blockRealMatrix10.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double52 = blockRealMatrix10.walkInOptimizedOrder(realMatrixChangingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, ",", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (short) 1, (double) (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray7 = new double[] { (-1), 1.5637431630493914d, 10L, 10L, 1.5637431630493914d, 27.18281828459045d };
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) ' ', doubleArray7);
        int int9 = cMAESOptimizer8.getMaxEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction11 = null;
        org.apache.commons.math3.optimization.GoalType goalType12 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        double[] doubleArray21 = blockRealMatrix18.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix25.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        double[] doubleArray31 = blockRealMatrix28.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        double[] doubleArray40 = blockRealMatrix37.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray40);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair42 = cMAESOptimizer8.optimize((-1), multivariateFunction11, goalType12, doubleArray21, doubleArray31, doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.add(blockRealMatrix14);
        double[][] doubleArray20 = blockRealMatrix11.getData();
        org.apache.commons.math3.exception.MathInternalError mathInternalError21 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        double[][] doubleArray12 = blockRealMatrix10.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray12);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix6.walkInRowOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix13.walkInRowOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getKey();
        double[] doubleArray48 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double49 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray48);
        try {
            double double50 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray42, doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 141.77799547179387d + "'", double49 == 141.77799547179387d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        long long1 = org.apache.commons.math3.util.FastMath.round((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(1, 0, (double) 10);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(2.718281828459045d, 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 100L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("]", (int) ' ');
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((-1.5707963267948966d), 1.0455980441599998E12d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.045598044058429E12d + "'", double3 == 1.045598044058429E12d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector1.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        double[] doubleArray33 = blockRealMatrix30.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector24, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector1.append(arrayRealVector34);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor37 = null;
        try {
            double double38 = arrayRealVector34.walkInDefaultOrder(realVectorPreservingVisitor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix16.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix20.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector24 = blockRealMatrix20.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = blockRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix29.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix29.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix37.add(blockRealMatrix40);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix45.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix20.subtract(blockRealMatrix47);
        org.apache.commons.math3.linear.RealVector realVector50 = blockRealMatrix20.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix53.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix56);
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = blockRealMatrix57.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector61 = blockRealMatrix57.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor62 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double63 = blockRealMatrix57.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor62);
        double double64 = blockRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor62);
        try {
            double double69 = array2DRowRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor62, 10, 10, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray13);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) Double.NaN, (java.lang.Object[]) intArray13);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.99038372622382d + "'", double1 == 51.99038372622382d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 97, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09684168599911366d + "'", double2 == 0.09684168599911366d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) intArray14);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray14);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        mersenneTwister7.setSeed((long) 52);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 10, 100.0f, (-127));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix54.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix51.add(blockRealMatrix54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor63 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double64 = blockRealMatrix54.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        defaultRealMatrixPreservingVisitor63.visit(0, (int) (byte) 0, 4.9E-324d);
        double double69 = blockRealMatrix6.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix6.add(realMatrix70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix38, (int) 'a');
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix38);
        int[] intArray47 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister48 = new org.apache.commons.math3.random.MersenneTwister(intArray47);
        int[] intArray54 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister55 = new org.apache.commons.math3.random.MersenneTwister(intArray54);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister56 = new org.apache.commons.math3.random.MersenneTwister(intArray54);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, intArray47, intArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.1102230246251565E-14d, (double) 1L, (-1.5707963267948966d), (double) 1077936128);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6932181103819134E9d) + "'", double4 == (-1.6932181103819134E9d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray12);
        java.lang.Integer[] intArray14 = multiDimensionMismatchException13.getWrongDimensions();
        int int16 = multiDimensionMismatchException13.getWrongDimension((int) (byte) 1);
        try {
            int int18 = multiDimensionMismatchException13.getExpectedDimension((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) (byte) 10, 1, orderDirection3, true);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        boolean boolean7 = nonMonotonicSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonicSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 10 + "'", number8.equals((byte) 10));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        try {
            org.apache.commons.math3.linear.RealVector realVector61 = eigenDecomposition59.getEigenvector(13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        boolean boolean21 = blockRealMatrix18.isSquare();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = defaultRealMatrixPreservingVisitor22.end();
        defaultRealMatrixPreservingVisitor22.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double31 = blockRealMatrix18.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix37.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 97, 9.999999f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double[][] doubleArray19 = blockRealMatrix10.getData();
        int int20 = blockRealMatrix10.getRowDimension();
        java.lang.String str21 = blockRealMatrix10.toString();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str21.equals("BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(13, 10);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix19.add(blockRealMatrix22);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix27);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix33 = blockRealMatrix5.getSubMatrix((int) (byte) 10, 0, 13, 13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10, (double) (byte) -10, 0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = blockRealMatrix5.scalarMultiply((-0.24260312498277528d));
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = blockRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1L), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 2.718281828459045d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1L, (double) 100L, (double) (byte) -10, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 110.0d + "'", double4 == 110.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector25.copy();
        double[] doubleArray36 = arrayRealVector25.toArray();
        double[] doubleArray37 = array2DRowRealMatrix13.operate(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        double[][] doubleArray49 = blockRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = defaultRealMatrixPreservingVisitor52.end();
        defaultRealMatrixPreservingVisitor52.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double61 = array2DRowRealMatrix51.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double[][] doubleArray62 = array2DRowRealMatrix51.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix51);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor64 = null;
        try {
            double double65 = array2DRowRealMatrix63.walkInColumnOrder(realMatrixChangingVisitor64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor24.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double32 = blockRealMatrix23.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray41);
        double[] doubleArray43 = blockRealMatrix23.preMultiply(doubleArray41);
        try {
            blockRealMatrix2.setRow((int) '#', doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-1L), (java.lang.Number) (short) 100, (java.lang.Number) 0.0f);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Class<?> wildcardClass6 = number5.getClass();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { (-1.0d), 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (byte) 0, localizable3, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (short) 1, (java.lang.Object[]) doubleArray6);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 53 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(0.99999994f, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector24.copy();
        double double35 = arrayRealVector34.getMaxValue();
        double double37 = arrayRealVector34.getEntry((int) (byte) 10);
        double double38 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.0d + "'", double35 == 10.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix40);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix45.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix48.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix34.subtract(blockRealMatrix48);
        try {
            blockRealMatrix20.setColumnMatrix(100, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        boolean boolean21 = blockRealMatrix18.isSquare();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = defaultRealMatrixPreservingVisitor22.end();
        defaultRealMatrixPreservingVisitor22.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double31 = blockRealMatrix18.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix18.walkInRowOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        double double30 = arrayRealVector21.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector37.setEntry(0, (double) 10.0f);
        double double41 = arrayRealVector32.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector32);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapMultiplyToSelf((double) 1);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector42.unitVector();
        try {
            arrayRealVector1.setSubVector((int) (short) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        double double13 = defaultRealMatrixPreservingVisitor11.end();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 1.1102230246251565E-14d, true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        int int2 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring(",", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector10.set(52.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = realVector8.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray10);
        long long12 = mersenneTwister6.nextLong();
        int int13 = mersenneTwister6.nextInt();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6490845983449753485L + "'", long12 == 6490845983449753485L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 913358275 + "'", int13 == 913358275);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor12.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double20 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        double[] doubleArray31 = blockRealMatrix11.preMultiply(doubleArray29);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double37 = blockRealMatrix11.walkInRowOrder(realMatrixChangingVisitor32, (int) '#', (int) (short) 0, 97, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 35 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector17.copy();
        double double28 = arrayRealVector27.getMaxValue();
        double double30 = arrayRealVector27.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector8.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double double32 = arrayRealVector27.getMinValue();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, true);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 52, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSuffix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector4.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, false);
        boolean boolean10 = arrayRealVector4.isInfinite();
        double double11 = arrayRealVector4.getMinValue();
        try {
            java.lang.String str12 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double[][] doubleArray24 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[][] doubleArray36 = blockRealMatrix34.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor39 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double40 = defaultRealMatrixPreservingVisitor39.end();
        defaultRealMatrixPreservingVisitor39.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double48 = array2DRowRealMatrix38.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor39);
        double[][] doubleArray49 = array2DRowRealMatrix38.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49, false);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix13.multiply(array2DRowRealMatrix51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector48.setEntry(0, (double) 10.0f);
        double double52 = arrayRealVector43.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector43.copy();
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector17.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        double[] doubleArray12 = arrayRealVector1.toArray();
        double[] doubleArray13 = arrayRealVector1.toArray();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        double[] doubleArray21 = blockRealMatrix18.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double[] doubleArray23 = blockRealMatrix2.operate(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector39.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector44.setEntry(0, (double) 10.0f);
        double double48 = arrayRealVector39.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        double double49 = arrayRealVector37.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector53.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector58.setEntry(0, (double) 10.0f);
        double double62 = arrayRealVector53.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector53.copy();
        double double64 = arrayRealVector63.getMaxValue();
        double double66 = arrayRealVector63.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector44.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.RealVector realVector68 = blockRealMatrix35.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        try {
            org.apache.commons.math3.linear.RealVector realVector69 = blockRealMatrix2.operateTranspose(realVector68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.0d + "'", double49 == 10.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.0d + "'", double64 == 10.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(realVector68);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            double double9 = openMapRealMatrix5.getEntry(1077936128, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        int int2 = cMAESOptimizer0.getEvaluations();
        org.apache.commons.math3.optimization.GoalType goalType3 = cMAESOptimizer0.getGoalType();
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(goalType3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        double double35 = blockRealMatrix33.getNorm();
        int[] intArray41 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister42 = new org.apache.commons.math3.random.MersenneTwister(intArray41);
        int[] intArray48 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister49 = new org.apache.commons.math3.random.MersenneTwister(intArray48);
        int int50 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray41, intArray48);
        int[] intArray56 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister57 = new org.apache.commons.math3.random.MersenneTwister(intArray56);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister58 = new org.apache.commons.math3.random.MersenneTwister(intArray56);
        int[] intArray64 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister65 = new org.apache.commons.math3.random.MersenneTwister(intArray64);
        int int66 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray56, intArray64);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix33.getSubMatrix(intArray41, intArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 27.18281828459045d + "'", double35 == 27.18281828459045d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 3.141592653589793d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) (-1L), (double) 100.0f, (-0.24260312498277528d), 1.5574077246549023d, (double) (byte) -10, 141.77799547179387d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 405.574319270048d + "'", double8 == 405.574319270048d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getKey();
        java.lang.Double double43 = pointValuePair40.getValue();
        java.lang.Double double44 = pointValuePair40.getSecond();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44.equals(0.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        double[] doubleArray60 = eigenDecomposition59.getImagEigenvalues();
        try {
            double double62 = eigenDecomposition59.getImagEigenvalue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector25.copy();
        double[] doubleArray36 = arrayRealVector25.toArray();
        double[] doubleArray37 = array2DRowRealMatrix13.operate(doubleArray36);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix13.getSubMatrix((int) (byte) 10, 1493912449, (int) (byte) -10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray12 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        int[] intArray20 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(intArray20);
        int int22 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray12, intArray20);
        int int23 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.add(blockRealMatrix14);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix19, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        double[] doubleArray30 = blockRealMatrix27.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector33.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector33);
        double[] doubleArray38 = blockRealMatrix19.operate(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray38);
        java.lang.StringBuffer stringBuffer40 = null;
        java.text.FieldPosition fieldPosition41 = null;
        try {
            java.lang.StringBuffer stringBuffer42 = realMatrixFormat0.format(realMatrix39, stringBuffer40, fieldPosition41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector17.copy();
        double double28 = arrayRealVector27.getMaxValue();
        double double30 = arrayRealVector27.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector8.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector35.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        double double44 = arrayRealVector35.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector46.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector51.setEntry(0, (double) 10.0f);
        double double55 = arrayRealVector46.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf(3.831008000716577E22d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector27.combineToSelf((double) 30000, 2.2737367544323206E-13d, (org.apache.commons.math3.linear.RealVector) arrayRealVector56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 200");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(realVector58);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 0L);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0L + "'", number2.equals(0L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 100L, 0.5720011145449332d, 0.09684168599911366d, 5.298342365610589d, (double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.71321186217958d + "'", double6 == 57.71321186217958d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(11013.232874703393d, (double) 1.0f, (double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        double[] doubleArray25 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double26 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray25);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector14.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 105");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 141.77799547179387d + "'", double26 == 141.77799547179387d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        openMapRealMatrix6.setEntry((int) (short) 10, 0, 2.718281828459045d);
        int int11 = openMapRealMatrix6.getRowDimension();
        try {
            openMapRealMatrix6.addToEntry(1, 1077936128, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        boolean boolean7 = arrayRealVector1.isInfinite();
        double double8 = arrayRealVector1.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, true);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector10.walkInOptimizedOrder(realVectorPreservingVisitor11, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = blockRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        double double24 = defaultRealMatrixPreservingVisitor22.end();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix39);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix40.add(blockRealMatrix43);
        double[][] doubleArray49 = blockRealMatrix40.getData();
        int int50 = blockRealMatrix40.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector54.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector59.setEntry(0, (double) 10.0f);
        double double63 = arrayRealVector54.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        double double64 = arrayRealVector52.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector68.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector73.setEntry(0, (double) 10.0f);
        double double77 = arrayRealVector68.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        double double78 = arrayRealVector66.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = arrayRealVector59.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix40.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        double[][] doubleArray81 = blockRealMatrix40.getData();
        try {
            blockRealMatrix18.copySubMatrix((int) (short) 10, 100, 913358275, 32, doubleArray81);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.0d + "'", double64 == 10.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.0d + "'", double78 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4056476493802699d + "'", double1 == 1.4056476493802699d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix6.scalarAdd((double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector46.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector51.setEntry(0, (double) 10.0f);
        double double55 = arrayRealVector46.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        double double56 = arrayRealVector44.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector60.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector65.setEntry(0, (double) 10.0f);
        double double69 = arrayRealVector60.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector60.copy();
        double double71 = arrayRealVector70.getMaxValue();
        double double73 = arrayRealVector70.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector51.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        try {
            org.apache.commons.math3.linear.RealVector realVector75 = blockRealMatrix42.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 10.0d + "'", double56 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.0d + "'", double71 == 10.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector74);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor1 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double2 = defaultRealMatrixPreservingVisitor1.end();
        double double3 = array2DRowRealMatrix0.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = blockRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, true);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix21.add(blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor33 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double34 = blockRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
        defaultRealMatrixPreservingVisitor33.visit(0, (int) (byte) 0, 4.9E-324d);
        try {
            double double43 = blockRealMatrix10.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33, 0, 30000, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector3.copy();
        double[] doubleArray14 = arrayRealVector3.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector1.append((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        boolean boolean16 = arrayRealVector1.isNaN();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector1.mapAddToSelf(0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        float float1 = org.apache.commons.math3.util.FastMath.signum(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double[][] doubleArray24 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray27 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector4.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, false);
        boolean boolean10 = arrayRealVector4.isInfinite();
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        try {
            java.lang.StringBuffer stringBuffer13 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer11, fieldPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(51.99038372622382d, 1.0108893781963495E19d, (double) (-1), 1.0455980441599998E12d, 142.13022197970423d, (-6.053128792867638d), (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.2556526572632205E20d + "'", double8 == 5.2556526572632205E20d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray10);
        long long12 = mersenneTwister6.nextLong();
        int[] intArray18 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math3.random.MersenneTwister(intArray18);
        byte[] byteArray23 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister19.nextBytes(byteArray23);
        mersenneTwister6.nextBytes(byteArray23);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6490845983449753485L + "'", long12 == 6490845983449753485L);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(byteArray23);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) (-1L), (java.lang.Number) 9.999999f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 9.999999f + "'", number5.equals(9.999999f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double double27 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector8.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double double30 = arrayRealVector8.getEntry(10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector8.copy();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor32 = null;
        try {
            double double33 = arrayRealVector8.walkInDefaultOrder(realVectorChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix25.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.add(blockRealMatrix25);
        double double31 = blockRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix42.add(blockRealMatrix45);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix50, (int) 'a');
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix30, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor55 = null;
        try {
            double double60 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor55, 0, 0, (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix13.getColumnVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        double[] doubleArray17 = blockRealMatrix14.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(realVector8, arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector18.mapDivide(0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.copy();
        double[][] doubleArray8 = blockRealMatrix5.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.add(blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix40.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix15.subtract(blockRealMatrix42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix57.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.add(blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix57.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor66 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double67 = blockRealMatrix57.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor66);
        double double68 = blockRealMatrix15.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor66);
        double double69 = blockRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor66);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSuffix();
        java.text.NumberFormat numberFormat3 = realVectorFormat1.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector5.setEntry(0, (double) 10.0f);
        double[] doubleArray14 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double15 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector5.mapMultiplyToSelf(1.5574077246549023d);
        try {
            java.lang.String str22 = realVectorFormat1.format(realVector21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 141.77799547179387d + "'", double15 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix38, (int) 'a');
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.RealVector realVector43 = blockRealMatrix38.getRowVector(0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(realVector43);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        openMapRealMatrix6.setEntry((int) (short) 10, 0, 2.718281828459045d);
        int int11 = openMapRealMatrix6.getRowDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix6, 13, 13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (13)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = openMapRealMatrix6.getSubMatrix(1, 1077936128, (int) '4', 30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix58.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix61);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix55.add(blockRealMatrix58);
        try {
            blockRealMatrix43.setColumnMatrix(97, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("; ", "", "; ");
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector3.copy();
        double[] doubleArray14 = arrayRealVector3.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector1.append((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix22.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector28.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector33.setEntry(0, (double) 10.0f);
        double double37 = arrayRealVector28.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        double double38 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector42.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector47.setEntry(0, (double) 10.0f);
        double double51 = arrayRealVector42.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        double double52 = arrayRealVector40.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector33.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        double double55 = arrayRealVector33.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector56 = blockRealMatrix22.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        try {
            double double57 = arrayRealVector1.getDistance(realVector56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 10.0d + "'", double38 == 10.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 10.0d + "'", double52 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector25.copy();
        double[] doubleArray36 = arrayRealVector25.toArray();
        double[] doubleArray37 = array2DRowRealMatrix13.operate(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix51.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix48.add(blockRealMatrix51);
        double double57 = blockRealMatrix56.getFrobeniusNorm();
        double[] doubleArray59 = blockRealMatrix56.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix62.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix62.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix69);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix73.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix70.add(blockRealMatrix73);
        double double79 = blockRealMatrix78.getFrobeniusNorm();
        double[] doubleArray81 = blockRealMatrix78.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix82 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray81);
        double double83 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray59, doubleArray81);
        double[] doubleArray84 = array2DRowRealMatrix13.preMultiply(doubleArray59);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(realMatrix82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", ", ", ",", "}", "{", "");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector1.copy();
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer0.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(doubleList2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(", ", "BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", ", ");
        java.lang.String str4 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ", " + "'", str4.equals(", "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1097.2817086347977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1097.0d + "'", double1 == 1097.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(6, (int) (byte) -10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6) + "'", int2 == (-6));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getKey();
        java.lang.Double double43 = pointValuePair40.getValue();
        java.lang.Double double44 = pointValuePair40.getValue();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44.equals(0.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        double[] doubleArray51 = blockRealMatrix48.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector42.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector52.mapMultiply(0.23115483517811797d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector59.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector64.setEntry(0, (double) 10.0f);
        double double68 = arrayRealVector59.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector59.copy();
        double[] doubleArray70 = arrayRealVector59.toArray();
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector57.append((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        boolean boolean72 = arrayRealVector57.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector52.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.RealVector realVector74 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector73.subtract(realVector74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(arrayRealVector73);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double43 = arrayRealVector12.getMaxValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor44 = null;
        try {
            double double47 = arrayRealVector12.walkInDefaultOrder(realVectorChangingVisitor44, 1077936128, 13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 10.0d + "'", double43 == 10.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix33.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = blockRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix58.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix61);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix55.add(blockRealMatrix58);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix63, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix63.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix63);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 100.00001f, 0.0d, (double) 30000);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-6), 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix43.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix54.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix51.add(blockRealMatrix54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor63 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double64 = blockRealMatrix54.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        defaultRealMatrixPreservingVisitor63.visit(0, (int) (byte) 0, 4.9E-324d);
        double double69 = blockRealMatrix6.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        double[] doubleArray71 = null;
        try {
            blockRealMatrix6.setRow((int) (short) 10, doubleArray71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float2 = org.apache.commons.math3.util.FastMath.max((-1.0f), (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100, (double) ' ');
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf(0.5720011145449331d);
        realVector4.unitize();
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        double double61 = eigenDecomposition59.getImagEigenvalue((int) (short) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        int int14 = array2DRowRealMatrix13.getRowDimension();
        try {
            array2DRowRealMatrix13.setEntry(913358275, (int) (short) -1, 4.9E-324d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (913,358,275)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.add(blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix40.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix15.subtract(blockRealMatrix42);
        org.apache.commons.math3.linear.RealVector realVector45 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix6.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15);
        try {
            double[] doubleArray48 = blockRealMatrix6.getRow((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector12.mapAddToSelf((double) 10);
        org.apache.commons.math3.linear.RealVector realVector26 = null;
        try {
            arrayRealVector12.setSubVector((int) (byte) 0, realVector26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix33.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = blockRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        defaultRealMatrixPreservingVisitor42.visit((int) '#', (int) '4', 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        double[] doubleArray17 = blockRealMatrix14.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(realVector8, arrayRealVector18);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException21 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 3.831008000716577E22d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = notPositiveException21.getContext();
        boolean boolean23 = arrayRealVector19.equals((java.lang.Object) notPositiveException21);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor24 = null;
        try {
            double double25 = arrayRealVector19.walkInDefaultOrder(realVectorPreservingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix2.getColumnMatrix((-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix57.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.add(blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix64.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor67 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor67.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double75 = blockRealMatrix66.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor67);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix81 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix82 = blockRealMatrix78.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix81);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix85 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix78.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix85);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix87 = blockRealMatrix85.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor88 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor88.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double96 = blockRealMatrix87.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor88);
        double double97 = blockRealMatrix66.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor88);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix98 = blockRealMatrix18.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix82);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix87);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) 1097.0d, number3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor23.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double31 = blockRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix42.add(blockRealMatrix45);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix50, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = blockRealMatrix50.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = blockRealMatrix50.scalarAdd(1097.2817086347977d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix57 = blockRealMatrix22.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(realMatrix56);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector17.copy();
        double double28 = arrayRealVector27.getMaxValue();
        double double30 = arrayRealVector27.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector8.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor32 = null;
        try {
            double double35 = arrayRealVector27.walkInOptimizedOrder(realVectorChangingVisitor32, (-127), 1077936128);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer0.getStatisticsSigmaHistory();
        int int3 = cMAESOptimizer0.getMaxEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        org.apache.commons.math3.optimization.GoalType goalType6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector13.setEntry(0, (double) 10.0f);
        double double17 = arrayRealVector8.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        double double28 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13);
        int int31 = arrayRealVector30.getMaxIndex();
        double[] doubleArray32 = arrayRealVector30.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix47.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix50);
        double[] doubleArray53 = blockRealMatrix50.getRow((int) (short) 1);
        blockRealMatrix35.setRow(0, doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray32, doubleArray53, (double) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector58.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector63.setEntry(0, (double) 10.0f);
        double double67 = arrayRealVector58.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector58.copy();
        double[] doubleArray69 = arrayRealVector58.toArray();
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray69);
        double[] doubleArray71 = null;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair72 = cMAESOptimizer0.optimize((int) (short) 0, multivariateFunction5, goalType6, doubleArray53, doubleArray69, doubleArray71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double[][] doubleArray19 = blockRealMatrix10.getData();
        int int20 = blockRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = blockRealMatrix27.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = blockRealMatrix36.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix36.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor41 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double42 = blockRealMatrix36.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix56.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix59);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix53.add(blockRealMatrix56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix61.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix36.subtract(blockRealMatrix63);
        org.apache.commons.math3.linear.RealVector realVector66 = blockRealMatrix36.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix10.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        double double30 = arrayRealVector21.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector37.setEntry(0, (double) 10.0f);
        double double41 = arrayRealVector32.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        int int44 = arrayRealVector43.getMaxIndex();
        double[] doubleArray45 = arrayRealVector43.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        double[] doubleArray54 = blockRealMatrix51.getRow((int) (short) 1);
        double double55 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray45, doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector57.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector62.setEntry(0, (double) 10.0f);
        double double66 = arrayRealVector57.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double double67 = arrayRealVector57.getNorm();
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector57.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector57.mapSubtractToSelf(0.0d);
        double[] doubleArray72 = arrayRealVector57.toArray();
        double double73 = org.apache.commons.math3.util.MathArrays.distance(doubleArray54, doubleArray72);
        try {
            blockRealMatrix18.setRow((int) '#', doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 10.0d + "'", double55 == 10.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.0d + "'", double73 == 10.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
    }
}

