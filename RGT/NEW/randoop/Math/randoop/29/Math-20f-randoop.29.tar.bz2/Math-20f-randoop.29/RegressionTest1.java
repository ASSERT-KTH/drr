import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 0, true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[][] doubleArray0 = new double[][] {};
        try {
            double[][] doubleArray1 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float[] floatArray5 = new float[] { 1, (byte) 100, 1, (byte) 100, 1.0f };
        float[] floatArray10 = new float[] { 0.0f, (byte) 10, 0, (byte) 1 };
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray5, floatArray10);
        float[] floatArray13 = new float[] { '#' };
        float[] floatArray19 = new float[] { ' ', (-1.0f), 0, ' ', 100L };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(floatArray13, floatArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(floatArray10, floatArray13);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.power(13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray8 = new double[] { 1.0f, 1.2676506E30f, 27.18281828459045d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector10.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector15.setEntry(0, (double) 10.0f);
        double double19 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        double double30 = arrayRealVector21.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15);
        int int33 = arrayRealVector32.getMaxIndex();
        double[] doubleArray34 = arrayRealVector32.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector41.setEntry(0, (double) 10.0f);
        double double45 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector47.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector52.setEntry(0, (double) 10.0f);
        double double56 = arrayRealVector47.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41);
        int int59 = arrayRealVector58.getMaxIndex();
        double[] doubleArray60 = arrayRealVector58.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix63.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        double[] doubleArray69 = blockRealMatrix66.getRow((int) (short) 1);
        double double70 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector72.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector77.setEntry(0, (double) 10.0f);
        double double81 = arrayRealVector72.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        double double82 = arrayRealVector72.getNorm();
        org.apache.commons.math3.linear.RealVector realVector84 = arrayRealVector72.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector72.mapSubtractToSelf(0.0d);
        double[] doubleArray87 = arrayRealVector72.toArray();
        double double88 = org.apache.commons.math3.util.MathArrays.distance(doubleArray69, doubleArray87);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair89 = cMAESOptimizer1.optimize(0, multivariateFunction3, goalType4, doubleArray8, doubleArray34, doubleArray87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.0d + "'", double70 == 10.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 10.0d + "'", double82 == 10.0d);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 10.0d + "'", double88 == 10.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray25, orderDirection26, true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        int int7 = openMapRealMatrix2.getColumnDimension();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray1 = null;
        try {
            double[] doubleArray2 = array2DRowRealMatrix0.operate(doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector13.setEntry(0, (double) 10.0f);
        double double17 = arrayRealVector8.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector19.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        double double28 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13);
        int int31 = arrayRealVector30.getMaxIndex();
        double[] doubleArray32 = arrayRealVector30.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        double double42 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray32, doubleArray41);
        try {
            double[] doubleArray43 = openMapRealMatrix2.operate(doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.0d + "'", double42 == 10.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 1.045598044058429E12d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor12.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double20 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        double[] doubleArray31 = blockRealMatrix11.preMultiply(doubleArray29);
        try {
            blockRealMatrix11.addToEntry(30, (int) '#', 0.23115483517811797d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(57.71321186217958d, 0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        double[] doubleArray21 = blockRealMatrix18.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double[] doubleArray23 = blockRealMatrix2.operate(doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = blockRealMatrix2.getColumnMatrix(0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor23.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double31 = blockRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix41.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor44 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor44.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double52 = blockRealMatrix43.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double double53 = blockRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector55.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector60.setEntry(0, (double) 10.0f);
        double double64 = arrayRealVector55.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector55.copy();
        double[] doubleArray66 = arrayRealVector55.toArray();
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = blockRealMatrix22.multiply(realMatrix67);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair0 = null;
        try {
            org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair1 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArrayPair0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix40);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix37.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix44.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor47 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor47.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double55 = blockRealMatrix46.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix58.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix61);
        double[] doubleArray64 = blockRealMatrix61.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix65 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray64);
        double[] doubleArray66 = blockRealMatrix46.preMultiply(doubleArray64);
        try {
            double[] doubleArray67 = blockRealMatrix6.operate(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = blockRealMatrix23.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix36.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix39);
        double[] doubleArray42 = blockRealMatrix39.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double[] doubleArray44 = blockRealMatrix23.operate(doubleArray42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix23.copy();
        try {
            blockRealMatrix19.setColumnMatrix(1077936128, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        double[][] doubleArray55 = blockRealMatrix53.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix58.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix61);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix58.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix69.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix72);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix66.add(blockRealMatrix69);
        double double75 = blockRealMatrix74.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix81 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix82 = blockRealMatrix78.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix81);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix85 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix78.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix85);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix89 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix92 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix93 = blockRealMatrix89.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix92);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix94 = blockRealMatrix86.add(blockRealMatrix89);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix94, (int) 'a');
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix74, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix94);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix74);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix99 = blockRealMatrix43.multiply(blockRealMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix82);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix93);
        org.junit.Assert.assertNotNull(blockRealMatrix94);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker0 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double double1 = simpleValueChecker0.getAbsoluteThreshold();
        double double2 = simpleValueChecker0.getRelativeThreshold();
        double double3 = simpleValueChecker0.getAbsoluteThreshold();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.add(blockRealMatrix18);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix23, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        double[] doubleArray34 = blockRealMatrix31.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector37.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, arrayRealVector37);
        double[] doubleArray42 = blockRealMatrix23.operate(doubleArray34);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 0.0d, false);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix59.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix62);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix56.add(blockRealMatrix59);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix64, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix69.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix72);
        double[] doubleArray75 = blockRealMatrix72.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector78.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75, arrayRealVector78);
        double[] doubleArray83 = blockRealMatrix64.operate(doubleArray75);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair86 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray83, 0.0d, false);
        java.lang.Double double87 = pointValuePair86.getValue();
        double[] doubleArray88 = pointValuePair86.getKey();
        java.lang.Double double89 = pointValuePair86.getValue();
        boolean boolean90 = simpleValueChecker0.converged(10, pointValuePair45, pointValuePair86);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-14d + "'", double2 == 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2250738585072014E-306d + "'", double3 == 2.2250738585072014E-306d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, false);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        double[] doubleArray24 = blockRealMatrix21.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15, arrayRealVector25);
        double double27 = arrayRealVector1.dotProduct(realVector15);
        double double28 = realVector15.getMaxValue();
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.136238463529799E46d + "'", double27 == 7.136238463529799E46d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 7.1362384635298E45d + "'", double28 == 7.1362384635298E45d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.5720011145449331d, (java.lang.Number) 520.0d, false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray12 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        int int14 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        int[] intArray20 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(intArray20);
        int[] intArray27 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        int int29 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray20, intArray27);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        int[] intArray31 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27);
        int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray27);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double11 = arrayRealVector1.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector1.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        double[] doubleArray33 = blockRealMatrix30.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector24, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector1.append(arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector34.copy();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector25.copy();
        double[] doubleArray36 = arrayRealVector25.toArray();
        double[] doubleArray37 = array2DRowRealMatrix13.operate(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        double[][] doubleArray49 = blockRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = defaultRealMatrixPreservingVisitor52.end();
        defaultRealMatrixPreservingVisitor52.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double61 = array2DRowRealMatrix51.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double[][] doubleArray62 = array2DRowRealMatrix51.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix51);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor64 = null;
        try {
            double double65 = array2DRowRealMatrix51.walkInColumnOrder(realMatrixChangingVisitor64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getSecond();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.3440585709080678E43d, 7.136238463529799E46d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        try {
            blockRealMatrix18.addToEntry(30000, 1, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 13, (float) (short) 10, (float) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.copy();
        java.lang.Class<?> wildcardClass8 = blockRealMatrix7.getClass();
        try {
            blockRealMatrix7.setEntry(13, 97, (-6.053128792867638d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (13)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double11 = arrayRealVector1.getNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector1.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector1.mapSubtractToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) '#', (double) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.000004f + "'", float2 == 35.000004f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = blockRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        int int24 = blockRealMatrix13.getRowDimension();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException8 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(1, 0, (double) 10);
        int int9 = nonSymmetricMatrixException8.getRow();
        double double10 = nonSymmetricMatrixException8.getThreshold();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) nonSymmetricMatrixException8);
        int int12 = nonSymmetricMatrixException8.getRow();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1L + "'", number4.equals(1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getKey();
        java.lang.Double double43 = pointValuePair40.getValue();
        java.lang.Object obj44 = null;
        boolean boolean45 = pointValuePair40.equals(obj44);
        java.lang.Double double46 = pointValuePair40.getSecond();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46.equals(0.0d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix42.add(blockRealMatrix45);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix50, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix55.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix58);
        double[] doubleArray61 = blockRealMatrix58.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector64.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61, arrayRealVector64);
        double[] doubleArray69 = blockRealMatrix50.operate(doubleArray61);
        blockRealMatrix26.setColumn(1, doubleArray69);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix73.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        double[] doubleArray79 = blockRealMatrix76.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray79);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray79);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition83 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray69, doubleArray79, 3.831008000716577E22d);
        double[] doubleArray84 = eigenDecomposition83.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix85 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray84);
        arrayRealVector12.setSubVector(30, doubleArray84);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(realMatrix85);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(1, 100);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 10, (float) (-6), (float) 30000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(141.77799547179387d, 30, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray12 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        int int14 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        int[] intArray21 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math3.random.MersenneTwister(intArray21);
        byte[] byteArray26 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister22.nextBytes(byteArray26);
        mersenneTwister15.nextBytes(byteArray26);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(byteArray26);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector27.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector27.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double double39 = arrayRealVector23.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        double[] doubleArray21 = blockRealMatrix18.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double[] doubleArray23 = blockRealMatrix2.operate(doubleArray21);
        int int24 = org.apache.commons.math3.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1796951359) + "'", int24 == (-1796951359));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-6), (double) (byte) 10, (double) 97.0f, (double) (byte) 0, (double) (byte) 0, (double) 100, 1.5574077246549023d, (double) 13);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-39.75369957948627d) + "'", double8 == (-39.75369957948627d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        int int14 = array2DRowRealMatrix13.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double26 = arrayRealVector16.getNorm();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector16.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.mapSubtractToSelf(0.0d);
        double[] doubleArray31 = arrayRealVector16.toArray();
        double[] doubleArray32 = array2DRowRealMatrix13.operate(doubleArray31);
        double double35 = array2DRowRealMatrix13.getEntry(0, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray12 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        int int14 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        int[] intArray20 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(intArray20);
        int[] intArray27 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        int int29 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray20, intArray27);
        double double30 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray20);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str4 = realMatrixFormat3.getRowSeparator();
        java.lang.String str5 = realMatrixFormat3.getRowSeparator();
        java.lang.String str6 = realMatrixFormat3.getRowSuffix();
        java.lang.String str7 = realMatrixFormat3.getColumnSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("]", "", "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [30,000, -1] range", numberFormat8);
        org.junit.Assert.assertNotNull(realMatrixFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "," + "'", str5.equals(","));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "}" + "'", str6.equals("}"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "," + "'", str7.equals(","));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long1 = org.apache.commons.math3.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        double[] doubleArray10 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector1.mapMultiplyToSelf(1.5574077246549023d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector1.append((double) ' ');
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 141.77799547179387d + "'", double11 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector1.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        double[] doubleArray33 = blockRealMatrix30.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector24, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector1.append(arrayRealVector34);
        boolean boolean38 = arrayRealVector36.equals((java.lang.Object) 1.5707963267948966d);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor39 = null;
        try {
            double double42 = arrayRealVector36.walkInOptimizedOrder(realVectorChangingVisitor39, (int) (short) 100, 30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 100 after final row 30");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100, (double) ' ');
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf(0.5720011145449331d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector11.setEntry(0, (double) 10.0f);
        double double15 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        double double23 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        double double34 = arrayRealVector25.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector41.setEntry(0, (double) 10.0f);
        double double45 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector17.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        double[] doubleArray56 = blockRealMatrix53.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = arrayRealVector47.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector60.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector65.setEntry(0, (double) 10.0f);
        double double69 = arrayRealVector60.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector71.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector76.setEntry(0, (double) 10.0f);
        double double80 = arrayRealVector71.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, arrayRealVector71);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector81.mapMultiplyToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, realVector83);
        try {
            double double85 = arrayRealVector2.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 300");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(realVector83);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(7.136238463529799E46d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.136238463529799E46d + "'", double1 == 7.136238463529799E46d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) -10, 13);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 405.574319270048d, number1, true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "]" + "'", str1.equals("]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-6), 100.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector22.setEntry(0, (double) 10.0f);
        double double26 = arrayRealVector17.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector17.copy();
        double double28 = arrayRealVector27.getMaxValue();
        double double30 = arrayRealVector27.getEntry((int) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector8.combineToSelf((double) (short) -1, (double) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector27.mapMultiplyToSelf((-1.6932181103819134E9d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix18.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        double[] doubleArray32 = blockRealMatrix29.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector35.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector35);
        try {
            blockRealMatrix18.setRowVector((-6), (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double[] doubleArray34 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double35 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray34);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector25.mapMultiplyToSelf(1.5574077246549023d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, false);
        double double44 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction45 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector43.map(univariateFunction45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 141.77799547179387d + "'", double35 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 5.574077246549024d + "'", double44 == 5.574077246549024d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        double double35 = blockRealMatrix34.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix38.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix38.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor47 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double48 = blockRealMatrix38.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix51.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix54);
        double[] doubleArray57 = blockRealMatrix54.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57);
        double[] doubleArray59 = blockRealMatrix38.operate(doubleArray57);
        try {
            double[] doubleArray60 = blockRealMatrix34.preMultiply(doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 27.18281828459045d + "'", double35 == 27.18281828459045d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        double[] doubleArray21 = blockRealMatrix10.getRow(0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) -10, 6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        int int14 = array2DRowRealMatrix13.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double26 = arrayRealVector16.getNorm();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector16.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.mapSubtractToSelf(0.0d);
        double[] doubleArray31 = arrayRealVector16.toArray();
        double[] doubleArray32 = array2DRowRealMatrix13.operate(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix45.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix48);
        double[] doubleArray51 = blockRealMatrix48.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector42.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor54 = null;
        try {
            double double55 = arrayRealVector42.walkInOptimizedOrder(realVectorChangingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.multiply(blockRealMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        double[] doubleArray20 = blockRealMatrix17.getRow((int) (short) 1);
        blockRealMatrix2.setRow(0, doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.add(blockRealMatrix35);
        double double41 = blockRealMatrix40.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix44.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix44.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix55.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix58);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix52.add(blockRealMatrix55);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix60, (int) 'a');
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix40, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix60);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix64);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor23.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double31 = blockRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix34.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix41.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor44 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor44.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double52 = blockRealMatrix43.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double double53 = blockRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double[][] doubleArray54 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double60 = blockRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor55, (int) (short) -1, (int) (byte) 100, 32, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix15.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix15.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.add(blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix40.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix15.subtract(blockRealMatrix42);
        org.apache.commons.math3.linear.RealVector realVector45 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix6.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math3.linear.RealVector realVector48 = blockRealMatrix6.getColumnVector((int) (byte) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector12.mapAddToSelf((double) 10);
        arrayRealVector12.setEntry(10, 27.18281828459045d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 100, (double) ' ');
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf(0.5720011145449331d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix29.add(blockRealMatrix32);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix37, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix42.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix45);
        double[] doubleArray48 = blockRealMatrix45.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector51.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, arrayRealVector51);
        double[] doubleArray56 = blockRealMatrix37.operate(doubleArray48);
        blockRealMatrix13.setColumn(1, doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix60.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix63);
        double[] doubleArray66 = blockRealMatrix63.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray66);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition70 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray56, doubleArray66, 3.831008000716577E22d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection71 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean74 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray66, orderDirection71, true, false);
        try {
            boolean boolean77 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection71, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1493912449 + "'", int10 == 1493912449);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray41 = blockRealMatrix38.getRow((int) (short) 1);
        blockRealMatrix23.setRow(0, doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector45.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector50.setEntry(0, (double) 10.0f);
        double double54 = arrayRealVector45.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector56.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector61.setEntry(0, (double) 10.0f);
        double double65 = arrayRealVector56.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, arrayRealVector56);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector66.mapDivideToSelf(3.831008000716577E22d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43, realVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 200");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(realVector68);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) '#', (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5032385536E11d + "'", double2 == 1.5032385536E11d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor43 = null;
        try {
            double double44 = arrayRealVector12.walkInOptimizedOrder(realVectorChangingVisitor43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix19.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        arrayRealVector24.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, false);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        double[] doubleArray56 = blockRealMatrix53.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(realVector47, arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector24.append(arrayRealVector57);
        boolean boolean61 = arrayRealVector59.equals((java.lang.Object) 1.5707963267948966d);
        double double62 = arrayRealVector59.getNorm();
        try {
            blockRealMatrix19.setColumnVector(30, (org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 520.0d + "'", double62 == 520.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (-1), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        boolean boolean60 = eigenDecomposition59.hasComplexEigenvalues();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver61 = eigenDecomposition59.getSolver();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(decompositionSolver61);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        int int8 = openMapRealMatrix7.getColumnDimension();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = openMapRealMatrix4.multiply(openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 32");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        int int1 = cMAESOptimizer0.getMaxEvaluations();
        int int2 = cMAESOptimizer0.getEvaluations();
        int int3 = cMAESOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix22.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix33.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix30.add(blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix33.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = blockRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        java.lang.String str45 = blockRealMatrix18.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix48.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix55);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix59.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix62);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix56.add(blockRealMatrix59);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix59.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor68 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double69 = blockRealMatrix59.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor68);
        defaultRealMatrixPreservingVisitor68.visit(0, (int) (byte) 0, 4.9E-324d);
        double double74 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor68);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str45.equals("BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix5.createMatrix(30, 13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector30.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector35.setEntry(0, (double) 10.0f);
        double double39 = arrayRealVector30.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double double40 = arrayRealVector28.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        arrayRealVector28.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector44.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44, false);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix54.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        double[] doubleArray60 = blockRealMatrix57.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(realVector51, arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector28.append(arrayRealVector61);
        try {
            blockRealMatrix5.setRowVector(30, (org.apache.commons.math3.linear.RealVector) arrayRealVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.0d + "'", double40 == 10.0d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(arrayRealVector63);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        int int5 = openMapRealMatrix4.getRowDimension();
        openMapRealMatrix4.setEntry(0, 0, (double) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed(1L);
        mersenneTwister6.setSeed((int) (byte) -10);
        int[] intArray16 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister(intArray16);
        byte[] byteArray21 = new byte[] { (byte) 1, (byte) -1, (byte) -1 };
        mersenneTwister17.nextBytes(byteArray21);
        mersenneTwister6.nextBytes(byteArray21);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        double[] doubleArray10 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector1.mapMultiplyToSelf(1.5574077246549023d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        double double20 = arrayRealVector19.getMinValue();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector19.walkInOptimizedOrder(realVectorPreservingVisitor21, (int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 141.77799547179387d + "'", double11 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double[] doubleArray11 = arrayRealVector1.getDataRef();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector1.mapDivide((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector27.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, false);
        double double33 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector35.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        double double44 = arrayRealVector35.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector46.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector51.setEntry(0, (double) 10.0f);
        double double55 = arrayRealVector46.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector27.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix60.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix63);
        double[] doubleArray66 = blockRealMatrix63.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = arrayRealVector57.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector70.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector75.setEntry(0, (double) 10.0f);
        double double79 = arrayRealVector70.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector81.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector86.setEntry(0, (double) 10.0f);
        double double90 = arrayRealVector81.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector75, arrayRealVector81);
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector91.mapMultiplyToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, realVector93);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector1.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector94);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 300");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(realVector93);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat3 = realMatrixFormat0.getFormat();
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = realMatrixFormat0.parse("{", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix21.add(blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix10.subtract(blockRealMatrix24);
        double[] doubleArray34 = null;
        try {
            double[] doubleArray35 = blockRealMatrix10.operate(doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector1.set(52.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, false);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.4E-45f);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        double[] doubleArray33 = blockRealMatrix30.getRow((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector24, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector1.append(arrayRealVector34);
        boolean boolean38 = arrayRealVector36.equals((java.lang.Object) 1.5707963267948966d);
        int int39 = arrayRealVector36.getDimension();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 200 + "'", int39 == 200);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix13.walkInRowOrder(realMatrixChangingVisitor24, 13, (int) (short) -1, (int) (short) 10, 1077936128);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (13)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray6 = new double[] { 2.2737367544323206E-13d, (-1L), 1, (byte) 0, 27.18281828459045d, (-1.0f) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray14);
        java.lang.Integer[] intArray16 = multiDimensionMismatchException15.getWrongDimensions();
        java.lang.Integer[] intArray17 = multiDimensionMismatchException15.getWrongDimensions();
        java.lang.Integer[] intArray18 = multiDimensionMismatchException15.getWrongDimensions();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 4.641588833612779d, (java.lang.Object[]) intArray18);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(27.18281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        int int60 = org.apache.commons.math3.util.MathUtils.hash(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1493912449 + "'", int60 == 1493912449);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.4E-45f, (java.lang.Number) (-1L), false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix14.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double34 = arrayRealVector22.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector38.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        double double47 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double48 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = arrayRealVector29.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double double51 = arrayRealVector29.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector52 = blockRealMatrix18.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x10 but expected 10x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (-6), (float) 200);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray13);
        java.lang.Integer[] intArray15 = multiDimensionMismatchException14.getWrongDimensions();
        java.lang.Integer[] intArray16 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { (-1) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray16, intArray18);
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray32 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException33 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray32);
        java.lang.Integer[] intArray34 = multiDimensionMismatchException33.getWrongDimensions();
        java.lang.Integer[] intArray35 = multiDimensionMismatchException33.getExpectedDimensions();
        java.lang.Integer[] intArray37 = new java.lang.Integer[] { (-1) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException38 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray35, intArray37);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException39 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray18, intArray37);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getKey();
        java.lang.Double double43 = pointValuePair40.getSecond();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43.equals(0.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring(", ", "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [30,000, -1] range", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[] doubleArray7 = new double[] { (-1), 1.5637431630493914d, 10L, 10L, 1.5637431630493914d, 27.18281828459045d };
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) ' ', doubleArray7);
        int int9 = cMAESOptimizer8.getMaxEvaluations();
        java.util.List<java.lang.Double> doubleList10 = cMAESOptimizer8.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(doubleList10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        double[] doubleArray34 = blockRealMatrix31.getRow((int) (short) 1);
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray25, doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector37.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector42.setEntry(0, (double) 10.0f);
        double double46 = arrayRealVector37.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double double47 = arrayRealVector37.getNorm();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector37.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector37.mapSubtractToSelf(0.0d);
        double[] doubleArray52 = arrayRealVector37.toArray();
        double double53 = org.apache.commons.math3.util.MathArrays.distance(doubleArray34, doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix57.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix57.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix68.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix65.add(blockRealMatrix68);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix73.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix75.scalarAdd((double) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor78 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor78.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double86 = blockRealMatrix77.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor78);
        double double87 = array2DRowRealMatrix54.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor78);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.0d + "'", double35 == 10.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 10.0d + "'", double53 == 10.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector28.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector33.setEntry(0, (double) 10.0f);
        double double37 = arrayRealVector28.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector39.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector44.setEntry(0, (double) 10.0f);
        double double48 = arrayRealVector39.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector52.setEntry(0, (double) 10.0f);
        double[] doubleArray61 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double62 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector52.mapMultiplyToSelf(1.5574077246549023d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, false);
        double double71 = arrayRealVector33.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector33.mapMultiplyToSelf(0.0d);
        try {
            blockRealMatrix18.setColumnVector(32, (org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 141.77799547179387d + "'", double62 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 5.574077246549024d + "'", double71 == 5.574077246549024d);
        org.junit.Assert.assertNotNull(realVector73);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double11 = arrayRealVector1.getNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector1.append(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix16.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix20.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector45.setEntry(0, (double) 10.0f);
        double double49 = arrayRealVector40.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        double double50 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = arrayRealVector31.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double double53 = arrayRealVector31.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector54 = blockRealMatrix20.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector31.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector55);
        double[] doubleArray58 = null;
        try {
            arrayRealVector55.setSubVector((int) (short) 1, doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 10.0d + "'", double50 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5032385536E11d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-40.0d) + "'", double2 == (-40.0d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.5720011145449332d, 30000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        java.lang.String str3 = realMatrixFormat0.getRowSuffix();
        java.lang.String str4 = realMatrixFormat0.getColumnSeparator();
        java.text.NumberFormat numberFormat5 = realMatrixFormat0.getFormat();
        java.text.ParsePosition parsePosition7 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = realMatrixFormat0.parse(", ", parsePosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix6.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix6.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix26.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix23.add(blockRealMatrix26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix6.subtract(blockRealMatrix33);
        double[][] doubleArray35 = blockRealMatrix6.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        double[][] doubleArray38 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        double[] doubleArray10 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, (int) (byte) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray10);
        double double16 = arrayRealVector15.getNorm();
        java.io.ObjectOutputStream objectOutputStream17 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15, objectOutputStream17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 141.77799547179387d + "'", double11 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 142.13022197970423d + "'", double16 == 142.13022197970423d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker2 = cMAESOptimizer1.getConvergenceChecker();
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) ' ');
        incrementor1.incrementCount((int) ' ');
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        double[] doubleArray46 = blockRealMatrix43.getRow((int) (short) 1);
        blockRealMatrix28.setRow(0, doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray46, (double) 100);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = eigenDecomposition49.getD();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str2 = realMatrixFormat1.getColumnSeparator();
        java.lang.String str3 = realMatrixFormat1.getRowSeparator();
        java.text.NumberFormat numberFormat4 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = org.apache.commons.math3.util.CompositeFormat.formatDouble(3.732511156817248d, numberFormat4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        double[] doubleArray8 = blockRealMatrix5.getRow((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix11.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        double[] doubleArray17 = blockRealMatrix14.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector20);
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix39.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix36.add(blockRealMatrix39);
        double double45 = blockRealMatrix44.getFrobeniusNorm();
        double[] doubleArray47 = blockRealMatrix44.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix61.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix58.add(blockRealMatrix61);
        double double67 = blockRealMatrix66.getFrobeniusNorm();
        double[] doubleArray69 = blockRealMatrix66.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray69);
        double double71 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray47, doubleArray69);
        try {
            double double72 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        boolean boolean7 = blockRealMatrix5.isSquare();
        org.apache.commons.math3.linear.RealVector realVector9 = blockRealMatrix5.getColumnVector((int) '4');
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        double[] doubleArray46 = blockRealMatrix43.getRow((int) (short) 1);
        blockRealMatrix28.setRow(0, doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray46, (double) 100);
        double double51 = eigenDecomposition49.getRealEigenvalue((int) ' ');
        try {
            double double53 = eigenDecomposition49.getRealEigenvalue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
        double[] doubleArray15 = blockRealMatrix12.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) realMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 32x10 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 0.0f, (double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.000003814697266d + "'", double2 == 35.000003814697266d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1102230246251565E-16d) + "'", double1 == (-1.1102230246251565E-16d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 0, (double) 1077936128);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        double[] doubleArray46 = blockRealMatrix43.getRow((int) (short) 1);
        blockRealMatrix28.setRow(0, doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray46, (double) 100);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = eigenDecomposition49.getV();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix50);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1.2676506E30f, (double) 30000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray12);
        java.lang.Integer[] intArray14 = multiDimensionMismatchException13.getWrongDimensions();
        int int16 = multiDimensionMismatchException13.getWrongDimension((int) (byte) 1);
        java.lang.Integer[] intArray17 = multiDimensionMismatchException13.getExpectedDimensions();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarMultiply((double) ' ');
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((-6.053128792867638d), (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.47783612200574d + "'", double2 == 94.47783612200574d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        double[] doubleArray23 = blockRealMatrix20.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23, arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector26.mapDivide((double) (-1));
        try {
            arrayRealVector8.setSubVector((-1), realVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-6));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray10);
        mersenneTwister6.clear();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix18.add(blockRealMatrix21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix26, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix31.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray37 = blockRealMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector40.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector40);
        double[] doubleArray45 = blockRealMatrix26.operate(doubleArray37);
        blockRealMatrix2.setColumn(1, doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix49.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        double[] doubleArray55 = blockRealMatrix52.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition59 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray45, doubleArray55, 3.831008000716577E22d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection60 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean63 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray55, orderDirection60, true, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection64 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            boolean boolean67 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray55, orderDirection64, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection60.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { (-1.0d), 52.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray3);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 62 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(2.99822295029797d, (-0.5440203106881555d), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, (-1), 1, 30000, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 97, 30000, 30000, (-1), 100, 97 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray13);
        java.lang.Integer[] intArray15 = multiDimensionMismatchException14.getWrongDimensions();
        java.lang.Integer[] intArray16 = multiDimensionMismatchException14.getExpectedDimensions();
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { (-1) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray16, intArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray16);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        try {
            openMapRealMatrix6.addToEntry((int) (byte) 10, 13, 50.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (13)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double[][] doubleArray24 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix34.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double45 = blockRealMatrix36.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        double double46 = array2DRowRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix53.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix56);
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = blockRealMatrix57.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector61 = blockRealMatrix57.getColumnVector((int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor62 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double63 = blockRealMatrix57.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor62);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix66.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix69);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix66.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix73);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix80 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix81 = blockRealMatrix77.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix80);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix82 = blockRealMatrix74.add(blockRealMatrix77);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix84 = blockRealMatrix82.scalarAdd(2.718281828459045d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix57.subtract(blockRealMatrix84);
        double[][] doubleArray86 = blockRealMatrix57.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix87 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray86);
        try {
            array2DRowRealMatrix13.copySubMatrix((int) (short) 1, 0, 0, (-6), doubleArray86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(blockRealMatrix81);
        org.junit.Assert.assertNotNull(blockRealMatrix82);
        org.junit.Assert.assertNotNull(blockRealMatrix84);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix19.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = blockRealMatrix19.walkInRowOrder(realMatrixChangingVisitor22, 0, 6, (int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix41.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix44.copy();
        double[][] doubleArray47 = blockRealMatrix44.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray37, doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(52, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (short) 0, 5.574077246549024d, 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.00001f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker0 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double double1 = simpleValueChecker0.getAbsoluteThreshold();
        double double2 = simpleValueChecker0.getRelativeThreshold();
        double double3 = simpleValueChecker0.getRelativeThreshold();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.add(blockRealMatrix18);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix23, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        double[] doubleArray34 = blockRealMatrix31.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector37.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, arrayRealVector37);
        double[] doubleArray42 = blockRealMatrix23.operate(doubleArray34);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 0.0d, false);
        java.lang.Double double46 = pointValuePair45.getValue();
        double[] doubleArray47 = pointValuePair45.getFirst();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix50.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix61.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix58.add(blockRealMatrix61);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix66, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix74);
        double[] doubleArray77 = blockRealMatrix74.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector80.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77, arrayRealVector80);
        double[] doubleArray85 = blockRealMatrix66.operate(doubleArray77);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair88 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray85, 0.0d, false);
        double[] doubleArray89 = pointValuePair88.getPointRef();
        boolean boolean90 = simpleValueChecker0.converged((int) (short) 0, pointValuePair45, pointValuePair88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-14d + "'", double2 == 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1102230246251565E-14d + "'", double3 == 1.1102230246251565E-14d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = blockRealMatrix2.getColumnMatrix((int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
        double[][] doubleArray24 = blockRealMatrix22.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        defaultRealMatrixPreservingVisitor27.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double36 = array2DRowRealMatrix26.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector38.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        double double47 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector38.copy();
        double[] doubleArray49 = arrayRealVector38.toArray();
        double[] doubleArray50 = array2DRowRealMatrix26.operate(doubleArray49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix53.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix53.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        double[][] doubleArray62 = blockRealMatrix60.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor65 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double66 = defaultRealMatrixPreservingVisitor65.end();
        defaultRealMatrixPreservingVisitor65.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double74 = array2DRowRealMatrix64.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65);
        double[][] doubleArray75 = array2DRowRealMatrix64.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer0.getStatisticsSigmaHistory();
        int int3 = cMAESOptimizer0.getEvaluations();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList4 = cMAESOptimizer0.getStatisticsMeanHistory();
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(realMatrixList4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        int int3 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray6 = null;
        try {
            openMapRealMatrix4.setColumn(1077936128, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,077,936,128)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        int int24 = arrayRealVector23.getMaxIndex();
        double[] doubleArray25 = arrayRealVector23.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix28.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix40.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        double[] doubleArray46 = blockRealMatrix43.getRow((int) (short) 1);
        blockRealMatrix28.setRow(0, doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray46, (double) 100);
        double[] doubleArray50 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector52.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector57.setEntry(0, (double) 10.0f);
        double double61 = arrayRealVector52.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector63.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector68.setEntry(0, (double) 10.0f);
        double double72 = arrayRealVector63.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57, arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57);
        int int75 = arrayRealVector74.getMaxIndex();
        double[] doubleArray76 = arrayRealVector74.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix79 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix82 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix83 = blockRealMatrix79.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix82);
        double[] doubleArray85 = blockRealMatrix82.getRow((int) (short) 1);
        double double86 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray76, doubleArray85);
        double double87 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray50, doubleArray85);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(blockRealMatrix83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 10.0d + "'", double86 == 10.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10.0d + "'", double87 == 10.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1), 0);
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) (byte) 10, 1, orderDirection3, true);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonicSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor12.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double20 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix23.add(openMapRealMatrix26);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix11.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 32");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector3.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector8.setEntry(0, (double) 10.0f);
        double double12 = arrayRealVector3.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix17.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix25.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix25.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix36.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix39);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix33.add(blockRealMatrix36);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix41, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        double[] doubleArray52 = blockRealMatrix49.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector55.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray52, arrayRealVector55);
        double[] doubleArray60 = blockRealMatrix41.operate(doubleArray52);
        blockRealMatrix17.setColumn(1, doubleArray60);
        try {
            arrayRealVector1.setSubVector((int) (short) 100, doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        double[] doubleArray41 = pointValuePair40.getKey();
        double[] doubleArray42 = pointValuePair40.getPointRef();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 10, (float) (byte) -10, (float) 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        defaultRealMatrixPreservingVisitor14.start((int) '4', (int) 'a', (int) (byte) 0, 100, 0, (int) (byte) -1);
        double double23 = array2DRowRealMatrix13.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double[][] doubleArray24 = array2DRowRealMatrix13.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix27.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix38.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix35.add(blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix38.createMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor47 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double48 = blockRealMatrix38.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        defaultRealMatrixPreservingVisitor47.visit(0, (int) (byte) 0, 4.9E-324d);
        double double53 = array2DRowRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor54 = null;
        try {
            double double59 = array2DRowRealMatrix13.walkInRowOrder(realMatrixChangingVisitor54, (int) (byte) 100, (int) ' ', (int) (byte) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 3.732511156817248d, (java.lang.Number) 52, (java.lang.Number) 1.1102230246251565E-14d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.732511156817248d + "'", number4.equals(3.732511156817248d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace(",", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(35.000004f, (float) (-127), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1493912449);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1493912448 + "'", int1 == 1493912448);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker1 = cMAESOptimizer0.getConvergenceChecker();
        int int2 = cMAESOptimizer0.getEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray11 = new double[] { 1.0d, 10L, 0.0d, (byte) 100, (byte) 100 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, (int) (byte) 0, (int) (byte) 1);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = cMAESOptimizer0.optimize(97, multivariateFunction4, goalType5, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 141.77799547179387d + "'", double12 == 141.77799547179387d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double[][] doubleArray19 = blockRealMatrix10.getData();
        int int20 = blockRealMatrix10.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector24.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector29.setEntry(0, (double) 10.0f);
        double double33 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double34 = arrayRealVector22.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector38.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector43.setEntry(0, (double) 10.0f);
        double double47 = arrayRealVector38.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double48 = arrayRealVector36.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = arrayRealVector29.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector50 = blockRealMatrix10.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray52 = blockRealMatrix10.getRow((int) (byte) 0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.copy();
        double[][] doubleArray8 = blockRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, true);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-40.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.117214930923896d + "'", double1 == 1.117214930923896d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor12.start((int) 'a', (int) (short) 1, (int) (short) -1, 13, (-1), 10);
        double double20 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        double[] doubleArray31 = blockRealMatrix11.preMultiply(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair33 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1796951359));
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        java.lang.String str3 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str4 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "}" + "'", str4.equals("}"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        int int14 = array2DRowRealMatrix13.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double26 = arrayRealVector16.getNorm();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector16.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.mapSubtractToSelf(0.0d);
        double[] doubleArray31 = arrayRealVector16.toArray();
        double[] doubleArray32 = array2DRowRealMatrix13.operate(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix35.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix32.add(blockRealMatrix35);
        double double41 = blockRealMatrix40.getFrobeniusNorm();
        double[] doubleArray43 = blockRealMatrix40.getColumn((int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray43);
        double double45 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray21, doubleArray43);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair47 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray21, (java.lang.Double) 1097.2817086347977d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int[] intArray5 = new int[] { (short) -1, (short) 0, 100, (short) 10, '4' };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed(1L);
        mersenneTwister6.setSeed((int) (byte) -10);
        float float11 = mersenneTwister6.nextFloat();
        mersenneTwister6.setSeed(0L);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.2761221f + "'", float11 == 0.2761221f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = blockRealMatrix6.scalarMultiply((double) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix6.add(realMatrix43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realMatrix42);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        int int14 = array2DRowRealMatrix13.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector16.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector21.setEntry(0, (double) 10.0f);
        double double25 = arrayRealVector16.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double26 = arrayRealVector16.getNorm();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector16.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector16.mapSubtractToSelf(0.0d);
        double[] doubleArray31 = arrayRealVector16.toArray();
        double[] doubleArray32 = array2DRowRealMatrix13.operate(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix36.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix39);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix36.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix43);
        double[][] doubleArray45 = blockRealMatrix43.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45, false);
        int int48 = array2DRowRealMatrix47.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector50.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector55.setEntry(0, (double) 10.0f);
        double double59 = arrayRealVector50.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        double double60 = arrayRealVector50.getNorm();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector50.append(0.0d);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector50.mapSubtractToSelf(0.0d);
        double[] doubleArray65 = arrayRealVector50.toArray();
        double[] doubleArray66 = array2DRowRealMatrix47.operate(doubleArray65);
        double[][] doubleArray67 = array2DRowRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.0d + "'", double60 == 10.0d);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (-6), (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math3.util.FastMath.log10(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.954589770191003d) + "'", double1 == (-13.954589770191003d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) ' ', 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        try {
            openMapRealMatrix7.addToEntry((-1), (int) (byte) -10, (double) 13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray6 = new double[] { 2.2737367544323206E-13d, (-1L), 1, (byte) 0, 27.18281828459045d, (-1.0f) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.getSubVector(52, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.add(blockRealMatrix13);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
        double[] doubleArray29 = blockRealMatrix26.getRow((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector32.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector32);
        double[] doubleArray37 = blockRealMatrix18.operate(doubleArray29);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, 0.0d, false);
        java.lang.Double double41 = pointValuePair40.getValue();
        double[] doubleArray42 = pointValuePair40.getFirst();
        double[] doubleArray43 = pointValuePair40.getKey();
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarMultiply((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector17.setEntry(0, (double) 10.0f);
        double double21 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double22 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector26.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        double double35 = arrayRealVector26.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double36 = arrayRealVector24.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        double double39 = arrayRealVector17.getEntry(10);
        org.apache.commons.math3.linear.RealVector realVector40 = blockRealMatrix6.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix6.scalarAdd((double) (short) -1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix42.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix46.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 10, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix57.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix60);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.add(blockRealMatrix57);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix62, (int) 'a');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix43.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x10 but expected 10x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) ' ', (float) (short) 10, (-127));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector1.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector6.setEntry(0, (double) 10.0f);
        double double10 = arrayRealVector1.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector12.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        double double18 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector20.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector25.setEntry(0, (double) 10.0f);
        double double29 = arrayRealVector20.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector31.setEntry(0, (double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
        arrayRealVector36.setEntry(0, (double) 10.0f);
        double double40 = arrayRealVector31.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector12.mapMultiplyToSelf((double) '#');
        org.apache.commons.math3.exception.util.Localizable localizable45 = null;
        org.apache.commons.math3.exception.util.Localizable localizable46 = null;
        org.apache.commons.math3.exception.NoDataException noDataException47 = new org.apache.commons.math3.exception.NoDataException(localizable46);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext48 = noDataException47.getContext();
        java.lang.Throwable[] throwableArray49 = noDataException47.getSuppressed();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) realVector44, localizable45, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(realVector44);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(exceptionContext48);
        org.junit.Assert.assertNotNull(throwableArray49);
    }
}

