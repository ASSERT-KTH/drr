import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField21.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getLn10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField28.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.add(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getLn10();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp33.subtract(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField44 = dfp42.getField();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp19.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.newInstance(0.6923023678465664d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpField44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.21832965848010036d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9762606057648759d + "'", double1 == 0.9762606057648759d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass15 = roundingMode14.getClass();
        dfpField11.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp9.add(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.multiply((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2032451572L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.032451572E9d + "'", double1 == 2.032451572E9d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 4, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField12.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.newInstance();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField21.getRoundingMode();
        int int24 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = dfpField29.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(100L);
        int int35 = dfp34.log10();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = dfpField37.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getLn10();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance((long) 100);
        boolean boolean43 = dfp34.greaterThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode47 = dfpField45.getRoundingMode();
        int int48 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.getE();
        int int50 = dfp49.getRadixDigits();
        boolean boolean51 = dfp40.lessThan(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField53.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField53.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getLn10();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField53.getLn5();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp40.divide(dfp57);
        boolean boolean59 = dfp27.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.Dfp.copysign(dfp19, dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp8.remainder(dfp58);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertTrue("'" + roundingMode47 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode47.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.FastMath.min(0.17827547f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(10L);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
//        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
//        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
//        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
//        int int13 = dfp12.log10();
//        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField15.getRoundingMode();
//        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((long) 100);
//        boolean boolean21 = dfp12.greaterThan(dfp18);
//        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField23.getRoundingMode();
//        int int26 = dfpField23.getIEEEFlags();
//        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.getE();
//        int int28 = dfp27.getRadixDigits();
//        boolean boolean29 = dfp18.lessThan(dfp27);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister();
//        int int32 = mersenneTwister30.nextInt((int) (byte) 1);
//        long long33 = mersenneTwister30.nextLong();
//        boolean boolean34 = dfp27.equals((java.lang.Object) long33);
//        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField38.getRoundingMode();
//        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance(100L);
//        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
//        dfpField45.clearIEEEFlags();
//        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField45.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
//        java.lang.Class<?> wildcardClass49 = roundingMode48.getClass();
//        dfpField45.setRoundingMode(roundingMode48);
//        org.apache.commons.math.dfp.Dfp dfp51 = dfpField45.getLn2();
//        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getTwo();
//        org.apache.commons.math.dfp.Dfp dfp53 = dfp27.dotrap(1446742981, "org.apache.commons.math.exception.MathRuntimeException: ", dfp41, dfp51);
//        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance();
//        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
//        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getPiSplit();
//        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode58 = dfpField56.getRoundingMode();
//        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getLn10();
//        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.newInstance(100L);
//        boolean boolean62 = dfp54.lessThan(dfp59);
//        org.apache.commons.math.dfp.Dfp dfp63 = dfp5.divide(dfp54);
//        org.junit.Assert.assertNotNull(dfpArray2);
//        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(dfp4);
//        org.junit.Assert.assertNotNull(dfp5);
//        org.junit.Assert.assertNotNull(dfpArray8);
//        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(dfp10);
//        org.junit.Assert.assertNotNull(dfp12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dfpArray16);
//        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(dfp18);
//        org.junit.Assert.assertNotNull(dfp20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dfpArray24);
//        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
//        org.junit.Assert.assertNotNull(dfp27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 5232904197945889330L + "'", long33 == 5232904197945889330L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dfpArray39);
//        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(dfp41);
//        org.junit.Assert.assertNotNull(dfp43);
//        org.junit.Assert.assertNotNull(dfpArray47);
//        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(dfp51);
//        org.junit.Assert.assertNotNull(dfp52);
//        org.junit.Assert.assertNotNull(dfp53);
//        org.junit.Assert.assertNotNull(dfp54);
//        org.junit.Assert.assertNotNull(dfpArray57);
//        org.junit.Assert.assertTrue("'" + roundingMode58 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode58.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
//        org.junit.Assert.assertNotNull(dfp59);
//        org.junit.Assert.assertNotNull(dfp61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(dfp63);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException7.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        java.lang.Number number12 = notStrictlyPositiveException7.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number17 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray18 = notStrictlyPositiveException16.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable14, objArray18);
        java.lang.Class<?> wildcardClass20 = localizable14.getClass();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException24.addSuppressed((java.lang.Throwable) notStrictlyPositiveException27);
        java.lang.Number number29 = numberIsTooSmallException24.getMin();
        java.lang.Throwable[] throwableArray30 = numberIsTooSmallException24.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable3, localizable14, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathRuntimeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathRuntimeException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 1.3382446839149402d, (java.lang.Number) (-0.8813735870195429d), true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (byte) 0 + "'", number17.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1.0d + "'", number29.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(647325673);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(1833.4649444186343d);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 0, 0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 5232904197945889330L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException3.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number13 = notStrictlyPositiveException12.getArgument();
        java.lang.Object[] objArray14 = notStrictlyPositiveException12.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable10, objArray14);
        java.lang.Class<?> wildcardClass16 = localizable10.getClass();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number19 = notStrictlyPositiveException18.getArgument();
        java.lang.Object[] objArray20 = notStrictlyPositiveException18.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException24.addSuppressed((java.lang.Throwable) notStrictlyPositiveException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray39 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister33.setSeed(intArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException43.addSuppressed((java.lang.Throwable) notStrictlyPositiveException46);
        java.lang.Object[] objArray49 = new java.lang.Object[] { (short) -1, 0, intArray39, notStrictlyPositiveException43, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException27, localizable29, localizable30, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException55.addSuppressed((java.lang.Throwable) notStrictlyPositiveException58);
        java.lang.Number number60 = notStrictlyPositiveException55.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException55);
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException55.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number65 = notStrictlyPositiveException64.getArgument();
        java.lang.Object[] objArray66 = notStrictlyPositiveException64.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable62, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a', numberIsTooSmallException73, (-1.0f), (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray76);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18, localizable51, localizable52, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 10L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException84 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException87 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable85, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException84.addSuppressed((java.lang.Throwable) notStrictlyPositiveException87);
        java.lang.Number number89 = numberIsTooSmallException84.getMin();
        java.lang.Throwable[] throwableArray90 = numberIsTooSmallException84.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable51, (java.lang.Object[]) throwableArray90);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 0 + "'", number13.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (byte) 0 + "'", number19.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 0 + "'", number60.equals(0));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + (byte) 0 + "'", number65.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + 1.0d + "'", number89.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray90);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.4752602133939071d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6084326787624168d + "'", double1 == 0.6084326787624168d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(2);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((-4));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.cosh(43.08715043318904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5791801541797612E18d + "'", double1 == 2.5791801541797612E18d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0.15071714f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.635455978971311d + "'", double1 == 8.635455978971311d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1446742981);
        dfpField1.setIEEEFlagsBits(16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.newInstance(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(647325673);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.ceil();
        int int15 = dfp14.getRadixDigits();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException23.addSuppressed((java.lang.Throwable) notStrictlyPositiveException26);
        java.lang.Number number28 = notStrictlyPositiveException23.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException23);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number33 = notStrictlyPositiveException32.getArgument();
        java.lang.Object[] objArray34 = notStrictlyPositiveException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable30, objArray34);
        java.lang.Class<?> wildcardClass36 = localizable30.getClass();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException40.addSuppressed((java.lang.Throwable) notStrictlyPositiveException43);
        java.lang.Number number45 = numberIsTooSmallException40.getMin();
        java.lang.Throwable[] throwableArray46 = numberIsTooSmallException40.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18, localizable19, localizable30, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathRuntimeException47.getGeneralPattern();
        boolean boolean49 = dfp14.equals((java.lang.Object) localizable48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp6.nextAfter(dfp14);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (byte) 0 + "'", number33.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1.0d + "'", number45.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.subtract(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField24 = dfp22.getField();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((int) (short) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpField24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(647325673);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 100);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1412375784) + "'", int4 == (-1412375784));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 100);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.6711556f + "'", float3 == 0.6711556f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp6.nextAfter(dfp14);
        int int24 = dfp14.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 3688677);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.813925595701662d + "'", double1 == 15.813925595701662d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5637033385775058d) + "'", double1 == (-0.5637033385775058d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5538323529363413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6183905846101025d + "'", double1 == 0.6183905846101025d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((long) 100);
        boolean boolean15 = dfp6.greaterThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        int int20 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getE();
        int int22 = dfp21.getRadixDigits();
        boolean boolean23 = dfp12.lessThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 8729313035327295421L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5918197323600835d, 4.994838410232779d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5918197323600835d + "'", double2 == 0.5918197323600835d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.String str8 = mathRuntimeException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathRuntimeException7.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str8.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField21.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getLn10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField28.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getLn10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.add(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getLn10();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp33.subtract(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField44 = dfp42.getField();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp19.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.power10K(2032451572);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpField44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp5.remainder(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.getLn10();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(100L);
        int int30 = dfp29.log10();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField39.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode41 = dfpField39.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.getLn10();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.add(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp29.nextAfter(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField48.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField48.getESplit();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp46.divide(dfp52);
        boolean boolean54 = dfp5.lessThan(dfp46);
        int int55 = dfp46.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertTrue("'" + roundingMode41 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode41.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9175963564003126d), 1.8613860176427304d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9175963564003126d) + "'", double2 == (-0.9175963564003126d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.5488135008937807d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException15.addSuppressed((java.lang.Throwable) notStrictlyPositiveException18);
        java.lang.Number number20 = notStrictlyPositiveException15.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException15);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number25 = notStrictlyPositiveException24.getArgument();
        java.lang.Object[] objArray26 = notStrictlyPositiveException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable22, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException30.addSuppressed((java.lang.Throwable) notStrictlyPositiveException33);
        java.lang.Number number35 = notStrictlyPositiveException30.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException30);
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException30.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException11, localizable22, localizable37, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException43.addSuppressed((java.lang.Throwable) notStrictlyPositiveException46);
        java.lang.Number number48 = notStrictlyPositiveException43.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException43);
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Throwable[] throwableArray51 = notStrictlyPositiveException43.getSuppressed();
        java.lang.Object[] objArray52 = notStrictlyPositiveException43.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException55.addSuppressed((java.lang.Throwable) notStrictlyPositiveException58);
        java.lang.Number number60 = notStrictlyPositiveException55.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException55);
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException55.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException68.addSuppressed((java.lang.Throwable) notStrictlyPositiveException71);
        java.lang.Number number73 = notStrictlyPositiveException68.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException68);
        org.apache.commons.math.exception.util.Localizable localizable75 = notStrictlyPositiveException68.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number78 = notStrictlyPositiveException77.getArgument();
        java.lang.Object[] objArray79 = notStrictlyPositiveException77.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable75, objArray79);
        java.lang.Class<?> wildcardClass81 = localizable75.getClass();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException83 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number84 = notStrictlyPositiveException83.getArgument();
        java.lang.Object[] objArray85 = notStrictlyPositiveException83.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException43, localizable62, localizable75, objArray85);
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException89 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number90 = notStrictlyPositiveException89.getArgument();
        java.lang.Object[] objArray91 = notStrictlyPositiveException89.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable87, objArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray91);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (byte) 0 + "'", number25.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0 + "'", number35.equals(0));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0 + "'", number48.equals(0));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 0 + "'", number60.equals(0));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 0 + "'", number73.equals(0));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + (byte) 0 + "'", number78.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (byte) 0 + "'", number84.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertTrue("'" + number90 + "' != '" + (byte) 0 + "'", number90.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1, (double) 7692698082559361259L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.1073424338879928E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1073424560924536E-8d + "'", double1 == 2.1073424560924536E-8d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0);
//        mersenneTwister0.setSeed(100L);
//        float float6 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed(100);
//        int int10 = mersenneTwister0.nextInt((int) (short) 100);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.07871711f + "'", float6 == 0.07871711f);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) 100);
        boolean boolean22 = dfp13.greaterThan(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField24.getRoundingMode();
        int int27 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.getE();
        int int29 = dfp28.getRadixDigits();
        boolean boolean30 = dfp19.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField33.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getLn10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField40.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getLn10();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.add(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp19.remainder(dfp38);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass11 = roundingMode10.getClass();
        dfpField7.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp();
        int int14 = dfp13.log10K();
        boolean boolean15 = dfp5.greaterThan(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.newInstance((byte) 100, (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp18);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed((int) (byte) 1);
//        mersenneTwister0.setSeed((int) (short) 0);
//        boolean boolean6 = mersenneTwister0.nextBoolean();
//        long long7 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.09627032f + "'", float1 == 0.09627032f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-7510691156635244939L) + "'", long7 == (-7510691156635244939L));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.6321205588285577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6750663910725149d + "'", double1 == 0.6750663910725149d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8187316803950414d + "'", double1 == 0.8187316803950414d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(2);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.divide((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField10.getRoundingMode();
        int int13 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField18.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance(100L);
        int int24 = dfp23.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn10();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance((long) 100);
        boolean boolean32 = dfp23.greaterThan(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.getE();
        int int39 = dfp38.getRadixDigits();
        boolean boolean40 = dfp29.lessThan(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode44 = dfpField42.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getLn10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp29.divide(dfp46);
        boolean boolean48 = dfp16.greaterThan(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp47);
        boolean boolean50 = dfp47.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField52.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode54 = dfpField52.getRoundingMode();
        int int55 = dfpField52.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.getE();
        int int57 = dfp56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeExp(dfp47, dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertTrue("'" + roundingMode44 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode44.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertTrue("'" + roundingMode54 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode54.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.7031839360032603E-108d), 4.7769081081662863E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.newInstance(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(97.0d);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField20.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn10();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp32.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp14.dotrap(10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp25, dfp32);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = dfpField43.getRoundingMode();
        int int46 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.getE();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField49.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode51 = dfpField49.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getLn10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp47.divide(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField57.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = dfpField57.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getLn10();
        org.apache.commons.math.dfp.Dfp dfp61 = org.apache.commons.math.dfp.DfpField.computeExp(dfp54, dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField63.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = dfpField63.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.getLn10();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField70.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField70.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.getLn10();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.add(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp60.newInstance(dfp75);
        org.apache.commons.math.dfp.Dfp dfp78 = new org.apache.commons.math.dfp.Dfp(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp32.subtract(dfp78);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray82 = dfpField81.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode83 = dfpField81.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField81.getLn10();
        org.apache.commons.math.dfp.Dfp dfp86 = dfp84.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField88 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray89 = dfpField88.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode90 = dfpField88.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField88.getLn10();
        org.apache.commons.math.dfp.Dfp dfp93 = dfp91.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp94 = dfp86.newInstance(dfp91);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp94.multiply(4);
        boolean boolean97 = dfp79.greaterThan(dfp96);
        org.apache.commons.math.dfp.Dfp dfp99 = dfp79.newInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertTrue("'" + roundingMode51 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode51.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfpArray82);
        org.junit.Assert.assertTrue("'" + roundingMode83 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode83.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfpArray89);
        org.junit.Assert.assertTrue("'" + roundingMode90 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode90.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertNotNull(dfp99);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((long) 100);
        boolean boolean15 = dfp6.greaterThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        int int20 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getE();
        int int22 = dfp21.getRadixDigits();
        boolean boolean23 = dfp12.lessThan(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getLn5();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp12.divide(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        int int35 = dfpField32.getIEEEFlags();
        dfpField32.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp38);
        double[] doubleArray40 = dfp30.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        java.lang.String str7 = dfp6.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.609437912434" + "'", str7.equals("1.609437912434"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = numberIsTooSmallException3.getMin();
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number11 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7568024953079282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9886883909790607d + "'", double1 == 0.9886883909790607d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.newInstance(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(97.0d);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField20.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn10();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp32.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp14.dotrap(10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp25, dfp32);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = dfpField43.getRoundingMode();
        int int46 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.getE();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField49.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode51 = dfpField49.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getLn10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp47.divide(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField57.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = dfpField57.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getLn10();
        org.apache.commons.math.dfp.Dfp dfp61 = org.apache.commons.math.dfp.DfpField.computeExp(dfp54, dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField63.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = dfpField63.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.getLn10();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField70.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField70.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.getLn10();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.add(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp60.newInstance(dfp75);
        org.apache.commons.math.dfp.Dfp dfp78 = new org.apache.commons.math.dfp.Dfp(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp32.subtract(dfp78);
        double double80 = dfp78.toDouble();
        org.apache.commons.math.dfp.Dfp dfp81 = new org.apache.commons.math.dfp.Dfp(dfp78);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertTrue("'" + roundingMode51 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode51.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.0d + "'", double80 == 100.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass13 = roundingMode12.getClass();
        dfpField9.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp7.add(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.power10K(35);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-1L));
        java.lang.Object[] objArray12 = notStrictlyPositiveException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException15.addSuppressed((java.lang.Throwable) notStrictlyPositiveException18);
        java.lang.Number number20 = notStrictlyPositiveException15.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException15);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) (-1L));
        java.lang.Object[] objArray25 = notStrictlyPositiveException24.getArguments();
        java.lang.Object[] objArray26 = notStrictlyPositiveException24.getArguments();
        notStrictlyPositiveException11.addSuppressed((java.lang.Throwable) notStrictlyPositiveException24);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException30.addSuppressed((java.lang.Throwable) notStrictlyPositiveException33);
        java.lang.Number number35 = notStrictlyPositiveException30.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException30);
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException30.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField44.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField44.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException11, localizable37, localizable42, (java.lang.Object[]) dfpArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathRuntimeException50.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0 + "'", number35.equals(0));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(100);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.negate();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.newInstance(dfp13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(647325673);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((-1L));
        boolean boolean12 = dfp11.isNaN();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField8.clearIEEEFlags();
        int int10 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3();
        boolean boolean12 = dfp5.greaterThan(dfp11);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) 100);
        boolean boolean22 = dfp13.greaterThan(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField24.getRoundingMode();
        int int27 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.getE();
        int int29 = dfp28.getRadixDigits();
        boolean boolean30 = dfp19.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp19);
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.newInstance((double) (-6364434420694545467L));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.sqrt();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.divide((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 647325673);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8024596284161762d) + "'", double1 == (-0.8024596284161762d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        int int6 = dfp5.getRadixDigits();
        boolean boolean7 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass15 = roundingMode14.getClass();
        dfpField11.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField22.getRoundingMode();
        int int25 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(100L);
        int int36 = dfp35.log10();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField38.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getLn10();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((long) 100);
        boolean boolean44 = dfp35.greaterThan(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField46.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = dfpField46.getRoundingMode();
        int int49 = dfpField46.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getE();
        int int51 = dfp50.getRadixDigits();
        boolean boolean52 = dfp41.lessThan(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField54.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = dfpField54.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.getLn10();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp41.divide(dfp58);
        boolean boolean60 = dfp28.greaterThan(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp5.dotrap(1560931061, "hi!", dfp20, dfp28);
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp20.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField62.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertNotNull(dfpArray63);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.floor((-744.4400719213812d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-745.0d) + "'", double1 == (-745.0d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math.util.FastMath.abs(3688677);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3688677 + "'", int1 == 3688677);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits(35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException3.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number13 = notStrictlyPositiveException12.getArgument();
        java.lang.Object[] objArray14 = notStrictlyPositiveException12.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable10, objArray14);
        java.lang.Class<?> wildcardClass16 = localizable10.getClass();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, number17);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 0 + "'", number13.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp5.remainder(dfp21);
        int int23 = dfp22.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray6 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister0.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean9 = mersenneTwister8.nextBoolean();
        int[] intArray16 = new int[] { 4, ' ', ' ', ' ', (byte) -1, 100 };
        mersenneTwister8.setSeed(intArray16);
        mersenneTwister0.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField10.getRoundingMode();
        int int13 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField18.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance(100L);
        int int24 = dfp23.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn10();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance((long) 100);
        boolean boolean32 = dfp23.greaterThan(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.getE();
        int int39 = dfp38.getRadixDigits();
        boolean boolean40 = dfp29.lessThan(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode44 = dfpField42.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getLn10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp29.divide(dfp46);
        boolean boolean48 = dfp16.greaterThan(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp47);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.divide((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertTrue("'" + roundingMode44 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode44.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.String str9 = mathRuntimeException8.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.3258176636680326d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1446742981);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp6.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp6.divide(dfp30);
        boolean boolean32 = dfp31.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
        int int2 = mersenneTwister1.nextInt();
        int int3 = mersenneTwister1.nextInt();
        int int4 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed(8271634306652721373L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1560931061 + "'", int3 == 1560931061);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 839849605 + "'", int4 == 839849605);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 100);
        mersenneTwister1.setSeed((long) (byte) 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField11.getRoundingMode();
        int int14 = dfpField11.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getE();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.divide(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeExp(dfp22, dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.ceil();
        boolean boolean31 = dfp9.lessThan(dfp29);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray18 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister12.setSeed(intArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException22.addSuppressed((java.lang.Throwable) notStrictlyPositiveException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) -1, 0, intArray18, notStrictlyPositiveException22, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable8, localizable9, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 33, (java.lang.Number) 0.17354298f, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) (byte) 2, (java.lang.Number) (-0.9175963564003126d), false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(647325673);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField5.newDfp((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass17 = roundingMode16.getClass();
        dfpField13.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.negate();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException11.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray26 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister20.setSeed(intArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException30.addSuppressed((java.lang.Throwable) notStrictlyPositiveException33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) -1, 0, intArray26, notStrictlyPositiveException30, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException14, localizable16, localizable17, objArray36);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathRuntimeException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = mathRuntimeException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = mathRuntimeException37.getGeneralPattern();
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNull(localizable39);
        org.junit.Assert.assertNull(localizable40);
        org.junit.Assert.assertNull(localizable41);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray18 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister12.setSeed(intArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException22.addSuppressed((java.lang.Throwable) notStrictlyPositiveException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) -1, 0, intArray18, notStrictlyPositiveException22, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable8, localizable9, objArray28);
        java.lang.String str30 = notStrictlyPositiveException6.toString();
        boolean boolean31 = notStrictlyPositiveException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = notStrictlyPositiveException6.getSuppressed();
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)" + "'", str30.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass5 = roundingMode4.getClass();
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField12.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(100L);
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField20.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((long) 100);
        boolean boolean26 = dfp17.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField28.getRoundingMode();
        int int31 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getE();
        int int33 = dfp32.getRadixDigits();
        boolean boolean34 = dfp23.lessThan(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getLn10();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getLn5();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp23.divide(dfp40);
        boolean boolean42 = dfp10.greaterThan(dfp23);
        org.apache.commons.math.dfp.Dfp dfp43 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp44 = dfp23.add(dfp43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((long) 100);
        boolean boolean15 = dfp6.greaterThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        int int20 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getE();
        int int22 = dfp21.getRadixDigits();
        boolean boolean23 = dfp12.lessThan(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getLn5();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp12.divide(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        int int35 = dfpField32.getIEEEFlags();
        dfpField32.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField41.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getESplit();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.getTwo();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.getTwo();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.sqrt();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp47);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField14.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.add(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp5.multiply(dfp22);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 3);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.27470565f + "'", float2 == 0.27470565f);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0);
//        mersenneTwister0.setSeed((int) (byte) -1);
//        float float6 = mersenneTwister0.nextFloat();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean8 = mersenneTwister7.nextBoolean();
//        mersenneTwister7.setSeed(0);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((int) (short) 100);
//        byte[] byteArray15 = new byte[] {};
//        mersenneTwister14.nextBytes(byteArray15);
//        mersenneTwister12.nextBytes(byteArray15);
//        mersenneTwister7.nextBytes(byteArray15);
//        mersenneTwister0.nextBytes(byteArray15);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.78306735f + "'", float6 == 0.78306735f);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(byteArray15);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 4884609326931777910L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8846093269317775E18d + "'", double1 == 4.8846093269317775E18d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(2);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass7 = roundingMode6.getClass();
        dfpField1.setRoundingMode(roundingMode6);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp5.remainder(dfp21);
        boolean boolean23 = dfp21.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp30.add(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField42.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass46 = roundingMode45.getClass();
        dfpField42.setRoundingMode(roundingMode45);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.getLn2();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp38, dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField53.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField53.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getLn10();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField60.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode62 = dfpField60.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getLn10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.newInstance(100L);
        int int66 = dfp65.log10();
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField68.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode70 = dfpField68.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.getLn10();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance((long) 100);
        boolean boolean74 = dfp65.greaterThan(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray77 = dfpField76.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode78 = dfpField76.getRoundingMode();
        int int79 = dfpField76.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField76.getE();
        int int81 = dfp80.getRadixDigits();
        boolean boolean82 = dfp71.lessThan(dfp80);
        org.apache.commons.math.dfp.Dfp dfp83 = org.apache.commons.math.dfp.Dfp.copysign(dfp58, dfp71);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp50.add(dfp58);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertTrue("'" + roundingMode62 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode62.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertTrue("'" + roundingMode70 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode70.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(dfpArray77);
        org.junit.Assert.assertTrue("'" + roundingMode78 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode78.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 16 + "'", int79 == 16);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 4 + "'", int81 == 4);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(100L);
        int int23 = dfp22.log10();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance((long) 100);
        boolean boolean31 = dfp22.greaterThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField33.getRoundingMode();
        int int36 = dfpField33.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getE();
        int int38 = dfp37.getRadixDigits();
        boolean boolean39 = dfp28.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp5.remainder(dfp28);
        double double41 = dfp40.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.415696735465d + "'", double41 == 0.415696735465d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        double double15 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(100L);
        int int23 = dfp22.log10();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance((long) 100);
        boolean boolean31 = dfp22.greaterThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField33.getRoundingMode();
        int int36 = dfpField33.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getE();
        int int38 = dfp37.getRadixDigits();
        boolean boolean39 = dfp28.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp5.remainder(dfp28);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.71828182846d + "'", double15 == 2.71828182846d);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4862913247812135d + "'", double1 == 2.4862913247812135d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5448831893094142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6110747340269295d + "'", double1 == 0.6110747340269295d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray18 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister12.setSeed(intArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException22.addSuppressed((java.lang.Throwable) notStrictlyPositiveException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) -1, 0, intArray18, notStrictlyPositiveException22, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable8, localizable9, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException33.addSuppressed((java.lang.Throwable) notStrictlyPositiveException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister42 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray48 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister42.setSeed(intArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException52.addSuppressed((java.lang.Throwable) notStrictlyPositiveException55);
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) -1, 0, intArray48, notStrictlyPositiveException52, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException36, localizable38, localizable39, objArray58);
        notStrictlyPositiveException6.addSuppressed((java.lang.Throwable) mathRuntimeException59);
        java.lang.String str61 = notStrictlyPositiveException6.toString();
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)" + "'", str61.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)"));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0);
//        long long4 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8322921849960486353L) + "'", long4 == (-8322921849960486353L));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Throwable[] throwableArray10 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Object[] objArray11 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException14.addSuppressed((java.lang.Throwable) notStrictlyPositiveException17);
        java.lang.Number number19 = notStrictlyPositiveException14.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException27.addSuppressed((java.lang.Throwable) notStrictlyPositiveException30);
        java.lang.Number number32 = notStrictlyPositiveException27.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException27);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException27.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number37 = notStrictlyPositiveException36.getArgument();
        java.lang.Object[] objArray38 = notStrictlyPositiveException36.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable34, objArray38);
        java.lang.Class<?> wildcardClass40 = localizable34.getClass();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number43 = notStrictlyPositiveException42.getArgument();
        java.lang.Object[] objArray44 = notStrictlyPositiveException42.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable21, localizable34, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number49 = notStrictlyPositiveException48.getArgument();
        java.lang.Object[] objArray50 = notStrictlyPositiveException48.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable46, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 3.4965075614664802d);
        java.lang.Number number54 = notStrictlyPositiveException53.getArgument();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0 + "'", number32.equals(0));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (byte) 0 + "'", number37.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (byte) 0 + "'", number43.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (byte) 0 + "'", number49.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 3.4965075614664802d + "'", number54.equals(3.4965075614664802d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.math.util.FastMath.max(2032451572, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2032451572 + "'", int2 == 2032451572);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp13.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance(97.0d);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn10();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = dfpField41.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getLn10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp39.newInstance(dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp21.dotrap(10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp32, dfp39);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp6.subtract(dfp51);
        int int53 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(100L);
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) 100);
        boolean boolean22 = dfp13.greaterThan(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField24.getRoundingMode();
        int int27 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.getE();
        int int29 = dfp28.getRadixDigits();
        boolean boolean30 = dfp19.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField33.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getLn10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(100L);
        int int39 = dfp38.log10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = dfpField41.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getLn10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance((long) 100);
        boolean boolean47 = dfp38.greaterThan(dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp19.nextAfter(dfp38);
        int int49 = dfp38.classify();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException2.getGeneralPattern();
        boolean boolean10 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.0d, (java.lang.Number) 3.4965075614664802d, false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.floor();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField17.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass27 = roundingMode26.getClass();
        dfpField23.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp();
        int int30 = dfp29.log10K();
        boolean boolean31 = dfp21.greaterThan(dfp29);
        boolean boolean32 = dfp13.lessThan(dfp29);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.rint();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField12.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass16 = roundingMode15.getClass();
        dfpField12.setRoundingMode(roundingMode15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp10.add(dfp18);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        long long4 = mersenneTwister3.nextLong();
        int int5 = mersenneTwister3.nextInt();
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean7 = mersenneTwister6.nextBoolean();
        int[] intArray14 = new int[] { 4, ' ', ' ', ' ', (byte) -1, 100 };
        mersenneTwister6.setSeed(intArray14);
        mersenneTwister3.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        double double18 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8322921849960486353L) + "'", long4 == (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1223252363) + "'", int5 == (-1223252363));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.6549833169109538d + "'", double18 == 0.6549833169109538d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(100L);
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray6 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister0.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int int9 = mersenneTwister8.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1572990666 + "'", int9 == 1572990666);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.141592653589793d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray18 = new int[] { '#', 4, 4, '4', 16 };
        mersenneTwister12.setSeed(intArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 3.141592653589793d);
        notStrictlyPositiveException22.addSuppressed((java.lang.Throwable) notStrictlyPositiveException25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) -1, 0, intArray18, notStrictlyPositiveException22, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable8, localizable9, objArray28);
        java.lang.String str30 = notStrictlyPositiveException6.toString();
        boolean boolean31 = notStrictlyPositiveException6.getBoundIsAllowed();
        boolean boolean32 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)" + "'", str30.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(7692698082559361259L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.FastMath.max(3.1385946710539034d, 1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1385946710539034d + "'", double2 == 3.1385946710539034d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getESplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getTwo();
        boolean boolean21 = dfp5.lessThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.divide((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance(100L);
        int int38 = dfp37.log10();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField40.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getLn10();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance((long) 100);
        boolean boolean46 = dfp37.greaterThan(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField48.getRoundingMode();
        int int51 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getE();
        int int53 = dfp52.getRadixDigits();
        boolean boolean54 = dfp43.lessThan(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp43);
        boolean boolean56 = dfp55.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField60.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode62 = dfpField60.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getLn10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField67.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode69 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.getLn10();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp65.add(dfp72);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.negate();
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray77 = dfpField76.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode78 = dfpField76.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField76.getLn10();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp81.sqrt();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp55.dotrap((int) (short) 10, "", dfp72, dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp20.add(dfp55);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertTrue("'" + roundingMode62 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode62.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertTrue("'" + roundingMode69 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode69.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfpArray77);
        org.junit.Assert.assertTrue("'" + roundingMode78 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode78.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 764944319202303706L, (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.6494433E17f + "'", float2 == 7.6494433E17f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) 100);
        double double7 = dfp4.toDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.302585092994d + "'", double7 == 2.302585092994d);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        int[] intArray8 = new int[] { 4, ' ', ' ', ' ', (byte) -1, 100 };
//        mersenneTwister0.setSeed(intArray8);
//        boolean boolean10 = mersenneTwister0.nextBoolean();
//        int int11 = mersenneTwister0.nextInt();
//        double double12 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1446742981 + "'", int11 == 1446742981);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.13347296516751905d + "'", double12 == 0.13347296516751905d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        int int14 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getESplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getTwo();
        boolean boolean21 = dfp5.lessThan(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField25.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField32.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp30.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp39 = null;
        org.apache.commons.math.dfp.Dfp dfp40 = dfp5.dotrap(100, "org.apache.commons.math.exception.NotStrictlyPositiveException: 3.142 is smaller than, or equal to, the minimum (0)", dfp38, dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp38.getTwo();
        boolean boolean42 = dfp41.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode46 = dfpField44.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode47 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        java.lang.Class<?> wildcardClass48 = roundingMode47.getClass();
        dfpField44.setRoundingMode(roundingMode47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField44.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField44.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField44.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField44.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode58 = dfpField56.getRoundingMode();
        int int59 = dfpField56.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField62.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode64 = dfpField62.getRoundingMode();
        int int65 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField62.getE();
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField68.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode70 = dfpField68.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.getLn10();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp66.divide(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.sqrt();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp60.nextAfter(dfp73);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField44.newDfp(dfp60);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp41.add(dfp77);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertTrue("'" + roundingMode46 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode46.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode47 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode47.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertTrue("'" + roundingMode58 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode58.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfpArray63);
        org.junit.Assert.assertTrue("'" + roundingMode64 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode64.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertTrue("'" + roundingMode70 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode70.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(35);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp13.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance(97.0d);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn10();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance((long) 100);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = dfpField41.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getLn10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp39.newInstance(dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp21.dotrap(10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp32, dfp39);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp6.subtract(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(0);
        dfpField54.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.getPi();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.ceil();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp59.newInstance();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.rint();
        int int62 = dfp61.log10K();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp51.subtract(dfp61);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(dfp63);
    }
}

