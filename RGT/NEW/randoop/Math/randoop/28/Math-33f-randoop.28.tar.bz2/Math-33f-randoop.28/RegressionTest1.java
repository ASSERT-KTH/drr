import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), (-1.1071486939522315d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0000001f) + "'", float2 == (-1.0000001f));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (-1023));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1023L + "'", long1 == 1023L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(5.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        java.io.ObjectInputStream objectInputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) pointValuePair10, "}", objectInputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        java.lang.String str2 = maxCountExceededException1.toString();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded" + "'", str2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0L + "'", number3.equals(0L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray2 = array2DRowRealMatrix1.getData();
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray2);
        java.lang.Number number4 = zeroException3.getArgument();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        try {
            blockRealMatrix2.setEntry((int) (short) 10, (-127), 5.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeDivide(realVector20);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1023L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix5.walkInRowOrder(realMatrixChangingVisitor6, (int) (byte) 10, 100, 1079574528, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector0.mapToSelf(univariateFunction13);
        boolean boolean15 = arrayRealVector0.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int[] intArray7 = new int[] { 5, ' ', 6 };
        int[] intArray12 = new int[] { 5, 1079574528, 32, 1079574528 };
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray27 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray28 = new double[][] { doubleArray20, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException30 = new org.apache.commons.math3.exception.NullArgumentException(localizable13, (java.lang.Object[]) doubleArray28);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray7, intArray12, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        try {
            double[] doubleArray7 = blockRealMatrix2.getRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.subtract(realMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) 'a', (-1023), (int) ' ', 1079574528);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.power((-127));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: p must be >= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        try {
            array2DRowRealMatrix17.setEntry(36, (-127), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        double double14 = arrayRealVector13.getNorm();
        arrayRealVector13.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, false);
        try {
            blockRealMatrix2.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math3.util.Precision.round((double) ' ', 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 36, (int) (short) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double double20 = arrayRealVector19.getNorm();
        arrayRealVector19.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector29.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector19.ebeDivide(realVector32);
        boolean boolean34 = arrayRealVector0.equals((java.lang.Object) arrayRealVector19);
        try {
            arrayRealVector19.setEntry(5, (double) 5.0000005f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.0d + "'", double20 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray18 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray18, (double) (-1L));
        double[] doubleArray21 = pointValuePair20.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector15.mapMultiply((double) '#');
        double double25 = arrayRealVector15.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector15.append((double) 6);
        try {
            blockRealMatrix2.setColumnVector((int) (short) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0f), (java.lang.Number) 4.654551027821466d, (java.lang.Number) 6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, 1072693248, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(5.0000005f, 1.07957453E9f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = blockRealMatrix6.walkInOptimizedOrder(realMatrixChangingVisitor7, (int) (short) 0, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 180.0d, (java.lang.Number) 3.58351893845611d, false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealVector realVector7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, realVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray26 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, (double) (-1L));
        double[] doubleArray29 = pointValuePair28.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray34 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair36 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray34, (double) (-1L));
        double[] doubleArray37 = pointValuePair36.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.copy();
        java.lang.String str40 = arrayRealVector31.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector31);
        double double42 = arrayRealVector31.getLInfNorm();
        try {
            double double43 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{}" + "'", str40.equals("{}"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor5, 5, 0, (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) -1, 52, 0, (-1023));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.getRowMatrix((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat8 = realVectorFormat7.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat8);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat10 = new org.apache.commons.math3.linear.RealVectorFormat(">=", ">=", "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", numberFormat8);
        java.text.ParsePosition parsePosition11 = null;
        try {
            java.lang.Number number12 = org.apache.commons.math3.util.CompositeFormat.parseNumber("}", numberFormat8, parsePosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, 100.0d, true);
        java.lang.Double double16 = pointValuePair15.getValue();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16.equals(100.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(0.5d, (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        int[] intArray9 = new int[] { (short) 10, 0 };
        int[] intArray10 = new int[] {};
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, intArray9, intArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        boolean boolean15 = linearConstraint13.equals((java.lang.Object) 32L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0L + "'", number2.equals(0L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        double[] doubleArray8 = null;
        try {
            blockRealMatrix4.setRow((-1), doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1), (double) 32L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix6.getRowVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (-1L), 35.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        try {
            double[] doubleArray8 = blockRealMatrix4.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction21 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector19, 0.5210953054937474d);
        double[] doubleArray27 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray37 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray37);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint41 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray27, (double) 5, relationship31, doubleArray37, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector19.mapSubtractToSelf((double) 5);
        boolean boolean45 = arrayRealVector19.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray49 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray49, (double) (-1L));
        double[] doubleArray52 = pointValuePair51.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector46, doubleArray52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray57 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray57, (double) (-1L));
        double[] doubleArray60 = pointValuePair59.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector54, doubleArray60);
        org.apache.commons.math3.linear.RealVector realVector63 = arrayRealVector54.mapMultiply((double) '#');
        double double64 = arrayRealVector54.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector46.append((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector54.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector54.mapMultiply(4.654551027821466d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector54);
        try {
            double double71 = linearObjectiveFunction11.getValue((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double double26 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray30 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1L));
        double[] doubleArray33 = pointValuePair32.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector27.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction38 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector27, 32.0d);
        double[] doubleArray39 = arrayRealVector27.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        try {
            double[] doubleArray41 = array2DRowRealMatrix0.preMultiply(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 210.78424988599124d + "'", double26 == 210.78424988599124d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        float float2 = org.apache.commons.math3.util.FastMath.min(32.000004f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector8.copy();
        java.lang.String str17 = arrayRealVector8.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector8);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        try {
            arrayRealVector18.setSubVector((int) (byte) 10, doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        java.lang.Double double11 = pointValuePair10.getValue();
        double[] doubleArray12 = pointValuePair10.getKey();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6045724816965523d + "'", double11.equals(0.6045724816965523d));
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 2, (float) 1L, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("=", 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = blockRealMatrix4.walkInOptimizedOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction15 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray12, 0.5210953054937474d);
        org.apache.commons.math3.linear.RealVector realVector16 = linearObjectiveFunction15.getCoefficients();
        double[] doubleArray21 = new double[] { 1023L, 0.0f, (-57.29577951308232d), 0.6610060414837631d };
        try {
            double double22 = linearObjectiveFunction15.getValue(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix6.transpose();
        boolean boolean9 = blockRealMatrix8.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.copy();
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship4 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) relationship4);
        try {
            array2DRowRealMatrix0.setRowMatrix((int) (short) 100, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship4 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship4.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        double double3 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.optimization.linear.Relationship relationship20 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = relationship20.oppositeRelationship();
        double[] doubleArray27 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint30 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray17, (double) 1L, relationship20, doubleArray27, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, (double) 0L, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        try {
            org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix8.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + relationship20 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship20.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix18.getRowVector(52);
        double double21 = blockRealMatrix18.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix15, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        java.io.ObjectInputStream objectInputStream22 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray20, "{}", objectInputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 6, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("", "Array2DRowRealMatrix{}", "=", numberFormat7);
        java.text.ParsePosition parsePosition11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = realVectorFormat9.parse("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", parsePosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        matrixDimensionMismatchException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector7.append(arrayRealVector8);
        double double19 = arrayRealVector18.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.0d + "'", double19 == 32.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray39 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray39, (double) (-1L));
        double[] doubleArray42 = pointValuePair41.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, (org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray51 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair53 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray51, (double) (-1L));
        double[] doubleArray54 = pointValuePair53.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector48.mapMultiply((double) '#');
        double double58 = arrayRealVector48.getLInfNorm();
        boolean boolean60 = arrayRealVector48.equals((java.lang.Object) 1.0f);
        boolean boolean61 = arrayRealVector48.isInfinite();
        int int62 = arrayRealVector48.getDimension();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector33.combineToSelf((double) '#', 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector9, 3.970291913552122d);
        org.apache.commons.math3.linear.RealVector realVector12 = linearObjectiveFunction11.getCoefficients();
        double[] doubleArray19 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray26 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray27 = new double[][] { doubleArray19, doubleArray26 };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray27);
        boolean boolean30 = linearObjectiveFunction11.equals((java.lang.Object) realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4, (int) (short) 0, 1072693248, (int) (short) 1, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("Array2DRowRealMatrix{{0.0},{32.0}}", "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector0.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector12.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector12.mapAddToSelf((-0.7339880056937724d));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair21 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 2.154434690031884d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, true);
        double double25 = arrayRealVector23.getEntry(0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, arrayRealVector19);
        boolean boolean21 = arrayRealVector8.isInfinite();
        try {
            arrayRealVector8.setEntry(52, (-0.32660790974246073d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector0.mapToSelf(univariateFunction13);
        double double15 = arrayRealVector14.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math3.util.FastMath.acos((-2.5663706143591725d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        int[] intArray12 = new int[] { 1072693248, (short) 1, 1079574528, (short) 100, (-127), 2 };
        int[] intArray15 = new int[] { (-127), 1079574528 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix5, intArray12, intArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair8 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray5, (java.lang.Double) 0.8813735870195429d);
        java.lang.Double double9 = doubleArrayPair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8813735870195429d + "'", double9.equals(0.8813735870195429d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector7.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 32.0d);
        double[] doubleArray19 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        try {
            blockRealMatrix2.setColumnVector(1, realVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 0, (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7937005259840998d + "'", double1 == 0.7937005259840998d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector22.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            double double36 = arrayRealVector22.getEntry((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 0L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.transpose();
        try {
            blockRealMatrix6.setRowMatrix((-1023), blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) doubleArray9);
        try {
            double[][] doubleArray11 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray11);
        int int14 = multiDimensionMismatchException12.getWrongDimension(1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector7.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 32.0d);
        double[] doubleArray19 = arrayRealVector7.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction22 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray19, 0.5210953054937474d);
        try {
            double[] doubleArray23 = blockRealMatrix2.operate(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = realVectorFormat0.format(realVector2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, (int) (short) -1, (int) (short) 0, 36);
        try {
            int int6 = matrixDimensionMismatchException4.getExpectedDimension(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double31 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor26, (int) '4', (int) (byte) 10, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.9155040003582885E22d, (java.lang.Number) 32L, false);
        boolean boolean12 = pointValuePair4.equals((java.lang.Object) numberIsTooLargeException11);
        boolean boolean13 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooLargeException11.getMax();
        boolean boolean15 = numberIsTooLargeException11.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 32L + "'", number14.equals(32L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (short) 0, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        int[] intArray24 = new int[] { 36, (short) 1, (short) -1 };
        int[] intArray25 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix19.getSubMatrix(intArray24, intArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarAdd((-0.32660790974246073d));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = blockRealMatrix6.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) -1, (int) '#', (int) (byte) 1, (int) (byte) 0);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        double[] doubleArray6 = null;
        try {
            double[] doubleArray7 = blockRealMatrix2.preMultiply(doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double3 = org.apache.commons.math3.util.Precision.round(100.0d, 2, 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector11.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) ' ', 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector10.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction21 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector10, 32.0d);
        double double22 = arrayRealVector10.getL1Norm();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector7.combine(5.298292365610485d, (-0.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor5, 32, 10, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 32 after final row 10");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, (double) 5, relationship19, doubleArray25, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector7.mapSubtractToSelf((double) 5);
        boolean boolean33 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray45 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair47 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) (-1L));
        double[] doubleArray48 = pointValuePair47.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector42.mapMultiply((double) '#');
        double double52 = arrayRealVector42.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector34.append((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector42.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector42.mapMultiply(4.654551027821466d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(realVector57);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("; ", "{0; 1}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(36, 100);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray14, (int) ' ', 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 52L, 11013.232920103323d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.0d + "'", double3 == 53.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix18.transpose();
        double double20 = array2DRowRealMatrix18.getFrobeniusNorm();
        try {
            double double23 = array2DRowRealMatrix18.getEntry(5, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 210.78424988599124d + "'", double20 == 210.78424988599124d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.multiply(blockRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long1 = org.apache.commons.math3.util.FastMath.round(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11013L + "'", long1 == 11013L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[][] doubleArray2 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (byte) -1, doubleArray2, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector18.mapMultiplyToSelf((double) (short) -1);
        try {
            blockRealMatrix2.setColumnVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix6.getColumnVector((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) -1, 1072693248);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(10, 36);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction31 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector29, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray35 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray35, (double) (-1L));
        double[] doubleArray38 = pointValuePair37.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, arrayRealVector40);
        try {
            array2DRowRealMatrix18.setColumnVector(2, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 2x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.getColumnMatrix(6);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix2.subtract(blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        try {
            double[] doubleArray4 = blockRealMatrix2.getColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (-1.5707963267948966d), false);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.transpose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector0.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector12.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector12);
        double[] doubleArray20 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray20);
        org.apache.commons.math3.optimization.linear.Relationship relationship24 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray30 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray30);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint34 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray20, (double) 5, relationship24, doubleArray30, 1.7453292519943295d);
        double[] doubleArray40 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray40);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, 0.6045724816965523d, false);
        double[] doubleArray46 = pointValuePair45.getPoint();
        double[] doubleArray47 = pointValuePair45.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, doubleArray47);
        double double49 = arrayRealVector48.getLInfNorm();
        try {
            double double50 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + relationship24 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship24.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.0d + "'", double49 == 10.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapDivideToSelf((double) Float.NaN);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
        java.io.ObjectOutputStream objectOutputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8, objectOutputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math3.util.FastMath.rint(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134E13d + "'", double1 == 3.948148009134E13d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 36, (-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix4.walkInRowOrder(realMatrixPreservingVisitor7, (int) (short) 1, (-1023), (-127), (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double19 = array2DRowRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarAdd((-0.32660790974246073d));
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = blockRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor9, (-127), 6, 52, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, false);
        double double12 = arrayRealVector7.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.6610060414837631d, 5.298292365610485d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6610060414837631d + "'", double3 == 0.6610060414837631d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = null;
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (byte) 10, realMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray3 = array2DRowRealMatrix2.getData();
        double double4 = array2DRowRealMatrix2.getNorm();
        double[][] doubleArray5 = array2DRowRealMatrix2.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix((int) '#', (int) 'a', doubleArray5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor5, (int) (byte) 0, 1, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        boolean boolean20 = array2DRowRealMatrix18.isSquare();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double22 = array2DRowRealMatrix21.getFrobeniusNorm();
        java.lang.String str23 = array2DRowRealMatrix21.toString();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = array2DRowRealMatrix18.add(array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Array2DRowRealMatrix{}" + "'", str23.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double6 = array2DRowRealMatrix5.getFrobeniusNorm();
        double double7 = array2DRowRealMatrix5.getFrobeniusNorm();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        try {
            blockRealMatrix2.setColumnMatrix((int) (short) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray11);
        java.lang.Integer[] intArray13 = multiDimensionMismatchException12.getExpectedDimensions();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(2.154434690031884d, (double) (-35.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.154434690031884d) + "'", double2 == (-2.154434690031884d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double double26 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector27 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, realVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 210.78424988599124d + "'", double26 == 210.78424988599124d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        boolean boolean13 = arrayRealVector0.isInfinite();
        int int14 = arrayRealVector0.getDimension();
        int int15 = arrayRealVector0.getDimension();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray16);
        java.lang.Throwable[] throwableArray19 = nullArgumentException18.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.scalarAdd(2.718281828459045d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector25 = blockRealMatrix23.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix23.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = blockRealMatrix23.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix19.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix18.transpose();
        double double20 = array2DRowRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.getRowMatrix((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 210.78424988599124d + "'", double20 == 210.78424988599124d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, (double) 5, relationship19, doubleArray25, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector7.mapSubtractToSelf((double) 5);
        boolean boolean33 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray45 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair47 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) (-1L));
        double[] doubleArray48 = pointValuePair47.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector42.mapMultiply((double) '#');
        double double52 = arrayRealVector42.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector34.append((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector42.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector42.mapMultiply(4.654551027821466d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector42);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector42.mapAdd(6.283185307179586d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector60);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        double[] doubleArray9 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1L));
        double[] doubleArray12 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.optimization.linear.Relationship relationship15 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship16 = relationship15.oppositeRelationship();
        double[] doubleArray22 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint25 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray12, (double) 1L, relationship15, doubleArray22, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        try {
            blockRealMatrix2.setRowVector(5, realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x2 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + relationship15 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship15.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship16 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship16.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 2, (-147.04220486917677d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) 'a', (int) (byte) 10);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector0.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector12.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 1);
        try {
            double double17 = arrayRealVector12.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.transpose();
        try {
            blockRealMatrix2.setColumnMatrix((int) (short) 100, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        try {
            blockRealMatrix2.setEntry(0, 1079574528, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.217652850343311d + "'", double1 == 1.217652850343311d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector20);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        java.io.ObjectOutputStream objectOutputStream20 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix18, objectOutputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        boolean boolean20 = arrayRealVector0.isNaN();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector10.mapMultiply((double) '#');
        double double20 = arrayRealVector10.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector2.append((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        try {
            org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix0.operateTranspose(realVector21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.transpose();
        double[] doubleArray13 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, 0.6045724816965523d, false);
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean32 = array2DRowRealMatrix29.equals((java.lang.Object) relationship31);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint34 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector21, relationship31, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship35 = relationship31.oppositeRelationship();
        double[] doubleArray38 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, (double) (-1L));
        double[] doubleArray41 = pointValuePair40.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.optimization.linear.Relationship relationship44 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship45 = relationship44.oppositeRelationship();
        double[] doubleArray51 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector52 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray51);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint54 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray41, (double) 1L, relationship44, doubleArray51, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint56 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray19, 180.0d, relationship31, doubleArray51, 2.718281828459045d);
        try {
            blockRealMatrix2.setRow(52, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + relationship35 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship35.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + relationship44 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship44.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship45 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship45.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = relationship8.oppositeRelationship();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(5.0d, (double) 32.000004f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1549967237414013d + "'", double2 == 0.1549967237414013d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.getSubMatrix(1072693248, (int) (short) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.scalarAdd((double) 6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor21 = null;
        try {
            double double22 = array2DRowRealMatrix18.walkInColumnOrder(realMatrixPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix18.getSubMatrix((int) '4', (-127), 2, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) ' ');
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 10, (-127), 36, 0);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-127) + "'", int5 == (-127));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-127) + "'", int6 == (-127));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-127) + "'", int7 == (-127));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        try {
            double[] doubleArray7 = blockRealMatrix2.getColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-127), (int) (byte) -1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(11013.232874703393d, (double) (byte) 100, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray21 = array2DRowRealMatrix20.getData();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (-1L), (java.lang.Object[]) doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray18);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair22 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray18, (java.lang.Double) 0.6610060414837631d);
        try {
            blockRealMatrix8.setRow((int) '#', doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(0.7615941559557649d, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math3.util.FastMath.sin((-35.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.428182669496151d + "'", double1 == 0.428182669496151d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        java.lang.Double double8 = pointValuePair4.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray12 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1L));
        double[] doubleArray15 = pointValuePair14.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector9.mapMultiply((double) '#');
        double double19 = arrayRealVector9.getLInfNorm();
        boolean boolean21 = arrayRealVector9.equals((java.lang.Object) 1.0f);
        boolean boolean22 = arrayRealVector9.isInfinite();
        boolean boolean23 = pointValuePair4.equals((java.lang.Object) boolean22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.scalarAdd((double) 6);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction15 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray12, 0.5210953054937474d);
        org.apache.commons.math3.linear.RealVector realVector16 = linearObjectiveFunction15.getCoefficients();
        org.apache.commons.math3.linear.RealVector realVector17 = linearObjectiveFunction15.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Number) 127.0f, false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = mathArithmeticException18.getContext();
        zeroException17.addSuppressed((java.lang.Throwable) mathArithmeticException18);
        java.lang.String str21 = mathArithmeticException18.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception" + "'", str21.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray12 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1L));
        double[] doubleArray15 = pointValuePair14.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector9.copy();
        java.lang.String str18 = arrayRealVector9.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8, arrayRealVector9);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{}" + "'", str18.equals("{}"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix18.transpose();
        double double20 = array2DRowRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor21 = null;
        try {
            double double26 = array2DRowRealMatrix18.walkInColumnOrder(realMatrixPreservingVisitor21, (int) (short) 1, (int) (short) 10, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 210.78424988599124d + "'", double20 == 210.78424988599124d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = array2DRowRealMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix14.getSubMatrix(36, (int) (short) -1, 35, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray21 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray22 = new double[][] { doubleArray14, doubleArray21 };
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray22);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        try {
            blockRealMatrix4.setSubMatrix(doubleArray22, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.math3.util.FastMath.min(100, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, false);
        arrayRealVector11.set(10.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, (double) 5, relationship19, doubleArray25, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector7.mapSubtractToSelf((double) 5);
        boolean boolean33 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray45 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair47 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) (-1L));
        double[] doubleArray48 = pointValuePair47.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, doubleArray48);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector42.mapMultiply((double) '#');
        double double52 = arrayRealVector42.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector34.append((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector42.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector42.mapMultiply(4.654551027821466d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray63 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair65 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray63, (double) (-1L));
        double[] doubleArray66 = pointValuePair65.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector60, doubleArray66);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double69 = array2DRowRealMatrix68.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship70 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean71 = array2DRowRealMatrix68.equals((java.lang.Object) relationship70);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint73 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector60, relationship70, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector60.append((double) 100L);
        double double76 = arrayRealVector60.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector60.mapDivide((double) 35.999996f);
        double[] doubleArray79 = arrayRealVector60.getDataRef();
        try {
            arrayRealVector7.setSubVector((int) (short) -1, doubleArray79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship70 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship70.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = blockRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor8, 35, 1077937089, 32, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,077,937,089)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
        try {
            double double10 = blockRealMatrix8.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double[] doubleArray20 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray20);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, 0.6045724816965523d, false);
        double[] doubleArray26 = pointValuePair25.getPoint();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray26);
        double[] doubleArray33 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray33);
        org.apache.commons.math3.optimization.linear.Relationship relationship37 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray43 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector44 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray43);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray43);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint47 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray33, (double) 5, relationship37, doubleArray43, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, doubleArray43);
        try {
            double[] doubleArray49 = blockRealMatrix14.preMultiply(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + relationship37 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship37.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 1023L, 4.654551027821466d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.566246454938293d + "'", double2 == 1.566246454938293d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) doubleArray9);
        double[] doubleArray11 = pointValuePair4.getPoint();
        double[] doubleArray12 = pointValuePair4.getPoint();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{", "{", "Array2DRowRealMatrix{{0.0},{32.0}}");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray27 = array2DRowRealMatrix26.getData();
        double double28 = array2DRowRealMatrix26.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) (-1));
        try {
            org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector2.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector8.mapMultiplyToSelf((double) 0L);
        double double22 = arrayRealVector8.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(3.58351893845611d, (double) 0.0f, 0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0471975511965979d + "'", double1 == 1.0471975511965979d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        boolean boolean13 = arrayRealVector0.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat4);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat4);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.6483608274590866d, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6483608274590866d + "'", double2 == 0.6483608274590866d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarAdd((-0.32660790974246073d));
        double[] doubleArray14 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair17 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray14, (java.lang.Double) 0.8813735870195429d);
        try {
            double[] doubleArray18 = blockRealMatrix6.preMultiply(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.optimization.linear.Relationship relationship16 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = relationship16.oppositeRelationship();
        double[] doubleArray23 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector24 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray23);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint26 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray13, (double) 1L, relationship16, doubleArray23, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) 0L, false);
        double[] doubleArray31 = pointValuePair30.getKey();
        try {
            double[] doubleArray32 = blockRealMatrix2.operate(doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + relationship16 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship16.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 2.3124383412727525d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.ZeroException zeroException18 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = mathArithmeticException21.getContext();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapDivideToSelf((-1.0d));
        double double11 = realVector10.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.0d) + "'", double11 == (-0.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction13 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray11, 1.5707963267948966d);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double21 = array2DRowRealMatrix20.getNorm();
        boolean boolean22 = linearConstraint19.equals((java.lang.Object) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray24 = array2DRowRealMatrix23.getData();
        int int25 = array2DRowRealMatrix23.getColumnDimension();
        java.lang.String str26 = array2DRowRealMatrix23.toString();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix20.multiply(array2DRowRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{}" + "'", str26.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        java.lang.String str25 = array2DRowRealMatrix24.toString();
        boolean boolean26 = array2DRowRealMatrix24.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Array2DRowRealMatrix{{0.0},{32.0}}" + "'", str25.equals("Array2DRowRealMatrix{{0.0},{32.0}}"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector0.getSubVector(36, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray19 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair21 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray19, (double) (-1L));
        double[] doubleArray22 = pointValuePair21.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector16.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector16);
        try {
            blockRealMatrix2.setRowVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.566246454938293d, 0.6483608274590866d, 0.6483608274590866d, 11013.232920103323d, 1.9155040003582885E22d, 0.0d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor7, (-127), (-127), (-1023), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{}", "Array2DRowRealMatrix{}", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math3.util.FastMath.max(4.9E-324d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(127.0f, 10, 1077937089);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 1,077,937,089, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(5, (int) '#');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-0.7339880056937724d), (double) 5.0000005f, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math3.util.FastMath.tan(6.305116760146989E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.305116760146989E-16d + "'", double1 == 6.305116760146989E-16d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.428182669496151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100.0f, (java.lang.Number) 11013.232920103323d, (java.lang.Number) (-127));
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 11013.232920103323d + "'", number4.equals(11013.232920103323d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.7937005259840998d, 0.7937005259840998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("Array2DRowRealMatrix{{0.0},{32.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray17);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray17, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 52 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math3.util.FastMath.asin(53.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 1077937089, 3.948148009134E13d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07793728E9f + "'", float2 == 1.07793728E9f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) (byte) 1, (double) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, 1072693248, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,072,693,250 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 100, (double) 0, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.7763568394002505E-15d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((-1), (-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix6.getSubMatrix((int) (byte) 1, 2, (int) '4', 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(4.654551027821466d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 104.0620394755764d + "'", double1 == 104.0620394755764d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException5 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray4);
        java.lang.Integer[] intArray6 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException7 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray6);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray6);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray39 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray39, (double) (-1L));
        double[] doubleArray42 = pointValuePair41.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, (org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        int int46 = arrayRealVector44.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int1 = org.apache.commons.math3.util.FastMath.abs(36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(4.654551027821466d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.654551027821467d + "'", double2 == 4.654551027821467d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray10 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        try {
            blockRealMatrix2.setRow((int) '4', doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector19.map(univariateFunction20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3, 1072693248, (int) (byte) 1, (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        double double6 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor7, (int) (byte) 0, (int) 'a', (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable8, intArray15, intArray19);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray19);
        try {
            int int23 = multiDimensionMismatchException21.getWrongDimension((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math3.util.FastMath.floor((-35.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.0d) + "'", double1 == (-35.0d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        arrayRealVector0.set(52.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 1, 0.0f, (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, (-1023), (int) (byte) 0, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector9, 3.970291913552122d);
        org.apache.commons.math3.linear.RealVector realVector12 = linearObjectiveFunction11.getCoefficients();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double14 = array2DRowRealMatrix13.getNorm();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        boolean boolean16 = linearObjectiveFunction11.equals((java.lang.Object) doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(6.283185307179586d, (-57.0d), (-1.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double4 = blockRealMatrix3.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.getColumnMatrix(6);
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        java.lang.Double double14 = pointValuePair13.getValue();
        boolean boolean16 = pointValuePair13.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray18 = array2DRowRealMatrix17.getData();
        boolean boolean19 = pointValuePair13.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) blockRealMatrix5, localizable8, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        java.lang.Double double6 = pointValuePair4.getValue();
        boolean boolean8 = pointValuePair4.equals((java.lang.Object) "=");
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(52);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector12.add(realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix2.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        double double6 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix2.scalarMultiply(0.0d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 4.654551027821467d, (java.lang.Number) 1.9155040003582885E22d, false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray8 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector9 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair11 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray8, (java.lang.Double) 0.8813735870195429d);
        try {
            double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 0L, (double) 127.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 35.999996f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.999999682108553d + "'", double1 == 5.999999682108553d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeDivide(realVector20);
        java.lang.Class<?> wildcardClass22 = realVector20.getClass();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double31 = realVector20.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.1102230246251565E-16d);
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray17 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix21.transpose();
        double[] doubleArray28 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray28);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair33 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, 0.6045724816965523d, false);
        double[] doubleArray34 = pointValuePair33.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray39 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray39, (double) (-1L));
        double[] doubleArray42 = pointValuePair41.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double45 = array2DRowRealMatrix44.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship46 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean47 = array2DRowRealMatrix44.equals((java.lang.Object) relationship46);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint49 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector36, relationship46, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship50 = relationship46.oppositeRelationship();
        double[] doubleArray53 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair55 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) (-1L));
        double[] doubleArray56 = pointValuePair55.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56);
        org.apache.commons.math3.optimization.linear.Relationship relationship59 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship60 = relationship59.oppositeRelationship();
        double[] doubleArray66 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector67 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray66);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint69 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray56, (double) 1L, relationship59, doubleArray66, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint71 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray34, 180.0d, relationship46, doubleArray66, 2.718281828459045d);
        org.apache.commons.math3.optimization.linear.Relationship relationship72 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship73 = relationship72.oppositeRelationship();
        java.lang.Object[] objArray74 = new java.lang.Object[] { array2DRowRealMatrix21, 180.0d, relationship72 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException75 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, objArray74);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship46 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship46.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + relationship50 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship50.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + relationship59 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship59.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship60 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship60.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertTrue("'" + relationship72 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship72.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship73 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship73.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, (double) 5, relationship19, doubleArray25, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector7.mapSubtractToSelf((double) 5);
        java.lang.String str33 = arrayRealVector7.toString();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{-5; 27}" + "'", str33.equals("{-5; 27}"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) 10L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat4);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray18 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray18, (double) (-1L));
        double[] doubleArray21 = pointValuePair20.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector15.mapMultiply((double) '#');
        double double25 = arrayRealVector15.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector7.append((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        java.lang.String str27 = realVectorFormat6.format((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        java.text.NumberFormat numberFormat28 = realVectorFormat6.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{}" + "'", str27.equals("{}"));
        org.junit.Assert.assertNotNull(numberFormat28);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(1.7434383785452805E91d, 1077937089);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (double) 1.4E-45f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = linearConstraint18.getRelationship();
        org.apache.commons.math3.linear.RealVector realVector20 = linearConstraint18.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double10 = arrayRealVector9.getNorm();
        arrayRealVector9.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        java.lang.String str14 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.String str15 = realVectorFormat0.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = realVectorFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 1}" + "'", str14.equals("{0; 1}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "; " + "'", str15.equals("; "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 1077937089);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double3 = array2DRowRealMatrix2.getNorm();
        int int4 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2);
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship15 = relationship14.oppositeRelationship();
        double[] doubleArray21 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint24 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray11, (double) 1L, relationship14, doubleArray21, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) 0L, false);
        double[] doubleArray29 = pointValuePair28.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship15 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship15.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("Array2DRowRealMatrix{{0.0},{32.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{0.0},{32.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(180.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("", "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", "", numberFormat3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(3.141592653589793d, (-1.1071486939522315d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1071486939522313d) + "'", double2 == (-1.1071486939522313d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(104.0620394755764d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        double[] doubleArray15 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1L));
        double[] doubleArray18 = pointValuePair17.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double21 = arrayRealVector20.getNorm();
        arrayRealVector20.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray30 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1L));
        double[] doubleArray33 = pointValuePair32.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double36 = array2DRowRealMatrix35.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship37 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean38 = array2DRowRealMatrix35.equals((java.lang.Object) relationship37);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint40 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector27, relationship37, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship41 = relationship37.oppositeRelationship();
        double[] doubleArray44 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray44, (double) (-1L));
        double[] doubleArray47 = pointValuePair46.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint51 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, (double) (-35.0f), relationship37, (org.apache.commons.math3.linear.RealVector) arrayRealVector48, (double) 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship37 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship37.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + relationship41 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship41.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, arrayRealVector19);
        int int21 = arrayRealVector20.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException6 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray5);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) intArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(5, (int) (byte) 1, (int) (short) -1, 36);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray17 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = array2DRowRealMatrix0.add(array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double3 = array2DRowRealMatrix2.getNorm();
        int int4 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray21 = new double[][] { doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray25 = array2DRowRealMatrix24.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double31 = blockRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix30.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix30.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix30, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix36);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix0.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (-35.0f), 0.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (short) -1, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(104.0620394755764d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 109.79029128213669d + "'", double2 == 109.79029128213669d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math3.util.FastMath.log10((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        boolean boolean13 = arrayRealVector0.isInfinite();
        int int14 = arrayRealVector0.getDimension();
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray22 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray29 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) int14, localizable15, (java.lang.Object[]) doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix0.getSubMatrix((-127), (-1023), (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        java.lang.Double double13 = pointValuePair12.getValue();
        boolean boolean15 = pointValuePair12.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        boolean boolean18 = pointValuePair12.equals((java.lang.Object) doubleArray17);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) blockRealMatrix4, localizable7, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray23 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1L));
        double[] doubleArray26 = pointValuePair25.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, doubleArray26);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector20.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction31 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector20, 32.0d);
        double[] doubleArray32 = arrayRealVector20.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double36 = array2DRowRealMatrix35.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship37 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean38 = array2DRowRealMatrix35.equals((java.lang.Object) relationship37);
        java.lang.String str39 = relationship37.toString();
        double[] doubleArray42 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair44 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, (double) (-1L));
        double[] doubleArray45 = pointValuePair44.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        org.apache.commons.math3.optimization.linear.Relationship relationship48 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship49 = relationship48.oppositeRelationship();
        double[] doubleArray55 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint58 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray45, (double) 1L, relationship48, doubleArray55, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint60 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray32, 3.141592653589793d, relationship37, doubleArray55, 0.0d);
        try {
            double[] doubleArray61 = blockRealMatrix4.preMultiply(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship37 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship37.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "=" + "'", str39.equals("="));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + relationship48 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship48.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship49 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship49.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        java.lang.Double double11 = pointValuePair10.getValue();
        boolean boolean13 = pointValuePair10.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        boolean boolean16 = pointValuePair10.equals((java.lang.Object) doubleArray15);
        double[] doubleArray17 = pointValuePair10.getPoint();
        try {
            blockRealMatrix2.setRow((int) (short) -1, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction13 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray11, 1.5707963267948966d);
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.optimization.linear.Relationship relationship22 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = relationship22.oppositeRelationship();
        double[] doubleArray29 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint32 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray19, (double) 1L, relationship22, doubleArray29, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray19, 2.154434690031884d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, true);
        try {
            double double38 = linearObjectiveFunction13.getValue(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + relationship22 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship22.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.1549967237414013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.988012036558065d + "'", double1 == 0.988012036558065d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        double double6 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, 1079574528, 100, (int) (short) 1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, (double) 5, relationship19, doubleArray25, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector7.mapSubtractToSelf((double) 5);
        try {
            org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector7.getSubVector(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (31)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4, (int) '#', (int) (short) 1, 32, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray23 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1L));
        double[] doubleArray26 = pointValuePair25.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, doubleArray26);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector20.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction31 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector20, 32.0d);
        double[] doubleArray32 = arrayRealVector20.getDataRef();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 100.0d, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector0.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector12.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector12);
        boolean boolean15 = arrayRealVector14.isNaN();
        double double16 = arrayRealVector14.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        float float2 = org.apache.commons.math3.util.FastMath.min(32.000004f, (float) 1072693248);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.000004f + "'", float2 == 32.000004f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix8.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double17 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix16.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix8.add(blockRealMatrix16);
        double double21 = blockRealMatrix8.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix2.add(blockRealMatrix8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray27 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1L));
        double[] doubleArray30 = pointValuePair29.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray30);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double33 = array2DRowRealMatrix32.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship34 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) relationship34);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint37 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector24, relationship34, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector24.append((double) 100L);
        double double40 = arrayRealVector24.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector24.mapDivide((double) 35.999996f);
        double[] doubleArray43 = arrayRealVector24.getDataRef();
        try {
            blockRealMatrix2.setRow((-1023), doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship34 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship34.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double25 = blockRealMatrix24.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = blockRealMatrix24.scalarMultiply((-1.5707963267948966d));
        boolean boolean28 = array2DRowRealMatrix19.equals((java.lang.Object) (-1.5707963267948966d));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) (-57.0d), (java.lang.Number) 100.0f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        double[] doubleArray9 = blockRealMatrix2.getRow(52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        float float2 = org.apache.commons.math3.util.FastMath.min((-0.99999994f), (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        boolean boolean13 = arrayRealVector0.isInfinite();
        int int14 = arrayRealVector0.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray19 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair21 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray19, (double) (-1L));
        double[] doubleArray22 = pointValuePair21.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray27 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1L));
        double[] doubleArray30 = pointValuePair29.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector24.copy();
        java.lang.String str33 = arrayRealVector24.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        try {
            arrayRealVector0.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{}" + "'", str33.equals("{}"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException6 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int7 = matrixDimensionMismatchException6.getExpectedColumnDimension();
        int int8 = matrixDimensionMismatchException6.getExpectedColumnDimension();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double11 = array2DRowRealMatrix10.getFrobeniusNorm();
        double double12 = array2DRowRealMatrix10.getFrobeniusNorm();
        double[][] doubleArray13 = array2DRowRealMatrix10.getData();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) matrixDimensionMismatchException6, localizable9, (java.lang.Object[]) doubleArray13);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) (short) -1, doubleArray13, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        double double16 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray21 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) (-1L));
        double[] doubleArray24 = pointValuePair23.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray24);
        try {
            blockRealMatrix14.setRow((int) (short) 100, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.RealVector.unmodifiableRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector14 = null;
        try {
            double double15 = arrayRealVector0.getL1Distance(realVector14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean5 = array2DRowRealMatrix0.isSquare();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        double[] doubleArray15 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1L));
        double[] doubleArray18 = pointValuePair17.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double21 = arrayRealVector20.getNorm();
        arrayRealVector20.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat21 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat22 = realVectorFormat21.getFormat();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double31 = arrayRealVector30.getNorm();
        arrayRealVector30.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, false);
        java.lang.String str35 = realVectorFormat21.format((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector18.combineToSelf(2.0d, (double) 2, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray40 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair42 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, (double) (-1L));
        double[] doubleArray43 = pointValuePair42.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector37.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction48 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector46, 3.970291913552122d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, realVector46);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector11.append((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(numberFormat22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 32.0d + "'", double31 == 32.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{0; 1}" + "'", str35.equals("{0; 1}"));
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector1.mapMultiply((double) '#');
        double double11 = arrayRealVector1.getLInfNorm();
        boolean boolean13 = arrayRealVector1.equals((java.lang.Object) 1.0f);
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        double double22 = arrayRealVector21.getNorm();
        arrayRealVector21.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector25.mapSubtractToSelf((double) (byte) 10);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 32.0d + "'", double22 == 32.0d);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 127.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 127.0d + "'", double1 == 127.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        double[] doubleArray9 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1L));
        double[] doubleArray12 = pointValuePair11.getPoint();
        try {
            blockRealMatrix2.setColumn((int) '#', doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = blockRealMatrix8.walkInOptimizedOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector21.mapMultiply((double) '#');
        double double31 = arrayRealVector21.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction32 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector21.mapToSelf(univariateFunction32);
        try {
            array2DRowRealMatrix19.setRowVector((int) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector33);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) '4', 100, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector0.mapMultiply((double) 10L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.getSubMatrix(32, (int) ' ', 1072693248, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double21 = array2DRowRealMatrix20.getNorm();
        boolean boolean22 = linearConstraint19.equals((java.lang.Object) array2DRowRealMatrix20);
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship32 = relationship31.oppositeRelationship();
        double[] doubleArray38 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint41 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray28, (double) 1L, relationship31, doubleArray38, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction43 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray28, 1.5707963267948966d);
        int int44 = org.apache.commons.math3.util.MathUtils.hash(doubleArray28);
        boolean boolean45 = linearConstraint19.equals((java.lang.Object) doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship32 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship32.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1077937089 + "'", int44 == 1077937089);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getWrongDimension(0);
        int int8 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 1.07957453E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1104156224 + "'", int1 == 1104156224);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.getColumnMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 6, (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 0.7615941559557649d, 0.6045724816965523d, (-57.0d), (-0.0d) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, (int) (byte) -1, 1104156224);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,104,156,223 is larger than the maximum (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6716024091342656d) + "'", double1 == (-1.6716024091342656d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeDivide(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray33 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray33, (double) (-1L));
        double[] doubleArray36 = pointValuePair35.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.copy();
        java.lang.String str39 = arrayRealVector30.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray46 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, (double) (-1L));
        double[] doubleArray49 = pointValuePair48.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray54 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair56 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray54, (double) (-1L));
        double[] doubleArray57 = pointValuePair56.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray57);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector51.mapMultiply((double) '#');
        double double61 = arrayRealVector51.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector43.append((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray68 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair70 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray68, (double) (-1L));
        double[] doubleArray71 = pointValuePair70.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, doubleArray71);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector65.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector65.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector43.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector30.combineToSelf(1.0d, (double) (-1023), (org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector43.mapAdd(1.7434383785452805E91d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{}" + "'", str39.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertNotNull(realVector81);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector8.copy();
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        java.lang.Double double31 = pointValuePair30.getValue();
        double[] doubleArray37 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray37);
        org.apache.commons.math3.optimization.linear.Relationship relationship41 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray47 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray47);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint51 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray37, (double) 5, relationship41, doubleArray47, 1.7453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector52 = linearConstraint51.getCoefficients();
        boolean boolean53 = pointValuePair30.equals((java.lang.Object) realVector52);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector19.ebeDivide(realVector52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.6045724816965523d + "'", double31.equals(0.6045724816965523d));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertTrue("'" + relationship41 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship41.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeDivide(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray33 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray33, (double) (-1L));
        double[] doubleArray36 = pointValuePair35.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.copy();
        java.lang.String str39 = arrayRealVector30.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray46 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, (double) (-1L));
        double[] doubleArray49 = pointValuePair48.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray54 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair56 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray54, (double) (-1L));
        double[] doubleArray57 = pointValuePair56.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray57);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector51.mapMultiply((double) '#');
        double double61 = arrayRealVector51.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector43.append((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray68 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair70 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray68, (double) (-1L));
        double[] doubleArray71 = pointValuePair70.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, doubleArray71);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector65.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector65.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector43.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector30.combineToSelf(1.0d, (double) (-1023), (org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double80 = arrayRealVector7.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{}" + "'", str39.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        boolean boolean12 = arrayRealVector0.equals((java.lang.Object) 1.0f);
        double[] doubleArray15 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1L));
        double[] doubleArray18 = pointValuePair17.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double21 = arrayRealVector20.getNorm();
        arrayRealVector20.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector24);
        int int26 = arrayRealVector24.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math3.util.FastMath.acos(5.298292365610485d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 52, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(32.0f, (float) (byte) 0, (float) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        boolean boolean20 = array2DRowRealMatrix18.isSquare();
        int[] intArray21 = new int[] {};
        int[] intArray27 = new int[] { '#', (byte) -1, 1077937089, (short) 1, 1072693248 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, intArray21, intArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected row index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix8.getSubMatrix((int) '#', 0, (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 35 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1072693248, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269325E9f + "'", float2 == 1.07269325E9f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, (-1.0d));
        double double12 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector13.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction24 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector13, 32.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        double double10 = array2DRowRealMatrix8.getFrobeniusNorm();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) matrixDimensionMismatchException4, localizable7, (java.lang.Object[]) doubleArray11);
        int int13 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver0 = new org.apache.commons.math3.optimization.linear.SimplexSolver();
        simplexSolver0.setMaxIterations((-1023));
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship12 = relationship11.oppositeRelationship();
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint21 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray8, (double) 1L, relationship11, doubleArray18, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction23 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray8, 1.5707963267948966d);
        double[] doubleArray29 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray29);
        org.apache.commons.math3.optimization.linear.Relationship relationship33 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray39 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray39);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint43 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray29, (double) 5, relationship33, doubleArray39, 1.7453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector44 = linearConstraint43.getCoefficients();
        org.apache.commons.math3.optimization.linear.LinearConstraint[] linearConstraintArray45 = new org.apache.commons.math3.optimization.linear.LinearConstraint[] { linearConstraint43 };
        java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint> linearConstraintList46 = new java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList46, linearConstraintArray45);
        org.apache.commons.math3.optimization.GoalType goalType48 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair50 = simplexSolver0.optimize(linearObjectiveFunction23, (java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList46, goalType48, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException; message: no feasible solution");
        } catch (org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship12 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship12.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertTrue("'" + relationship33 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship33.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(linearConstraintArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + goalType48 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType48.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        int int5 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector7.append(arrayRealVector8);
        int int19 = arrayRealVector7.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector11.copy();
        java.lang.String str20 = arrayRealVector11.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector11.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction32 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector11, (double) (-1.0f));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray36 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) (-1L));
        double[] doubleArray39 = pointValuePair38.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray44 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray44, (double) (-1L));
        double[] doubleArray47 = pointValuePair46.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, doubleArray47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector41.mapMultiply((double) '#');
        double double51 = arrayRealVector41.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector33.append((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector41.append((double) 6);
        java.lang.Class<?> wildcardClass55 = arrayRealVector41.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector11.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        try {
            org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector0.getSubVector((int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 32L, 35.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray22 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray29 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException32 = new org.apache.commons.math3.exception.NullArgumentException(localizable15, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[][] doubleArray34 = array2DRowRealMatrix33.getData();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 127.0f, (java.lang.Object[]) doubleArray34);
        try {
            blockRealMatrix2.copySubMatrix(intArray12, intArray13, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected row index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.scalarAdd(0.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.scalarMultiply((double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.6045724816965523d, (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (-1));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, 5, 1, 0, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 5 after final row 1");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver0 = new org.apache.commons.math3.optimization.linear.SimplexSolver();
        simplexSolver0.setMaxIterations((-1023));
        int int3 = simplexSolver0.getIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{", "", "Array2DRowRealMatrix{{0.0},{32.0}}");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        double[] doubleArray7 = null;
        try {
            double[] doubleArray8 = blockRealMatrix2.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) (short) 100, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        java.lang.Number number7 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 5.298292365610485d + "'", number7.equals(5.298292365610485d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        int int18 = array2DRowRealMatrix17.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction19 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, 32.0d);
        double[] doubleArray20 = arrayRealVector8.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        try {
            blockRealMatrix2.setColumn(35, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray9 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1L));
        double[] doubleArray12 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray18 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray18, (double) (-1L));
        double[] doubleArray21 = pointValuePair20.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector15.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction26 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector15, 32.0d);
        double[] doubleArray27 = arrayRealVector15.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray27);
        try {
            double[] doubleArray29 = blockRealMatrix5.operate(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(104.0620394755764d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 208.1240789511528d + "'", double2 == 208.1240789511528d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(Float.NaN, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int8 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        double double7 = blockRealMatrix2.getFrobeniusNorm();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        java.lang.Double double11 = pointValuePair10.getValue();
        double[] doubleArray17 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray17);
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray27 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint31 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray17, (double) 5, relationship21, doubleArray27, 1.7453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector32 = linearConstraint31.getCoefficients();
        boolean boolean33 = pointValuePair10.equals((java.lang.Object) realVector32);
        java.lang.Double double34 = pointValuePair10.getValue();
        java.text.NumberFormat numberFormat38 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat39 = new org.apache.commons.math3.linear.RealVectorFormat("}", "{}", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat38);
        boolean boolean40 = pointValuePair10.equals((java.lang.Object) numberFormat38);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6045724816965523d + "'", double11.equals(0.6045724816965523d));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.6045724816965523d + "'", double34.equals(0.6045724816965523d));
        org.junit.Assert.assertNotNull(numberFormat38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        double double16 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix14.getColumnMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 10, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.023993865417028d + "'", double2 == 10.023993865417028d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) 32, 2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        boolean boolean7 = blockRealMatrix2.equals((java.lang.Object) false);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = blockRealMatrix2.getColumnVector((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((-127));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(6.283185307179586d, 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException(">=", (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(1);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.copy();
        java.lang.String str30 = arrayRealVector21.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector21);
        double double32 = arrayRealVector21.getLInfNorm();
        boolean boolean33 = arrayRealVector0.equals((java.lang.Object) arrayRealVector21);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        double[] doubleArray26 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray33 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray34);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math3.exception.NullArgumentException(localizable19, (java.lang.Object[]) doubleArray34);
        double[][] doubleArray37 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.exception.ZeroException zeroException39 = new org.apache.commons.math3.exception.ZeroException(localizable18, (java.lang.Object[]) doubleArray34);
        try {
            array2DRowRealMatrix17.setSubMatrix(doubleArray34, (int) (short) 100, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("=", (int) '#');
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector8.append((double) 6);
        double double22 = arrayRealVector8.getMaxValue();
        double double23 = arrayRealVector8.getL1Norm();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector8);
        double[] doubleArray27 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1L));
        double[] doubleArray30 = pointValuePair29.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat34 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat35 = realVectorFormat34.getFormat();
        double[] doubleArray38 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, (double) (-1L));
        double[] doubleArray41 = pointValuePair40.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double double44 = arrayRealVector43.getNorm();
        arrayRealVector43.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, false);
        java.lang.String str48 = realVectorFormat34.format((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector31.combineToSelf(2.0d, (double) 2, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray53 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair55 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) (-1L));
        double[] doubleArray56 = pointValuePair55.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, doubleArray56);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector50.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction61 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector59, 3.970291913552122d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, realVector59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector8.ebeMultiply(realVector59);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(numberFormat35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 32.0d + "'", double44 == 32.0d);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{0; 1}" + "'", str48.equals("{0; 1}"));
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector63);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        try {
            openMapRealMatrix2.setEntry((-127), (int) 'a', (-2.154434690031884d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        java.lang.String str7 = blockRealMatrix2.toString();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str7.equals("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapAdd(0.5403023058681398d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        try {
            arrayRealVector0.setEntry((int) ' ', (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) (-127), 35);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        java.lang.String str1 = relationship0.toString();
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "=" + "'", str1.equals("="));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3, 2, (int) 'a', (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 6.283185307179586d, (java.lang.Number) 35, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 35 + "'", number5.equals(35));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix8.getColumnVector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.getColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat0.parse("}", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(6.305116760146989E-16d, 0.6045724816965523d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0429050198337775E-15d + "'", double2 == 1.0429050198337775E-15d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math3.util.FastMath.asin(10.023993865417028d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        java.io.ObjectOutputStream objectOutputStream35 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix34, objectOutputStream35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        try {
            double[] doubleArray5 = array2DRowRealMatrix0.getColumn(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair9 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray5, (java.lang.Double) 0.6610060414837631d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException14 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int15 = matrixDimensionMismatchException14.getExpectedColumnDimension();
        int int16 = matrixDimensionMismatchException14.getExpectedColumnDimension();
        java.lang.Integer[] intArray17 = matrixDimensionMismatchException14.getExpectedDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray29 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException30 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable18, intArray25, intArray29);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException31 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray17, intArray29);
        boolean boolean32 = doubleArrayPair9.equals((java.lang.Object) intArray29);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        boolean boolean12 = blockRealMatrix8.isSquare();
        boolean boolean13 = blockRealMatrix8.isSquare();
        double double14 = blockRealMatrix8.getNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix8.getSubMatrix((int) '#', 6, 6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 35 after final row 6");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector0.append((double) 100L);
        double double16 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, false);
        double[] doubleArray19 = arrayRealVector18.toArray();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair9 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray5, (java.lang.Double) 0.6610060414837631d);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1322834079 + "'", int10 == 1322834079);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double6 = array2DRowRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double8 = array2DRowRealMatrix7.getNorm();
        int int9 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) (short) -1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        java.lang.String str25 = array2DRowRealMatrix24.toString();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix24.power(1077937089);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Array2DRowRealMatrix{{0.0},{32.0}}" + "'", str25.equals("Array2DRowRealMatrix{{0.0},{32.0}}"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray1 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException7 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int8 = matrixDimensionMismatchException7.getExpectedColumnDimension();
        int int9 = matrixDimensionMismatchException7.getExpectedColumnDimension();
        java.lang.Integer[] intArray10 = matrixDimensionMismatchException7.getExpectedDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray18, intArray22);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray10, intArray22);
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException30 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(5, (int) (byte) 1, (int) (short) -1, 36);
        java.lang.Integer[] intArray31 = matrixDimensionMismatchException30.getExpectedDimensions();
        org.apache.commons.math3.exception.ZeroException zeroException32 = new org.apache.commons.math3.exception.ZeroException(localizable25, (java.lang.Object[]) intArray31);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException33 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray22, intArray31);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException34 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray1, intArray31);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.transpose();
        int int7 = blockRealMatrix2.getRowDimension();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double double17 = arrayRealVector16.getNorm();
        arrayRealVector16.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, false);
        try {
            blockRealMatrix2.setColumnVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 32.0d + "'", double17 == 32.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        try {
            openMapRealMatrix2.multiplyEntry((int) (short) 100, 10, 0.6483608274590866d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.scalarAdd((double) 6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix20, (int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 35.999996f, (java.lang.Number) 1.07793728E9f, false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix2.getNorm();
        double double16 = blockRealMatrix2.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.scalarMultiply(0.0d);
        int[] intArray23 = new int[] { 1322834079, 100, 32 };
        int[] intArray28 = new int[] { 3, (-127), (-1), 1322834079 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17, intArray23, intArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,322,834,079)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair20 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray5, (java.lang.Double) 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        java.lang.Double double13 = pointValuePair12.getValue();
        boolean boolean15 = pointValuePair12.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        boolean boolean18 = pointValuePair12.equals((java.lang.Object) doubleArray17);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) blockRealMatrix4, localizable7, (java.lang.Object[]) doubleArray17);
        double[] doubleArray21 = blockRealMatrix4.getColumn((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        boolean boolean7 = blockRealMatrix2.equals((java.lang.Object) false);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.getSubMatrix(1104156224, (int) 'a', 32, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,104,156,224)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double10 = arrayRealVector9.getNorm();
        arrayRealVector9.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        java.lang.String str14 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.String str15 = realVectorFormat0.getSuffix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray19 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair21 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray19, (double) (-1L));
        double[] doubleArray22 = pointValuePair21.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, doubleArray22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray27 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1L));
        double[] doubleArray30 = pointValuePair29.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector24.mapMultiply((double) '#');
        double double34 = arrayRealVector24.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector16.append((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double[] doubleArray40 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair42 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, (double) (-1L));
        double[] doubleArray43 = pointValuePair42.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        org.apache.commons.math3.optimization.linear.Relationship relationship46 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship47 = relationship46.oppositeRelationship();
        double[] doubleArray53 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector54 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray53);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint56 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray43, (double) 1L, relationship46, doubleArray53, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray43);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray43, 2.154434690031884d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector61);
        java.lang.StringBuffer stringBuffer63 = null;
        java.text.FieldPosition fieldPosition64 = null;
        try {
            java.lang.StringBuffer stringBuffer65 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector37, stringBuffer63, fieldPosition64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 1}" + "'", str14.equals("{0; 1}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "}" + "'", str15.equals("}"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + relationship46 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship46.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship47 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship47.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector57);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 6.305116760146989E-16d, (java.lang.Number) 11.03017970588336d, (java.lang.Number) 100.0f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix0.transpose();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat5 = realVectorFormat4.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat5);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat5);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        try {
            java.lang.StringBuffer stringBuffer10 = org.apache.commons.math3.util.CompositeFormat.formatDouble(1.0429050198337775E-15d, numberFormat5, stringBuffer8, fieldPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        java.io.ObjectOutputStream objectOutputStream20 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector19, objectOutputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        int int11 = arrayRealVector0.getMaxIndex();
        boolean boolean12 = arrayRealVector0.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (-57.29577951308232d), true);
        try {
            double[] doubleArray15 = blockRealMatrix5.operate(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector20 = linearConstraint19.getCoefficients();
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = linearConstraint19.getRelationship();
        org.apache.commons.math3.optimization.linear.Relationship relationship22 = relationship21.oppositeRelationship();
        java.lang.String str23 = relationship22.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + relationship22 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship22.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "=" + "'", str23.equals("="));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = blockRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor7, 32, (int) 'a', 1079574528, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double3 = array2DRowRealMatrix2.getNorm();
        int int4 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2);
        try {
            array2DRowRealMatrix0.setEntry(5, 2, (double) 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable8, intArray15, intArray19);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray27 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException28 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray27);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) intArray27);
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray33 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException34 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray33);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException35 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable22, intArray27, intArray31);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray19, intArray27);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray23 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1L));
        double[] doubleArray26 = pointValuePair25.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship30 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean31 = array2DRowRealMatrix28.equals((java.lang.Object) relationship30);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint33 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector20, relationship30, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint35 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, relationship30, (double) (short) 1);
        org.apache.commons.math3.optimization.linear.Relationship relationship36 = relationship30.oppositeRelationship();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship30 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship30.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + relationship36 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship36.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int2 = org.apache.commons.math3.util.FastMath.min((-127), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-127) + "'", int2 == (-127));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        double[] doubleArray40 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair43 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray40, (java.lang.Double) 0.8813735870195429d);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction45 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray40, 0.1549967237414013d);
        try {
            arrayRealVector33.setSubVector((int) (short) 100, doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector7, 0.5210953054937474d);
        double double10 = linearObjectiveFunction9.getConstantTerm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5210953054937474d + "'", double10 == 0.5210953054937474d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix2.transpose();
        int int7 = blockRealMatrix2.getRowDimension();
        double[] doubleArray9 = blockRealMatrix2.getRow((int) (short) 10);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = null;
        try {
            blockRealMatrix17.setRowMatrix((int) (short) -1, blockRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        double double22 = array2DRowRealMatrix19.getNorm();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 200.0d + "'", double22 == 200.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "{}", "{");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        java.text.NumberFormat numberFormat5 = realVectorFormat3.getFormat();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector22.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector0.copy();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        boolean boolean7 = blockRealMatrix2.equals((java.lang.Object) false);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.createMatrix((int) (byte) 0, 1104156224);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

