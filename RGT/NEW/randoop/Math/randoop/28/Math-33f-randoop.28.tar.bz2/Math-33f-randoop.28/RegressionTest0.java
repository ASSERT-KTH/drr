import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, realVector1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction2 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 100, (float) 0L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math3.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 1, 100, (int) (short) 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.apache.commons.math3.optimization.linear.AbstractLinearOptimizer.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (byte) 0, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = null;
        org.apache.commons.math3.linear.RealVector realVector9 = null;
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint11 = new org.apache.commons.math3.optimization.linear.LinearConstraint(realVector6, (double) (short) 100, relationship8, realVector9, 1.7453292519943295d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 0, (double) Float.NaN, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double10 = arrayRealVector9.getNorm();
        try {
            array2DRowRealMatrix0.setColumnVector((int) 'a', (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0, (java.lang.Number) 10L, true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1, 36, (int) 'a', (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray29 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix15, (org.apache.commons.math3.linear.AnyMatrix) realMatrix31);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix31, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6045724816965523d + "'", double0 == 0.6045724816965523d);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(32.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        float float1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 36, (double) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.999996f + "'", float2 == 35.999996f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) (short) -1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) '4', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double16 = arrayRealVector15.getNorm();
        try {
            arrayRealVector6.setSubVector((int) (byte) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32L, number2, false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray12 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1L));
        double[] doubleArray15 = pointValuePair14.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        try {
            double double17 = arrayRealVector0.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray31 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray32);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix17, (org.apache.commons.math3.linear.AnyMatrix) realMatrix33);
        double[] doubleArray41 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray48 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray49 = new double[][] { doubleArray41, doubleArray48 };
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray64 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray65 = new double[][] { doubleArray57, doubleArray64 };
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix50, (org.apache.commons.math3.linear.AnyMatrix) realMatrix66);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix17, (org.apache.commons.math3.linear.AnyMatrix) realMatrix50);
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (byte) -1, realMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix66);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 100L, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        try {
            double double13 = arrayRealVector0.getEntry((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        org.apache.commons.math3.linear.RealVector realVector12 = null;
        try {
            double double13 = arrayRealVector0.cosine(realVector12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (short) 1, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-1.0d), (double) (-1L), 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 1, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float3 = org.apache.commons.math3.util.Precision.round((float) (short) 0, (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 4.9E-324d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.scalarMultiply((double) Float.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 1, (double) 100.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) '4', (float) 0, (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) -1, (double) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship3 = relationship2.oppositeRelationship();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray7 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1L));
        double[] doubleArray10 = pointValuePair9.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector4.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction15 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector4, 32.0d);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint17 = new org.apache.commons.math3.optimization.linear.LinearConstraint(realVector0, 32.0d, relationship3, (org.apache.commons.math3.linear.RealVector) arrayRealVector4, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship3 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship3.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19);
        org.apache.commons.math3.optimization.linear.Relationship relationship22 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship23 = relationship22.oppositeRelationship();
        double[] doubleArray29 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint32 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray19, (double) 1L, relationship22, doubleArray29, (double) 36);
        try {
            arrayRealVector0.setSubVector((int) (byte) 1, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + relationship22 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship22.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship23 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship23.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray29 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix15, (org.apache.commons.math3.linear.AnyMatrix) realMatrix31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray36 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) (-1L));
        double[] doubleArray39 = pointValuePair38.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector33.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector33, 32.0d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix15, (org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2, 0, (int) (short) -1, 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (byte) 0, (double) 10.0f, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.6483608274590866d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6483608274590866d + "'", double2 == 0.6483608274590866d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, objArray5);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException(number2, objArray5);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, number1, objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor1, (int) 'a', (-127), 5, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 1L, 1.1102230246251565E-16d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4, (int) (short) -1, 5, (int) (short) 10, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double3 = org.apache.commons.math3.util.Precision.round(0.0d, (int) '4', 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.power(1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) '4');
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2, (int) (byte) 10, (-1), (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        try {
            double double15 = arrayRealVector6.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '#', (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-35.0f) + "'", float2 == (-35.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math3.util.FastMath.acos(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = relationship9.oppositeRelationship();
        double[] doubleArray16 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector17 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray16);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray6, (double) 1L, relationship9, doubleArray16, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        java.lang.StringBuffer stringBuffer21 = null;
        java.text.FieldPosition fieldPosition22 = null;
        try {
            java.lang.StringBuffer stringBuffer23 = realVectorFormat0.format(realVector20, stringBuffer21, fieldPosition22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.0d) + "'", double1 == (-57.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{}", "{}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            array2DRowRealMatrix0.setColumnVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-57.29577951308232d), 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-35.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.transpose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector6.getMaxValue();
        double[] doubleArray14 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = realVector15.mapAdd((double) (short) 100);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector6.ebeDivide(realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math3.util.FastMath.tan(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3, 100, (-127), 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (short) -1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{}", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 52, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray3 = array2DRowRealMatrix2.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) 10, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        arrayRealVector0.set((double) (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray3 = null;
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.preMultiply(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = relationship10.oppositeRelationship();
        double[] doubleArray17 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray7, (double) 1L, relationship10, doubleArray17, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray7);
        try {
            double[] doubleArray22 = array2DRowRealMatrix0.operate(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship12 = relationship11.oppositeRelationship();
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint21 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray8, (double) 1L, relationship11, doubleArray18, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 0L, false);
        double[] doubleArray26 = pointValuePair25.getKey();
        try {
            double[] doubleArray27 = array2DRowRealMatrix0.operate(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship12 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship12.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-57.0d), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-57.0d) + "'", double2 == (-57.0d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3, (int) (byte) 0, 5, (-1), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 0, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math3.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0000005f + "'", float1 == 5.0000005f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            double[] doubleArray3 = array2DRowRealMatrix0.getColumn(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.scalarMultiply(11013.232874703393d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) (byte) 0, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) -1, 0.0f, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship12 = relationship11.oppositeRelationship();
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint21 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray8, (double) 1L, relationship11, doubleArray18, (double) 36);
        try {
            double[] doubleArray22 = array2DRowRealMatrix0.operate(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship12 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship12.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1079574528, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957453E9f + "'", float2 == 1.07957453E9f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '#', (-35.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-35.0f) + "'", float2 == (-35.0f));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 1, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        double double16 = arrayRealVector8.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray20 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) (-1L));
        double[] doubleArray23 = pointValuePair22.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray28 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1L));
        double[] doubleArray31 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector25.mapMultiply((double) '#');
        double double35 = arrayRealVector25.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector17.append((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        try {
            org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector8.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(7.930067261567154E14d, (double) 35.999996f, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01999733397315053d + "'", double2 == 0.01999733397315053d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("{}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0d), (short) 0, 1.0d, true, 1.0d };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (short) -1, localizable3, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray9);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship5 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean6 = array2DRowRealMatrix3.equals((java.lang.Object) relationship5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship5 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship5.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        double[] doubleArray6 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = realVector7.mapAdd((double) (short) 100);
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        try {
            java.lang.StringBuffer stringBuffer12 = realVectorFormat0.format(realVector9, stringBuffer10, fieldPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray21 = new double[][] { doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, (java.lang.Object[]) doubleArray21);
        try {
            array2DRowRealMatrix0.copySubMatrix((int) '4', (int) 'a', (int) ' ', (int) (short) 10, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (-127), (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        java.lang.String str2 = array2DRowRealMatrix0.toString();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Array2DRowRealMatrix{}" + "'", str2.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) 'a');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 10, doubleArray4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException5 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray4);
        org.apache.commons.math3.exception.ZeroException zeroException6 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray4);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 1, 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float2 = org.apache.commons.math3.util.FastMath.max((-1.0f), (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction2 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (-1));
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1) + "'", number2.equals((-1)));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.optimization.linear.Relationship relationship20 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = relationship20.oppositeRelationship();
        double[] doubleArray27 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint30 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray17, (double) 1L, relationship20, doubleArray27, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, (double) 0L, false);
        double[] doubleArray35 = pointValuePair34.getKey();
        try {
            double double36 = linearObjectiveFunction11.getValue(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + relationship20 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship20.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        java.lang.String str2 = maxCountExceededException1.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = maxCountExceededException1.getContext();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded" + "'", str2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded"));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        double double11 = arrayRealVector0.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.util.MathUtils.checkFinite(4.9E-324d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapDivideToSelf((-1.0d));
        try {
            double double12 = arrayRealVector7.getEntry(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(36, 100);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1,872 != 1,728");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 100L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math3.util.Pair<java.lang.IllegalArgumentException, org.apache.commons.math3.exception.MathIllegalStateException> illegalArgumentExceptionPair5 = new org.apache.commons.math3.util.Pair<java.lang.IllegalArgumentException, org.apache.commons.math3.exception.MathIllegalStateException>((java.lang.IllegalArgumentException) notStrictlyPositiveException1, (org.apache.commons.math3.exception.MathIllegalStateException) maxCountExceededException4);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 1 + "'", number2.equals((byte) 1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        java.lang.String str2 = array2DRowRealMatrix0.toString();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.scalarAdd(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Array2DRowRealMatrix{}" + "'", str2.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        java.lang.String str2 = array2DRowRealMatrix0.toString();
        try {
            array2DRowRealMatrix0.addToEntry((-127), (int) (byte) -1, (double) (-35.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Array2DRowRealMatrix{}" + "'", str2.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector3 = array2DRowRealMatrix0.operate(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector7.append(arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int8 = matrixDimensionMismatchException4.getWrongDimension(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector7.map(univariateFunction11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(7.930067261567154E14d, (-57.0d), 2.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (-35.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.305116760146989E-16d + "'", double1 == 6.305116760146989E-16d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(52, (int) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) '4', 36);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.multiply(blockRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        java.lang.String str2 = array2DRowRealMatrix0.toString();
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.getColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Array2DRowRealMatrix{}" + "'", str2.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) ' ', (double) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.000004f + "'", float2 == 32.000004f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix24, 0, (-127), 5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        try {
            double double5 = blockRealMatrix2.getEntry(1079574528, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException();
        java.lang.Throwable[] throwableArray2 = noDataException1.getSuppressed();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.8813735870195429d, (java.lang.Object[]) throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) '#', (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.6045724816965523d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.3954275183034477d) + "'", double2 == (-0.3954275183034477d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) relationship9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray25 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray26 = new double[][] { doubleArray18, doubleArray25 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray26);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException28 = new org.apache.commons.math3.exception.NullArgumentException(localizable11, (java.lang.Object[]) doubleArray26);
        double[][] doubleArray29 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        array2DRowRealMatrix7.setSubMatrix(doubleArray26, (int) (short) 0, (int) (byte) 0);
        try {
            array2DRowRealMatrix0.copySubMatrix((int) 'a', 36, 36, (int) 'a', doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray30 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1L));
        double[] doubleArray33 = pointValuePair32.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray33);
        try {
            array2DRowRealMatrix0.setRowVector(1079574528, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector11.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction22 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector11, (-1.0d));
        try {
            double double23 = arrayRealVector8.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("; ", 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 32L, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector8.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math3.linear.RealVector realVector24 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector8.combineToSelf((double) 35.999996f, (double) 100L, realVector24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 1, (float) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math3.util.FastMath.log10(6.305116760146989E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.200306866613815d) + "'", double1 == (-15.200306866613815d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100L, (float) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double[] doubleArray8 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector9 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.subtract(realMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double23 = blockRealMatrix22.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix18.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix19.walkInRowOrder(realMatrixPreservingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(5.0000005f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector22.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        try {
            org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (short) 0, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector0.append((double) 100L);
        double double16 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray20 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) (-1L));
        double[] doubleArray23 = pointValuePair22.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector24.mapDivideToSelf((-1.0d));
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector0.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(number5, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray8);
        java.lang.Class<?> wildcardClass12 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship1 = relationship0.oppositeRelationship();
        java.lang.String str2 = relationship0.toString();
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship1 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship1.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ">=" + "'", str2.equals(">="));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        int[] intArray24 = new int[] { (short) 100, 0, '#', 1079574528, 'a' };
        int[] intArray29 = new int[] { (-127), '#', 2, (short) -1 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, intArray24, intArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = mathArithmeticException18.getContext();
        zeroException17.addSuppressed((java.lang.Throwable) mathArithmeticException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext21 = mathArithmeticException18.getContext();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertNotNull(exceptionContext21);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(7.930067261567154E14d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double double26 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 210.78424988599124d + "'", double26 == 210.78424988599124d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(4.9E-324d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        double double16 = arrayRealVector8.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector8.map(univariateFunction17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray3 = null;
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.preMultiply(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        double[] doubleArray25 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray32 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix34);
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray49 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray50 = new double[][] { doubleArray42, doubleArray49 };
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray50);
        double[] doubleArray58 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray65 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray66);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix51, (org.apache.commons.math3.linear.AnyMatrix) realMatrix67);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(4.61512051684126d, 0.6045724816965523d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.654551027821466d + "'", double2 == 4.654551027821466d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, objArray3);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, objArray3);
        java.lang.Class<?> wildcardClass6 = objArray3.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.0E-323d, (double) 0.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.getSubMatrix((int) (short) 10, (int) (short) 100, (-1), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor4, 0, 0, 2, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, (-1.0d));
        double double12 = linearObjectiveFunction11.getConstantTerm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        org.apache.commons.math3.linear.RealVector realVector12 = linearObjectiveFunction11.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math3.util.FastMath.abs(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.9155040003582885E22d, (java.lang.Number) 32L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32L + "'", number4.equals(32L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32L + "'", number5.equals(32L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, "}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector14 = null;
        try {
            double double15 = arrayRealVector0.getDistance(realVector14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (-127), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 127.0f + "'", float2 == 127.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        try {
            arrayRealVector8.setEntry((int) (byte) 10, 210.78424988599124d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = null;
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray3, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 100 columns are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 0, (int) '4');
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getPrefix();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray22 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair24 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) (-1L));
        double[] doubleArray25 = pointValuePair24.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray30 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1L));
        double[] doubleArray33 = pointValuePair32.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        double double35 = arrayRealVector27.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector34);
        int int37 = arrayRealVector36.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double21 = array2DRowRealMatrix20.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix18.subtract(array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int[] intArray7 = new int[] { (-127), 36, (short) 0, '4', 6 };
        int[] intArray13 = new int[] { 6, 10, (short) 100, (byte) 0, 10 };
        org.apache.commons.math3.exception.util.Localizable localizable14 = null;
        double[] doubleArray21 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray28 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray29 = new double[][] { doubleArray21, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException31 = new org.apache.commons.math3.exception.NullArgumentException(localizable14, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[][] doubleArray33 = array2DRowRealMatrix32.getData();
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray7, intArray13, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
        java.lang.Throwable[] throwableArray1 = noDataException0.getSuppressed();
        java.lang.Throwable[] throwableArray2 = noDataException0.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", "=");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded" + "'", str4.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 1);
        try {
            org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector1.getSubVector((int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(100.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealVector realVector6 = null;
        try {
            blockRealMatrix2.setRowVector((-1), realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.power(2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 1, (float) 1079574528, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(52.0d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix0.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int2 = org.apache.commons.math3.util.FastMath.max(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.getRowMatrix((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(number5, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray8);
        boolean boolean12 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(210.78424988599124d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double20 = array2DRowRealMatrix19.getFrobeniusNorm();
        double double21 = array2DRowRealMatrix19.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix18.add(array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6, 1079574528, 6, (int) (byte) 10, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double3 = org.apache.commons.math3.util.Precision.round(Double.POSITIVE_INFINITY, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 'a', (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray21 = new double[][] { doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        try {
            blockRealMatrix2.setRowMatrix((int) (byte) 10, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((-0.3954275183034477d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7339880056937724d) + "'", double1 == (-0.7339880056937724d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str15 = relationship14.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint17 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship14, (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray21 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) (-1L));
        double[] doubleArray24 = pointValuePair23.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector25.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(realVector28);
        try {
            double double30 = arrayRealVector0.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ">=" + "'", str15.equals(">="));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5210953054937474d + "'", double1 == 0.5210953054937474d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        double double16 = arrayRealVector8.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        arrayRealVector8.set(0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(0.0f, (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray28 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1L));
        double[] doubleArray31 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector25.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = array2DRowRealMatrix24.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(arrayRealVector33);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.5d, (double) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix18.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix18.walkInRowOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray22 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair24 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) (-1L));
        double[] doubleArray25 = pointValuePair24.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray30 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1L));
        double[] doubleArray33 = pointValuePair32.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33);
        double double35 = arrayRealVector27.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector34);
        double[] doubleArray39 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray39, (double) (-1L));
        double[] doubleArray42 = pointValuePair41.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        try {
            double double44 = arrayRealVector36.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 7 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.transpose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean1 = arrayRealVector0.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector10.mapMultiply((double) '#');
        double double20 = arrayRealVector10.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector2.append((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        double double24 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double[] doubleArray30 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray30);
        try {
            org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector0.projection(realVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) 100, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getKey();
        double[] doubleArray7 = pointValuePair4.getKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 'a', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(">=", "", ">=");
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix2.getSubMatrix((int) '4', (int) '#', (int) (byte) 1, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 52 after final row 35");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(10.0f, (float) (-1L), (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray13);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray26 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException27 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable15, intArray22, intArray26);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException28 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray9, intArray26);
        java.lang.Integer[] intArray29 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException30 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray26, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction15 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector13, 0.5210953054937474d);
        double[] doubleArray21 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray21);
        org.apache.commons.math3.optimization.linear.Relationship relationship25 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray31 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint35 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray21, (double) 5, relationship25, doubleArray31, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray31);
        try {
            array2DRowRealMatrix0.setRow((int) (short) -1, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + relationship25 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship25.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2, 32, (-1023), 6, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4, (int) (byte) 10, 52, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        int[] intArray25 = new int[] { 'a', (byte) 0, ' ', 1079574528, (-1023) };
        int[] intArray26 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix18.getSubMatrix(intArray25, intArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray7 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1L));
        java.lang.Double double10 = pointValuePair9.getValue();
        double[] doubleArray11 = pointValuePair9.getKey();
        try {
            blockRealMatrix2.setRow((-127), doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double double20 = arrayRealVector19.getNorm();
        arrayRealVector19.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector29.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector19.ebeDivide(realVector32);
        boolean boolean34 = arrayRealVector0.equals((java.lang.Object) arrayRealVector19);
        arrayRealVector19.unitize();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.0d + "'", double20 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship12 = relationship11.oppositeRelationship();
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint21 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray8, (double) 1L, relationship11, doubleArray18, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 0L, false);
        double[] doubleArray26 = pointValuePair25.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        try {
            double[] doubleArray28 = array2DRowRealMatrix0.preMultiply(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship12 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship12.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray9 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray9, (java.lang.Double) 0.8813735870195429d);
        try {
            array2DRowRealMatrix0.setRow((int) 'a', doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        java.lang.String str9 = arrayRealVector0.toString();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.optimization.linear.Relationship relationship19 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship20 = relationship19.oppositeRelationship();
        double[] doubleArray26 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint29 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray16, (double) 1L, relationship19, doubleArray26, (double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray33 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray33, (double) (-1L));
        double[] doubleArray36 = pointValuePair35.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        double[] doubleArray41 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray41, (double) (-1L));
        double[] doubleArray44 = pointValuePair43.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44);
        double double46 = arrayRealVector38.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, arrayRealVector45);
        try {
            arrayRealVector0.setSubVector(6, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + relationship19 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship19.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship20 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship20.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray9 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1L));
        double[] doubleArray12 = pointValuePair11.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector6.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector6.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean19 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector18);
        try {
            blockRealMatrix2.setRowVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4, (int) (byte) -1, 36, 36, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.optimization.linear.UnboundedSolutionException unboundedSolutionException0 = new org.apache.commons.math3.optimization.linear.UnboundedSolutionException();
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        java.lang.Number number20 = notStrictlyPositiveException19.getArgument();
        nullArgumentException17.addSuppressed((java.lang.Throwable) notStrictlyPositiveException19);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 1 + "'", number20.equals((byte) 1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.5663706143591725d) + "'", double2 == (-2.5663706143591725d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray19 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math3.exception.NullArgumentException(localizable5, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray24 = array2DRowRealMatrix23.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.getColumnMatrix(2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(36, 100);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray7, 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
        java.lang.String str3 = dimensionMismatchException2.toString();
        java.lang.String str4 = dimensionMismatchException2.toString();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray8, intArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) intArray10);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) str4, localizable5, (java.lang.Object[]) intArray10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1" + "'", str3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1" + "'", str4.equals("org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1"));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector22.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            arrayRealVector22.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (-35.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.0d) + "'", double1 == (-35.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        double[] doubleArray25 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray32 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix34);
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray49 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray50 = new double[][] { doubleArray42, doubleArray49 };
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray50);
        double[] doubleArray58 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray65 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray66);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix51, (org.apache.commons.math3.linear.AnyMatrix) realMatrix67);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix51);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix0.multiply(realMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math3.util.FastMath.pow(210.78424988599124d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        int[] intArray24 = new int[] { (-1), (-127), (byte) -1, (short) 1 };
        int[] intArray30 = new int[] { 'a', (byte) 10, 52, 52, 5 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19, intArray24, intArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((-0.3954275183034477d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.32660790974246073d) + "'", double1 == (-0.32660790974246073d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector0.mapToSelf(univariateFunction13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray20 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) (-1L));
        double[] doubleArray23 = pointValuePair22.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector24.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(realVector27);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector14.combine(4.61512051684126d, 0.7615941559557649d, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray23 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray24 = new double[][] { doubleArray16, doubleArray23 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray24);
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException(localizable9, (java.lang.Object[]) doubleArray24);
        try {
            blockRealMatrix4.copySubMatrix((int) (short) 0, (int) (short) 1, (int) ' ', (int) '#', doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3, 0, (int) (short) 10, (-1023), 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(127.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) (-1), number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[] doubleArray11 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray11);
        org.apache.commons.math3.optimization.linear.Relationship relationship15 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray21 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray21);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint25 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray11, (double) 5, relationship15, doubleArray21, 1.7453292519943295d);
        double[] doubleArray31 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair36 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, 0.6045724816965523d, false);
        double[] doubleArray37 = pointValuePair36.getPoint();
        double[] doubleArray38 = pointValuePair36.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, doubleArray38);
        try {
            blockRealMatrix4.setColumn(32, doubleArray38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + relationship15 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship15.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[] doubleArray12 = new double[] { (-1023), 52.0d, 3.141592653589793d };
        double[] doubleArray16 = new double[] { (-1023), 52.0d, 3.141592653589793d };
        double[] doubleArray20 = new double[] { (-1023), 52.0d, 3.141592653589793d };
        double[][] doubleArray21 = new double[][] { doubleArray12, doubleArray16, doubleArray20 };
        try {
            blockRealMatrix2.copySubMatrix((int) (short) 1, 36, 5, 10, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector7.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector7.mapDivide(0.6045724816965523d);
        try {
            org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix4.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(100, (int) (byte) -1, doubleArray8, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 180.0d + "'", double1 == 180.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getKey();
        java.lang.Double double7 = pointValuePair4.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7.equals((-1.0d)));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        int[] intArray24 = new int[] { (byte) 0, 1, '4', 36 };
        int[] intArray25 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix19.getSubMatrix(intArray24, intArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        java.io.ObjectInputStream objectInputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) arrayRealVector7, "Array2DRowRealMatrix{}", objectInputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        double double10 = blockRealMatrix8.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.multiply(blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(100);
        try {
            org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector1.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double double4 = blockRealMatrix2.getNorm();
        try {
            double double5 = blockRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = blockRealMatrix5.getColumnVector(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[] doubleArray7 = new double[] { (-57.29577951308232d), 1, (byte) 1, 0.8813735870195429d, 5 };
        try {
            double[] doubleArray8 = array2DRowRealMatrix0.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, objArray3);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray3);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, "org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math3.util.FastMath.floor(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        double[] doubleArray13 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector16 = realVector14.mapAdd((double) (short) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = arrayRealVector0.outerProduct(realVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector34.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector42, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector33.add((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray15 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1L));
        double[] doubleArray18 = pointValuePair17.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapSubtractToSelf((double) (-1L));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector11.append(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.util.MathUtils.checkFinite(0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double double26 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 210.78424988599124d + "'", double26 == 210.78424988599124d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        try {
            double double3 = blockRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 100, (float) 1079574528);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957453E9f + "'", float2 == 1.07957453E9f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.6045724816965523d, (double) 35.999996f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.999996185302734d + "'", double2 == 35.999996185302734d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(210.78424988599124d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7434383785452805E91d + "'", double1 == 1.7434383785452805E91d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        try {
            double double6 = blockRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        try {
            org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double double5 = blockRealMatrix2.getNorm();
        try {
            double double8 = blockRealMatrix2.getEntry(100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(35.0f, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999996f + "'", float2 == 34.999996f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) 0L, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray6 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray6, (double) (-1L));
        double[] doubleArray9 = pointValuePair8.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector3.mapMultiply((double) '#');
        double double13 = arrayRealVector3.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector3.mapToSelf(univariateFunction14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction17 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector3, 2.154434690031884d);
        double[] doubleArray20 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) (-1L));
        double[] doubleArray23 = pointValuePair22.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.optimization.linear.Relationship relationship26 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship27 = relationship26.oppositeRelationship();
        double[] doubleArray33 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint36 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray23, (double) 1L, relationship26, doubleArray33, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint[] linearConstraintArray37 = new org.apache.commons.math3.optimization.linear.LinearConstraint[] { linearConstraint36 };
        java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint> linearConstraintList38 = new java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList38, linearConstraintArray37);
        org.apache.commons.math3.optimization.GoalType goalType40 = null;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair42 = simplexSolver2.optimize(linearObjectiveFunction17, (java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList38, goalType40, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException; message: no feasible solution");
        } catch (org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + relationship26 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship26.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship27 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship27.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(linearConstraintArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.subtract(blockRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException4 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (short) -1, objArray3);
        java.lang.Throwable[] throwableArray5 = notFiniteNumberException4.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, number1, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector7.ebeDivide(realVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction22 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector21.map(univariateFunction22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((-127), (int) (byte) 100);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray16);
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix13.walkInColumnOrder(realMatrixChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        try {
            blockRealMatrix5.addToEntry((-1), (int) (short) -1, 0.7615941559557649d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            array2DRowRealMatrix19.setEntry((int) 'a', 0, (double) 32L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        double double9 = arrayRealVector7.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship15 = relationship14.oppositeRelationship();
        double[] doubleArray21 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint24 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray11, (double) 1L, relationship14, doubleArray21, (double) 36);
        try {
            double[] doubleArray25 = blockRealMatrix2.preMultiply(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship15 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship15.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction19 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, 32.0d);
        double[] doubleArray20 = arrayRealVector8.getDataRef();
        try {
            blockRealMatrix4.setColumn((int) 'a', doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray26 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, (double) (-1L));
        double[] doubleArray29 = pointValuePair28.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray34 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair36 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray34, (double) (-1L));
        double[] doubleArray37 = pointValuePair36.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.copy();
        java.lang.String str40 = arrayRealVector31.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector31);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector22.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{}" + "'", str40.equals("{}"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray21 = new double[][] { doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable6, (java.lang.Object[]) doubleArray21);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray21, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '#', (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29);
        try {
            org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) (-1023), (java.lang.Number) 5.0000005f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 0, Float.NaN, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(number5, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray8);
        java.lang.Number number12 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 1 + "'", number12.equals((short) 1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-147.04220486917677d) + "'", double1 == (-147.04220486917677d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.5663706143591725d) + "'", double2 == (-2.5663706143591725d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor2, (int) '4', 0, 52, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction15 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray12, 0.5210953054937474d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray20 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray21 = new double[][] { doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        try {
            blockRealMatrix6.setSubMatrix(doubleArray21, (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[] doubleArray10 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray20 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray20);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint24 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray10, (double) 5, relationship14, doubleArray20, 1.7453292519943295d);
        try {
            double[] doubleArray25 = blockRealMatrix2.operate(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray15 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray16);
        java.lang.Throwable[] throwableArray19 = nullArgumentException18.getSuppressed();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{}", "Array2DRowRealMatrix{}", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
        java.lang.String str4 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{}" + "'", str4.equals("{}"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSeparator();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            java.lang.String str3 = realVectorFormat0.format(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.6045724816965523d, false);
        double[] doubleArray31 = pointValuePair30.getPoint();
        double[] doubleArray32 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (byte) -1);
        org.apache.commons.math3.exception.util.Localizable localizable36 = null;
        java.lang.Integer[] intArray38 = new java.lang.Integer[] { 1079574528 };
        java.lang.Integer[] intArray40 = new java.lang.Integer[] { 1 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException41 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray38, intArray40);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector33, localizable36, (java.lang.Object[]) intArray38);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(2.718281828459045d, (-1023), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) 'a');
        boolean boolean9 = pointValuePair4.equals((java.lang.Object) doubleArray8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4, (-1), 1079574528, (-127), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Object obj5 = null;
        boolean boolean6 = pointValuePair4.equals(obj5);
        double[] doubleArray7 = pointValuePair4.getKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.getSubMatrix(100, (int) (short) 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.9155040003582885E22d, (java.lang.Number) 100L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (-0.99999994f), 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1071486939522315d) + "'", double2 == (-1.1071486939522315d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.getColumnMatrix(6);
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix4.getRowVector(1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix18.walkInRowOrder(realMatrixPreservingVisitor20, (int) (byte) 10, (int) '#', 1072693248, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (-1), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        double double8 = arrayRealVector7.getNorm();
        double double9 = arrayRealVector7.getNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        int int2 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor3, 52, 32, 10, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double5 = array2DRowRealMatrix4.getNorm();
        int int6 = array2DRowRealMatrix4.getColumnDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double[] doubleArray31 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair36 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, 0.6045724816965523d, false);
        double[] doubleArray37 = pointValuePair36.getPoint();
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray37);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector0.mapToSelf(univariateFunction13);
        double[] doubleArray15 = arrayRealVector14.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray2 = array2DRowRealMatrix1.getData();
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray2);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("=", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector8.copy();
        java.lang.String str17 = arrayRealVector8.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector8);
        try {
            arrayRealVector8.addToEntry(100, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector13.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction24 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector13, 32.0d);
        double[] doubleArray25 = arrayRealVector13.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray25, 0.5210953054937474d);
        org.apache.commons.math3.linear.RealVector realVector29 = linearObjectiveFunction28.getCoefficients();
        try {
            blockRealMatrix2.setRowVector(6, realVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 2, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver((double) 0L, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray6 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray6, (double) (-1L));
        double[] doubleArray9 = pointValuePair8.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector3.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction14 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector3, 32.0d);
        double[] doubleArray15 = arrayRealVector3.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray15, 0.5210953054937474d);
        org.apache.commons.math3.linear.RealVector realVector19 = linearObjectiveFunction18.getCoefficients();
        double[] doubleArray25 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.linear.Relationship relationship29 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray35 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint39 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray25, (double) 5, relationship29, doubleArray35, 1.7453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector40 = linearConstraint39.getCoefficients();
        double[] doubleArray43 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray43, (double) (-1L));
        double[] doubleArray46 = pointValuePair45.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46);
        org.apache.commons.math3.optimization.linear.Relationship relationship49 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship50 = relationship49.oppositeRelationship();
        double[] doubleArray56 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint59 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray46, (double) 1L, relationship49, doubleArray56, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint[] linearConstraintArray60 = new org.apache.commons.math3.optimization.linear.LinearConstraint[] { linearConstraint39, linearConstraint59 };
        java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint> linearConstraintList61 = new java.util.ArrayList<org.apache.commons.math3.optimization.linear.LinearConstraint>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList61, linearConstraintArray60);
        org.apache.commons.math3.optimization.GoalType goalType63 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair65 = simplexSolver2.optimize(linearObjectiveFunction18, (java.util.Collection<org.apache.commons.math3.optimization.linear.LinearConstraint>) linearConstraintList61, goalType63, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException; message: no feasible solution");
        } catch (org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + relationship29 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship29.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + relationship49 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship49.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship50 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship50.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(linearConstraintArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + goalType63 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType63.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double5 = blockRealMatrix2.getEntry(36, 0);
        double double6 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray21 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray22 = new double[][] { doubleArray14, doubleArray21 };
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray22);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix25.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) realMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (int) (byte) 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        java.io.ObjectInputStream objectInputStream23 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) arrayRealVector21, "", objectInputStream23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 32, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix4.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-1.1071486939522315d), 1.7453292519943295d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double23 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor18, 36, (int) (byte) 1, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getWrongDimension(6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector11.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException noFeasibleSolutionException0 = new org.apache.commons.math3.optimization.linear.NoFeasibleSolutionException();
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 7.930067261567154E14d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship1 = relationship0.oppositeRelationship();
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + relationship1 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship1.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 1.07957453E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector8.copy();
        java.lang.String str17 = arrayRealVector8.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray32 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, (double) (-1L));
        double[] doubleArray35 = pointValuePair34.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.mapMultiply((double) '#');
        double double39 = arrayRealVector29.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector21.append((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray46 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, (double) (-1L));
        double[] doubleArray49 = pointValuePair48.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector43.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector43.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector8.combineToSelf(1.0d, (double) (-1023), (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double[] doubleArray60 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair62 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray60, (double) (-1L));
        double[] doubleArray63 = pointValuePair62.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        org.apache.commons.math3.optimization.linear.Relationship relationship66 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship67 = relationship66.oppositeRelationship();
        double[] doubleArray73 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector74 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray73);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint76 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray63, (double) 1L, relationship66, doubleArray73, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector77 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray63);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair80 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray63, (double) 0L, false);
        double[] doubleArray81 = pointValuePair80.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray81);
        try {
            arrayRealVector8.setSubVector((int) (short) 10, doubleArray81);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + relationship66 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship66.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship67 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship67.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 0.7615941559557649d, 0.6045724816965523d, (-57.0d), (-0.0d) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, 10, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,072,693,258 is larger than the maximum (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 35.999996f, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 127.0f, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(4.654551027821466d, (double) 10.000001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.03017970588336d + "'", double2 == 11.03017970588336d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction11 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector0, 32.0d);
        double[] doubleArray12 = arrayRealVector0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double16 = array2DRowRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean18 = array2DRowRealMatrix15.equals((java.lang.Object) relationship17);
        java.lang.String str19 = relationship17.toString();
        double[] doubleArray22 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair24 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) (-1L));
        double[] doubleArray25 = pointValuePair24.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.apache.commons.math3.optimization.linear.Relationship relationship28 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship29 = relationship28.oppositeRelationship();
        double[] doubleArray35 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint38 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray25, (double) 1L, relationship28, doubleArray35, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint40 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray12, 3.141592653589793d, relationship17, doubleArray35, 0.0d);
        org.apache.commons.math3.exception.MathParseException mathParseException43 = new org.apache.commons.math3.exception.MathParseException("{}", 0);
        boolean boolean44 = linearConstraint40.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "=" + "'", str19.equals("="));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + relationship28 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship28.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship29 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship29.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) '4', (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(10.000001f, (float) (short) 0, (float) 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-147.04220486917677d), 3.58351893845611d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray17 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = array2DRowRealMatrix0.add(array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor6, 36, 0, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 36 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double double9 = arrayRealVector8.getNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math3.util.FastMath.rint(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray25 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray26 = new double[][] { doubleArray18, doubleArray25 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray26);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix8.subtract(realMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.mapToSelf(univariateFunction11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector0.mapToSelf(univariateFunction13);
        int int15 = arrayRealVector0.getMaxIndex();
        java.lang.Object obj16 = null;
        boolean boolean17 = arrayRealVector0.equals(obj16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray7 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1L));
        double[] doubleArray10 = pointValuePair9.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10);
        org.apache.commons.math3.optimization.linear.Relationship relationship13 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = relationship13.oppositeRelationship();
        double[] doubleArray20 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint23 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray10, (double) 1L, relationship13, doubleArray20, (double) 36);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix0.add(realMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 1x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + relationship13 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship13.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector0.append(0.5d);
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double double19 = arrayRealVector18.getNorm();
        arrayRealVector18.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector28.mapDivideToSelf((-1.0d));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector18.ebeDivide(realVector31);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector0.ebeDivide(realVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.0d + "'", double19 == 32.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarAdd((-0.32660790974246073d));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double12 = blockRealMatrix11.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector14 = blockRealMatrix11.getRowVector(2);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix6.add(blockRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x100 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math3.exception.NullArgumentException(localizable6, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(number5, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException11.getContext();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }
}

