import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector0.append((double) 5.0000005f);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray18 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray18, (double) (-1L));
        double[] doubleArray21 = pointValuePair20.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector15.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector14.append(arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix4.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix6.scalarAdd((-0.32660790974246073d));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix6.walkInRowOrder(realMatrixChangingVisitor9, (-1), (int) (byte) -1, 2, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean1 = arrayRealVector0.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray5 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1L));
        double[] doubleArray8 = pointValuePair7.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector10.mapMultiply((double) '#');
        double double20 = arrayRealVector10.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector2.append((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        double double24 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double double25 = arrayRealVector2.getMaxValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math3.util.FastMath.atan(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948712d + "'", double1 == 1.5707963267948712d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector27 = array2DRowRealMatrix0.getRowVector(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.DimensionMismatchException: 0 != -1", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", "");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double10 = array2DRowRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship11 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) relationship11);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint14 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector1, relationship11, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship15 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str16 = relationship15.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector1, relationship15, (double) 10);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException23 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int24 = matrixDimensionMismatchException23.getExpectedColumnDimension();
        int int25 = matrixDimensionMismatchException23.getExpectedColumnDimension();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException> relationshipPair26 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException>(relationship15, (java.lang.IllegalArgumentException) matrixDimensionMismatchException23);
        java.lang.Integer[] intArray27 = matrixDimensionMismatchException23.getExpectedDimensions();
        int int28 = matrixDimensionMismatchException23.getExpectedRowDimension();
        java.lang.Integer[] intArray29 = matrixDimensionMismatchException23.getExpectedDimensions();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException34 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int35 = matrixDimensionMismatchException34.getExpectedColumnDimension();
        int int36 = matrixDimensionMismatchException34.getExpectedColumnDimension();
        java.lang.Integer[] intArray37 = matrixDimensionMismatchException34.getExpectedDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable38 = null;
        java.lang.Integer[] intArray45 = new java.lang.Integer[] { 36, 6, 6, 1, 1079574528, 100 };
        java.lang.Integer[] intArray49 = new java.lang.Integer[] { 5, 5, 10 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException50 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable38, intArray45, intArray49);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException51 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray37, intArray49);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException52 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray29, intArray49);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray29);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship11 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship11.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + relationship15 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship15.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + ">=" + "'", str16.equals(">="));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 2);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        double[] doubleArray35 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray43 = new double[][] { doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException45 = new org.apache.commons.math3.exception.NullArgumentException(localizable28, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix46);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor48 = null;
        try {
            double double53 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor48, 0, 1322834079, (-1023), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,322,834,079)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double2 = org.apache.commons.math3.util.FastMath.pow(200.0d, 3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7611022316753015E8d + "'", double2 == 1.7611022316753015E8d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) -1, 0, (int) (byte) 0, (int) (byte) 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 2);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        double[] doubleArray35 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray43 = new double[][] { doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException45 = new org.apache.commons.math3.exception.NullArgumentException(localizable28, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix46);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double49 = array2DRowRealMatrix46.walkInColumnOrder(realMatrixChangingVisitor48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.copy();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction10 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, (double) (-1));
        double[] doubleArray13 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1L));
        double[] doubleArray16 = pointValuePair15.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction20 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector18, 0.5210953054937474d);
        double[] doubleArray26 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        org.apache.commons.math3.optimization.linear.Relationship relationship30 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray36 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint40 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray26, (double) 5, relationship30, doubleArray36, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector18.mapSubtractToSelf((double) 5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + relationship30 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship30.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realVector43);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 1, number2, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        double double16 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double22 = blockRealMatrix14.walkInRowOrder(realMatrixPreservingVisitor17, (int) (byte) 1, 0, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) doubleArray9);
        double[] doubleArray11 = pointValuePair4.getPoint();
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>((org.apache.commons.math3.util.Pair<double[], java.lang.Double>) pointValuePair4);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) (-1L), false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException3 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = nullArgumentException3.getContext();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply((-1.5707963267948966d));
        double[] doubleArray12 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray19 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[] doubleArray28 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray35 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix21, (org.apache.commons.math3.linear.AnyMatrix) realMatrix37);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix2.subtract(realMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x1 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.transpose();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) ' ', (double) 34.999996f, (-0.32660790974246073d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray8 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1L));
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray17 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, (double) (-1L));
        double[] doubleArray20 = pointValuePair19.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector14.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction25 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector14, 32.0d);
        double[] doubleArray26 = arrayRealVector14.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix0.operate(doubleArray26);
        double[] doubleArray31 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair33 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1L));
        double[] doubleArray34 = pointValuePair33.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        org.apache.commons.math3.optimization.linear.Relationship relationship37 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship38 = relationship37.oppositeRelationship();
        double[] doubleArray44 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector45 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray44);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint47 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray34, (double) 1L, relationship37, doubleArray44, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray34);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction54 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray34, (-57.29577951308232d));
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray34);
        try {
            double[] doubleArray56 = array2DRowRealMatrix0.preMultiply(doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + relationship37 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship37.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship38 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship38.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getNorm();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3, 100, 5, 52, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.0d, 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction19 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector8, 32.0d);
        double[] doubleArray20 = arrayRealVector8.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector6.ebeDivide(realVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double10 = arrayRealVector9.getNorm();
        arrayRealVector9.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        java.lang.String str14 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.String str15 = realVectorFormat0.getSuffix();
        java.text.ParsePosition parsePosition17 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = realVectorFormat0.parse("Array2DRowRealMatrix{}", parsePosition17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 1}" + "'", str14.equals("{0; 1}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "}" + "'", str15.equals("}"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        double double6 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = blockRealMatrix2.getColumnMatrix((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("BlockRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.text.NumberFormat numberFormat4 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("}", "{}", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded", numberFormat4);
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        try {
            java.lang.StringBuffer stringBuffer8 = org.apache.commons.math3.util.CompositeFormat.formatDouble((-0.7339880056937724d), numberFormat4, stringBuffer6, fieldPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 2);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        double[] doubleArray35 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray43 = new double[][] { doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException45 = new org.apache.commons.math3.exception.NullArgumentException(localizable28, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix46);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor48 = null;
        try {
            double double53 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor48, (int) (short) -1, 10, 52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapMultiplyToSelf((double) (short) -1);
        double double11 = arrayRealVector7.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix17.getRowVector(52);
        double double20 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.subtract(blockRealMatrix17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix10.transpose();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (short) 100, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 136 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.00000000000003d + "'", double1 == 200.00000000000003d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        java.lang.Double double5 = pointValuePair4.getValue();
        boolean boolean7 = pointValuePair4.equals((java.lang.Object) ' ');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        boolean boolean10 = pointValuePair4.equals((java.lang.Object) doubleArray9);
        double[] doubleArray11 = pointValuePair4.getPoint();
        double[] doubleArray12 = pointValuePair4.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray16 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1L));
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double31 = array2DRowRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship32 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean33 = array2DRowRealMatrix30.equals((java.lang.Object) relationship32);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint35 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector22, relationship32, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship36 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str37 = relationship36.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint39 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector22, relationship36, (double) 10);
        org.apache.commons.math3.linear.RealVector realVector40 = linearConstraint39.getCoefficients();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, realVector40);
        boolean boolean42 = pointValuePair4.equals((java.lang.Object) arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship32 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship32.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + relationship36 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship36.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + ">=" + "'", str37.equals(">="));
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4, 1104156224, 32, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,104,156,224)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector0.append((double) 100L);
        org.apache.commons.math3.optimization.linear.Relationship relationship16 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = relationship16.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = relationship17.oppositeRelationship();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship18, 1.0471975511965979d);
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = linearConstraint20.getRelationship();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + relationship16 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship16.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship21 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship21.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999995877692d + "'", double1 == 9.999999995877692d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(208.1240789511528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0312873873633555d + "'", double1 == 6.0312873873633555d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str15 = relationship14.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint17 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship14, (double) 10);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException22 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int23 = matrixDimensionMismatchException22.getExpectedColumnDimension();
        int int24 = matrixDimensionMismatchException22.getExpectedColumnDimension();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException> relationshipPair25 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException>(relationship14, (java.lang.IllegalArgumentException) matrixDimensionMismatchException22);
        java.lang.Integer[] intArray26 = matrixDimensionMismatchException22.getExpectedDimensions();
        int int27 = matrixDimensionMismatchException22.getExpectedRowDimension();
        int int28 = matrixDimensionMismatchException22.getExpectedRowDimension();
        int int29 = matrixDimensionMismatchException22.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ">=" + "'", str15.equals(">="));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        double double5 = openMapRealMatrix2.getEntry((int) (short) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.subtract(openMapRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        blockRealMatrix8.setEntry(35, 0, (double) (-1.0000001f));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = blockRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        double double16 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix14.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix14.power((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (100x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(1.07957453E9f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957453E9f + "'", float2 == 1.07957453E9f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray15);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.scalarAdd(0.0d);
        try {
            double double22 = array2DRowRealMatrix19.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction13 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray11, 1.5707963267948966d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray17 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, (double) (-1L));
        double[] doubleArray20 = pointValuePair19.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector21.append(arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapSubtractToSelf((-1.1071486939522313d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        double double26 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray32 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 0.6045724816965523d, false);
        double[] doubleArray38 = pointValuePair37.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray43 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray43, (double) (-1L));
        double[] doubleArray46 = pointValuePair45.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double49 = array2DRowRealMatrix48.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship50 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean51 = array2DRowRealMatrix48.equals((java.lang.Object) relationship50);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint53 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector40, relationship50, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship54 = relationship50.oppositeRelationship();
        double[] doubleArray57 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray57, (double) (-1L));
        double[] doubleArray60 = pointValuePair59.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60);
        org.apache.commons.math3.optimization.linear.Relationship relationship63 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship64 = relationship63.oppositeRelationship();
        double[] doubleArray70 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector71 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray70);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint73 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray60, (double) 1L, relationship63, doubleArray70, (double) 36);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint75 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray38, 180.0d, relationship50, doubleArray70, 2.718281828459045d);
        try {
            double[] doubleArray76 = array2DRowRealMatrix0.preMultiply(doubleArray70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 210.78424988599124d + "'", double26 == 210.78424988599124d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship50 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship50.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + relationship54 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship54.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + relationship63 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship63.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship64 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship64.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector71);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 11.03017970588336d, (java.lang.Number) (-2.154434690031884d), (java.lang.Number) 200.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(2.0d, 0.0d, (double) 52L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix8.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double17 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix16.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix8.add(blockRealMatrix16);
        double double21 = blockRealMatrix8.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix2.add(blockRealMatrix8);
        int[] intArray27 = new int[] { (short) 1, (-1023), 52, 36 };
        int[] intArray33 = new int[] { (byte) 1, 32, 5, 1, '#' };
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(36, 100);
        try {
            blockRealMatrix22.copySubMatrix(intArray27, intArray33, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 1322834079);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,322,834,079)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        try {
            openMapRealMatrix2.multiplyEntry(1104156224, (int) (short) 0, 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,104,156,224)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((-0.32660790974246073d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.005700383388062405d) + "'", double1 == (-0.005700383388062405d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        java.lang.String str2 = array2DRowRealMatrix0.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Array2DRowRealMatrix{}" + "'", str2.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 1072693248);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07269325E9f + "'", float1 == 1.07269325E9f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray16 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, false);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 5.999999682108553d, (java.lang.Object[]) doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(34.999996f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double9 = array2DRowRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship10 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean11 = array2DRowRealMatrix8.equals((java.lang.Object) relationship10);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint13 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship10, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str15 = relationship14.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint17 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector0, relationship14, (double) 10);
        double double18 = arrayRealVector0.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship10 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship10.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ">=" + "'", str15.equals(">="));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.optimization.linear.Relationship relationship30 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship31 = relationship30.oppositeRelationship();
        double[] doubleArray37 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint40 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray27, (double) 1L, relationship30, doubleArray37, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, 2.154434690031884d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + relationship30 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship30.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship31 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship31.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray17 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException(localizable2, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray22);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 10L, (java.lang.Object[]) doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double2 = org.apache.commons.math3.util.Precision.round((-57.0d), 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-57.0d) + "'", double2 == (-57.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{}", 6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapSubtractToSelf(1.0E-323d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (-57.29577951308232d), true);
        java.lang.Double double9 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-57.29577951308232d) + "'", double9.equals((-57.29577951308232d)));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        double[] doubleArray4 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1L));
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double10 = arrayRealVector9.getNorm();
        arrayRealVector9.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        java.lang.String str14 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.String str15 = realVectorFormat0.getSuffix();
        java.lang.String str16 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 1}" + "'", str14.equals("{0; 1}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "}" + "'", str15.equals("}"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "}" + "'", str16.equals("}"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 0.7615941559557649d, 0.6045724816965523d, (-57.0d), (-0.0d) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.RealVector.unmodifiableRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        boolean boolean7 = arrayRealVector5.isNaN();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector7.append(arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray25 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (-1L));
        double[] doubleArray28 = pointValuePair27.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector22.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean35 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, arrayRealVector34);
        try {
            double double37 = arrayRealVector7.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray6 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray6, (double) (-1L));
        double[] doubleArray9 = pointValuePair8.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double12 = array2DRowRealMatrix11.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship13 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean14 = array2DRowRealMatrix11.equals((java.lang.Object) relationship13);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint16 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector3, relationship13, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str18 = relationship17.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint20 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector3, relationship17, (double) 10);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException25 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) 10, (int) (byte) 100, (int) (short) 10);
        int int26 = matrixDimensionMismatchException25.getExpectedColumnDimension();
        int int27 = matrixDimensionMismatchException25.getExpectedColumnDimension();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException> relationshipPair28 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.optimization.linear.Relationship, java.lang.IllegalArgumentException>(relationship17, (java.lang.IllegalArgumentException) matrixDimensionMismatchException25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray32 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, (double) (-1L));
        double[] doubleArray35 = pointValuePair34.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.mapMultiply((double) '#');
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction40 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector29, 32.0d);
        double[] doubleArray41 = arrayRealVector29.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = realVector42.mapMultiply((double) 6.0f);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint46 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector1, (double) '4', relationship17, realVector42, 104.0620394755764d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship13 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship13.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + ">=" + "'", str18.equals(">="));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double[] doubleArray2 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1L));
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship8 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = relationship8.oppositeRelationship();
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint18 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 1L, relationship8, doubleArray15, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) 0L, false);
        double[] doubleArray23 = pointValuePair22.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray28 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1L));
        double[] doubleArray31 = pointValuePair30.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector25.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector25.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean38 = arrayRealVector37.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector37);
        try {
            org.apache.commons.math3.linear.RealVector realVector40 = array2DRowRealMatrix24.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + relationship8 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship8.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector8.copy();
        java.lang.String str17 = arrayRealVector8.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector7, arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray32 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, (double) (-1L));
        double[] doubleArray35 = pointValuePair34.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.mapMultiply((double) '#');
        double double39 = arrayRealVector29.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector21.append((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray46 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, (double) (-1L));
        double[] doubleArray49 = pointValuePair48.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector43.mapMultiply((double) '#');
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector43.mapDivide(0.6045724816965523d);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector8.combineToSelf(1.0d, (double) (-1023), (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        int int57 = arrayRealVector21.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 0.6045724816965523d, false);
        double[] doubleArray11 = pointValuePair10.getPoint();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        double[] doubleArray18 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray18);
        org.apache.commons.math3.optimization.linear.Relationship relationship22 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray28 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray28);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint32 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray18, (double) 5, relationship22, doubleArray28, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray28);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapAddToSelf((double) (-0.99999994f));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + relationship22 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship22.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        double double5 = openMapRealMatrix2.getEntry((int) (short) 0, (int) (byte) 1);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 10, 32);
        double double11 = openMapRealMatrix8.getEntry((int) (short) 0, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = openMapRealMatrix2.multiply(openMapRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 32 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getData();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        int[] intArray6 = new int[] { (-1), (byte) 100, 2 };
        int[] intArray13 = new int[] { 0, (short) 100, 52, 52, (byte) 1, (short) 100 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, intArray6, intArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.5707963267948712d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (-127), 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-127L) + "'", long2 == (-127L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 10L, 208.1240789511528d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04801133651244052d + "'", double2 == 0.04801133651244052d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double[] doubleArray6 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray13 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix21.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix21.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double30 = blockRealMatrix29.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector32 = blockRealMatrix29.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix21.add(blockRealMatrix29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix29.transpose();
        try {
            array2DRowRealMatrix17.setRowMatrix((int) (short) 10, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector8.append((double) 6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction23 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(realVector21, 1.5707963267948966d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int int4 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 100, (int) '#', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship2 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean3 = array2DRowRealMatrix0.equals((java.lang.Object) relationship2);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray11 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray18 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math3.exception.NullArgumentException(localizable4, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        array2DRowRealMatrix0.setSubMatrix(doubleArray19, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 2);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        double[] doubleArray35 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray42 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray43 = new double[][] { doubleArray35, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException45 = new org.apache.commons.math3.exception.NullArgumentException(localizable28, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix46);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix46.getSubMatrix(1322834079, (int) (byte) 1, (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,322,834,079)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship2 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship2.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 97L, (-0.005700383388062405d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-97.0d) + "'", double2 == (-97.0d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        double[] doubleArray10 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1L));
        double[] doubleArray13 = pointValuePair12.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        org.apache.commons.math3.optimization.linear.Relationship relationship16 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship17 = relationship16.oppositeRelationship();
        double[] doubleArray23 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector24 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray23);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint26 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray13, (double) 1L, relationship16, doubleArray23, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction33 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray13, (-57.29577951308232d));
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        double[] doubleArray37 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1L));
        double[] doubleArray40 = pointValuePair39.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.optimization.linear.Relationship relationship43 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        org.apache.commons.math3.optimization.linear.Relationship relationship44 = relationship43.oppositeRelationship();
        double[] doubleArray50 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector51 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray50);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint53 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray40, (double) 1L, relationship43, doubleArray50, (double) 36);
        org.apache.commons.math3.linear.RealVector realVector54 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair57 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, (double) 0L, false);
        double[] doubleArray58 = pointValuePair57.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, doubleArray58);
        try {
            blockRealMatrix2.setRow(1079574528, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + relationship16 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship16.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship17 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship17.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + relationship43 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship43.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + relationship44 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship44.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double2 = array2DRowRealMatrix1.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship3 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean4 = array2DRowRealMatrix1.equals((java.lang.Object) relationship3);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray19 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math3.exception.NullArgumentException(localizable5, (java.lang.Object[]) doubleArray20);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        array2DRowRealMatrix1.setSubMatrix(doubleArray20, (int) (short) 0, (int) (byte) 0);
        double[][] doubleArray27 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship3 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship3.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.scalarMultiply((double) (-0.99999994f));
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix10.getRowVector(2);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.add(blockRealMatrix10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix17.getRowVector(52);
        double double20 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.subtract(blockRealMatrix17);
        int[] intArray23 = new int[] { (short) 1 };
        int[] intArray26 = new int[] { ' ', 35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double30 = blockRealMatrix29.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix29.transpose();
        boolean boolean32 = blockRealMatrix31.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.copy();
        double[][] doubleArray34 = blockRealMatrix33.getData();
        try {
            blockRealMatrix10.copySubMatrix(intArray23, intArray26, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.transpose();
        boolean boolean11 = blockRealMatrix10.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.copy();
        try {
            blockRealMatrix2.setRowMatrix((int) (short) 0, blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x100 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray11 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (-1L));
        double[] doubleArray14 = pointValuePair13.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector8.mapMultiply((double) '#');
        double double18 = arrayRealVector8.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector20 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector0.append(realVector20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 0.7615941559557649d, 0.6045724816965523d, (-57.0d), (-0.0d) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix2.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double[] doubleArray5 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray5);
        org.apache.commons.math3.optimization.linear.Relationship relationship9 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        double[] doubleArray15 = new double[] { (-1L), 0, 10, (-1), 0.0d };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint19 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray5, (double) 5, relationship9, doubleArray15, 1.7453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray23 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1L));
        double[] doubleArray26 = pointValuePair25.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship30 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean31 = array2DRowRealMatrix28.equals((java.lang.Object) relationship30);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint33 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector20, relationship30, 2.154434690031884d);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint35 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray15, relationship30, (double) (short) 1);
        org.apache.commons.math3.linear.RealVector realVector36 = linearConstraint35.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + relationship9 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship9.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship30 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship30.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) -1 };
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, objArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException(number6, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException13 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-0.0d), (double) 1.07793728E9f, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(5.0000005f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 6, (java.lang.Number) (-0.9999999999999999d), false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.6931471805599453d, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(5, (int) (short) 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray14 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray7, doubleArray14 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray15);
        org.apache.commons.math3.exception.ZeroException zeroException17 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[][] doubleArray20 = array2DRowRealMatrix19.getData();
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean1 = arrayRealVector0.isInfinite();
        boolean boolean3 = arrayRealVector0.equals((java.lang.Object) 11.03017970588336d);
        try {
            org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, 1);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix8.getRowVector(52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.add(blockRealMatrix8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double13 = array2DRowRealMatrix12.getFrobeniusNorm();
        org.apache.commons.math3.optimization.linear.Relationship relationship14 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        boolean boolean15 = array2DRowRealMatrix12.equals((java.lang.Object) relationship14);
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        double[] doubleArray23 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray30 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray31 = new double[][] { doubleArray23, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException33 = new org.apache.commons.math3.exception.NullArgumentException(localizable16, (java.lang.Object[]) doubleArray31);
        double[][] doubleArray34 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        array2DRowRealMatrix12.setSubMatrix(doubleArray31, (int) (short) 0, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix12, 2);
        org.apache.commons.math3.exception.util.Localizable localizable40 = null;
        double[] doubleArray47 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[] doubleArray54 = new double[] { 'a', (byte) 10, (-1.0d), (byte) -1, 100, '4' };
        double[][] doubleArray55 = new double[][] { doubleArray47, doubleArray54 };
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray55);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException57 = new org.apache.commons.math3.exception.NullArgumentException(localizable40, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix58);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix60 = blockRealMatrix8.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + relationship14 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship14.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray3 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1L));
        double[] doubleArray6 = pointValuePair5.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.mapMultiply((double) '#');
        double double10 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray14 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (-1L));
        double[] doubleArray17 = pointValuePair16.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector11.copy();
        java.lang.String str20 = arrayRealVector11.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray24 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1L));
        double[] doubleArray27 = pointValuePair26.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector11.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction32 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector11, (double) (-1.0f));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray36 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) (-1L));
        double[] doubleArray39 = pointValuePair38.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray44 = new double[] { (short) 0, ' ' };
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray44, (double) (-1L));
        double[] doubleArray47 = pointValuePair46.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, doubleArray47);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector41.mapMultiply((double) '#');
        double double51 = arrayRealVector41.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector33.append((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector41.append((double) 6);
        java.lang.Class<?> wildcardClass55 = arrayRealVector41.getClass();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector11.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        double double58 = arrayRealVector0.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }
}

