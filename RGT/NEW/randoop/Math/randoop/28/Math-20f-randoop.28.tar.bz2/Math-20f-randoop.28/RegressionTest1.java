import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        double double12 = blockRealMatrix4.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix4.getColumnMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) (-1), (double) 0.0f);
        double double3 = simpleValueChecker2.getAbsoluteThreshold();
        double double4 = simpleValueChecker2.getRelativeThreshold();
        double double5 = simpleValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        try {
            double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[][] doubleArray16 = array2DRowRealMatrix5.getData();
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        double[] doubleArray29 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        double[] doubleArray33 = new double[] { '#' };
        double[] doubleArray36 = new double[] { 100, (byte) 10 };
        double double37 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray33, doubleArray36);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray33, (double) (-1), true);
        double[] doubleArray41 = pointValuePair40.getKey();
        double[] doubleArray42 = pointValuePair40.getFirst();
        double[] doubleArray43 = pointValuePair40.getKey();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        int int51 = org.apache.commons.math3.util.MathUtils.hash(doubleArray49);
        boolean boolean52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray43, doubleArray49);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair54 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray49, 2.2250738585072014E-308d);
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equals(doubleArray29, doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray61 = array2DRowRealMatrix59.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, doubleArray61);
        try {
            double[] doubleArray63 = array2DRowRealMatrix5.operate(doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 65.0d + "'", double37 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1766139745) + "'", int51 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[][] doubleArray16 = array2DRowRealMatrix5.getData();
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        java.lang.String str56 = arrayRealVector55.toString();
        double double57 = arrayRealVector55.getMinValue();
        java.lang.Double[] doubleArray58 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        double double60 = arrayRealVector59.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector59.mapDivideToSelf((double) (short) 10);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector55.add((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 7 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}" + "'", str56.equals("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.007035801295960806d + "'", double57 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector62);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574941524760881d + "'", double1 == 4.574941524760881d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        int int5 = cMAESOptimizer1.getMaxEvaluations();
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) cMAESOptimizer1, "hi!", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        double double17 = realVector14.getMinValue();
        double double18 = realVector14.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector20 = realVector14.mapAdd(5.298292365610485d);
        java.io.ObjectInputStream objectInputStream22 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 5.298292365610485d, "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", objectInputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.007035801295960806d + "'", double17 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.007035801295960806d + "'", double18 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1), doubleArray2);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction12 = null;
        org.apache.commons.math3.optimization.GoalType goalType13 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray15 = new double[] { '#' };
        double[] doubleArray18 = new double[] { 100, (byte) 10 };
        double double19 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray15, doubleArray18);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1), true);
        double[] doubleArray23 = pointValuePair22.getKey();
        double[] doubleArray24 = pointValuePair22.getFirst();
        double[] doubleArray25 = pointValuePair22.getKey();
        double[] doubleArray31 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        int int33 = org.apache.commons.math3.util.MathUtils.hash(doubleArray31);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray25, doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        double[] doubleArray37 = new double[] { '#' };
        double[] doubleArray40 = new double[] { 100, (byte) 10 };
        double double41 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray37, doubleArray40);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair44 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1), true);
        double[] doubleArray45 = pointValuePair44.getKey();
        double[] doubleArray46 = pointValuePair44.getFirst();
        double[] doubleArray47 = pointValuePair44.getKey();
        double[] doubleArray53 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector54 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray53);
        int int55 = org.apache.commons.math3.util.MathUtils.hash(doubleArray53);
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray53);
        double[] doubleArray57 = null;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair58 = cMAESOptimizer10.optimize((-1207516062), multivariateFunction12, goalType13, doubleArray31, doubleArray47, doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + goalType13 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType13.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 65.0d + "'", double19 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1766139745) + "'", int33 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 65.0d + "'", double41 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1766139745) + "'", int55 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double7 = arrayRealVector1.walkInDefaultOrder(realVectorPreservingVisitor4, (int) '#', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        double[] doubleArray7 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray14 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray21 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray22 = new double[][] { doubleArray7, doubleArray14, doubleArray21 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22, true);
        java.lang.StringBuffer stringBuffer26 = null;
        java.text.FieldPosition fieldPosition27 = null;
        try {
            java.lang.StringBuffer stringBuffer28 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix25, stringBuffer26, fieldPosition27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String[] strArray0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException4.getDirection();
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray0, orderDirection5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor56 = null;
        try {
            double double59 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor56, 36, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        double double8 = array2DRowRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.04350032773179846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0444603366148346d + "'", double1 == 1.0444603366148346d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        double[] doubleArray12 = new double[] { '#' };
        double[] doubleArray15 = new double[] { 100, (byte) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0f, (byte) 100, doubleArray9, double16, realVector23, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 10.0d, localizable2, objArray25);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException27 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = nullArgumentException27.getContext();
        java.lang.Throwable[] throwableArray29 = nullArgumentException27.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 65.0d + "'", double16 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(exceptionContext28);
        org.junit.Assert.assertNotNull(throwableArray29);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray8);
        java.lang.Integer[] intArray10 = multiDimensionMismatchException9.getExpectedDimensions();
        java.lang.Integer[] intArray11 = multiDimensionMismatchException9.getExpectedDimensions();
        try {
            int int13 = multiDimensionMismatchException9.getWrongDimension((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NoDataException: no data", ",", "org.apache.commons.math3.exception.NoDataException: no data", numberFormat4);
        java.lang.String str6 = realVectorFormat5.getPrefix();
        java.text.ParsePosition parsePosition8 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = realVectorFormat5.parse("", parsePosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat3);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NoDataException: no data" + "'", str6.equals("org.apache.commons.math3.exception.NoDataException: no data"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector18);
        int int22 = arrayRealVector21.getDimension();
        boolean boolean23 = arrayRealVector21.isInfinite();
        double double24 = arrayRealVector21.getMaxValue();
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), true);
        arrayRealVector21.setSubVector((int) (short) 0, doubleArray27);
        double[] doubleArray41 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        realVector42.unitize();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        realVector50.unitize();
        double double52 = realVector42.cosine(realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(realVector50);
        int int54 = arrayRealVector53.getDimension();
        boolean boolean55 = arrayRealVector53.isInfinite();
        double double56 = arrayRealVector53.getMaxValue();
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        double[] doubleArray66 = new double[] { '#' };
        double[] doubleArray69 = new double[] { 100, (byte) 10 };
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray66, doubleArray69);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, (double) (-1), true);
        double[] doubleArray74 = pointValuePair73.getKey();
        double[] doubleArray75 = pointValuePair73.getFirst();
        double[] doubleArray76 = pointValuePair73.getKey();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        int int84 = org.apache.commons.math3.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray76, doubleArray82);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair87 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray82, 2.2250738585072014E-308d);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray82);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.lang.String str91 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor92 = null;
        try {
            double double95 = arrayRealVector21.walkInDefaultOrder(realVectorChangingVisitor92, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0000000000000002d + "'", double52 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7035801295960805d + "'", double56 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 65.0d + "'", double70 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1766139745) + "'", int84 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str91.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray5 = new double[] { '#' };
        double[] doubleArray8 = new double[] { 100, (byte) 10 };
        double double9 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), true);
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        realVector22.unitize();
        double[] doubleArray29 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        realVector30.unitize();
        double double32 = realVector22.cosine(realVector30);
        java.lang.Object[] objArray34 = new java.lang.Object[] { pointValuePair12, (byte) 1, (short) 1, true, realVector30, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException35 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable3, objArray34);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray34);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException37 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable1, objArray34);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException38 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray34);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext39 = mathArithmeticException38.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext40 = mathArithmeticException38.getContext();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 65.0d + "'", double9 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0000000000000002d + "'", double32 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertNotNull(exceptionContext40);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long1 = org.apache.commons.math3.util.FastMath.round(2.492385186467945d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        java.lang.Double[] doubleArray13 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13);
        double double15 = arrayRealVector14.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector14.mapSubtractToSelf(1.223994989065759d);
        try {
            blockRealMatrix4.setRowVector((-1869155408), (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector17.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor87 = null;
        try {
            double double90 = arrayRealVector49.walkInDefaultOrder(realVectorPreservingVisitor87, 4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 4 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) 100, (-1869155408));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1869155408) + "'", int2 == (-1869155408));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "{", "");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray9);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray13);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray13, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray31);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray35);
        java.lang.Integer[] intArray42 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable22, intArray35, intArray42);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray13, intArray42);
        try {
            int int46 = multiDimensionMismatchException44.getExpectedDimension((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        boolean boolean12 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray13 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray18 = array2DRowRealMatrix16.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        boolean boolean20 = array2DRowRealMatrix19.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor22 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double23 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22);
        try {
            double double28 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor22, (int) (short) 100, (int) (byte) 100, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 2L, 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, (-1207516062), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7771211630872612d + "'", double1 == 0.7771211630872612d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        int int5 = cMAESOptimizer1.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker6 = cMAESOptimizer1.getConvergenceChecker();
        int int7 = cMAESOptimizer1.getMaxEvaluations();
        int int8 = cMAESOptimizer1.getEvaluations();
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor6, (int) (byte) 10, 0, 35, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 10 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.scalarMultiply((double) (short) -1);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix24.scalarMultiply((-2.464205265045166d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), (double) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        java.io.ObjectInputStream objectInputStream20 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) realMatrix18, "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", objectInputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double double29 = realVector19.cosine(realVector27);
        java.lang.Object[] objArray31 = new java.lang.Object[] { pointValuePair9, (byte) 1, (short) 1, true, realVector27, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException32 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray31);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext33 = mathUnsupportedOperationException32.getContext();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0000000000000002d + "'", double29 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(exceptionContext33);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.003267627914076726d, (java.lang.Number) 1.0444603366148346d, false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.2250738585072014E-308d, (double) 1500420478);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "{", "");
        java.lang.String str4 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str4.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        float float2 = org.apache.commons.math3.util.FastMath.min(1.1920929E-7f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920929E-7f + "'", float2 == 1.1920929E-7f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 0, 10.000001f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(52);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(4, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat0.parse("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.mapDivide((double) 10);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector55.mapDivideToSelf(0.7771211630872612d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor6.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        try {
            double double18 = blockRealMatrix4.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6, (int) (byte) 1, 10, 32, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial column 32 after final column 10");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray21 = arrayRealVector17.toArray();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor22 = null;
        try {
            double double25 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor22, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector17.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivideToSelf(5.298292365610485d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray9);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray13);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray13, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray31);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray35);
        java.lang.Integer[] intArray42 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable22, intArray35, intArray42);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray13, intArray42);
        try {
            int int46 = multiDimensionMismatchException44.getWrongDimension(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_MAXITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30000 + "'", int0 == 30000);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", ",", "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}");
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
//        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
//        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
//        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
//        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
//        double[][] doubleArray12 = array2DRowRealMatrix5.getData();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        int int16 = blockRealMatrix15.getColumnDimension();
//        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix15.scalarMultiply(0.0d);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
//        boolean boolean25 = array2DRowRealMatrix24.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
//        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
//        double double28 = array2DRowRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
//        double double29 = blockRealMatrix15.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean31 = mersenneTwister30.nextBoolean();
//        int[] intArray34 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math3.random.MersenneTwister(intArray34);
//        int[] intArray36 = org.apache.commons.math3.util.MathArrays.copyOf(intArray34);
//        mersenneTwister30.setSeed(intArray36);
//        int[] intArray40 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister41 = new org.apache.commons.math3.random.MersenneTwister(intArray40);
//        int[] intArray42 = org.apache.commons.math3.util.MathArrays.copyOf(intArray40);
//        org.apache.commons.math3.linear.RealMatrix realMatrix43 = blockRealMatrix15.getSubMatrix(intArray36, intArray40);
//        int[] intArray44 = null;
//        try {
//            org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix5.getSubMatrix(intArray40, intArray44);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
//        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(realMatrix7);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertNotNull(realVector11);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertNotNull(realMatrix18);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(realMatrix26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertNotNull(realMatrix43);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NoDataException: no data", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "org.apache.commons.math3.exception.NoDataException: no data", numberFormat3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 1766139745L, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 11013.232920103323d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1), 0.2350943972754704d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = array2DRowRealMatrix8.multiply(array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        float float2 = org.apache.commons.math3.util.FastMath.max(0.0f, (float) 1766139745L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.76613978E9f + "'", float2 == 1.76613978E9f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = blockRealMatrix4.walkInColumnOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (-1), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray11);
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray11, intArray15);
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray15, intArray22);
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        java.lang.Integer[] intArray27 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray33 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException34 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray27, intArray33);
        java.lang.Integer[] intArray37 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException38 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray33, intArray37);
        java.lang.Integer[] intArray44 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException45 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable24, intArray37, intArray44);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException46 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray15, intArray44);
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException47 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray1, intArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.0000001f, (float) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.createMatrix((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1766139745), 0, 5, 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        try {
            int int7 = matrixDimensionMismatchException4.getExpectedDimension((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = array2DRowRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double16 = defaultRealMatrixPreservingVisitor14.end();
        double double17 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double18 = defaultRealMatrixPreservingVisitor14.end();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 34.92964198704039d);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1));
        try {
            incrementor1.incrementCount(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix2.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.8342233605065102d, (java.lang.Number) 16414.03175005872d, number3);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        double[] doubleArray14 = new double[] { '#' };
        double[] doubleArray17 = new double[] { 100, (byte) 10 };
        double double18 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray17);
        double[] doubleArray20 = new double[] { '#' };
        double[] doubleArray23 = new double[] { 100, (byte) 10 };
        double double24 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray20, doubleArray23);
        double[] doubleArray30 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1.0f, (byte) 100, doubleArray17, double24, realVector31, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 10.0d, localizable10, objArray33);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException35 = new org.apache.commons.math3.exception.NullArgumentException(localizable8, objArray33);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable6, (java.lang.Number) 2.2250738585072014E-308d, objArray33);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) objArray33);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException4, localizable5, objArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 65.0d + "'", double18 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 65.0d + "'", double24 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        org.apache.commons.math3.optimization.GoalType goalType3 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer19 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10, doubleArray9, (-52), (double) (byte) 1, true, 35, 1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister17, false);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = cMAESOptimizer0.optimize(10, multivariateFunction2, goalType3, doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType3.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(5);
        int int2 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 52.0f, false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.apache.commons.math3.util.FastMath.max(0, (-1766139745));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.util.MathUtils.checkFinite(0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 100, 3.8146973E-6f, (-1207516062));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor20 = null;
        try {
            double double23 = arrayRealVector19.walkInOptimizedOrder(realVectorPreservingVisitor20, 52, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "{", "");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer19 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (byte) 10);
        boolean boolean20 = arrayRealVector17.equals((java.lang.Object) (byte) 10);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor21, 52, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) '4', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector17.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        boolean boolean35 = arrayRealVector34.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1500420478);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1500420480 + "'", int1 == 1500420480);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.223994989065759d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        blockRealMatrix4.multiplyEntry(0, (int) (byte) 10, (double) '#');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray15 = array2DRowRealMatrix13.getColumn((int) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 35x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NoDataException: no data", ",", "org.apache.commons.math3.exception.NoDataException: no data", numberFormat4);
        java.lang.String str6 = realVectorFormat5.getPrefix();
        java.lang.String str7 = realVectorFormat5.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat3);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NoDataException: no data" + "'", str6.equals("org.apache.commons.math3.exception.NoDataException: no data"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "," + "'", str7.equals(","));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NoDataException: no data", ",", "org.apache.commons.math3.exception.NoDataException: no data", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", ",", numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        java.lang.String str11 = realMatrixFormat10.getColumnSeparator();
        org.junit.Assert.assertNotNull(realVectorFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "," + "'", str11.equals(","));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray17);
        try {
            double[] doubleArray20 = array2DRowRealMatrix2.preMultiply(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor4, 1500420478, (int) 'a', 30000, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray8);
        java.lang.Integer[] intArray10 = multiDimensionMismatchException9.getExpectedDimensions();
        try {
            int int12 = multiDimensionMismatchException9.getWrongDimension(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        try {
            double[] doubleArray13 = blockRealMatrix4.getRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1766139745), 0, 5, 100);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) matrixDimensionMismatchException4, "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair41 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 5.298292365610485d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray4 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray9 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray14 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int36 = array2DRowRealMatrix35.getRowDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = array2DRowRealMatrix32.multiply(array2DRowRealMatrix35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 24 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector20.map(univariateFunction21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, 5);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double double7 = array2DRowRealMatrix5.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        realVector12.unitize();
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double double22 = realVector12.cosine(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(realVector20);
        int int24 = arrayRealVector23.getDimension();
        boolean boolean25 = arrayRealVector23.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector23.copy();
        double[] doubleArray27 = arrayRealVector23.toArray();
        try {
            blockRealMatrix2.setRow(35, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0000000000000002d + "'", double22 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray9);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray13);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray13, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray31);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray35);
        java.lang.Integer[] intArray42 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable22, intArray35, intArray42);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray13, intArray42);
        java.lang.Integer[] intArray45 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException46 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray42, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        double[] doubleArray11 = pointValuePair8.getKey();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        int int19 = org.apache.commons.math3.util.MathUtils.hash(doubleArray17);
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray11, doubleArray17);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, 2.2250738585072014E-308d);
        double[] doubleArray23 = null;
        try {
            double double24 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray17, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1766139745) + "'", int19 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(1.76613978E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1766139745), (int) (byte) 0, 32, (-1207516062));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        double double6 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor7, (int) (byte) 0, 30000, (int) (byte) 1, 1500420480);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        mersenneTwister0.setSeed(0L);
        mersenneTwister0.clear();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        boolean boolean10 = array2DRowRealMatrix9.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = array2DRowRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix2.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x52) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, true);
        double[] doubleArray11 = new double[] { '#' };
        double[] doubleArray14 = new double[] { 100, (byte) 10 };
        double double15 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray11, doubleArray14);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray14, orderDirection16, false, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection16, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not decreasing (10 < 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1766139745) + "'", int7 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 65.0d + "'", double15 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(1500420478, (int) (short) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair2 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray0, (java.lang.Double) 5.298292365610485d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        try {
            double double5 = openMapRealMatrix2.getEntry(0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        blockRealMatrix4.multiplyEntry(0, (int) (byte) 10, (double) '#');
        double[] doubleArray17 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray24 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray31 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray32 = new double[][] { doubleArray17, doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix35.scalarMultiply((double) (short) -1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix38 = blockRealMatrix4.subtract(realMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 3x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-1655.020990364699d), (double) 0.0f, (double) 10, 32.0d, 0.7771211630872612d, (double) 1.1920929E-7f, 0.0d, 0.2350943972754704d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 320.00000009264005d + "'", double8 == 320.00000009264005d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        double[] doubleArray30 = new double[] { '#' };
        double[] doubleArray33 = new double[] { 100, (byte) 10 };
        double double34 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray30, doubleArray33);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1), true);
        double[] doubleArray38 = pointValuePair37.getKey();
        double[] doubleArray39 = pointValuePair37.getFirst();
        double[] doubleArray40 = pointValuePair37.getKey();
        double[] doubleArray46 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector47 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray46);
        int int48 = org.apache.commons.math3.util.MathUtils.hash(doubleArray46);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray46);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, 2.2250738585072014E-308d);
        boolean boolean52 = org.apache.commons.math3.util.MathArrays.equals(doubleArray26, doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray46);
        arrayRealVector17.set((double) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 65.0d + "'", double34 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1766139745) + "'", int48 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        double[] doubleArray38 = new double[] { '#' };
        double[] doubleArray41 = new double[] { 100, (byte) 10 };
        double double42 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray38, doubleArray41);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, (double) (-1), true);
        double[] doubleArray46 = pointValuePair45.getKey();
        double[] doubleArray47 = pointValuePair45.getFirst();
        double[] doubleArray48 = pointValuePair45.getKey();
        double[] doubleArray54 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector55 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray54);
        int int56 = org.apache.commons.math3.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray48, doubleArray54);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray54, 2.2250738585072014E-308d);
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, doubleArray34);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray66 = array2DRowRealMatrix64.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, doubleArray66);
        try {
            blockRealMatrix9.setRowVector(100, (org.apache.commons.math3.linear.RealVector) arrayRealVector67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 65.0d + "'", double42 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1766139745) + "'", int56 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (-0.1078758181147519d), true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.0d, (-25.158314235157036d), (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.474942705471108d + "'", double3 == 23.474942705471108d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78);
        int int88 = arrayRealVector87.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector87, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 4 + "'", int88 == 4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        double[] doubleArray8 = new double[] { '#' };
        double[] doubleArray11 = new double[] { 100, (byte) 10 };
        double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray11);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1), true);
        double[] doubleArray16 = pointValuePair15.getKey();
        double[] doubleArray17 = pointValuePair15.getFirst();
        java.lang.Double double18 = pointValuePair15.getSecond();
        double[] doubleArray19 = pointValuePair15.getFirst();
        double[] doubleArray20 = pointValuePair15.getKey();
        double[] doubleArray21 = pointValuePair15.getKey();
        try {
            double[] doubleArray22 = blockRealMatrix4.operate(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 65.0d + "'", double12 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        float float2 = org.apache.commons.math3.util.FastMath.max(0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(5.0d, 572.9577951308232d, (double) (-1869155408), 0.9533921721708404d, 1.554912086407338d, 1.9558505399828548E181d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0411756438256593E181d + "'", double6 == 3.0411756438256593E181d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 100, (-1207516062));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.8414709848078965d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        blockRealMatrix2.multiplyEntry(0, 0, (double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix2.getColumnVector((int) '4');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.copy();
        double[][] doubleArray16 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealVector realVector18 = blockRealMatrix15.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix15.getColumnVector((int) (byte) 10);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 100, (byte) 1 };
//        mersenneTwister0.nextBytes(byteArray5);
//        float float7 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(byteArray5);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.17901957f + "'", float7 == 0.17901957f);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        try {
            array2DRowRealMatrix8.multiplyEntry((int) '#', (-1869155408), 16414.03175005872d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.copy();
        double[][] doubleArray10 = blockRealMatrix9.getData();
        double double11 = blockRealMatrix9.getNorm();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.554912086407338d, (double) 100, (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(realVector56);
        int int60 = arrayRealVector59.getDimension();
        boolean boolean61 = arrayRealVector59.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector59.copy();
        double[] doubleArray68 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector69 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray68);
        realVector69.unitize();
        double[] doubleArray76 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector77 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray76);
        realVector77.unitize();
        double double79 = realVector69.cosine(realVector77);
        double double80 = realVector77.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector82 = realVector77.mapAdd((double) (-1));
        double double83 = arrayRealVector62.dotProduct(realVector82);
        double double84 = arrayRealVector20.getL1Distance(realVector82);
        arrayRealVector20.set(57.29577951308232d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0000000000000002d + "'", double79 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.007035801295960806d + "'", double80 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + (-0.554912086407338d) + "'", double83 == (-0.554912086407338d));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 5.0d + "'", double84 == 5.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 10, (double) 32.0f, 1.0444603366148346d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int2 = org.apache.commons.math3.util.FastMath.min(32, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double24 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        double[] doubleArray11 = pointValuePair8.getKey();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        int int19 = org.apache.commons.math3.util.MathUtils.hash(doubleArray17);
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray11, doubleArray17);
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double[] doubleArray35 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        realVector36.unitize();
        double double38 = realVector28.cosine(realVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(realVector36);
        int int40 = arrayRealVector39.getDimension();
        boolean boolean41 = arrayRealVector39.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector39.copy();
        double[] doubleArray48 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector49 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray48);
        realVector49.unitize();
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double double59 = realVector49.cosine(realVector57);
        double double60 = realVector57.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector62 = realVector57.mapAdd((double) (-1));
        double double63 = arrayRealVector42.dotProduct(realVector62);
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double[] doubleArray77 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector78 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray77);
        realVector78.unitize();
        double double80 = realVector70.cosine(realVector78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(realVector78);
        int int82 = arrayRealVector81.getDimension();
        boolean boolean83 = arrayRealVector81.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = arrayRealVector81.copy();
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector84.mapMultiply(Double.NaN);
        double double87 = arrayRealVector42.cosine(realVector86);
        double double88 = realVector21.cosine(realVector86);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1766139745) + "'", int19 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0000000000000002d + "'", double38 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 5 + "'", int40 == 5);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0000000000000002d + "'", double59 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.007035801295960806d + "'", double60 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + (-0.554912086407338d) + "'", double63 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.0000000000000002d + "'", double80 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 5 + "'", int82 == 5);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(arrayRealVector84);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertEquals((double) double87, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double88, Double.NaN, 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor40 = null;
        try {
            double double41 = arrayRealVector39.walkInDefaultOrder(realVectorChangingVisitor40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        double double12 = blockRealMatrix4.getFrobeniusNorm();
        try {
            double[] doubleArray14 = blockRealMatrix4.getColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        try {
            double double9 = blockRealMatrix2.getEntry((int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray10);
        java.lang.Integer[] intArray12 = multiDimensionMismatchException11.getExpectedDimensions();
        java.lang.Integer[] intArray13 = multiDimensionMismatchException11.getExpectedDimensions();
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray16, intArray22);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray13, intArray16);
        java.lang.Integer[] intArray25 = multiDimensionMismatchException24.getExpectedDimensions();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray25);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.mapToSelf(univariateFunction2);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor4 = null;
        try {
            double double7 = arrayRealVector1.walkInDefaultOrder(realVectorChangingVisitor4, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat2);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 0L, (float) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray23 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray24 = new double[][] { doubleArray16, doubleArray23 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray24);
        try {
            blockRealMatrix2.copySubMatrix((int) 'a', (int) (short) 10, 0, (int) (byte) 10, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math3.util.FastMath.log(Double.POSITIVE_INFINITY, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", "{10; 100; 10; 100; 1}", "; ", "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", "{", numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        try {
            double double5 = openMapRealMatrix2.getEntry(10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-0.8287275724147631d), (double) (byte) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getColumnMatrix(0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = blockRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            double double52 = eigenDecomposition49.getImagEigenvalue((-1869155408));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1869155408");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        realVector11.unitize();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double double21 = realVector11.cosine(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(realVector19);
        int int23 = arrayRealVector22.getDimension();
        boolean boolean24 = arrayRealVector22.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector22.copy();
        double[] doubleArray31 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        realVector32.unitize();
        double[] doubleArray39 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        realVector40.unitize();
        double double42 = realVector32.cosine(realVector40);
        double double43 = realVector40.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector45 = realVector40.mapAdd((double) (-1));
        double double46 = arrayRealVector25.dotProduct(realVector45);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector1.append(realVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction49 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector48.map(univariateFunction49);
        double[] doubleArray52 = new double[] { '#' };
        double[] doubleArray55 = new double[] { 100, (byte) 10 };
        double double56 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray52, doubleArray55);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray52, (double) (-1), true);
        double[] doubleArray60 = pointValuePair59.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000000000000002d + "'", double21 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0000000000000002d + "'", double42 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.007035801295960806d + "'", double43 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-0.554912086407338d) + "'", double46 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 65.0d + "'", double56 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (int) (short) 10);
        double double14 = blockRealMatrix4.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math3.util.FastMath.log10(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector17.mapSubtract((double) (byte) -1);
        org.apache.commons.math3.linear.RealVector realVector23 = realVector22.unitVector();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 32.0f, 10);
        java.lang.Number number4 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.0f + "'", number4.equals(32.0f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.mapDivide((double) 10);
        java.lang.String str58 = arrayRealVector55.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}" + "'", str58.equals("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        double[] doubleArray7 = new double[] { '#' };
        double[] doubleArray10 = new double[] { 100, (byte) 10 };
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1), true);
        double[] doubleArray15 = pointValuePair14.getKey();
        double[] doubleArray16 = pointValuePair14.getFirst();
        double[] doubleArray17 = pointValuePair14.getKey();
        try {
            double[] doubleArray18 = blockRealMatrix4.preMultiply(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 65.0d + "'", double11 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        double[][] doubleArray25 = array2DRowRealMatrix24.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double2 = org.apache.commons.math3.util.FastMath.pow(4.641588833612779d, (-1766139745));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[][] doubleArray5 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor6.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double14 = array2DRowRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1766139745), 0, 5, 100);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.1752011936438014d, (java.lang.Number) 168.5422962509616d, 35, orderDirection3, false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        try {
            array2DRowRealMatrix24.setEntry(0, 1500420478, (double) 1.0000001f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) -1);
        org.apache.commons.math3.optimization.GoalType goalType2 = cMAESOptimizer1.getGoalType();
        org.junit.Assert.assertNull(goalType2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.9558505399828548E181d, (java.lang.Number) (short) 10, (int) (short) 1);
        boolean boolean4 = nonMonotonicSequenceException3.getStrict();
        boolean boolean5 = nonMonotonicSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 10, (-1869155408));
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1869155408) + "'", int3 == (-1869155408));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray8);
        try {
            int int11 = multiDimensionMismatchException9.getExpectedDimension((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn((int) (short) 1);
        double[][] doubleArray10 = array2DRowRealMatrix7.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor11.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double19 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        try {
            double double24 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11, 52, (-1869155408), (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapSubtractToSelf(0.04350032773179846d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((-1L), (long) (-52));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        boolean boolean10 = pointValuePair8.equals((java.lang.Object) ' ');
        java.lang.Double double11 = pointValuePair8.getValue();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray17);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray17, orderDirection20, false, false);
        boolean boolean24 = pointValuePair8.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getColumnMatrix(0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor8, (int) (short) -1, (-1), 32, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math3.util.FastMath.tan(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.380515006246586d) + "'", double1 == (-3.380515006246586d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        mersenneTwister1.setSeed((int) 'a');
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister();
        byte[] byteArray6 = new byte[] { (byte) -1 };
        mersenneTwister4.nextBytes(byteArray6);
        mersenneTwister4.clear();
        int[] intArray14 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14, (int) (short) 100);
        int[] intArray22 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray22, (int) (short) 100);
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray22);
        mersenneTwister4.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        byte[] byteArray28 = null;
        try {
            mersenneTwister1.nextBytes(byteArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(36);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[][] doubleArray16 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) ' ', (int) (short) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix5.subtract(realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x1 but expected 32x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-52), (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double3 = org.apache.commons.math3.util.Precision.round((double) '4', 5, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray11 = new double[] { '#' };
        double[] doubleArray14 = new double[] { 100, (byte) 10 };
        double double15 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray11, doubleArray14);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer24 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10, doubleArray14, (-52), (double) (byte) 1, true, 35, 1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister22, false);
        double double25 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray14);
        double[] doubleArray26 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition28 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray1, doubleArray26, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 65.0d + "'", double15 == 65.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 65.0d + "'", double25 == 65.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix4.createMatrix(0, 1500420480);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        double[] doubleArray19 = null;
        try {
            double[] doubleArray20 = array2DRowRealMatrix14.preMultiply(doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double2 = org.apache.commons.math3.util.Precision.round(5.298292365610485d, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298292365610485d + "'", double2 == 5.298292365610485d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer7 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(5, doubleArray2);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction9 = null;
        org.apache.commons.math3.optimization.GoalType goalType10 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray12 = new double[] { '#' };
        double[] doubleArray15 = new double[] { 100, (byte) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray15);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1), true);
        double[] doubleArray20 = pointValuePair19.getKey();
        java.lang.Double double21 = pointValuePair19.getSecond();
        double[] doubleArray22 = pointValuePair19.getKey();
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = cMAESOptimizer7.optimize((int) (short) -1, multivariateFunction9, goalType10, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + goalType10 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType10.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 65.0d + "'", double16 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        try {
            double double16 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10, 30000, 10, (int) ' ', 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int2 = org.apache.commons.math3.util.FastMath.max(1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.007035801295960806d, (java.lang.Number) 1.5574077246549023d, (int) '4');
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (byte) 10);
        double double7 = blockRealMatrix2.getNorm();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        double[] doubleArray20 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray20);
        double[] doubleArray24 = new double[] { '#' };
        double[] doubleArray27 = new double[] { 100, (byte) 10 };
        double double28 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray24, doubleArray27);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair31 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1), true);
        double[] doubleArray32 = pointValuePair31.getKey();
        double[] doubleArray33 = pointValuePair31.getFirst();
        double[] doubleArray34 = pointValuePair31.getKey();
        double[] doubleArray40 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        int int42 = org.apache.commons.math3.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray40);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, 2.2250738585072014E-308d);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, doubleArray20);
        double[] doubleArray53 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector54 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray53);
        int int55 = org.apache.commons.math3.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition57 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray53, (double) 1766139745L);
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = eigenDecomposition57.getV();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix2.subtract(realMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 65.0d + "'", double28 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1766139745) + "'", int42 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1766139745) + "'", int55 == (-1766139745));
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 2L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix10.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix5.preMultiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.76613978E9f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("org.apache.commons.math3.exception.NoDataException: no data", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "", "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}");
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        double double3 = blockRealMatrix2.getFrobeniusNorm();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
//        double double5 = blockRealMatrix4.getNorm();
//        double double6 = blockRealMatrix4.getFrobeniusNorm();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        int int10 = blockRealMatrix9.getColumnDimension();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        int int16 = blockRealMatrix15.getColumnDimension();
//        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix15.scalarMultiply(0.0d);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
//        boolean boolean25 = array2DRowRealMatrix24.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
//        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
//        double double28 = array2DRowRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
//        double double29 = blockRealMatrix15.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean31 = mersenneTwister30.nextBoolean();
//        int[] intArray34 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math3.random.MersenneTwister(intArray34);
//        int[] intArray36 = org.apache.commons.math3.util.MathArrays.copyOf(intArray34);
//        mersenneTwister30.setSeed(intArray36);
//        int[] intArray40 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister41 = new org.apache.commons.math3.random.MersenneTwister(intArray40);
//        int[] intArray42 = org.apache.commons.math3.util.MathArrays.copyOf(intArray40);
//        org.apache.commons.math3.linear.RealMatrix realMatrix43 = blockRealMatrix15.getSubMatrix(intArray36, intArray40);
//        try {
//            blockRealMatrix9.setColumnMatrix((int) (short) 1, realMatrix43);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x2 but expected 35x1");
//        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertNotNull(blockRealMatrix4);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertNotNull(blockRealMatrix11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertNotNull(realMatrix18);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(realMatrix26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertNotNull(realMatrix43);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.mapDivide((double) 10);
        double[] doubleArray63 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector64 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray63);
        realVector64.unitize();
        double[] doubleArray71 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector72 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray71);
        realVector72.unitize();
        double double74 = realVector64.cosine(realVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(realVector72);
        int int76 = arrayRealVector75.getDimension();
        boolean boolean77 = arrayRealVector75.isInfinite();
        double double78 = arrayRealVector75.getMaxValue();
        double[] doubleArray81 = new double[] { '#' };
        double[] doubleArray84 = new double[] { 100, (byte) 10 };
        double double85 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray81, doubleArray84);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair88 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray81, (double) (-1), true);
        arrayRealVector75.setSubVector((int) (short) 0, doubleArray81);
        boolean boolean90 = arrayRealVector75.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = arrayRealVector55.append(arrayRealVector75);
        arrayRealVector55.set((double) 4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0000000000000002d + "'", double74 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 5 + "'", int76 == 5);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.7035801295960805d + "'", double78 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 65.0d + "'", double85 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(arrayRealVector91);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) '4', 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor12, 52, 0, (int) (byte) 1, 1500420478);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) realMatrixFormat0);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix13.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray21 = array2DRowRealMatrix19.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray23 = array2DRowRealMatrix22.getData();
        array2DRowRealMatrix13.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix22.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray31 = array2DRowRealMatrix29.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix32.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray39 = array2DRowRealMatrix37.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[][] doubleArray41 = array2DRowRealMatrix40.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix32.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray47 = array2DRowRealMatrix45.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        boolean boolean49 = array2DRowRealMatrix48.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor51 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double52 = array2DRowRealMatrix48.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        double double53 = defaultRealMatrixPreservingVisitor51.end();
        double double54 = array2DRowRealMatrix32.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        double double55 = array2DRowRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        try {
            double double60 = array2DRowRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51, 0, 0, 10, 1500420480);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        boolean boolean10 = array2DRowRealMatrix9.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = array2DRowRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor15, (int) (short) -1, (int) (short) 0, 0, 1500420480);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        java.lang.String str3 = realMatrixFormat0.getPrefix();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double8 = blockRealMatrix6.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix6.copy();
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        try {
            java.lang.StringBuffer stringBuffer12 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix6, stringBuffer10, fieldPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[" + "'", str3.equals("["));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number1, (java.lang.Number) (short) 10, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException6 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathUnsupportedOperationException6.getContext();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((-3.380515006246586d), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getKey();
        double[] doubleArray11 = pointValuePair9.getFirst();
        double[] doubleArray12 = pointValuePair9.getKey();
        java.lang.Double double13 = pointValuePair9.getSecond();
        double[] doubleArray14 = pointValuePair9.getPoint();
        try {
            double double15 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray0, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair10 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray6, (java.lang.Double) 0.003267627914076726d);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { '#' };
        double[] doubleArray16 = new double[] { 100, (byte) 10 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray16);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1), true);
        double[] doubleArray21 = pointValuePair20.getKey();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray27 = array2DRowRealMatrix25.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection22, doubleArray29);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray21);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException38 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection39 = nonMonotonicSequenceException38.getDirection();
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray21, orderDirection39, true);
        try {
            boolean boolean44 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection39, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1766139745) + "'", int8 == (-1766139745));
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 65.0d + "'", double17 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        double[] doubleArray22 = blockRealMatrix20.getRow(10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) '#', 0.9323608146471463d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.0444603366148346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01822927178041715d + "'", double1 == 0.01822927178041715d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        double[] doubleArray11 = pointValuePair8.getKey();
        java.lang.Double double12 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        realVector11.unitize();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double double21 = realVector11.cosine(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(realVector19);
        int int23 = arrayRealVector22.getDimension();
        boolean boolean24 = arrayRealVector22.isInfinite();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector1.add((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000000000000002d + "'", double21 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix2.getRowVector(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("org.apache.commons.math3.exception.NoDataException: no data", "}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (long) 1500420480);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        realVector7.unitize();
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        realVector15.unitize();
        double double17 = realVector7.cosine(realVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15);
        int int19 = arrayRealVector18.getDimension();
        boolean boolean20 = arrayRealVector18.isInfinite();
        double double21 = arrayRealVector18.getMaxValue();
        double[] doubleArray24 = new double[] { '#' };
        double[] doubleArray27 = new double[] { 100, (byte) 10 };
        double double28 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray24, doubleArray27);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair31 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1), true);
        arrayRealVector18.setSubVector((int) (short) 0, doubleArray24);
        double[] doubleArray38 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        realVector39.unitize();
        double[] doubleArray46 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector47 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray46);
        realVector47.unitize();
        double double49 = realVector39.cosine(realVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(realVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector18.add(realVector47);
        org.apache.commons.math3.linear.RealVector realVector53 = realVector47.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector55 = realVector53.mapSubtract(Double.NEGATIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector0.ebeDivide(realVector53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0000000000000002d + "'", double17 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.7035801295960805d + "'", double21 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 65.0d + "'", double28 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0000000000000002d + "'", double49 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector55);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        try {
            array2DRowRealMatrix13.multiplyEntry((-1), 0, (double) 1766139745L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10.000000000000002d, (-2.464205265045166d), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, (-52));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.76613978E9f, (float) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        float float1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray7 = array2DRowRealMatrix5.getColumn((int) (short) 1);
        double double8 = array2DRowRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11);
        boolean boolean15 = array2DRowRealMatrix11.isTransposable();
        double[][] doubleArray16 = array2DRowRealMatrix11.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray21 = array2DRowRealMatrix19.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        boolean boolean23 = array2DRowRealMatrix22.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        double double27 = defaultRealMatrixPreservingVisitor25.end();
        double double28 = array2DRowRealMatrix11.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x10 but expected 35x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray5 = array2DRowRealMatrix3.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[][] doubleArray7 = array2DRowRealMatrix6.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.7771211630872612d, 32, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (-52L), 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '#', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray9);
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray9);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (byte) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        double[][] doubleArray18 = blockRealMatrix17.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.copy();
        double double24 = blockRealMatrix23.getNorm();
        double double25 = blockRealMatrix23.getFrobeniusNorm();
        blockRealMatrix23.multiplyEntry(0, (int) (byte) 10, (double) '#');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix17.subtract(blockRealMatrix23);
        try {
            blockRealMatrix9.setRowMatrix(30000, blockRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor0 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor0.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        defaultRealMatrixPreservingVisitor0.start((int) (short) 1, 1500420478, 1500420478, (int) (byte) 1, (int) (byte) 10, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getKey();
        double[] doubleArray11 = pointValuePair9.getFirst();
        java.lang.Double double12 = pointValuePair9.getSecond();
        double[] doubleArray13 = pointValuePair9.getPointRef();
        double[] doubleArray14 = pointValuePair9.getPoint();
        int[] intArray22 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math3.random.MersenneTwister(intArray22);
        mersenneTwister23.clear();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList28 = cMAESOptimizer27.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList29 = cMAESOptimizer27.getStatisticsDHistory();
        int int30 = cMAESOptimizer27.getEvaluations();
        int int31 = cMAESOptimizer27.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker32 = cMAESOptimizer27.getConvergenceChecker();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer33 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (byte) -1, doubleArray14, (int) ' ', 0.0d, true, (int) '4', (-52), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister23, true, pointValuePairConvergenceChecker32);
        org.apache.commons.math3.optimization.GoalType goalType34 = cMAESOptimizer33.getGoalType();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(doubleList28);
        org.junit.Assert.assertNotNull(realMatrixList29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker32);
        org.junit.Assert.assertNull(goalType34);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        try {
            blockRealMatrix2.addToEntry((int) ' ', (int) (short) -1, 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            double double52 = eigenDecomposition49.getRealEigenvalue(1500420480);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1500420480");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair12 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray10, (java.lang.Double) 1.5395564933646284d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double[] doubleArray0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException4.getDirection();
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        double[] doubleArray61 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        realVector62.unitize();
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double double72 = realVector62.cosine(realVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(realVector70);
        int int74 = arrayRealVector73.getDimension();
        boolean boolean75 = arrayRealVector73.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector73.copy();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapMultiply(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector55.append(arrayRealVector76);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor80 = null;
        try {
            double double81 = arrayRealVector79.walkInDefaultOrder(realVectorPreservingVisitor80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0000000000000002d + "'", double72 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(arrayRealVector79);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double double7 = array2DRowRealMatrix5.getNorm();
        try {
            array2DRowRealMatrix5.multiplyEntry((int) (byte) 100, (-1869155408), (double) 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        java.lang.Double double11 = pointValuePair8.getSecond();
        double[] doubleArray12 = pointValuePair8.getFirst();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.5707963267948966d), (java.lang.Number) (short) 10, false);
        boolean boolean17 = pointValuePair8.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray31 = array2DRowRealMatrix29.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray39 = array2DRowRealMatrix37.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        boolean boolean41 = array2DRowRealMatrix40.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor43 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double44 = array2DRowRealMatrix40.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double45 = defaultRealMatrixPreservingVisitor43.end();
        double double46 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double47 = array2DRowRealMatrix14.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double53 = array2DRowRealMatrix14.walkInRowOrder(realMatrixChangingVisitor48, (-52), (int) (short) 10, (int) '#', (-1766139745));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray19 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonSymmetricMatrixException3, localizable5, (java.lang.Object[]) doubleArray20);
        int int23 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double[] doubleArray7 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector8 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray7);
        realVector8.unitize();
        double[] doubleArray15 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        realVector16.unitize();
        double double18 = realVector8.cosine(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(realVector16);
        int int20 = arrayRealVector19.getDimension();
        boolean boolean21 = arrayRealVector19.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector19.copy();
        double double24 = arrayRealVector19.getEntry((int) (byte) 1);
        double[] doubleArray30 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector31 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray30);
        realVector31.unitize();
        double[] doubleArray38 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        realVector39.unitize();
        double double41 = realVector31.cosine(realVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(realVector39);
        int int43 = arrayRealVector42.getDimension();
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector42.mapSubtractToSelf(0.04350032773179846d);
        double double46 = arrayRealVector19.dotProduct(realVector45);
        double[] doubleArray48 = new double[] { '#' };
        double[] doubleArray51 = new double[] { 100, (byte) 10 };
        double double52 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray48, doubleArray51);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection53 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray51, orderDirection53, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray51);
        java.lang.String str58 = arrayRealVector57.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector57);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0000000000000002d + "'", double18 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0000000000000002d + "'", double41 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5 + "'", int43 == 5);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.9323608146471463d + "'", double46 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 65.0d + "'", double52 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}" + "'", str58.equals("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", "{10; 100; 10; 100; 1}", "hi!", "{10; 100; 10; 100; 1}", ",");
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
//        realVector7.unitize();
//        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
//        realVector15.unitize();
//        double double17 = realVector7.cosine(realVector15);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15);
//        int int19 = arrayRealVector18.getDimension();
//        boolean boolean20 = arrayRealVector18.isInfinite();
//        double double21 = arrayRealVector18.getMaxValue();
//        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
//        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
//        double[] doubleArray31 = new double[] { '#' };
//        double[] doubleArray34 = new double[] { 100, (byte) 10 };
//        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray34);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1), true);
//        double[] doubleArray39 = pointValuePair38.getKey();
//        double[] doubleArray40 = pointValuePair38.getFirst();
//        double[] doubleArray41 = pointValuePair38.getKey();
//        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
//        int int49 = org.apache.commons.math3.util.MathUtils.hash(doubleArray47);
//        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray47);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray47, 2.2250738585072014E-308d);
//        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray47);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray47);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister60 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray62 = new byte[] { (byte) -1 };
//        mersenneTwister60.nextBytes(byteArray62);
//        double double64 = mersenneTwister60.nextGaussian();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister65 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray67 = new byte[] { (byte) -1 };
//        mersenneTwister65.nextBytes(byteArray67);
//        mersenneTwister60.nextBytes(byteArray67);
//        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker73 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) (-1), (double) 0.0f);
//        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer74 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 1, doubleArray47, 35, (double) (-1766139745), false, (-52), (-1), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister60, true, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker73);
//        double double75 = mersenneTwister60.nextDouble();
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(realVector7);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(realVector15);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0000000000000002d + "'", double17 == 1.0000000000000002d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.7035801295960805d + "'", double21 == 0.7035801295960805d);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(realVector28);
//        org.junit.Assert.assertNotNull(realMatrix29);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray34);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 65.0d + "'", double35 == 65.0d);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertNotNull(doubleArray40);
//        org.junit.Assert.assertNotNull(doubleArray41);
//        org.junit.Assert.assertNotNull(doubleArray47);
//        org.junit.Assert.assertNotNull(realVector48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1766139745) + "'", int49 == (-1766139745));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(byteArray62);
//        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.2788905812302822d + "'", double64 == 1.2788905812302822d);
//        org.junit.Assert.assertNotNull(byteArray67);
//        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.6052535520996578d + "'", double75 == 0.6052535520996578d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getColumnMatrix(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = defaultRealMatrixPreservingVisitor8.end();
        double double10 = blockRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, (int) (short) 0);
        try {
            blockRealMatrix7.setColumnMatrix((int) '#', realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        double[] doubleArray51 = eigenDecomposition49.getRealEigenvalues();
        double double53 = eigenDecomposition49.getRealEigenvalue(0);
        try {
            org.apache.commons.math3.linear.RealVector realVector55 = eigenDecomposition49.getEigenvector((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 168.5422962509616d + "'", double53 == 168.5422962509616d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray6 = array2DRowRealMatrix4.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean8 = array2DRowRealMatrix7.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.copy();
        double[][] doubleArray10 = array2DRowRealMatrix7.getData();
        double[][] doubleArray11 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 1, (int) (byte) 1, doubleArray11, true);
        try {
            blockRealMatrix13.addToEntry((int) (byte) -1, 0, 4.9E-324d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, 36, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        double[] doubleArray51 = eigenDecomposition49.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = eigenDecomposition49.getD();
        double double53 = eigenDecomposition49.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 9.008100000000006E8d + "'", double53 == 9.008100000000006E8d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        boolean boolean10 = array2DRowRealMatrix9.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = array2DRowRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray34 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray39 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray44 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray45 = new double[][] { doubleArray19, doubleArray24, doubleArray29, doubleArray34, doubleArray39, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray46, (int) (short) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        org.apache.commons.math3.linear.RealVector realVector52 = realVector46.mapSubtract((double) 1.0f);
        double double53 = realVector52.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-0.9929641987040392d) + "'", double53 == (-0.9929641987040392d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 11013.232920103323d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector18);
        int int22 = arrayRealVector21.getDimension();
        boolean boolean23 = arrayRealVector21.isInfinite();
        double double24 = arrayRealVector21.getMaxValue();
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), true);
        arrayRealVector21.setSubVector((int) (short) 0, doubleArray27);
        double[] doubleArray41 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        realVector42.unitize();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        realVector50.unitize();
        double double52 = realVector42.cosine(realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(realVector50);
        int int54 = arrayRealVector53.getDimension();
        boolean boolean55 = arrayRealVector53.isInfinite();
        double double56 = arrayRealVector53.getMaxValue();
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        double[] doubleArray66 = new double[] { '#' };
        double[] doubleArray69 = new double[] { 100, (byte) 10 };
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray66, doubleArray69);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, (double) (-1), true);
        double[] doubleArray74 = pointValuePair73.getKey();
        double[] doubleArray75 = pointValuePair73.getFirst();
        double[] doubleArray76 = pointValuePair73.getKey();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        int int84 = org.apache.commons.math3.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray76, doubleArray82);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair87 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray82, 2.2250738585072014E-308d);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray82);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.lang.String str91 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        try {
            arrayRealVector21.addToEntry((-1869155408), (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0000000000000002d + "'", double52 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7035801295960805d + "'", double56 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 65.0d + "'", double70 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1766139745) + "'", int84 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str91.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        try {
            double double14 = blockRealMatrix4.getEntry((int) (byte) 10, (-1869155408));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray15 = array2DRowRealMatrix13.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, false);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, orderDirection10, doubleArray17);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, 10.000000000000002d);
        java.lang.Double double23 = pointValuePair22.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.000000000000002d + "'", double23.equals(10.000000000000002d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector17.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector17.copy();
        boolean boolean35 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor36 = null;
        try {
            double double37 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        realVector22.unitize();
        double double24 = realVector14.cosine(realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(realVector22);
        int int26 = arrayRealVector25.getDimension();
        boolean boolean27 = arrayRealVector25.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector25.copy();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtractToSelf((double) 1.0000001f);
        boolean boolean31 = array2DRowRealMatrix5.equals((java.lang.Object) arrayRealVector28);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0000000000000002d + "'", double24 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int[] intArray2 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister(intArray2);
        int[] intArray4 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2, 32);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair10 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray6, (java.lang.Double) 0.003267627914076726d);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { '#' };
        double[] doubleArray16 = new double[] { 100, (byte) 10 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray16);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1), true);
        double[] doubleArray21 = pointValuePair20.getKey();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray27 = array2DRowRealMatrix25.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection22, doubleArray29);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray21);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException38 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection39 = nonMonotonicSequenceException38.getDirection();
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray21, orderDirection39, true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray46 = array2DRowRealMatrix44.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getData();
        double[][] doubleArray49 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray48);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection39, doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1766139745) + "'", int8 == (-1766139745));
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 65.0d + "'", double17 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        double[] doubleArray61 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        realVector62.unitize();
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double double72 = realVector62.cosine(realVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(realVector70);
        int int74 = arrayRealVector73.getDimension();
        boolean boolean75 = arrayRealVector73.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector73.copy();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapMultiply(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector55.append(arrayRealVector76);
        try {
            arrayRealVector76.setEntry((-1869155408), 0.9866275920404853d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0000000000000002d + "'", double72 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(arrayRealVector79);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        float[] floatArray6 = new float[] { 1.0f, (byte) 10, (byte) 1, (-3455093127129143767L), '#', 1 };
        float[] floatArray13 = new float[] { 1.0000001f, 10L, 1, 5, 1L, (-52) };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray13);
        float[] floatArray21 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray22 = null;
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(floatArray21, floatArray22);
        float[] floatArray30 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray31 = null;
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(floatArray30, floatArray31);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray22, floatArray30);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray30);
        float[] floatArray41 = new float[] { 1.0f, (byte) 10, (byte) 1, (-3455093127129143767L), '#', 1 };
        float[] floatArray48 = new float[] { 1.0000001f, 10L, 1, 5, 1L, (-52) };
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equals(floatArray41, floatArray48);
        float[] floatArray56 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray57 = null;
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(floatArray56, floatArray57);
        float[] floatArray65 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray66 = null;
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equals(floatArray65, floatArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray57, floatArray65);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray41, floatArray65);
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray65);
        float[] floatArray77 = new float[] { 1.0f, (byte) 10, (byte) 1, (-3455093127129143767L), '#', 1 };
        float[] floatArray84 = new float[] { 1.0000001f, 10L, 1, 5, 1L, (-52) };
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equals(floatArray77, floatArray84);
        boolean boolean86 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray84);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1766139745L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.76613978E9f + "'", float2 == 1.76613978E9f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList3 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.optimization.GoalType goalType4 = cMAESOptimizer1.getGoalType();
        java.util.List<java.lang.Double> doubleList5 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        org.apache.commons.math3.optimization.GoalType goalType8 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        double[] doubleArray15 = new double[] { '#' };
        double[] doubleArray18 = new double[] { 100, (byte) 10 };
        double double19 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray15, doubleArray18);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair22 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray15, (double) (-1), true);
        double[] doubleArray23 = pointValuePair22.getKey();
        double[] doubleArray24 = pointValuePair22.getFirst();
        double[] doubleArray25 = pointValuePair22.getKey();
        double[] doubleArray31 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        int int33 = org.apache.commons.math3.util.MathUtils.hash(doubleArray31);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray25, doubleArray31);
        double[] doubleArray36 = new double[] { '#' };
        double[] doubleArray39 = new double[] { 100, (byte) 10 };
        double double40 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray36, doubleArray39);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) (-1), true);
        boolean boolean45 = pointValuePair43.equals((java.lang.Object) ' ');
        double[] doubleArray46 = pointValuePair43.getPoint();
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair47 = cMAESOptimizer1.optimize(4, multivariateFunction7, goalType8, doubleArray13, doubleArray31, doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(doubleList3);
        org.junit.Assert.assertNull(goalType4);
        org.junit.Assert.assertNotNull(doubleList5);
        org.junit.Assert.assertTrue("'" + goalType8 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType8.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 65.0d + "'", double19 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1766139745) + "'", int33 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 65.0d + "'", double40 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = array2DRowRealMatrix14.walkInColumnOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(1500420478, (int) 'a', doubleArray16, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 2,704");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double double19 = realVector18.getMaxValue();
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix11.operateTranspose(realVector18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector4 = openMapRealMatrix2.getRowVector(4);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.copy();
        double[][] doubleArray10 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix13.copy();
        double double16 = blockRealMatrix15.getNorm();
        double double17 = blockRealMatrix15.getFrobeniusNorm();
        blockRealMatrix15.multiplyEntry(0, (int) (byte) 10, (double) '#');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix9.subtract(blockRealMatrix15);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = eigenDecomposition49.getEigenvector((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
        boolean boolean2 = incrementor0.canIncrement();
        try {
            incrementor0.incrementCount(4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        boolean boolean12 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray13 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int7 = blockRealMatrix6.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = blockRealMatrix6.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray14 = array2DRowRealMatrix12.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        boolean boolean16 = array2DRowRealMatrix15.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix15.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double19 = array2DRowRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        double double20 = defaultRealMatrixPreservingVisitor18.end();
        double double21 = blockRealMatrix6.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        try {
            double double26 = array2DRowRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18, 3, 1500420480, 52, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,480)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        try {
            openMapRealMatrix2.multiplyEntry(1500420478, (int) (short) 0, (double) (-3455093127129143767L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int19 = array2DRowRealMatrix18.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        boolean boolean26 = array2DRowRealMatrix25.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix25.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor28 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double29 = array2DRowRealMatrix25.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28);
        double double30 = array2DRowRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28);
        try {
            double double35 = array2DRowRealMatrix13.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28, (int) (short) 100, 0, (int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-4.2178103739495964E10d), (-3.380515006246586d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        try {
            arrayRealVector17.setEntry((-1766139745), 286.4788975654116d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,766,139,745)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        int int23 = arrayRealVector17.getDimension();
        boolean boolean24 = arrayRealVector17.isNaN();
        try {
            org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector17.getSubVector(36, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        double double12 = array2DRowRealMatrix5.getNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        double double3 = mersenneTwister0.nextGaussian();
//        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) mersenneTwister0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.8923875036701576d) + "'", double3 == (-0.8923875036701576d));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 100);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        java.lang.String str17 = array2DRowRealMatrix14.toString();
        double[] doubleArray23 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector24 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray23);
        realVector24.unitize();
        double[] doubleArray31 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        realVector32.unitize();
        double double34 = realVector24.cosine(realVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(realVector32);
        int int36 = arrayRealVector35.getDimension();
        boolean boolean37 = arrayRealVector35.isInfinite();
        double double38 = arrayRealVector35.getMaxValue();
        double[] doubleArray41 = new double[] { '#' };
        double[] doubleArray44 = new double[] { 100, (byte) 10 };
        double double45 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray41, doubleArray44);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray41, (double) (-1), true);
        arrayRealVector35.setSubVector((int) (short) 0, doubleArray41);
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double[] doubleArray63 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector64 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray63);
        realVector64.unitize();
        double double66 = realVector56.cosine(realVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(realVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector35.add(realVector64);
        double[] doubleArray74 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector75 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray74);
        realVector75.unitize();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        realVector83.unitize();
        double double85 = realVector75.cosine(realVector83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(realVector83);
        int int87 = arrayRealVector86.getDimension();
        boolean boolean88 = arrayRealVector86.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector86.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector68, (org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        try {
            org.apache.commons.math3.linear.RealVector realVector91 = array2DRowRealMatrix14.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0000000000000002d + "'", double34 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.7035801295960805d + "'", double38 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 65.0d + "'", double45 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0000000000000002d + "'", double66 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0000000000000002d + "'", double85 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 5 + "'", int87 == 5);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(arrayRealVector89);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        arrayRealVector17.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        arrayRealVector17.unitize();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor1 = null;
        try {
            double double2 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray2);
        double[] doubleArray12 = new double[] { '#' };
        double[] doubleArray15 = new double[] { 100, (byte) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection17 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray15, orderDirection17, false, true);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 65.0d + "'", double16 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker0 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double[] doubleArray3 = new double[] { '#' };
        double[] doubleArray6 = new double[] { 100, (byte) 10 };
        double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray6);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1), true);
        double[] doubleArray11 = pointValuePair10.getPoint();
        double[] doubleArray13 = new double[] { '#' };
        double[] doubleArray16 = new double[] { 100, (byte) 10 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray16);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1), true);
        double[] doubleArray21 = pointValuePair20.getKey();
        double[] doubleArray22 = pointValuePair20.getFirst();
        java.lang.Double double23 = pointValuePair20.getSecond();
        double[] doubleArray24 = pointValuePair20.getFirst();
        boolean boolean26 = pointValuePair20.equals((java.lang.Object) (-52));
        boolean boolean27 = simpleValueChecker0.converged((int) (short) -1, pointValuePair10, pointValuePair20);
        java.lang.Double double28 = pointValuePair10.getValue();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 65.0d + "'", double7 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 65.0d + "'", double17 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28.equals((-1.0d)));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        java.lang.String str4 = realMatrixFormat0.getPrefix();
        java.lang.String str5 = realMatrixFormat0.getRowPrefix();
        java.text.NumberFormat numberFormat6 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{" + "'", str5.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix3);
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        realVector12.unitize();
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double double22 = realVector12.cosine(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(realVector20);
        int int24 = arrayRealVector23.getDimension();
        boolean boolean25 = arrayRealVector23.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector23.copy();
        double[] doubleArray27 = arrayRealVector23.toArray();
        try {
            openMapRealMatrix3.setRow(0, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0000000000000002d + "'", double22 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math3.util.FastMath.tan(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray54 = array2DRowRealMatrix52.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double double56 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray45, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 100.0d + "'", double56 == 100.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        double[][] doubleArray25 = array2DRowRealMatrix24.getData();
        java.lang.Double[] doubleArray26 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        double double28 = arrayRealVector27.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector27);
        try {
            org.apache.commons.math3.linear.RealVector realVector32 = array2DRowRealMatrix24.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        double[] doubleArray7 = blockRealMatrix2.getRow(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = null;
        try {
            blockRealMatrix2.setRowMatrix((int) '4', realMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("{10; 100; 10; 100; 1}", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", numberFormat3);
        java.lang.String str5 = realVectorFormat4.getSeparator();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str5.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        arrayRealVector49.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector49.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        double[] doubleArray56 = new double[] { '#' };
        double[] doubleArray59 = new double[] { 100, (byte) 10 };
        double double60 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray56, doubleArray59);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair63 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, (double) (-1), true);
        double[] doubleArray64 = pointValuePair63.getKey();
        java.lang.Double double65 = pointValuePair63.getSecond();
        double[] doubleArray66 = pointValuePair63.getKey();
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray66, 0.0d);
        arrayRealVector17.setSubVector(0, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 65.0d + "'", double60 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-1.0d) + "'", double65.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray19 = array2DRowRealMatrix17.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix20.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray28 = array2DRowRealMatrix26.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getData();
        array2DRowRealMatrix20.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix29.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix8.add(realMatrix33);
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException42 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int43 = nonSymmetricMatrixException42.getColumn();
        org.apache.commons.math3.exception.util.Localizable localizable44 = null;
        double[] doubleArray51 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray58 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray59 = new double[][] { doubleArray51, doubleArray58 };
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException61 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonSymmetricMatrixException42, localizable44, (java.lang.Object[]) doubleArray59);
        try {
            array2DRowRealMatrix8.copySubMatrix(52, (int) ' ', 5, 0, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(35.0d, 573.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 574.0679402300742d + "'", double2 == 574.0679402300742d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1));
        boolean boolean2 = incrementor1.canIncrement();
        try {
            incrementor1.incrementCount(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.5574077246549023d, 320.00000009264005d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector17.mapMultiply(0.9533921721708404d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction53 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector17.mapToSelf(univariateFunction53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        int int1 = cMAESOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str2 = realMatrixFormat1.getRowSeparator();
        java.text.NumberFormat numberFormat3 = realMatrixFormat1.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat3);
        java.text.ParsePosition parsePosition5 = null;
        try {
            java.lang.Number number6 = org.apache.commons.math3.util.CompositeFormat.parseNumber("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", numberFormat3, parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int[] intArray5 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5, (int) (short) 100);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        double[][] doubleArray12 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor16 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double17 = blockRealMatrix15.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        double double18 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix5.getSubMatrix(1500420480, (int) ' ', 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,480)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        double double4 = nonSymmetricMatrixException3.getThreshold();
        java.lang.String str5 = nonSymmetricMatrixException3.toString();
        int int6 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32" + "'", str5.equals("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = array2DRowRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double16 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math3.random.MersenneTwister();
        boolean boolean18 = mersenneTwister17.nextBoolean();
        int[] intArray21 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math3.random.MersenneTwister(intArray21);
        int[] intArray23 = org.apache.commons.math3.util.MathArrays.copyOf(intArray21);
        mersenneTwister17.setSeed(intArray23);
        int[] intArray27 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray27);
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = blockRealMatrix2.getSubMatrix(intArray23, intArray27);
        int[] intArray36 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray38 = org.apache.commons.math3.util.MathArrays.copyOf(intArray36, (int) (short) 100);
        int int39 = org.apache.commons.math3.util.MathArrays.distance1(intArray23, intArray38);
        int[] intArray40 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) 6.283185307179586d, false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.492385186467945d, (java.lang.Number) 0.04350032773179846d, (int) ' ', orderDirection3, false);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        int int7 = nonMonotonicSequenceException5.getIndex();
        int int8 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray44 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray49 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray54 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray59 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray64 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray69 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray70 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64, doubleArray69 };
        double[][] doubleArray71 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray70);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 24 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        double[] doubleArray15 = new double[] { '#' };
        double[] doubleArray18 = new double[] { 100, (byte) 10 };
        double double19 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray15, doubleArray18);
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 1.0f, (byte) 100, doubleArray12, double19, realVector26, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 10.0d, localizable5, objArray28);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 57.29577951308232d, localizable3, objArray28);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.1920929E-7f, objArray28);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext32 = maxCountExceededException31.getContext();
        java.lang.Number number33 = maxCountExceededException31.getMax();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 65.0d + "'", double19 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(exceptionContext32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.1920929E-7f + "'", number33.equals(1.1920929E-7f));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        java.lang.Double double11 = pointValuePair8.getSecond();
        double[] doubleArray12 = pointValuePair8.getFirst();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        try {
            double double6 = openMapRealMatrix2.getEntry(1500420480, (-1766139745));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,480)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        double[] doubleArray7 = blockRealMatrix2.getRow(0);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1493912449 + "'", int8 == 1493912449);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        org.apache.commons.math3.linear.RealVector realVector51 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver50 = eigenDecomposition49.getSolver();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(decompositionSolver50);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.223994989065759d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6574174791406237d + "'", double1 == 0.6574174791406237d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        double double6 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((-0.1078758181147519d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10787581811475189d) + "'", double1 == (-0.10787581811475189d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (short) 1);
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        int int15 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair17 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray13, (java.lang.Double) 0.003267627914076726d);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        double[] doubleArray20 = new double[] { '#' };
        double[] doubleArray23 = new double[] { 100, (byte) 10 };
        double double24 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray20, doubleArray23);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) (-1), true);
        double[] doubleArray28 = pointValuePair27.getKey();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection29 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray34 = array2DRowRealMatrix32.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[][] doubleArray36 = array2DRowRealMatrix35.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, false);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, orderDirection29, doubleArray36);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray28);
        int int42 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        try {
            blockRealMatrix2.setRow((int) (short) 10, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1766139745) + "'", int15 == (-1766139745));
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 65.0d + "'", double24 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1766139745) + "'", int42 == (-1766139745));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray7 = array2DRowRealMatrix5.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        double[][] doubleArray10 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) 0.8588892f, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.ZeroException zeroException12 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int1 = org.apache.commons.math3.util.FastMath.round(10.000001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        double[] doubleArray30 = new double[] { '#' };
        double[] doubleArray33 = new double[] { 100, (byte) 10 };
        double double34 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray30, doubleArray33);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray30, (double) (-1), true);
        double[] doubleArray38 = pointValuePair37.getKey();
        double[] doubleArray39 = pointValuePair37.getFirst();
        double[] doubleArray40 = pointValuePair37.getKey();
        double[] doubleArray46 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector47 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray46);
        int int48 = org.apache.commons.math3.util.MathUtils.hash(doubleArray46);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray46);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray46, 2.2250738585072014E-308d);
        boolean boolean52 = org.apache.commons.math3.util.MathArrays.equals(doubleArray26, doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray46);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector17.append(35.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(realVector55);
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        int int64 = org.apache.commons.math3.util.MathUtils.hash(doubleArray62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62, false);
        try {
            double double69 = arrayRealVector56.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 65.0d + "'", double34 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1766139745) + "'", int48 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1766139745) + "'", int64 == (-1766139745));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9, (int) '4', 5, 32, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.mapToSelf(univariateFunction2);
        double double4 = arrayRealVector1.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = array2DRowRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double16 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double[][] doubleArray17 = blockRealMatrix2.getData();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray17 = array2DRowRealMatrix15.getColumn((int) (short) 1);
        double double18 = array2DRowRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix21);
        int int25 = array2DRowRealMatrix15.getColumnDimension();
        java.lang.String str26 = array2DRowRealMatrix15.toString();
        try {
            blockRealMatrix9.setColumnMatrix(0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x52 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix6.copy();
        double[][] doubleArray9 = blockRealMatrix8.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.getColumnMatrix(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = defaultRealMatrixPreservingVisitor12.end();
        double double14 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double15 = array2DRowRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = blockRealMatrix9.transpose();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 0L, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        boolean boolean32 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector17.unitVector();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(5);
        incrementor1.setMaximalCount((int) (short) 10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        java.lang.String str7 = blockRealMatrix4.toString();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix15, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix4.multiply(realMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.5395564933646284d, (java.lang.Number) 51.99999999999999d, (java.lang.Number) 4.641588833612779d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) number5, "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 4.641588833612779d + "'", number5.equals(4.641588833612779d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number2, (java.lang.Number) (short) 10, false);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray11 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray16 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray21 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray26 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray31 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray36 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray37 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, localizable6, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException41 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 0.9533921721708404d, (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (byte) 1, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1766139745));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(4.662521952941945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(34.92964198704039d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1032528089) + "'", int1 == (-1032528089));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (byte) 10);
        double[][] doubleArray7 = blockRealMatrix2.getData();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray8, doubleArray9, doubleArray10, doubleArray11, doubleArray12, doubleArray13 };
        try {
            blockRealMatrix2.setSubMatrix(doubleArray14, 0, (-1869155408));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1493912449);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1493912448 + "'", int1 == 1493912448);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getRowVector(1493912449);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,493,912,449)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
        boolean boolean2 = incrementor0.canIncrement();
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount(4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray31 = array2DRowRealMatrix29.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray39 = array2DRowRealMatrix37.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        boolean boolean41 = array2DRowRealMatrix40.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor43 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double44 = array2DRowRealMatrix40.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double45 = defaultRealMatrixPreservingVisitor43.end();
        double double46 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double47 = array2DRowRealMatrix14.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int51 = blockRealMatrix50.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray56 = array2DRowRealMatrix54.getColumn((int) (short) 1);
        double[][] doubleArray57 = array2DRowRealMatrix54.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor58 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor58.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double66 = array2DRowRealMatrix54.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        double double67 = blockRealMatrix50.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        try {
            double double72 = array2DRowRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58, (int) (short) -1, 1, (-1207516062), 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        blockRealMatrix2.multiplyEntry(0, 0, (double) 0L);
        org.apache.commons.math3.linear.RealVector realVector10 = blockRealMatrix2.getColumnVector((int) '4');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.scalarAdd((double) (short) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int23 = blockRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix17.add(blockRealMatrix22);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix17, (int) (short) 10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix2.multiply(blockRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray5 = array2DRowRealMatrix3.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[][] doubleArray7 = array2DRowRealMatrix6.getData();
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 100, (double) 30000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(4.662521952941945d, 35.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[][] doubleArray5 = array2DRowRealMatrix2.getDataRef();
        double[] doubleArray8 = new double[] { '#' };
        double[] doubleArray11 = new double[] { 100, (byte) 10 };
        double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray11);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1), true);
        double[] doubleArray16 = pointValuePair15.getKey();
        double[] doubleArray17 = pointValuePair15.getFirst();
        java.lang.Double double18 = pointValuePair15.getSecond();
        double[] doubleArray19 = pointValuePair15.getPointRef();
        double[] doubleArray20 = pointValuePair15.getPoint();
        try {
            array2DRowRealMatrix2.setColumn((int) ' ', doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 65.0d + "'", double12 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        int int3 = openMapRealMatrix2.getRowDimension();
        try {
            openMapRealMatrix2.setEntry((-52), (int) 'a', (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector18);
        int int22 = arrayRealVector21.getDimension();
        boolean boolean23 = arrayRealVector21.isInfinite();
        double double24 = arrayRealVector21.getMaxValue();
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), true);
        arrayRealVector21.setSubVector((int) (short) 0, doubleArray27);
        double[] doubleArray41 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        realVector42.unitize();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        realVector50.unitize();
        double double52 = realVector42.cosine(realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(realVector50);
        int int54 = arrayRealVector53.getDimension();
        boolean boolean55 = arrayRealVector53.isInfinite();
        double double56 = arrayRealVector53.getMaxValue();
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        double[] doubleArray66 = new double[] { '#' };
        double[] doubleArray69 = new double[] { 100, (byte) 10 };
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray66, doubleArray69);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, (double) (-1), true);
        double[] doubleArray74 = pointValuePair73.getKey();
        double[] doubleArray75 = pointValuePair73.getFirst();
        double[] doubleArray76 = pointValuePair73.getKey();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        int int84 = org.apache.commons.math3.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray76, doubleArray82);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair87 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray82, 2.2250738585072014E-308d);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray82);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.lang.String str91 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.RealVector realVector92 = null;
        java.lang.StringBuffer stringBuffer93 = null;
        java.text.FieldPosition fieldPosition94 = null;
        try {
            java.lang.StringBuffer stringBuffer95 = realVectorFormat0.format(realVector92, stringBuffer93, fieldPosition94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0000000000000002d + "'", double52 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7035801295960805d + "'", double56 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 65.0d + "'", double70 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1766139745) + "'", int84 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str91.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        boolean boolean8 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = blockRealMatrix20.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double double23 = array2DRowRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        try {
            double double28 = array2DRowRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21, 3, (int) '#', 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        double[] doubleArray61 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        realVector62.unitize();
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double double72 = realVector62.cosine(realVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(realVector70);
        int int74 = arrayRealVector73.getDimension();
        boolean boolean75 = arrayRealVector73.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector73.copy();
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapMultiply(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector55.append(arrayRealVector76);
        double[] doubleArray80 = arrayRealVector55.getDataRef();
        double[] doubleArray81 = arrayRealVector55.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0000000000000002d + "'", double72 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(arrayRealVector79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
//        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
//        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
//        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        int int20 = blockRealMatrix19.getColumnDimension();
//        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix19.scalarMultiply(0.0d);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray27 = array2DRowRealMatrix25.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
//        boolean boolean29 = array2DRowRealMatrix28.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
//        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor31 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
//        double double32 = array2DRowRealMatrix28.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor31);
//        double double33 = blockRealMatrix19.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor31);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean35 = mersenneTwister34.nextBoolean();
//        int[] intArray38 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister39 = new org.apache.commons.math3.random.MersenneTwister(intArray38);
//        int[] intArray40 = org.apache.commons.math3.util.MathArrays.copyOf(intArray38);
//        mersenneTwister34.setSeed(intArray40);
//        int[] intArray44 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister45 = new org.apache.commons.math3.random.MersenneTwister(intArray44);
//        int[] intArray46 = org.apache.commons.math3.util.MathArrays.copyOf(intArray44);
//        org.apache.commons.math3.linear.RealMatrix realMatrix47 = blockRealMatrix19.getSubMatrix(intArray40, intArray44);
//        int[] intArray50 = new int[] { (short) 100, '#' };
//        try {
//            org.apache.commons.math3.linear.RealMatrix realMatrix51 = array2DRowRealMatrix5.getSubMatrix(intArray44, intArray50);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(realMatrix7);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(realMatrix22);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(realMatrix30);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(realMatrix47);
//        org.junit.Assert.assertNotNull(intArray50);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(1500420478, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        int int12 = array2DRowRealMatrix8.getRowDimension();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        int int20 = org.apache.commons.math3.util.MathUtils.hash(doubleArray18);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair22 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray18, (java.lang.Double) 0.003267627914076726d);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray18);
        try {
            double[] doubleArray24 = array2DRowRealMatrix8.operate(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1766139745) + "'", int20 == (-1766139745));
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray9 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray14 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray34 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray35 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, localizable4, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray44 = array2DRowRealMatrix42.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        double[][] doubleArray46 = array2DRowRealMatrix45.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = blockRealMatrix51.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double double54 = array2DRowRealMatrix48.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = blockRealMatrix39.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor56 = null;
        try {
            double double57 = blockRealMatrix39.walkInRowOrder(realMatrixChangingVisitor56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        try {
            openMapRealMatrix2.setEntry((-1032528089), (int) (byte) 10, 320.00000009264005d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,032,528,089)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double26 = blockRealMatrix16.walkInRowOrder(realMatrixChangingVisitor21, 3, 0, 36, (-1766139745));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 3 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        blockRealMatrix9.multiplyEntry(0, 0, (double) 0L);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix9.getColumnVector((int) '4');
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x100) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math3.util.MathUtils.checkFinite(286.4788975654116d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        arrayRealVector49.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector49.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = arrayRealVector17.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector17.append(arrayRealVector54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply((double) (-52));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        int int23 = arrayRealVector17.getDimension();
        boolean boolean24 = arrayRealVector17.isNaN();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector17.mapAddToSelf(35.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector17.mapSubtractToSelf((-0.8813735870195429d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector28);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
//        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
//        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
//        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
//        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
//        double[][] doubleArray12 = array2DRowRealMatrix5.getData();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor16 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
//        double double17 = blockRealMatrix15.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
//        double double18 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
//        int int22 = blockRealMatrix21.getColumnDimension();
//        org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix21.scalarMultiply(0.0d);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray29 = array2DRowRealMatrix27.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
//        boolean boolean31 = array2DRowRealMatrix30.isTransposable();
//        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix30.copy();
//        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor33 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
//        double double34 = array2DRowRealMatrix30.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
//        double double35 = blockRealMatrix21.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister36 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean37 = mersenneTwister36.nextBoolean();
//        int[] intArray40 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister41 = new org.apache.commons.math3.random.MersenneTwister(intArray40);
//        int[] intArray42 = org.apache.commons.math3.util.MathArrays.copyOf(intArray40);
//        mersenneTwister36.setSeed(intArray42);
//        int[] intArray46 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister47 = new org.apache.commons.math3.random.MersenneTwister(intArray46);
//        int[] intArray48 = org.apache.commons.math3.util.MathArrays.copyOf(intArray46);
//        org.apache.commons.math3.linear.RealMatrix realMatrix49 = blockRealMatrix21.getSubMatrix(intArray42, intArray46);
//        int[] intArray55 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
//        int[] intArray57 = org.apache.commons.math3.util.MathArrays.copyOf(intArray55, (int) (short) 100);
//        int int58 = org.apache.commons.math3.util.MathArrays.distance1(intArray42, intArray57);
//        int[] intArray59 = null;
//        org.apache.commons.math3.exception.util.Localizable localizable60 = null;
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray65 = array2DRowRealMatrix63.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
//        double[][] doubleArray67 = array2DRowRealMatrix66.getData();
//        double[][] doubleArray68 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
//        org.apache.commons.math3.exception.MathInternalError mathInternalError69 = new org.apache.commons.math3.exception.MathInternalError(localizable60, (java.lang.Object[]) doubleArray68);
//        try {
//            array2DRowRealMatrix5.copySubMatrix(intArray57, intArray59, doubleArray68);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
//        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(realMatrix7);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertNotNull(realVector11);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(realMatrix24);
//        org.junit.Assert.assertNotNull(doubleArray29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(realMatrix32);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(realMatrix49);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(doubleArray65);
//        org.junit.Assert.assertNotNull(doubleArray67);
//        org.junit.Assert.assertNotNull(doubleArray68);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getPoint();
        boolean boolean11 = pointValuePair8.equals((java.lang.Object) 573.0d);
        java.lang.Double double12 = pointValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapMultiply(Double.NaN);
        org.apache.commons.math3.linear.RealVector realVector23 = realVector22.unitVector();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 0, 4, (-0.8287275724147631d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList3 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        org.apache.commons.math3.optimization.GoalType goalType6 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        double[] doubleArray7 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray14 = null;
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection32 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray30, orderDirection32, false, true);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection32, false, true);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = cMAESOptimizer1.optimize(100, multivariateFunction5, goalType6, doubleArray7, doubleArray13, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(doubleList3);
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType6.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray6 = array2DRowRealMatrix4.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, true);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray8);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(realVector56);
        int int60 = arrayRealVector59.getDimension();
        boolean boolean61 = arrayRealVector59.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector59.copy();
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapMultiply(Double.NaN);
        double double65 = arrayRealVector20.cosine(realVector64);
        boolean boolean66 = arrayRealVector20.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector20.mapMultiply((-1.5707963267948966d));
        try {
            arrayRealVector20.addToEntry((int) ' ', (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(realVector68);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray19 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonSymmetricMatrixException3, localizable5, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20, true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, 32);
        double[] doubleArray5 = new double[] { '#' };
        double[] doubleArray8 = new double[] { 100, (byte) 10 };
        double double9 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), true);
        double[] doubleArray13 = pointValuePair12.getKey();
        java.lang.Double double14 = pointValuePair12.getSecond();
        double[] doubleArray15 = pointValuePair12.getKey();
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray15, 0.0d);
        try {
            blockRealMatrix2.setRow((-1), doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 65.0d + "'", double9 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray9 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray14 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray34 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray35 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, localizable4, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double43 = blockRealMatrix42.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix42.copy();
        double[][] doubleArray45 = blockRealMatrix44.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix44.getColumnMatrix(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor48 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double49 = defaultRealMatrixPreservingVisitor48.end();
        double double50 = blockRealMatrix47.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48);
        double double51 = blockRealMatrix39.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1));
        boolean boolean2 = incrementor1.canIncrement();
        int int3 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14, false);
        try {
            blockRealMatrix4.setSubMatrix(doubleArray14, 32, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (66)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "{10; 100; 10; 100; 1}", "}", "");
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.Double[] doubleArray2 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector3.map(univariateFunction4);
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        realVector12.unitize();
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double double22 = realVector12.cosine(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(realVector20);
        int int24 = arrayRealVector23.getDimension();
        boolean boolean25 = arrayRealVector23.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector23.copy();
        double double28 = arrayRealVector23.getEntry((int) (byte) 1);
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double[] doubleArray42 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector43 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray42);
        realVector43.unitize();
        double double45 = realVector35.cosine(realVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(realVector43);
        int int47 = arrayRealVector46.getDimension();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector46.mapSubtractToSelf(0.04350032773179846d);
        double double50 = arrayRealVector23.dotProduct(realVector49);
        double[] doubleArray52 = new double[] { '#' };
        double[] doubleArray55 = new double[] { 100, (byte) 10 };
        double double56 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray52, doubleArray55);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection57 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray55, orderDirection57, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray55);
        double[] doubleArray67 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector68 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray67);
        realVector68.unitize();
        double[] doubleArray75 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector76 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray75);
        realVector76.unitize();
        double double78 = realVector68.cosine(realVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(realVector76);
        int int80 = arrayRealVector79.getDimension();
        boolean boolean81 = arrayRealVector79.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector79.copy();
        org.apache.commons.math3.linear.RealVector realVector84 = arrayRealVector82.mapMultiply(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = arrayRealVector61.append(arrayRealVector82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, (org.apache.commons.math3.linear.RealVector) arrayRealVector82);
        java.lang.StringBuffer stringBuffer87 = null;
        java.text.FieldPosition fieldPosition88 = null;
        try {
            java.lang.StringBuffer stringBuffer89 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5, stringBuffer87, fieldPosition88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0000000000000002d + "'", double22 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.7035801295960805d + "'", double28 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0000000000000002d + "'", double45 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.9323608146471463d + "'", double50 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 65.0d + "'", double56 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection57.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0000000000000002d + "'", double78 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 5 + "'", int80 == 5);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertNotNull(arrayRealVector85);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        boolean boolean12 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray13 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = array2DRowRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double16 = defaultRealMatrixPreservingVisitor14.end();
        double double17 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        try {
            blockRealMatrix2.setEntry((int) 'a', 52, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        double[][] doubleArray12 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor16 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double17 = blockRealMatrix15.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        double double18 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        realVector25.unitize();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        realVector33.unitize();
        double double35 = realVector25.cosine(realVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(realVector33);
        int int37 = arrayRealVector36.getDimension();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector36.mapSubtractToSelf(0.04350032773179846d);
        boolean boolean40 = array2DRowRealMatrix5.equals((java.lang.Object) arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0000000000000002d + "'", double35 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        boolean boolean50 = eigenDecomposition49.hasComplexEigenvalues();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver51 = eigenDecomposition49.getSolver();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(decompositionSolver51);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        double[][] doubleArray9 = array2DRowRealMatrix6.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor10.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double18 = array2DRowRealMatrix6.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        double double19 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix25.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray33 = array2DRowRealMatrix31.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[][] doubleArray35 = array2DRowRealMatrix34.getData();
        array2DRowRealMatrix25.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix34.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray43 = array2DRowRealMatrix41.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix44.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray51 = array2DRowRealMatrix49.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        double[][] doubleArray53 = array2DRowRealMatrix52.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix44.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray59 = array2DRowRealMatrix57.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        boolean boolean61 = array2DRowRealMatrix60.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = array2DRowRealMatrix60.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor63 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double64 = array2DRowRealMatrix60.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        double double65 = defaultRealMatrixPreservingVisitor63.end();
        double double66 = array2DRowRealMatrix44.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        double double67 = array2DRowRealMatrix34.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        double double68 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor63);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix2.createMatrix((-52), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray11 = array2DRowRealMatrix9.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor19 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double20 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor19);
        double double21 = array2DRowRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor19);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix4.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.RealVector realVector7 = blockRealMatrix4.getRowVector(0);
        double double8 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix4.walkInRowOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
        org.apache.commons.math3.linear.RealVector realVector4 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector3.add(realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str4 = realMatrixFormat3.getRowSeparator();
        java.lang.String str5 = realMatrixFormat3.getRowPrefix();
        java.lang.String str6 = realMatrixFormat3.getRowPrefix();
        java.text.NumberFormat numberFormat7 = realMatrixFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", "", ",", numberFormat7);
        org.junit.Assert.assertNotNull(realMatrixFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{" + "'", str5.equals("{"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{" + "'", str6.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        mersenneTwister1.setSeed((int) 'a');
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8369441f + "'", float4 == 0.8369441f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray5 = new double[] { '#' };
        double[] doubleArray8 = new double[] { 100, (byte) 10 };
        double double9 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), true);
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        realVector22.unitize();
        double[] doubleArray29 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray29);
        realVector30.unitize();
        double double32 = realVector22.cosine(realVector30);
        java.lang.Object[] objArray34 = new java.lang.Object[] { pointValuePair12, (byte) 1, (short) 1, true, realVector30, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException35 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable3, objArray34);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray34);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException37 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable1, objArray34);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray34);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 65.0d + "'", double9 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0000000000000002d + "'", double32 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray44 = array2DRowRealMatrix42.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 4.662521952941945d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
//        realVector7.unitize();
//        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
//        realVector15.unitize();
//        double double17 = realVector7.cosine(realVector15);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15);
//        int int19 = arrayRealVector18.getDimension();
//        boolean boolean20 = arrayRealVector18.isInfinite();
//        double double21 = arrayRealVector18.getMaxValue();
//        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
//        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
//        double[] doubleArray31 = new double[] { '#' };
//        double[] doubleArray34 = new double[] { 100, (byte) 10 };
//        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray34);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1), true);
//        double[] doubleArray39 = pointValuePair38.getKey();
//        double[] doubleArray40 = pointValuePair38.getFirst();
//        double[] doubleArray41 = pointValuePair38.getKey();
//        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
//        int int49 = org.apache.commons.math3.util.MathUtils.hash(doubleArray47);
//        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray47);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray47, 2.2250738585072014E-308d);
//        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray47);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray47);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister60 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray62 = new byte[] { (byte) -1 };
//        mersenneTwister60.nextBytes(byteArray62);
//        double double64 = mersenneTwister60.nextGaussian();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister65 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray67 = new byte[] { (byte) -1 };
//        mersenneTwister65.nextBytes(byteArray67);
//        mersenneTwister60.nextBytes(byteArray67);
//        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker73 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) (-1), (double) 0.0f);
//        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer74 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 1, doubleArray47, 35, (double) (-1766139745), false, (-52), (-1), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister60, true, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker73);
//        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray47, 4);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(realVector7);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(realVector15);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0000000000000002d + "'", double17 == 1.0000000000000002d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.7035801295960805d + "'", double21 == 0.7035801295960805d);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(realVector28);
//        org.junit.Assert.assertNotNull(realMatrix29);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray34);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 65.0d + "'", double35 == 65.0d);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertNotNull(doubleArray40);
//        org.junit.Assert.assertNotNull(doubleArray41);
//        org.junit.Assert.assertNotNull(doubleArray47);
//        org.junit.Assert.assertNotNull(realVector48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1766139745) + "'", int49 == (-1766139745));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(byteArray62);
//        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-0.06210393375715178d) + "'", double64 == (-0.06210393375715178d));
//        org.junit.Assert.assertNotNull(byteArray67);
//        org.junit.Assert.assertNotNull(doubleArray76);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        java.lang.Double[] doubleArray3 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        double double5 = arrayRealVector4.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector1.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(arrayRealVector8);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.add(openMapRealMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1));
        incrementor1.setMaximalCount((-52));
        incrementor1.setMaximalCount(1500420480);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) -1, (int) (byte) 10);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double double7 = array2DRowRealMatrix5.getNorm();
        boolean boolean8 = array2DRowRealMatrix5.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[] doubleArray19 = new double[] { 1.1102230246251565E-16d, Double.NaN, 36, (short) 0, 1.0d, (short) 100 };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonSymmetricMatrixException3, localizable5, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = mathIllegalStateException22.getContext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(exceptionContext23);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor6 = null;
        try {
            double double9 = arrayRealVector1.walkInDefaultOrder(realVectorPreservingVisitor6, 32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getKey();
        double[] doubleArray11 = pointValuePair9.getFirst();
        java.lang.Double double12 = pointValuePair9.getSecond();
        double[] doubleArray13 = pointValuePair9.getFirst();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        org.apache.commons.math3.random.RandomGenerator randomGenerator20 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1), doubleArray13, 4, 4.9E-324d, true, 4, 4, randomGenerator20, false);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList23 = cMAESOptimizer22.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrixList23);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        java.lang.String str4 = realMatrixFormat0.getPrefix();
        java.lang.String str5 = realMatrixFormat0.getSuffix();
        java.lang.String str6 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "}" + "'", str5.equals("}"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "}" + "'", str6.equals("}"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        java.lang.Double double11 = pointValuePair8.getSecond();
        double[] doubleArray12 = pointValuePair8.getPointRef();
        java.lang.Double double13 = pointValuePair8.getValue();
        double[] doubleArray14 = pointValuePair8.getFirst();
        double[] doubleArray15 = pointValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        int int12 = array2DRowRealMatrix2.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix2.createMatrix(1500420478, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        double[] doubleArray46 = new double[] { '#' };
        double[] doubleArray49 = new double[] { 100, (byte) 10 };
        double double50 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray46, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection51, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray49);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.mapDivide((double) 10);
        double[] doubleArray63 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector64 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray63);
        realVector64.unitize();
        double[] doubleArray71 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector72 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray71);
        realVector72.unitize();
        double double74 = realVector64.cosine(realVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(realVector72);
        int int76 = arrayRealVector75.getDimension();
        boolean boolean77 = arrayRealVector75.isInfinite();
        double double78 = arrayRealVector75.getMaxValue();
        double[] doubleArray81 = new double[] { '#' };
        double[] doubleArray84 = new double[] { 100, (byte) 10 };
        double double85 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray81, doubleArray84);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair88 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray81, (double) (-1), true);
        arrayRealVector75.setSubVector((int) (short) 0, doubleArray81);
        boolean boolean90 = arrayRealVector75.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = arrayRealVector55.append(arrayRealVector75);
        arrayRealVector55.setEntry(3, 4.641588833612779d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 65.0d + "'", double50 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0000000000000002d + "'", double74 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 5 + "'", int76 == 5);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.7035801295960805d + "'", double78 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 65.0d + "'", double85 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(arrayRealVector91);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor18 = null;
        try {
            double double21 = arrayRealVector17.walkInOptimizedOrder(realVectorPreservingVisitor18, 1493912448, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,493,912,448)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4, 1500420480, (-1032528089), (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,480)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.6052535520996578d, (double) 'a', 0.7771211630872612d, (double) 1.0000001f, (double) (-1766139745));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.7661398801595113E9d) + "'", double6 == (-1.7661398801595113E9d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        realVector25.unitize();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        realVector33.unitize();
        double double35 = realVector25.cosine(realVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(realVector33);
        int int37 = arrayRealVector36.getDimension();
        boolean boolean38 = arrayRealVector36.isInfinite();
        double double39 = arrayRealVector36.getMaxValue();
        double[] doubleArray42 = new double[] { '#' };
        double[] doubleArray45 = new double[] { 100, (byte) 10 };
        double double46 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray42, doubleArray45);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair49 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, (double) (-1), true);
        arrayRealVector36.setSubVector((int) (short) 0, doubleArray42);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector36.add(realVector65);
        double double70 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        arrayRealVector17.set((double) 1.0f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0000000000000002d + "'", double35 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.7035801295960805d + "'", double39 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 65.0d + "'", double46 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 34.92964198704039d + "'", double70 == 34.92964198704039d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector17.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor35 = null;
        try {
            double double36 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector49 = blockRealMatrix47.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector51 = blockRealMatrix47.getColumnVector((int) (short) 1);
        try {
            double double52 = arrayRealVector17.dotProduct(realVector51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtractToSelf((double) 1.0000001f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector20.copy();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}");
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        java.lang.StringBuffer stringBuffer4 = null;
        java.text.FieldPosition fieldPosition5 = null;
        try {
            java.lang.StringBuffer stringBuffer6 = realVectorFormat0.format(realVector3, stringBuffer4, fieldPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.Number number0 = null;
        double[] doubleArray5 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray10 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray15 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray20 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray25 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray30 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray31 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        double[][] doubleArray32 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (-1766139745));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        float[] floatArray6 = new float[] { 1.0f, (byte) 10, (byte) 1, (-3455093127129143767L), '#', 1 };
        float[] floatArray13 = new float[] { 1.0000001f, 10L, 1, 5, 1L, (-52) };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray13);
        float[] floatArray21 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray22 = null;
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(floatArray21, floatArray22);
        float[] floatArray30 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray31 = null;
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(floatArray30, floatArray31);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray22, floatArray30);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray30);
        float[] floatArray41 = new float[] { 1.0f, (byte) 10, (byte) 1, (-3455093127129143767L), '#', 1 };
        float[] floatArray48 = new float[] { 1.0000001f, 10L, 1, 5, 1L, (-52) };
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equals(floatArray41, floatArray48);
        float[] floatArray56 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray57 = null;
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(floatArray56, floatArray57);
        float[] floatArray65 = new float[] { (short) 1, (-1), '#', 0, 100, 1L };
        float[] floatArray66 = null;
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equals(floatArray65, floatArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray57, floatArray65);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray41, floatArray65);
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray65);
        float[] floatArray71 = null;
        boolean boolean72 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray65, floatArray71);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.getColumnMatrix(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = defaultRealMatrixPreservingVisitor8.end();
        double double10 = blockRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        double double11 = defaultRealMatrixPreservingVisitor8.end();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9702919135521215d + "'", double1 == 3.9702919135521215d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence> sparseRealMatrixPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence>((org.apache.commons.math3.linear.SparseRealMatrix) openMapRealMatrix3, (java.lang.CharSequence) "{");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray11 = array2DRowRealMatrix9.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        boolean boolean13 = array2DRowRealMatrix12.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix12.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) realMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x10 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence> sparseRealMatrixPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence>((org.apache.commons.math3.linear.SparseRealMatrix) openMapRealMatrix3, (java.lang.CharSequence) "{");
        try {
            openMapRealMatrix3.addToEntry((-1869155408), (int) (short) 1, (double) 1.1920929E-7f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        int int4 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = openMapRealMatrix7.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix8.copy();
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix8);
        org.junit.Assert.assertNotNull(openMapRealMatrix9);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        boolean boolean12 = array2DRowRealMatrix11.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix11.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = array2DRowRealMatrix11.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        double double16 = defaultRealMatrixPreservingVisitor14.end();
        double double17 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        blockRealMatrix2.multiplyEntry(0, 52, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.RealVector realVector7 = blockRealMatrix4.getRowVector(0);
        double double8 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        boolean boolean15 = array2DRowRealMatrix14.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double18 = array2DRowRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        double double19 = defaultRealMatrixPreservingVisitor17.end();
        defaultRealMatrixPreservingVisitor17.visit((int) (short) 10, 36, 4.641588833612779d);
        try {
            double double28 = blockRealMatrix4.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17, (int) (byte) -1, 30000, (int) (short) -1, (-1869155408));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector87, false);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor90 = null;
        try {
            double double93 = arrayRealVector89.walkInOptimizedOrder(realVectorChangingVisitor90, 1493912448, (-1869155408));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,493,912,448)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector86.copy();
        arrayRealVector86.unitize();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(arrayRealVector87);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        double[] doubleArray7 = blockRealMatrix2.getRow(0);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, 1.5395564933646284d, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-1.0f), (float) 52, (float) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector17.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor87 = null;
        try {
            double double88 = arrayRealVector49.walkInOptimizedOrder(realVectorPreservingVisitor87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[][] doubleArray5 = array2DRowRealMatrix2.getDataRef();
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        double[] doubleArray22 = new double[] { '#' };
        double[] doubleArray25 = new double[] { 100, (byte) 10 };
        double double26 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray22, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) (-1), true);
        double[] doubleArray30 = pointValuePair29.getKey();
        double[] doubleArray31 = pointValuePair29.getFirst();
        double[] doubleArray32 = pointValuePair29.getKey();
        double[] doubleArray38 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        int int40 = org.apache.commons.math3.util.MathUtils.hash(doubleArray38);
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray38);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, 2.2250738585072014E-308d);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray50 = array2DRowRealMatrix48.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray50);
        try {
            double[] doubleArray52 = array2DRowRealMatrix2.operate(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 65.0d + "'", double26 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1766139745) + "'", int40 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        arrayRealVector17.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(realVector35);
        int int39 = arrayRealVector38.getDimension();
        boolean boolean40 = arrayRealVector38.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector38.copy();
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        double double59 = realVector56.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector61 = realVector56.mapAdd((double) (-1));
        double double62 = arrayRealVector41.dotProduct(realVector61);
        double[] doubleArray68 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector69 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray68);
        realVector69.unitize();
        double[] doubleArray76 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector77 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray76);
        realVector77.unitize();
        double double79 = realVector69.cosine(realVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(realVector77);
        int int81 = arrayRealVector80.getDimension();
        boolean boolean82 = arrayRealVector80.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector80.copy();
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector83.mapMultiply(Double.NaN);
        double double86 = arrayRealVector41.cosine(realVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector20.ebeDivide(realVector85);
        org.apache.commons.math3.linear.RealVector realVector89 = arrayRealVector87.mapAddToSelf((-0.9783565731117827d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.007035801295960806d + "'", double59 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-0.554912086407338d) + "'", double62 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0000000000000002d + "'", double79 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 5 + "'", int81 == 5);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertNotNull(realVector89);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getPoint();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) '4', doubleArray10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) ' ', (int) (short) 1);
        try {
            array2DRowRealMatrix5.setRowMatrix((int) (byte) 0, realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 32x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 35, 30000);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3, (-1207516062), (int) (short) 10, (int) (short) 10, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,207,516,062)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(3, (int) (byte) -1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        java.lang.Double[] doubleArray4 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        double double6 = arrayRealVector5.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector5.mapDivideToSelf((double) (short) 10);
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        realVector15.unitize();
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        realVector23.unitize();
        double double25 = realVector15.cosine(realVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(realVector23);
        int int27 = arrayRealVector26.getDimension();
        boolean boolean28 = arrayRealVector26.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector26.copy();
        double[] doubleArray35 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        realVector36.unitize();
        double[] doubleArray43 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector44 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray43);
        realVector44.unitize();
        double double46 = realVector36.cosine(realVector44);
        double double47 = realVector44.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector49 = realVector44.mapAdd((double) (-1));
        double double50 = arrayRealVector29.dotProduct(realVector49);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector5.append(realVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction53 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector52.map(univariateFunction53);
        try {
            blockRealMatrix2.setColumnVector(1500420478, (org.apache.commons.math3.linear.RealVector) arrayRealVector54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0000000000000002d + "'", double25 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0000000000000002d + "'", double46 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.007035801295960806d + "'", double47 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-0.554912086407338d) + "'", double50 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector54);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = org.apache.commons.math3.util.FastMath.max(1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.492385186467945d, (java.lang.Number) 0.04350032773179846d, (int) ' ', orderDirection3, false);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = nonMonotonicSequenceException5.getContext();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double[] doubleArray1 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister();
        byte[] byteArray9 = new byte[] { (byte) -1 };
        mersenneTwister7.nextBytes(byteArray9);
        byte[] byteArray12 = new byte[] { (byte) 1 };
        mersenneTwister7.nextBytes(byteArray12);
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker15 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double[] doubleArray18 = new double[] { '#' };
        double[] doubleArray21 = new double[] { 100, (byte) 10 };
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray18, doubleArray21);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray18, (double) (-1), true);
        double[] doubleArray26 = pointValuePair25.getPoint();
        double[] doubleArray28 = new double[] { '#' };
        double[] doubleArray31 = new double[] { 100, (byte) 10 };
        double double32 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1), true);
        double[] doubleArray36 = pointValuePair35.getKey();
        double[] doubleArray37 = pointValuePair35.getFirst();
        java.lang.Double double38 = pointValuePair35.getSecond();
        double[] doubleArray39 = pointValuePair35.getFirst();
        boolean boolean41 = pointValuePair35.equals((java.lang.Object) (-52));
        boolean boolean42 = simpleValueChecker15.converged((int) (short) -1, pointValuePair25, pointValuePair35);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer43 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1500420478, doubleArray1, 0, (double) (short) -1, true, (int) 'a', (int) 'a', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker15);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction45 = null;
        org.apache.commons.math3.optimization.GoalType goalType46 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray48 = new double[] { '#' };
        double[] doubleArray51 = new double[] { 100, (byte) 10 };
        double double52 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray48, doubleArray51);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair55 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray48, (double) (-1), true);
        double[] doubleArray56 = pointValuePair55.getKey();
        double[] doubleArray57 = pointValuePair55.getFirst();
        java.lang.Double double58 = pointValuePair55.getSecond();
        double[] doubleArray59 = pointValuePair55.getPointRef();
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = cMAESOptimizer43.optimize(36, multivariateFunction45, goalType46, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 65.0d + "'", double22 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 65.0d + "'", double32 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + goalType46 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType46.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 65.0d + "'", double52 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-1.0d) + "'", double58.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        double[] doubleArray19 = null;
        double[] doubleArray21 = new double[] { '#' };
        double[] doubleArray24 = new double[] { 100, (byte) 10 };
        double double25 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray21, doubleArray24);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) (-1), true);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray21);
        try {
            double[] doubleArray30 = array2DRowRealMatrix14.preMultiply(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 65.0d + "'", double25 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(5, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        int int5 = cMAESOptimizer1.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker6 = cMAESOptimizer1.getConvergenceChecker();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList7 = cMAESOptimizer1.getStatisticsDHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList8 = cMAESOptimizer1.getStatisticsMeanHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList9 = cMAESOptimizer1.getStatisticsMeanHistory();
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker6);
        org.junit.Assert.assertNotNull(realMatrixList7);
        org.junit.Assert.assertNotNull(realMatrixList8);
        org.junit.Assert.assertNotNull(realMatrixList9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((-1766139745), (int) (short) 0, 2.718281828459045d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        double[][] doubleArray9 = array2DRowRealMatrix6.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor10.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double18 = array2DRowRealMatrix6.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        double double19 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = blockRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor20, (int) (byte) 0, (-52), 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getCount();
        try {
            incrementor0.incrementCount(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence> sparseRealMatrixPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence>((org.apache.commons.math3.linear.SparseRealMatrix) openMapRealMatrix3, (java.lang.CharSequence) "{");
        openMapRealMatrix3.setEntry(3, 0, 1.1368683772161603E-13d);
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getPoint();
        java.lang.Double double10 = pointValuePair8.getValue();
        double[] doubleArray11 = pointValuePair8.getPoint();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
//        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
//        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
//        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
//        realVector14.unitize();
//        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
//        realVector22.unitize();
//        double double24 = realVector14.cosine(realVector22);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(realVector22);
//        int int26 = arrayRealVector25.getDimension();
//        boolean boolean27 = arrayRealVector25.isInfinite();
//        double double28 = arrayRealVector25.getMaxValue();
//        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
//        org.apache.commons.math3.linear.RealMatrix realMatrix36 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
//        double[] doubleArray38 = new double[] { '#' };
//        double[] doubleArray41 = new double[] { 100, (byte) 10 };
//        double double42 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray38, doubleArray41);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair45 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray38, (double) (-1), true);
//        double[] doubleArray46 = pointValuePair45.getKey();
//        double[] doubleArray47 = pointValuePair45.getFirst();
//        double[] doubleArray48 = pointValuePair45.getKey();
//        double[] doubleArray54 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
//        org.apache.commons.math3.linear.RealVector realVector55 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray54);
//        int int56 = org.apache.commons.math3.util.MathUtils.hash(doubleArray54);
//        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray48, doubleArray54);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray54, 2.2250738585072014E-308d);
//        boolean boolean60 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray54);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray54);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister67 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray69 = new byte[] { (byte) -1 };
//        mersenneTwister67.nextBytes(byteArray69);
//        double double71 = mersenneTwister67.nextGaussian();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister72 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray74 = new byte[] { (byte) -1 };
//        mersenneTwister72.nextBytes(byteArray74);
//        mersenneTwister67.nextBytes(byteArray74);
//        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker80 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) (-1), (double) 0.0f);
//        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer81 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 1, doubleArray54, 35, (double) (-1766139745), false, (-52), (-1), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister67, true, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker80);
//        try {
//            array2DRowRealMatrix5.setRow(1493912449, doubleArray54);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,493,912,449)");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertNotNull(realVector14);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(realVector22);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0000000000000002d + "'", double24 == 1.0000000000000002d);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.7035801295960805d + "'", double28 == 0.7035801295960805d);
//        org.junit.Assert.assertNotNull(doubleArray34);
//        org.junit.Assert.assertNotNull(realVector35);
//        org.junit.Assert.assertNotNull(realMatrix36);
//        org.junit.Assert.assertNotNull(doubleArray38);
//        org.junit.Assert.assertNotNull(doubleArray41);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 65.0d + "'", double42 == 65.0d);
//        org.junit.Assert.assertNotNull(doubleArray46);
//        org.junit.Assert.assertNotNull(doubleArray47);
//        org.junit.Assert.assertNotNull(doubleArray48);
//        org.junit.Assert.assertNotNull(doubleArray54);
//        org.junit.Assert.assertNotNull(realVector55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1766139745) + "'", int56 == (-1766139745));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(byteArray69);
//        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.2661774984372158d + "'", double71 == 1.2661774984372158d);
//        org.junit.Assert.assertNotNull(byteArray74);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int4 = nonSymmetricMatrixException3.getRow();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) nonSymmetricMatrixException3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray20 = array2DRowRealMatrix18.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        boolean boolean22 = array2DRowRealMatrix21.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix21.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = array2DRowRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        double double26 = defaultRealMatrixPreservingVisitor24.end();
        double double27 = array2DRowRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray32 = array2DRowRealMatrix30.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix33.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix33.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = array2DRowRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        double double38 = defaultRealMatrixPreservingVisitor36.end();
        defaultRealMatrixPreservingVisitor36.visit((int) (short) 10, 36, 4.641588833612779d);
        double double43 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        double[] doubleArray45 = new double[] { '#' };
        double[] doubleArray48 = new double[] { 100, (byte) 10 };
        double double49 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray45, doubleArray48);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection50 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray48, orderDirection50, false, true);
        try {
            double[] doubleArray54 = array2DRowRealMatrix5.preMultiply(doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 65.0d + "'", double49 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((-52), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray20 = array2DRowRealMatrix18.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        boolean boolean22 = array2DRowRealMatrix21.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix21.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = array2DRowRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        double double26 = defaultRealMatrixPreservingVisitor24.end();
        double double27 = array2DRowRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        defaultRealMatrixPreservingVisitor24.start(1, (int) (short) 10, 0, (-1207516062), (int) (short) -1, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.554912086407338d, (double) '#', (double) (-52), 168.5422962509616d, (double) 35, (double) 52.0f, (double) 1766139745L, 100.00153962526598d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7661668680359717E11d + "'", double8 == 1.7661668680359717E11d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        boolean boolean70 = arrayRealVector68.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        double double73 = arrayRealVector68.getL1Norm();
        double[] doubleArray79 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector80 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray79);
        realVector80.unitize();
        double[] doubleArray87 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector88 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray87);
        realVector88.unitize();
        double double90 = realVector80.cosine(realVector88);
        double double91 = realVector88.getMinValue();
        double double92 = realVector88.getMinValue();
        org.apache.commons.math3.linear.RealMatrix realMatrix93 = arrayRealVector68.outerProduct(realVector88);
        org.apache.commons.math3.linear.RealVector realVector95 = arrayRealVector68.mapDivide(0.01822927178041715d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.554912086407338d + "'", double73 == 1.554912086407338d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.0000000000000002d + "'", double90 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.007035801295960806d + "'", double91 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.007035801295960806d + "'", double92 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realMatrix93);
        org.junit.Assert.assertNotNull(realVector95);
    }
}

