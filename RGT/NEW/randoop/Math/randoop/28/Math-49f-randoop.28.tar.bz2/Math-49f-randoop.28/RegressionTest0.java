import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 10, (int) '#');
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) '4', (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.009614495783374d + "'", double2 == 52.009614495783374d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction15 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector14.map(univariateRealFunction15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double[] doubleArray22 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        double[] doubleArray25 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector23.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector9.add(openMapRealVector28);
        double double30 = openMapRealVector2.getDistance(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.356194490192345d + "'", double2 == 2.356194490192345d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix26.walkInRowOrder(realMatrixChangingVisitor27, 0, (int) (short) 10, (-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.18961709723636588d + "'", double0 == 0.18961709723636588d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray27 = new double[] {};
        try {
            double[] doubleArray28 = array2DRowRealMatrix26.preMultiply(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) -1, (-1.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector30.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector37.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray44 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44);
        double[] doubleArray47 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector45.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        double[] doubleArray54 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector52.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector48.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        double double58 = openMapRealVector57.getLInfNorm();
        openMapRealVector57.set((double) '4');
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector41.add((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        try {
            array2DRowRealMatrix26.setRowVector(100, realVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        double[] doubleArray35 = new double[] { (-0.8813735870195429d), 0.18961709723636588d, ' ', (byte) 10, 100.00000000000001d, (short) -1 };
        try {
            double[] doubleArray36 = array2DRowRealMatrix26.preMultiply(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        double[] doubleArray25 = new double[] { 1.0d, 100L };
        try {
            double double26 = openMapRealVector2.cosine(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0);
        double[] doubleArray5 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector6.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector9);
        double[] doubleArray12 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector13.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double34 = openMapRealVector33.getLInfNorm();
        openMapRealVector33.set((double) '4');
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector17.add((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        try {
            org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector1.combineToSelf((double) (byte) 100, (double) (-1.0f), realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector6.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector9);
        java.lang.Object[] objArray13 = new java.lang.Object[] { false, 10L, 100.0f, openMapRealVector9, 0, 52.009614495783374d };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray13);
        java.lang.Throwable[] throwableArray15 = mathArithmeticException14.getSuppressed();
        try {
            java.lang.String str16 = mathArithmeticException14.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix26.walkInRowOrder(realMatrixPreservingVisitor27, 35, (int) ' ', 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        float float1 = org.apache.commons.math.util.FastMath.ulp(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        try {
            double[] doubleArray31 = array2DRowRealMatrix26.operate(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray33 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray39 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray45 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray51 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray52 = new double[][] { doubleArray33, doubleArray39, doubleArray45, doubleArray51 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52, false);
        try {
            array2DRowRealMatrix26.setColumnMatrix(10, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        int[] intArray62 = new int[] { 100, (byte) 100, (short) 0, (short) -1 };
        int[] intArray68 = new int[] { 35, 32, 100, '4', (byte) 0 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix69 = array2DRowRealMatrix26.getSubMatrix(intArray62, intArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction15 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector13.map(univariateRealFunction15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.RealMatrix realMatrix87 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix26.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector13.getSubVector((int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (9)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        double[] doubleArray44 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector42.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector45.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector35.add(openMapRealVector54);
        double double56 = openMapRealVector32.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        double[] doubleArray68 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector66.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        double[] doubleArray75 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector73.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector69.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector59.add(openMapRealVector78);
        org.apache.commons.math.linear.RealVector realVector80 = openMapRealVector54.add((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray82 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray82);
        double double84 = openMapRealVector59.dotProduct(doubleArray82);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = openMapRealVector59.mapAddToSelf((double) (byte) 100);
        try {
            org.apache.commons.math.linear.RealVector realVector87 = array2DRowRealMatrix28.operate((org.apache.commons.math.linear.RealVector) openMapRealVector86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(openMapRealVector79);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0d + "'", double84 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector86);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52, (double) 100L);
        double[] doubleArray62 = new double[] { (short) 0, (byte) 100, (-1.0f), (byte) 10, 10 };
        try {
            double double63 = openMapRealVector56.getLInfDistance(doubleArray62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix26.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(97, 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor58 = null;
        try {
            double double63 = array2DRowRealMatrix55.walkInColumnOrder(realMatrixPreservingVisitor58, (int) (short) 1, (int) (short) -1, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        try {
            double[] doubleArray30 = array2DRowRealMatrix26.operate(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix28.walkInColumnOrder(realMatrixPreservingVisitor30, (int) (short) -1, (int) 'a', (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double29 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        try {
            org.apache.commons.math.linear.RealVector realVector30 = array2DRowRealMatrix28.getRowVector(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.18961709723636588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = null;
        try {
            double double24 = openMapRealVector2.dotProduct(openMapRealVector23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtract((double) 1);
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray5 = new double[] { 100 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = openMapRealVector0.outerProduct(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 0.0f, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 0);
        double double3 = openIntToDoubleHashMap1.get(0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        try {
            double double5 = iterator4.value();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        try {
            openMapRealMatrix2.addToEntry((int) '4', 1, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        int int27 = array2DRowRealMatrix26.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double29 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        try {
            double[] doubleArray28 = array2DRowRealMatrix26.getRow(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double double9 = openMapRealMatrix5.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector10.mapSubtract((double) 1);
        double double13 = openMapRealVector10.getMaxValue();
        try {
            org.apache.commons.math.linear.RealVector realVector14 = openMapRealMatrix5.preMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 35");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        int[] intArray9 = new int[] { (short) -1, (short) 0 };
        int[] intArray11 = new int[] { '#' };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = openMapRealMatrix2.getSubMatrix(intArray9, intArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = openMapRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor20, 97, (int) (short) -1, 97, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor29, (int) ' ', (int) ' ', 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        boolean boolean28 = array2DRowRealMatrix26.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix26.createMatrix((int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = openMapRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor8, (int) 'a', 10, (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double double9 = openMapRealMatrix5.getEntry(5, 5);
        try {
            double double10 = openMapRealMatrix5.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (35x10) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix24 = openMapRealMatrix19.getSubMatrix(0, (-1), (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 0);
        double double3 = openIntToDoubleHashMap1.get(0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        try {
            int int5 = iterator4.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        double[] doubleArray14 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray20 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray26 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray33 = new double[][] { doubleArray14, doubleArray20, doubleArray26, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33, false);
        double[] doubleArray41 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray47 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray53 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray59 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray60 = new double[][] { doubleArray41, doubleArray47, doubleArray53, doubleArray59 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, false);
        double[][] doubleArray65 = array2DRowRealMatrix64.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix66 = array2DRowRealMatrix35.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix64);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix67 = openMapRealMatrix5.multiply(realMatrix66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix66);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix28.createMatrix((int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        double[] doubleArray22 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        try {
            openMapRealMatrix19.setColumn((int) ' ', doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        try {
            openMapRealMatrix2.setColumnMatrix(97, (org.apache.commons.math.linear.RealMatrix) openMapRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray29 = new double[] { 52.009614495783374d, (byte) -1 };
        try {
            double[] doubleArray30 = array2DRowRealMatrix26.operate(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        try {
            array2DRowRealMatrix26.addToEntry((int) (short) 100, (int) (byte) 1, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor58 = null;
        try {
            double double63 = array2DRowRealMatrix26.walkInRowOrder(realMatrixChangingVisitor58, (int) (byte) 10, (int) (byte) 1, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        try {
            double double5 = openMapRealMatrix2.getEntry(10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.833336070820506d + "'", double1 == 11.833336070820506d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-1.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1, 0.18961709723636588d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = openMapRealMatrix5.walkInRowOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector25.add(openMapRealVector44);
        double double46 = openMapRealVector22.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector56.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector49.add(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector44.add((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        double double74 = openMapRealVector49.dotProduct(doubleArray72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector77 = openMapRealVector14.combine((double) (-1), (double) 1.4E-45f, (org.apache.commons.math.linear.RealVector) openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector14.unitVector();
        int int79 = openMapRealVector14.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        double[] doubleArray33 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray39 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray45 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray51 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray52 = new double[][] { doubleArray33, doubleArray39, doubleArray45, doubleArray51 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52, false);
        try {
            array2DRowRealMatrix26.setSubMatrix(doubleArray52, (int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        double[][] doubleArray60 = array2DRowRealMatrix28.getDataRef();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor61 = null;
        try {
            double double66 = array2DRowRealMatrix28.walkInColumnOrder(realMatrixChangingVisitor61, (int) '4', (int) (byte) 10, (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double double7 = openMapRealMatrix2.getNorm();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = openMapRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 97, 1.4E-45f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix28.getColumnMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        try {
            double double31 = array2DRowRealMatrix26.getEntry((-1), (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double double51 = openMapRealVector24.getLInfNorm();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction52 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector24.map(univariateRealFunction52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double[] doubleArray9 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9);
        double[] doubleArray12 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector13.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        double[] doubleArray22 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector20.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        double[] doubleArray26 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26);
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector27.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector23.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector13.add(openMapRealVector32);
        double double34 = openMapRealVector10.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector37.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector51.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector37.add(openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector32.add((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        double[] doubleArray60 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray60);
        double double62 = openMapRealVector37.dotProduct(doubleArray60);
        try {
            openMapRealMatrix5.setRow(100, doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = openMapRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.getRowMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        boolean boolean51 = openMapRealVector24.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = null;
        try {
            double double8 = openMapRealVector6.getL1Distance(openMapRealVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix28.scalarAdd(208.0384579831335d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor62 = null;
        try {
            double double63 = array2DRowRealMatrix28.walkInOptimizedOrder(realMatrixPreservingVisitor62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realMatrix61);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 0, 1);
        java.lang.Number number3 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float2 = org.apache.commons.math.util.FastMath.copySign(10.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        double[][] doubleArray60 = array2DRowRealMatrix28.getDataRef();
        try {
            double double61 = array2DRowRealMatrix28.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x5) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix28.getSubMatrix((int) (byte) 10, 32, 5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor7, 100, (-1), 5, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        try {
            openMapRealMatrix2.addToEntry((int) (short) -1, 0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        double[] doubleArray16 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector14.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector14.add(openMapRealVector33);
        double double35 = openMapRealVector11.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        double[] doubleArray40 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector38.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray44 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44);
        double[] doubleArray47 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector45.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        double[] doubleArray54 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector52.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector48.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector38.add(openMapRealVector57);
        org.apache.commons.math.linear.RealVector realVector59 = openMapRealVector33.add((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        double double63 = openMapRealVector38.dotProduct(doubleArray61);
        try {
            openMapRealMatrix7.setRowVector(10, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 1x10");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        int int8 = openMapRealMatrix7.getRowDimension();
        try {
            openMapRealMatrix7.multiplyEntry((int) (byte) 1, 97, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        boolean boolean61 = array2DRowRealMatrix28.equals((java.lang.Object) 1L);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor62 = null;
        try {
            double double63 = array2DRowRealMatrix28.walkInRowOrder(realMatrixPreservingVisitor62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix6.subtract(openMapRealMatrix9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealMatrix9.getColumnVector(0);
        try {
            openMapRealMatrix2.setRowMatrix((int) (short) 1, (org.apache.commons.math.linear.RealMatrix) openMapRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 35x10 but expected 1x10");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray60 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray60);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector61.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.RealVector realVector67 = openMapRealVector65.mapMultiply((double) 10L);
        double[] doubleArray68 = openMapRealVector65.getData();
        try {
            double[] doubleArray69 = array2DRowRealMatrix28.preMultiply(doubleArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = openMapRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math.util.FastMath.hypot(52.00000000000001d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.95280917949491d + "'", double2 == 52.95280917949491d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 0);
        double double4 = openIntToDoubleHashMap2.get(0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator5 = openIntToDoubleHashMap2.iterator();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException8 = new org.apache.commons.math.exception.DimensionMismatchException(97, 10);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        java.lang.Object[] objArray22 = new java.lang.Object[] { false, 10L, 100.0f, openMapRealVector18, 0, 52.009614495783374d };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException23 = new org.apache.commons.math.exception.MathArithmeticException(localizable9, objArray22);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext24 = mathArithmeticException23.getContext();
        double[] doubleArray26 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26);
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector27.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        double[] doubleArray33 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray33);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector34.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector30.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        double double40 = openMapRealVector39.getLInfNorm();
        openMapRealVector39.set((double) '4');
        java.lang.Object[] objArray45 = new java.lang.Object[] { openIntToDoubleHashMap2, 97, exceptionContext24, openMapRealVector39, 100.00000000000001d, (-0.8813735870195429d) };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException46 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray45);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext47 = mathArithmeticException46.getContext();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(exceptionContext24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(exceptionContext47);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.util.FastMath.copySign(11.833336070820506d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.833336070820506d + "'", double2 == 11.833336070820506d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        boolean boolean28 = array2DRowRealMatrix26.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor29, (int) '#', 0, (int) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 35, number2, (java.lang.Number) 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 97, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix5.createMatrix(0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        double[] doubleArray37 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray43 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray49 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray55 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray56 = new double[][] { doubleArray37, doubleArray43, doubleArray49, doubleArray55 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56, false);
        double[][] doubleArray61 = array2DRowRealMatrix60.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray61);
        try {
            array2DRowRealMatrix26.copySubMatrix(0, (int) (short) 0, (int) (short) 100, (int) (byte) -1, doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector6.mapMultiply((double) 10L);
        java.lang.Class<?> wildcardClass9 = openMapRealVector6.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 0);
        double double3 = openIntToDoubleHashMap1.get(0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        try {
            iterator4.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        double[] doubleArray8 = new double[] { 208.0384579831335d };
        double[] doubleArray10 = new double[] { 208.0384579831335d };
        double[] doubleArray12 = new double[] { 208.0384579831335d };
        double[] doubleArray14 = new double[] { 208.0384579831335d };
        double[] doubleArray16 = new double[] { 208.0384579831335d };
        double[] doubleArray18 = new double[] { 208.0384579831335d };
        double[][] doubleArray19 = new double[][] { doubleArray8, doubleArray10, doubleArray12, doubleArray14, doubleArray16, doubleArray18 };
        try {
            openMapRealMatrix2.copySubMatrix((int) (short) 10, (int) (byte) 0, 35, (int) (short) 0, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: initial row 10 after final row 0");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 100, (int) (short) 1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor90 = null;
        try {
            double double91 = array2DRowRealMatrix30.walkInRowOrder(realMatrixPreservingVisitor90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        boolean boolean58 = array2DRowRealMatrix55.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor59 = null;
        try {
            double double64 = array2DRowRealMatrix55.walkInRowOrder(realMatrixPreservingVisitor59, (int) (short) -1, (int) (byte) 100, (int) 'a', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        try {
            array2DRowRealMatrix26.setEntry((-1), (int) (short) -1, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix28.scalarAdd(208.0384579831335d);
        try {
            array2DRowRealMatrix28.multiplyEntry((int) (byte) -1, (int) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realMatrix61);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor59 = null;
        try {
            double double60 = array2DRowRealMatrix28.walkInRowOrder(realMatrixChangingVisitor59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix91 = array2DRowRealMatrix30.getRowMatrix(32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 10, 1);
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        java.lang.Number number5 = dimensionMismatchException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.floor(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (byte) 100, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector24.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long1 = org.apache.commons.math.util.FastMath.round(Double.NaN);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        boolean boolean28 = array2DRowRealMatrix26.isSquare();
        double double29 = array2DRowRealMatrix26.getNorm();
        try {
            double[] doubleArray31 = array2DRowRealMatrix26.getColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 208.0384579831335d + "'", double29 == 208.0384579831335d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        double double53 = openMapRealVector52.getLInfNorm();
        openMapRealVector52.set((double) '4');
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double double59 = openMapRealVector52.getL1Distance(doubleArray57);
        double double60 = openMapRealVector28.cosine(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector2.append(doubleArray57);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector64.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double[] doubleArray73 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = openMapRealVector67.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        double double77 = openMapRealVector76.getLInfNorm();
        int int78 = openMapRealVector76.getMinIndex();
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector61.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 53.0d + "'", double59 == 53.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(openMapRealVector76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        try {
            array2DRowRealMatrix28.multiplyEntry((int) (short) 100, (-1), (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtract((double) 1);
        double double3 = openMapRealVector0.getMaxValue();
        int int4 = openMapRealVector0.getDimension();
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector8.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = openMapRealVector12.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector22.add(openMapRealVector41);
        double double43 = openMapRealVector19.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector46.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector53.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector60.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector56.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = openMapRealVector46.add(openMapRealVector65);
        org.apache.commons.math.linear.RealVector realVector67 = openMapRealVector41.add((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        double[] doubleArray69 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69);
        double double71 = openMapRealVector46.dotProduct(doubleArray69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector15.add(doubleArray69);
        try {
            openMapRealVector0.setSubVector((int) (byte) -1, (org.apache.commons.math.linear.RealVector) openMapRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(openMapRealVector66);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertNotNull(realVector74);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor90 = null;
        try {
            double double95 = array2DRowRealMatrix30.walkInColumnOrder(realMatrixPreservingVisitor90, (int) (short) 100, (int) 'a', 0, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.875409442231813E-18d + "'", double1 == 3.875409442231813E-18d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor35 = null;
        try {
            double double36 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixChangingVisitor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector51.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        double double57 = openMapRealVector56.getLInfNorm();
        openMapRealVector56.set((double) '4');
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector40.add((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double double64 = openMapRealVector40.cosine(doubleArray62);
        double double65 = openMapRealVector2.getDistance(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-1.0d) + "'", double64 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) 1, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47381939152118063d + "'", double1 == 0.47381939152118063d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        int int20 = openMapRealMatrix19.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = openMapRealMatrix19.transpose();
        double[] doubleArray27 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray33 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray39 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray45 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray46 = new double[][] { doubleArray27, doubleArray33, doubleArray39, doubleArray45 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix53 = openMapRealMatrix19.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        double double21 = openMapRealVector14.getL1Distance(doubleArray19);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor22 = openMapRealVector14.iterator();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction23 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector14.map(univariateRealFunction23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 53.0d + "'", double21 == 53.0d);
        org.junit.Assert.assertNotNull(entryItor22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        double double21 = openMapRealVector14.getL1Distance(doubleArray19);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction22 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector14.mapToSelf(univariateRealFunction22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 53.0d + "'", double21 == 53.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = openMapRealMatrix6.multiply(realMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        int int20 = openMapRealMatrix19.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double26 = openMapRealMatrix19.walkInRowOrder(realMatrixChangingVisitor21, (int) '#', 1, 97, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float2 = org.apache.commons.math.util.FastMath.scalb(35.000004f, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.500002f + "'", float2 == 17.500002f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.356194490192345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.550724074197761d + "'", double1 == 10.550724074197761d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 10);
        double double3 = openIntToDoubleHashMap1.get((int) '#');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-1.0d), 52.009614495783374d, 52.009614495783374d, 0.0d, 10.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29, (double) 0L);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector29.mapSubtractToSelf((double) (byte) 1);
        boolean boolean57 = openMapRealVector29.isInfinite();
        double[] doubleArray58 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector29.ebeDivide(doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        try {
            array2DRowRealMatrix26.multiplyEntry((int) '4', 35, (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-1.0d), 52.009614495783374d, 52.009614495783374d, 0.0d, 10.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray6, (double) 0L);
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector8.mapDivideToSelf(11.833336070820506d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (byte) 10, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        double[][] doubleArray60 = array2DRowRealMatrix28.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor61 = null;
        try {
            double double62 = array2DRowRealMatrix28.walkInColumnOrder(realMatrixPreservingVisitor61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixChangingVisitor28, (int) (short) 1, (int) (short) -1, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 35, 52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.681735776859284d + "'", double2 == 62.681735776859284d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.exp(62.681735776859284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6685221024501446E27d + "'", double1 == 1.6685221024501446E27d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        try {
            array2DRowRealMatrix57.setColumn((int) '#', doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector29.mapMultiply((double) 10L);
        double[] doubleArray32 = openMapRealVector29.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector21.projection(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        try {
            array2DRowRealMatrix57.setEntry(5, 0, (-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = openMapRealMatrix21.walkInRowOrder(realMatrixChangingVisitor29, 0, (int) (byte) 1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray64 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray70 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray76 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray82 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray83 = new double[][] { doubleArray64, doubleArray70, doubleArray76, doubleArray82 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83, false);
        double double86 = array2DRowRealMatrix85.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix57.add(array2DRowRealMatrix85);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix89 = array2DRowRealMatrix57.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x5) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 208.0384579831335d + "'", double86 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        double double53 = openMapRealVector52.getLInfNorm();
        openMapRealVector52.set((double) '4');
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double double59 = openMapRealVector52.getL1Distance(doubleArray57);
        double double60 = openMapRealVector28.cosine(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector2.append(doubleArray57);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        double[] doubleArray68 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector66.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector72 = openMapRealVector70.mapMultiply((double) 10L);
        double[] doubleArray74 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray74);
        double[] doubleArray77 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector75.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        double[] doubleArray81 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray81);
        double[] doubleArray84 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray84);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = openMapRealVector82.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = openMapRealVector78.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector86);
        double double88 = openMapRealVector87.getLInfNorm();
        openMapRealVector87.set((double) '4');
        double[] doubleArray92 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector93 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray92);
        double double94 = openMapRealVector87.getL1Distance(doubleArray92);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray92, (double) 97.0f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector97 = openMapRealVector70.projection(doubleArray92);
        org.apache.commons.math.linear.RealVector realVector98 = openMapRealVector2.combineToSelf((double) 100L, (double) 100, (org.apache.commons.math.linear.RealVector) openMapRealVector97);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 53.0d + "'", double59 == 53.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(openMapRealVector79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(openMapRealVector86);
        org.junit.Assert.assertNotNull(openMapRealVector87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0d + "'", double88 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 53.0d + "'", double94 == 53.0d);
        org.junit.Assert.assertNotNull(openMapRealVector97);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector2.getMinValue();
        try {
            openMapRealVector2.setEntry((int) (short) 1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        double double21 = openMapRealVector14.getL1Distance(doubleArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 53.0d + "'", double21 == 53.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52, (double) 100L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector56.mapAddToSelf(1.0d);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector56.mapMultiply((double) 5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(realVector60);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.18961709723636588d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0019548129454512136d + "'", double2 == 0.0019548129454512136d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        try {
            double double35 = array2DRowRealMatrix26.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x5) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector25.add(openMapRealVector44);
        double double46 = openMapRealVector22.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector56.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector49.add(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector44.add((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        double double74 = openMapRealVector49.dotProduct(doubleArray72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector77 = openMapRealVector14.combine((double) (-1), (double) 1.4E-45f, (org.apache.commons.math.linear.RealVector) openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector14.unitVector();
        double double79 = openMapRealVector14.getSparsity();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector14);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 0, 1);
        java.lang.String str3 = dimensionMismatchException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: 0 != 1" + "'", str3.equals("org.apache.commons.math.exception.DimensionMismatchException: 0 != 1"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = array2DRowRealMatrix61.transpose();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor31 = null;
        try {
            double double32 = array2DRowRealMatrix30.walkInColumnOrder(realMatrixPreservingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        try {
            double double92 = array2DRowRealMatrix86.getEntry(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor64 = null;
        try {
            double double69 = array2DRowRealMatrix63.walkInColumnOrder(realMatrixChangingVisitor64, 0, 10, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double2 = org.apache.commons.math.util.FastMath.copySign(97.0d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = openMapRealVector2.getData();
        openMapRealVector2.set(62.681735776859284d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor30 = openMapRealVector2.iterator();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(entryItor30);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector25.add(openMapRealVector44);
        double double46 = openMapRealVector22.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector56.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector49.add(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector44.add((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        double double74 = openMapRealVector49.dotProduct(doubleArray72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector77 = openMapRealVector14.combine((double) (-1), (double) 1.4E-45f, (org.apache.commons.math.linear.RealVector) openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector14.unitVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = openMapRealVector14.append((double) 0L);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector80.getSubVector(10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(openMapRealVector80);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.6685221024501446E27d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7348460601518245E-43d + "'", double2 == 1.7348460601518245E-43d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector5.sparseIterator();
        double double16 = openMapRealVector5.getMinValue();
        int int17 = openMapRealVector5.getDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(entryItor15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536743164063946E-7d + "'", double1 == 9.536743164063946E-7d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix32.subtract(openMapRealMatrix35);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealMatrix35.getColumnVector(0);
        try {
            openMapRealMatrix5.setColumnVector((int) (byte) 10, realVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594700892207039d + "'", double1 == 4.594700892207039d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1.0f), 9.536743164063946E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.536743164063946E-7d + "'", double2 == 9.536743164063946E-7d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        double[] doubleArray58 = null;
        try {
            double double59 = openMapRealVector54.getDistance(doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector16.mapSubtract((double) 9.536743E-7f);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector31.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector21.add(openMapRealVector40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector51.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        double[] doubleArray68 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector66.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = openMapRealVector62.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector70);
        double double72 = openMapRealVector71.getLInfNorm();
        openMapRealVector71.set((double) '4');
        double[] doubleArray76 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray76);
        double double78 = openMapRealVector71.getL1Distance(doubleArray76);
        double double79 = openMapRealVector47.cosine(doubleArray76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = openMapRealVector21.append(doubleArray76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = openMapRealVector16.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double[] doubleArray82 = openMapRealVector16.toArray();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(openMapRealVector71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 53.0d + "'", double78 == 53.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector80);
        org.junit.Assert.assertNotNull(openMapRealVector81);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        double[][] doubleArray30 = array2DRowRealMatrix28.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor31 = null;
        try {
            double double36 = array2DRowRealMatrix28.walkInOptimizedOrder(realMatrixPreservingVisitor31, (-1), (int) (short) 0, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4677992676220695d + "'", double1 == 1.4677992676220695d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector66);
        double[] doubleArray69 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = openMapRealVector70.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector73);
        double[] doubleArray76 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray76);
        double[] doubleArray79 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray79);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = openMapRealVector77.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector80);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = openMapRealVector73.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector81);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector63.add(openMapRealVector82);
        double double84 = openMapRealVector60.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector82);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector82.mapSubtractToSelf(100.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = openMapRealVector24.append(realVector86);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector90 = openMapRealVector88.mapSubtract((double) 1);
        boolean boolean91 = openMapRealVector24.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(openMapRealVector74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(openMapRealVector81);
        org.junit.Assert.assertNotNull(openMapRealVector82);
        org.junit.Assert.assertNotNull(openMapRealVector83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(openMapRealVector87);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 5);
        double double3 = openIntToDoubleHashMap1.get((int) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(97, (int) (byte) 100);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(97, Double.NaN);
        double double4 = openIntToDoubleHashMap2.get((int) ' ');
        double double7 = openIntToDoubleHashMap2.put((int) (byte) 1, 52.95280917949491d);
        boolean boolean9 = openIntToDoubleHashMap2.containsKey((int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        boolean boolean28 = array2DRowRealMatrix26.isSquare();
        double double29 = array2DRowRealMatrix26.getNorm();
        double double32 = array2DRowRealMatrix26.getEntry((int) (short) 0, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 208.0384579831335d + "'", double29 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double double21 = openMapRealVector19.getEntry(0);
        double double22 = openMapRealVector19.getL1Norm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector13.add((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        int int24 = openMapRealVector19.getDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 10, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) '4', 11.833336070820506d);
        boolean boolean3 = openMapRealVector2.isNaN();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        try {
            array2DRowRealMatrix63.multiplyEntry(0, (int) '4', (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector54);
        int int59 = openMapRealVector54.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector((int) '4', 11.833336070820506d);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector11.add(openMapRealVector30);
        double double32 = openMapRealVector8.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        double[] doubleArray44 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector42.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector45.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector35.add(openMapRealVector54);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector30.add((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        openMapRealVector30.unitize();
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        double double62 = openMapRealVector60.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector30.add(openMapRealVector60);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector30.mapAdd(53.0d);
        double double66 = openMapRealVector5.getL1Distance(openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector2.add(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector67);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor31 = null;
        try {
            double double36 = array2DRowRealMatrix30.walkInRowOrder(realMatrixPreservingVisitor31, (int) (short) -1, (int) (byte) 1, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double double51 = openMapRealVector24.getL1Norm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector24.unitVector();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector52);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 100, 35);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(5.267884728309446d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.732115271690554d) + "'", double2 == (-4.732115271690554d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, 100.00000000000001d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector2.getMaxValue();
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double double34 = openMapRealVector32.getEntry(0);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector37.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        double[] doubleArray54 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector52.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector55.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector63);
        double double65 = openMapRealVector64.getLInfNorm();
        openMapRealVector64.set((double) '4');
        double[] doubleArray69 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69);
        double double71 = openMapRealVector64.getL1Distance(doubleArray69);
        double double72 = openMapRealVector40.cosine(doubleArray69);
        double double73 = openMapRealVector32.dotProduct(doubleArray69);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector2.combine(0.0d, 0.47381939152118063d, doubleArray69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-1.0d) + "'", double34 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 53.0d + "'", double71 == 53.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(realVector74);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector29.mapSubtract((double) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector5.sparseIterator();
        double double16 = openMapRealVector5.getL1Norm();
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector5.mapSubtract(0.0019548129454512136d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(entryItor15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor58 = null;
        try {
            double double63 = array2DRowRealMatrix55.walkInRowOrder(realMatrixChangingVisitor58, 32, 0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector24.mapAdd(53.0d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor60 = openMapRealVector59.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertNotNull(entryItor60);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray12 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray18 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray24 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray25 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        double[][] doubleArray30 = array2DRowRealMatrix29.getData();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double[] doubleArray9 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9);
        double[] doubleArray12 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector10.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double[] doubleArray16 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16);
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector17.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector13.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double double23 = openMapRealVector22.getLInfNorm();
        openMapRealVector22.set((double) '4');
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector33.add(openMapRealVector52);
        double double54 = openMapRealVector30.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray56 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56);
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector57.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector60);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector64.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double[] doubleArray73 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = openMapRealVector67.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector57.add(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector52.add((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        double[] doubleArray80 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80);
        double double82 = openMapRealVector57.dotProduct(doubleArray80);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector22.combine((double) (-1), (double) 1.4E-45f, (org.apache.commons.math.linear.RealVector) openMapRealVector84);
        try {
            openMapRealMatrix2.setColumnVector(0, realVector85);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(openMapRealVector76);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertNotNull(realVector85);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = openMapRealMatrix7.scalarMultiply(572.9577951308232d);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        try {
            array2DRowRealMatrix61.multiplyEntry(0, (int) 'a', (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double2 = org.apache.commons.math.util.FastMath.scalb(3.875409442231813E-18d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.875409442231813E-18d + "'", double2 == 3.875409442231813E-18d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix32.subtract(openMapRealMatrix35);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix36.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix38 = openMapRealMatrix28.add(openMapRealMatrix37);
        int int39 = openMapRealMatrix38.getRowDimension();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
        org.junit.Assert.assertNotNull(openMapRealMatrix38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 35 + "'", int39 == 35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int1 = org.apache.commons.math.util.FastMath.abs(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        int int20 = openMapRealMatrix19.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = openMapRealMatrix19.transpose();
        int[] intArray23 = new int[] { (short) 1 };
        int[] intArray27 = new int[] { 100, ' ', 35 };
        double[][] doubleArray28 = null;
        try {
            openMapRealMatrix19.copySubMatrix(intArray23, intArray27, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector6.mapMultiply((double) 10L);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector14.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        double double24 = openMapRealVector23.getLInfNorm();
        openMapRealVector23.set((double) '4');
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double double30 = openMapRealVector23.getL1Distance(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28, (double) 97.0f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector6.projection(doubleArray28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor34 = openMapRealVector6.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 53.0d + "'", double30 == 53.0d);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(entryItor34);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        try {
            openMapRealMatrix21.multiplyEntry(35, (int) '4', (double) 1.4E-45f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double double21 = openMapRealVector19.getEntry(0);
        double double22 = openMapRealVector19.getL1Norm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector13.add((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double double24 = openMapRealVector19.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector6.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector9);
        java.lang.Object[] objArray13 = new java.lang.Object[] { false, 10L, 100.0f, openMapRealVector9, 0, 52.009614495783374d };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException14.getContext();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector29.mapAddToSelf((double) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector57.unitVector();
        double[] doubleArray60 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray60);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector61.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.RealVector realVector67 = openMapRealVector65.mapMultiply((double) 10L);
        double[] doubleArray68 = openMapRealVector65.getData();
        double double69 = openMapRealVector58.cosine(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        int int28 = array2DRowRealMatrix26.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 10, (java.lang.Number) 100.0f, (java.lang.Number) (short) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double double65 = openMapRealVector63.getEntry(0);
        double[] doubleArray67 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = openMapRealVector68.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector71);
        double[] doubleArray74 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray74);
        double[] doubleArray77 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector75.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector79);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor81 = openMapRealVector71.sparseIterator();
        double double82 = openMapRealVector63.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector71);
        org.apache.commons.math.linear.RealVector realVector84 = openMapRealVector71.mapDivide(0.47381939152118063d);
        try {
            array2DRowRealMatrix28.setRowVector((int) (short) 10, (org.apache.commons.math.linear.RealVector) openMapRealVector71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-1.0d) + "'", double65 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(openMapRealVector72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(openMapRealVector79);
        org.junit.Assert.assertNotNull(openMapRealVector80);
        org.junit.Assert.assertNotNull(entryItor81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(realVector84);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        double[] doubleArray33 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray39 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray45 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray51 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray52 = new double[][] { doubleArray33, doubleArray39, doubleArray45, doubleArray51 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52, false);
        try {
            array2DRowRealMatrix26.setSubMatrix(doubleArray52, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) '4', 11.833336070820506d);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector8.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector8.add(openMapRealVector27);
        double double29 = openMapRealVector5.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector46.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector42.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector32.add(openMapRealVector51);
        org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector27.add((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        openMapRealVector27.unitize();
        double[] doubleArray56 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56);
        double double59 = openMapRealVector57.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector27.add(openMapRealVector57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector27.mapAdd(53.0d);
        double double63 = openMapRealVector2.getL1Distance(openMapRealVector27);
        org.apache.commons.math.linear.RealVector realVector65 = null;
        try {
            openMapRealVector2.setSubVector((int) (short) 1, realVector65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-1.0d) + "'", double59 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double double4 = openMapRealVector2.getEntry(0);
        double[] doubleArray6 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray6);
        double[] doubleArray9 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = openMapRealVector7.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        double[] doubleArray16 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector14.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector10.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        double double35 = openMapRealVector34.getLInfNorm();
        openMapRealVector34.set((double) '4');
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double double41 = openMapRealVector34.getL1Distance(doubleArray39);
        double double42 = openMapRealVector10.cosine(doubleArray39);
        double double43 = openMapRealVector2.dotProduct(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(openMapRealVector11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 53.0d + "'", double41 == 53.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix25 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix22.subtract(openMapRealMatrix25);
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealMatrix25.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = openMapRealMatrix14.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix25);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor59 = null;
        try {
            double double60 = array2DRowRealMatrix57.walkInRowOrder(realMatrixChangingVisitor59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double double21 = openMapRealVector19.getEntry(0);
        double double22 = openMapRealVector19.getL1Norm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector13.add((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        int int24 = openMapRealVector13.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap0 = new org.apache.commons.math.util.OpenIntToDoubleHashMap();
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator1 = openIntToDoubleHashMap0.iterator();
        double double3 = openIntToDoubleHashMap0.get((-1));
        org.junit.Assert.assertNotNull(iterator1);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector2.getMinValue();
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector33.add(openMapRealVector52);
        double double54 = openMapRealVector30.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray56 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56);
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector57.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector60);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector64.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double[] doubleArray73 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = openMapRealVector67.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector57.add(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector52.add((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        double[] doubleArray80 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80);
        double double82 = openMapRealVector57.dotProduct(doubleArray80);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80, (double) 100L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector2.subtract(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(openMapRealVector76);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector85);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(52.009614495783374d);
        boolean boolean3 = openIntToDoubleHashMap1.containsKey((int) '4');
        double double6 = openIntToDoubleHashMap1.put(100, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.009614495783374d + "'", double6 == 52.009614495783374d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 97.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 100, (int) (short) 100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtract((double) 1);
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray5 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double[] doubleArray22 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        double[] doubleArray25 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector23.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector9.add(openMapRealVector28);
        double double30 = openMapRealVector6.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector33.add(openMapRealVector52);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector28.add((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        openMapRealVector28.unitize();
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double double60 = openMapRealVector58.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector28.add(openMapRealVector58);
        try {
            double double62 = openMapRealVector0.dotProduct((org.apache.commons.math.linear.RealVector) openMapRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector61);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix28.scalarAdd((double) 0.0f);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector64.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double[] doubleArray73 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = openMapRealVector67.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        double double77 = openMapRealVector76.getL1Norm();
        try {
            array2DRowRealMatrix28.setRowVector(100, (org.apache.commons.math.linear.RealVector) openMapRealVector76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(openMapRealVector76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        int int8 = openMapRealMatrix7.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix10 = openMapRealMatrix7.getColumnMatrix(1);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math.util.FastMath.hypot(62.681735776859284d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.68971207462993d + "'", double2 == 62.68971207462993d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        double double33 = openMapRealVector31.getEntry(0);
        double double34 = openMapRealVector31.getL1Norm();
        boolean boolean35 = openMapRealMatrix5.equals((java.lang.Object) double34);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-0.8813735870195429d));
        double double3 = openIntToDoubleHashMap1.remove(10);
        double double5 = openIntToDoubleHashMap1.get(100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.8813735870195429d) + "'", double3 == (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.8813735870195429d) + "'", double5 == (-0.8813735870195429d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor59 = null;
        try {
            double double60 = array2DRowRealMatrix57.walkInColumnOrder(realMatrixPreservingVisitor59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor58 = null;
        try {
            double double63 = array2DRowRealMatrix55.walkInColumnOrder(realMatrixChangingVisitor58, 32, 32, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray64 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray70 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray76 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray82 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray83 = new double[][] { doubleArray64, doubleArray70, doubleArray76, doubleArray82 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = array2DRowRealMatrix28.subtract(array2DRowRealMatrix85);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix86);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix32.subtract(openMapRealMatrix35);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix36.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix38 = openMapRealMatrix28.add(openMapRealMatrix37);
        double[] doubleArray44 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray50 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray56 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray62 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray63 = new double[][] { doubleArray44, doubleArray50, doubleArray56, doubleArray62 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray63, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix66 = openMapRealMatrix38.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
        org.junit.Assert.assertNotNull(openMapRealMatrix38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector25.add(openMapRealVector44);
        double double46 = openMapRealVector22.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector56.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector49.add(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector44.add((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray72 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72);
        double double74 = openMapRealVector49.dotProduct(doubleArray72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray72, (double) 100L);
        org.apache.commons.math.linear.RealVector realVector77 = openMapRealVector14.combine((double) (-1), (double) 1.4E-45f, (org.apache.commons.math.linear.RealVector) openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector14.unitVector();
        double[] doubleArray80 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80);
        double[] doubleArray83 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray83);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector81.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector84);
        double double86 = openMapRealVector84.getMinValue();
        double double87 = openMapRealVector78.dotProduct((org.apache.commons.math.linear.RealVector) openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector89 = openMapRealVector84.mapSubtract(62.68971207462993d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + (-1.0d) + "'", double86 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-1.0d) + "'", double87 == (-1.0d));
        org.junit.Assert.assertNotNull(realVector89);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 0L, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector2.getMaxValue();
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 10.0d, (-1.0d), 52.009614495783374d, 52.009614495783374d, 0.0d, 10.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34, (double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector2.append((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector37);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996159447946292d + "'", double1 == 0.9996159447946292d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(3.875409442231813E-18d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector6.mapMultiply((double) 10L);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector14.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        double double24 = openMapRealVector23.getLInfNorm();
        openMapRealVector23.set((double) '4');
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double double30 = openMapRealVector23.getL1Distance(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28, (double) 97.0f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector6.projection(doubleArray28);
        double double34 = openMapRealVector33.getSparsity();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 53.0d + "'", double30 == 53.0d);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(0, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.add(openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        double double53 = openMapRealVector52.getLInfNorm();
        openMapRealVector52.set((double) '4');
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double double59 = openMapRealVector52.getL1Distance(doubleArray57);
        double double60 = openMapRealVector28.cosine(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector2.append(doubleArray57);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector2.getSubVector((int) '4', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 53.0d + "'", double59 == 53.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.550724074197761d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector13.getNorm();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapToSelf(univariateRealFunction16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(52.00000000000001d, (-2.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = openMapRealVector6.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector9);
        double[] doubleArray18 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray24 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray30 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray36 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray37 = new double[][] { doubleArray18, doubleArray24, doubleArray30, doubleArray36 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37, false);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix39.transpose();
        double[] doubleArray45 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        boolean boolean47 = array2DRowRealMatrix39.equals((java.lang.Object) doubleArray45);
        try {
            org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector9.combine((double) 9.536743E-7f, (double) 32L, doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix26.getColumnVector((int) (short) 1);
        try {
            double double29 = array2DRowRealMatrix26.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x5) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 62.681735776859284d, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) 10.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector29.mapAddToSelf((double) (byte) 100);
        boolean boolean57 = openMapRealVector56.isNaN();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix32.subtract(openMapRealMatrix35);
        double double39 = openMapRealMatrix35.getEntry(5, 5);
        double double40 = openMapRealMatrix35.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix41 = openMapRealMatrix28.multiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 35");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.6685221024501446E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.912120433005317E25d + "'", double1 == 2.912120433005317E25d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        try {
            double double9 = openMapRealMatrix5.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (35x10) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        double[][] doubleArray60 = array2DRowRealMatrix28.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = openMapRealMatrix5.createMatrix((int) (byte) 10, (int) (byte) 1);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix35 = openMapRealMatrix31.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 10x1 but expected 35x10");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix31);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor28, (int) (short) 100, (int) (byte) 1, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-1.0d), 52.009614495783374d, 52.009614495783374d, 0.0d, 10.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray6, (double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray6, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = openMapRealMatrix5.createMatrix((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.875409442231813E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix28.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix28.scalarAdd(208.0384579831335d);
        double[] doubleArray71 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray77 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray83 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray89 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray90 = new double[][] { doubleArray71, doubleArray77, doubleArray83, doubleArray89 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix92 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray90, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray90, true);
        try {
            array2DRowRealMatrix28.copySubMatrix((int) '#', (int) 'a', (int) 'a', (int) ' ', doubleArray90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector24.mapAdd(53.0d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor60 = openMapRealVector59.iterator();
        org.apache.commons.math.linear.RealVector realVector61 = null;
        try {
            double double62 = openMapRealVector59.getDistance(realVector61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertNotNull(entryItor60);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int2 = org.apache.commons.math.util.FastMath.min(5, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor31 = null;
        try {
            double double32 = array2DRowRealMatrix30.walkInColumnOrder(realMatrixPreservingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        int[] intArray32 = new int[] { 32, (-1) };
        int[] intArray37 = new int[] { (short) 1, 'a', (short) 0, (short) 0 };
        double[] doubleArray43 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray49 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray55 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray61 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray62 = new double[][] { doubleArray43, doubleArray49, doubleArray55, doubleArray61 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, false);
        double[][] doubleArray67 = array2DRowRealMatrix66.getData();
        try {
            array2DRowRealMatrix28.copySubMatrix(intArray32, intArray37, doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 10, 1.7348460601518245E-43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        openMapRealVector24.unitize();
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double double56 = openMapRealVector54.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector24.add(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector57.mapAddToSelf((double) 97);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(openMapRealVector59);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor64 = null;
        try {
            double double65 = array2DRowRealMatrix61.walkInOptimizedOrder(realMatrixPreservingVisitor64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor90 = null;
        try {
            double double95 = array2DRowRealMatrix86.walkInRowOrder(realMatrixChangingVisitor90, (int) '4', 35, (int) (short) 1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        int int20 = openMapRealMatrix14.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix22 = openMapRealMatrix14.power((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (35x10) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double double46 = openMapRealVector45.getLInfNorm();
        openMapRealVector45.set((double) '4');
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        double double52 = openMapRealVector45.getL1Distance(doubleArray50);
        try {
            array2DRowRealMatrix28.setRow(1, doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 1x5");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 53.0d + "'", double52 == 53.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 9.536743E-7f, 0.47381939152118063d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47381939152214037d + "'", double2 == 0.47381939152214037d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.868551121099462d + "'", double1 == 1.868551121099462d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, Double.NaN);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealMatrix5.getRowVector(5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = openMapRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 10);
        double double3 = openIntToDoubleHashMap1.get(10);
        double double6 = openIntToDoubleHashMap1.put((int) (short) 0, 10.0d);
        int int7 = openIntToDoubleHashMap1.size();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double double27 = openMapRealVector2.getMaxValue();
        double[] doubleArray29 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray29);
        double[] doubleArray32 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector30.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector37.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector33.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double double43 = openMapRealVector41.getNorm();
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector46.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double[] doubleArray55 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector53.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        double double59 = openMapRealVector58.getLInfNorm();
        openMapRealVector58.set((double) '4');
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double double65 = openMapRealVector58.getL1Distance(doubleArray63);
        double double66 = openMapRealVector41.getDistance(doubleArray63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector2.projection(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 53.0d + "'", double65 == 53.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 2.0d + "'", double66 == 2.0d);
        org.junit.Assert.assertNotNull(openMapRealVector67);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor58 = null;
        try {
            double double63 = array2DRowRealMatrix55.walkInOptimizedOrder(realMatrixChangingVisitor58, 1, (int) (short) 0, (int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        int int20 = openMapRealMatrix19.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = openMapRealMatrix19.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix23 = openMapRealMatrix19.scalarMultiply((double) (-1.0f));
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.633123935319537E16d + "'", double1 == 1.633123935319537E16d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', 1.6685221024501446E27d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double double27 = array2DRowRealMatrix26.getNorm();
        boolean boolean28 = array2DRowRealMatrix26.isSquare();
        double double29 = array2DRowRealMatrix26.getNorm();
        int[] intArray32 = new int[] { 32, (byte) -1 };
        int[] intArray33 = new int[] {};
        double[] doubleArray39 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray45 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray51 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray57 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray58 = new double[][] { doubleArray39, doubleArray45, doubleArray51, doubleArray57 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        double[][] doubleArray63 = array2DRowRealMatrix62.getData();
        double[][] doubleArray64 = array2DRowRealMatrix62.getDataRef();
        try {
            array2DRowRealMatrix26.copySubMatrix(intArray32, intArray33, doubleArray64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 208.0384579831335d + "'", double27 == 208.0384579831335d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 208.0384579831335d + "'", double29 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 52.95280917949491d, (java.lang.Number) (byte) 100, (java.lang.Number) 1);
        try {
            java.lang.String str5 = outOfRangeException4.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 0, 97);
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        try {
            java.lang.String str5 = dimensionMismatchException3.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap0 = new org.apache.commons.math.util.OpenIntToDoubleHashMap();
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator1 = openIntToDoubleHashMap0.iterator();
        try {
            int int2 = iterator1.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector16.mapSubtract((double) 9.536743E-7f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.mapAddToSelf(1.5430806348152437d);
        double[] doubleArray21 = openMapRealVector20.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        try {
            double double2 = openMapRealVector0.getEntry(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector5.sparseIterator();
        double double16 = openMapRealVector5.getL1Norm();
        double double17 = openMapRealVector5.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(entryItor15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1L), (double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector13.getNorm();
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double double31 = openMapRealVector30.getLInfNorm();
        openMapRealVector30.set((double) '4');
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double double37 = openMapRealVector30.getL1Distance(doubleArray35);
        double double38 = openMapRealVector13.getDistance(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 53.0d + "'", double37 == 53.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) '4', 11.833336070820506d);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector8.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector8.add(openMapRealVector27);
        double double29 = openMapRealVector5.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector32.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector46.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector42.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector32.add(openMapRealVector51);
        org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector27.add((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        openMapRealVector27.unitize();
        double[] doubleArray56 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56);
        double double59 = openMapRealVector57.getEntry(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector27.add(openMapRealVector57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector27.mapAdd(53.0d);
        double double63 = openMapRealVector2.getL1Distance(openMapRealVector27);
        double double64 = openMapRealVector27.getNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-1.0d) + "'", double59 == (-1.0d));
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double double9 = openMapRealMatrix5.getEntry(5, 5);
        double double10 = openMapRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = openMapRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) 'a', 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(100);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        try {
            array2DRowRealMatrix28.setEntry(35, (int) (short) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray36 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray42 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray48 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray54 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double[] doubleArray63 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray69 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray75 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray81 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray82 = new double[][] { doubleArray63, doubleArray69, doubleArray75, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix57.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix86);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix30.subtract(array2DRowRealMatrix86);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor90 = null;
        try {
            double double95 = array2DRowRealMatrix86.walkInRowOrder(realMatrixPreservingVisitor90, (int) (short) -1, (int) (short) 10, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray64 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray70 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray76 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray82 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray83 = new double[][] { doubleArray64, doubleArray70, doubleArray76, doubleArray82 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83, false);
        double double86 = array2DRowRealMatrix85.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix57.add(array2DRowRealMatrix85);
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix87.copy();
        try {
            array2DRowRealMatrix87.setEntry(1, 35, (double) 35.000004f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 208.0384579831335d + "'", double86 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
        org.junit.Assert.assertNotNull(realMatrix88);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(11.833336070820506d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.set((double) '4');
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor18 = openMapRealVector14.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(entryItor18);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector6.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector9);
        java.lang.Object[] objArray13 = new java.lang.Object[] { false, 10L, 100.0f, openMapRealVector9, 0, 52.009614495783374d };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray13);
        java.lang.Throwable[] throwableArray15 = mathArithmeticException14.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = mathArithmeticException14.getContext();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector2.mapDivide((double) 0L);
        double double29 = openMapRealVector2.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector29.mapSubtractToSelf((double) (byte) 1);
        boolean boolean57 = openMapRealVector29.isInfinite();
        double[] doubleArray59 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        double[] doubleArray62 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector60.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        double[] doubleArray69 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = openMapRealVector67.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = openMapRealVector63.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector71);
        double double73 = openMapRealVector72.getLInfNorm();
        int int74 = openMapRealVector72.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector29.add(openMapRealVector72);
        double[] doubleArray78 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray78);
        double[] doubleArray81 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray81);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector79.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector82);
        double[] doubleArray85 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray85);
        double[] doubleArray88 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray88);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector90 = openMapRealVector86.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector89);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = openMapRealVector82.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector93 = openMapRealVector90.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector95 = openMapRealVector93.mapSubtract((double) 9.536743E-7f);
        try {
            openMapRealVector29.setSubVector((int) (short) 10, realVector95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(openMapRealVector71);
        org.junit.Assert.assertNotNull(openMapRealVector72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(openMapRealVector83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(openMapRealVector90);
        org.junit.Assert.assertNotNull(openMapRealVector91);
        org.junit.Assert.assertNotNull(openMapRealVector93);
        org.junit.Assert.assertNotNull(realVector95);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray64 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray70 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray76 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray82 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray83 = new double[][] { doubleArray64, doubleArray70, doubleArray76, doubleArray82 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83, false);
        double double86 = array2DRowRealMatrix85.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix57.add(array2DRowRealMatrix85);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix91 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix94 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix95 = openMapRealMatrix91.subtract(openMapRealMatrix94);
        org.apache.commons.math.linear.RealVector realVector97 = openMapRealMatrix94.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix98 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix94);
        try {
            array2DRowRealMatrix85.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix) openMapRealMatrix98);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 35x10 but expected 1x5");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 208.0384579831335d + "'", double86 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
        org.junit.Assert.assertNotNull(openMapRealMatrix95);
        org.junit.Assert.assertNotNull(realVector97);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double double15 = openMapRealVector14.getLInfNorm();
        openMapRealVector14.unitize();
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        double[] doubleArray25 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray25);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector26.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector22.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        double double32 = openMapRealVector31.getLInfNorm();
        openMapRealVector31.set((double) '4');
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double double38 = openMapRealVector31.getL1Distance(doubleArray36);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor39 = openMapRealVector31.iterator();
        double double40 = openMapRealVector14.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        boolean boolean41 = openMapRealVector31.isInfinite();
        double double42 = openMapRealVector31.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 53.0d + "'", double38 == 53.0d);
        org.junit.Assert.assertNotNull(entryItor39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 53.0d + "'", double40 == 53.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.0d + "'", double42 == 52.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double double7 = openMapRealVector2.getLInfNorm();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.map(univariateRealFunction8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        int int30 = openMapRealMatrix29.getColumnDimension();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix28.walkInColumnOrder(realMatrixPreservingVisitor30, 97, (int) '4', (int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector13.mapMultiplyToSelf(1.6685221024501446E27d);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector32.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector35.mapSubtract((double) 9.536743E-7f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.mapAddToSelf(1.5430806348152437d);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector13.combineToSelf(52.009614495783374d, 0.47381939152214037d, (org.apache.commons.math.linear.RealVector) openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        double double30 = openMapRealMatrix28.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        double double18 = openMapRealMatrix14.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix5.subtract(openMapRealMatrix14);
        try {
            openMapRealMatrix19.addToEntry((int) 'a', (int) 'a', 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        double[] doubleArray39 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector40.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        double[] doubleArray49 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        double[] doubleArray56 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector54.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector50.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector40.add(openMapRealVector59);
        double double61 = openMapRealVector37.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        double[] doubleArray63 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray63);
        double[] doubleArray66 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = openMapRealVector64.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double[] doubleArray73 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector71.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector74);
        double[] doubleArray77 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray77);
        double[] doubleArray80 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray80);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = openMapRealVector78.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector81);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector74.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector82);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector64.add(openMapRealVector83);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector59.add((org.apache.commons.math.linear.RealVector) openMapRealVector64);
        double[] doubleArray87 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray87);
        double double89 = openMapRealVector64.dotProduct(doubleArray87);
        double[] doubleArray90 = openMapRealVector64.getData();
        try {
            double[] doubleArray91 = array2DRowRealMatrix26.preMultiply(doubleArray90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(openMapRealVector68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(openMapRealVector82);
        org.junit.Assert.assertNotNull(openMapRealVector83);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0d + "'", double89 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, true);
        int int29 = array2DRowRealMatrix28.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix28.walkInRowOrder(realMatrixPreservingVisitor30, (int) (byte) 0, 0, (int) (short) 100, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector16.mapSubtract((double) 9.536743E-7f);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector31.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector21.add(openMapRealVector40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        double[] doubleArray46 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        double[] doubleArray53 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector51.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector47.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        double[] doubleArray61 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector59.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        double[] doubleArray65 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray65);
        double[] doubleArray68 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector66.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = openMapRealVector62.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector70);
        double double72 = openMapRealVector71.getLInfNorm();
        openMapRealVector71.set((double) '4');
        double[] doubleArray76 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray76);
        double double78 = openMapRealVector71.getL1Distance(doubleArray76);
        double double79 = openMapRealVector47.cosine(doubleArray76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = openMapRealVector21.append(doubleArray76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = openMapRealVector16.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        org.apache.commons.math.linear.RealVector realVector82 = null;
        try {
            double double83 = openMapRealVector21.getDistance(realVector82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(openMapRealVector71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 53.0d + "'", double78 == 53.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector80);
        org.junit.Assert.assertNotNull(openMapRealVector81);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 10);
        double double3 = openIntToDoubleHashMap1.get((int) '#');
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap4 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap1);
        double double6 = openIntToDoubleHashMap1.get(0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double[] doubleArray64 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray70 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray76 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray82 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray83 = new double[][] { doubleArray64, doubleArray70, doubleArray76, doubleArray82 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83, false);
        double double86 = array2DRowRealMatrix85.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix57.add(array2DRowRealMatrix85);
        org.apache.commons.math.linear.RealMatrix realMatrix88 = array2DRowRealMatrix87.copy();
        double[][] doubleArray89 = array2DRowRealMatrix87.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 208.0384579831335d + "'", double86 == 208.0384579831335d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.subtract(openMapRealMatrix12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealMatrix12.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix18.subtract(openMapRealMatrix21);
        double double25 = openMapRealMatrix21.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix12.subtract(openMapRealMatrix21);
        int int27 = openMapRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix5.add(openMapRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix28);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix32.subtract(openMapRealMatrix35);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix43 = openMapRealMatrix39.subtract(openMapRealMatrix42);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealMatrix42.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix51 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = openMapRealMatrix48.subtract(openMapRealMatrix51);
        double double55 = openMapRealMatrix51.getEntry(5, 5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix56 = openMapRealMatrix42.subtract(openMapRealMatrix51);
        int int57 = openMapRealMatrix51.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = openMapRealMatrix35.add(openMapRealMatrix51);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix59 = openMapRealMatrix29.subtract(openMapRealMatrix58);
        double[] doubleArray61 = openMapRealMatrix59.getColumn(0);
        double[] doubleArray64 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray64);
        double[] doubleArray67 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray67);
        double[] doubleArray70 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = openMapRealVector68.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector71);
        double[] doubleArray74 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray74);
        double[] doubleArray77 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector75.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        double[] doubleArray81 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray81);
        double[] doubleArray84 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray84);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = openMapRealVector82.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = openMapRealVector78.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector86);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = openMapRealVector68.add(openMapRealVector87);
        double double89 = openMapRealVector65.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector87);
        org.apache.commons.math.linear.RealVector realVector91 = openMapRealVector87.mapSubtractToSelf(100.0d);
        try {
            openMapRealMatrix59.setColumnVector(5, realVector91);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix43);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealMatrix52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix58);
        org.junit.Assert.assertNotNull(openMapRealMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(openMapRealVector72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(openMapRealVector79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(openMapRealVector86);
        org.junit.Assert.assertNotNull(openMapRealVector87);
        org.junit.Assert.assertNotNull(openMapRealVector88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(realVector91);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix28.walkInRowOrder(realMatrixPreservingVisitor30, 35, 0, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix26.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = openMapRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10, (int) (byte) 1, 32, (int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        double double9 = openMapRealMatrix5.getEntry(5, 5);
        double double10 = openMapRealMatrix5.getFrobeniusNorm();
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13, 52.00000000000001d);
        try {
            openMapRealMatrix5.setColumn(0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtract((double) 1);
        double double3 = openMapRealVector0.getMaxValue();
        int int4 = openMapRealVector0.getDimension();
        double[] doubleArray6 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray6);
        double[] doubleArray9 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9);
        double[] doubleArray12 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector10.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        double[] doubleArray16 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16);
        double[] doubleArray19 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector17.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        double[] doubleArray26 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector20.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector10.add(openMapRealVector29);
        double double31 = openMapRealVector7.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray33 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray33);
        double[] doubleArray36 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector34.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        double[] doubleArray40 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray40);
        double[] doubleArray43 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector41.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector44);
        double[] doubleArray47 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray47);
        double[] doubleArray50 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector48.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector44.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector34.add(openMapRealVector53);
        org.apache.commons.math.linear.RealVector realVector55 = openMapRealVector29.add((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double double59 = openMapRealVector34.dotProduct(doubleArray57);
        double[] doubleArray60 = openMapRealVector34.getData();
        double double61 = openMapRealVector0.getDistance(openMapRealVector34);
        double[] doubleArray62 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector63 = openMapRealVector0.add(doubleArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealMatrix5.getColumnVector(0);
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealMatrix5.getRowVector(5);
        double[][] doubleArray11 = openMapRealMatrix5.getData();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector13.mapMultiplyToSelf((double) 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) ' ', 0, (-0.8414709848078965d));
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double[] doubleArray24 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector25.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector11.add(openMapRealVector30);
        double double32 = openMapRealVector8.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        double[] doubleArray34 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        double[] doubleArray37 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector35.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        double[] doubleArray41 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41);
        double[] doubleArray44 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector42.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        double[] doubleArray48 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray48);
        double[] doubleArray51 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector49.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector45.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector35.add(openMapRealVector54);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector30.add((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double[] doubleArray58 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray58);
        double double60 = openMapRealVector35.dotProduct(doubleArray58);
        try {
            org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector3.combine(52.0d, (double) (-1L), doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray40 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray46 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray52 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray53 = new double[][] { doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53, false);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix28.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix28.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor61 = null;
        try {
            double double66 = array2DRowRealMatrix28.walkInOptimizedOrder(realMatrixPreservingVisitor61, (int) '4', 0, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix60);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray5 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray11 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray17 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray23 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.transpose();
        double[] doubleArray32 = new double[] { 208.0384579831335d, 100.0d, (-0.8813735870195429d), (short) 1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        boolean boolean34 = array2DRowRealMatrix26.equals((java.lang.Object) doubleArray32);
        double[] doubleArray40 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray46 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray52 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray58 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray59 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix61.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix26.add(array2DRowRealMatrix61);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor64 = null;
        try {
            double double65 = array2DRowRealMatrix63.walkInRowOrder(realMatrixChangingVisitor64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        double[][] doubleArray31 = array2DRowRealMatrix30.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix30.transpose();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector6.mapMultiply((double) 10L);
        double[] doubleArray10 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10);
        double[] doubleArray13 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray17 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector18.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector14.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        double double24 = openMapRealVector23.getLInfNorm();
        openMapRealVector23.set((double) '4');
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double double30 = openMapRealVector23.getL1Distance(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28, (double) 97.0f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector6.projection(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 53.0d + "'", double30 == 53.0d);
        org.junit.Assert.assertNotNull(openMapRealVector33);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtract((double) 1);
        double double3 = openMapRealVector0.getMaxValue();
        double double4 = openMapRealVector0.getSparsity();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector13.mapAddToSelf((double) 10L);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector16.mapSubtract((double) 9.536743E-7f);
        double[] doubleArray20 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector21.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector28.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double34 = openMapRealVector33.getLInfNorm();
        openMapRealVector33.set((double) '4');
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        double double40 = openMapRealVector33.getL1Distance(doubleArray38);
        double double41 = openMapRealVector16.getL1Distance(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 53.0d + "'", double40 == 53.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 12.0d + "'", double41 == 12.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix6.copy();
        int int8 = openMapRealMatrix7.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        float float1 = org.apache.commons.math.util.FastMath.abs(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[][] doubleArray29 = array2DRowRealMatrix28.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray36 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray42 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray48 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[] doubleArray54 = new double[] { (byte) 0, 1.0d, (short) 10, 0L, (-1L) };
        double[][] doubleArray55 = new double[][] { doubleArray36, doubleArray42, doubleArray48, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = array2DRowRealMatrix30.add(array2DRowRealMatrix61);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix62);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray5 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray11 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray17 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray23 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray32 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray38 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray44 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[] doubleArray50 = new double[] { 1.0f, 2.356194490192345d, (short) -1, 52.009614495783374d, 2.356194490192345d };
        double[][] doubleArray51 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray56 = array2DRowRealMatrix55.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        boolean boolean58 = array2DRowRealMatrix55.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix55.power(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x5) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector2.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector9.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        double[] doubleArray15 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector16.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        double[] doubleArray23 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray23);
        double[] doubleArray26 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector24.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        double[] doubleArray30 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30);
        double[] doubleArray33 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector31.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector27.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector35);
        double double37 = openMapRealVector36.getLInfNorm();
        openMapRealVector36.set((double) '4');
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector20.add((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double double44 = openMapRealVector20.cosine(doubleArray42);
        double double45 = openMapRealVector6.getL1Distance(openMapRealVector20);
        double[] doubleArray46 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector6.ebeMultiply(doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(openMapRealVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[] doubleArray1 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector5.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray11 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray11);
        double[] doubleArray14 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector12.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        double[] doubleArray18 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray21 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector19.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector5.add(openMapRealVector24);
        double double26 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        double[] doubleArray28 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28);
        double[] doubleArray31 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray35 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        double[] doubleArray38 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector36.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray42 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray45 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector43.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector39.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector29.add(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector24.add((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        double[] doubleArray52 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52);
        double double54 = openMapRealVector29.dotProduct(doubleArray52);
        double[] doubleArray55 = openMapRealVector29.getData();
        double[] doubleArray57 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        double[] doubleArray60 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray60);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector58.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector61);
        double[] doubleArray64 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray64);
        double[] doubleArray67 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector65.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector61.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor71 = openMapRealVector61.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = openMapRealVector29.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector61);
        double[] doubleArray74 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray74);
        double[] doubleArray77 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector75.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        double[] doubleArray81 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray81);
        double[] doubleArray84 = new double[] { (byte) -1 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray84);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = openMapRealVector82.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = openMapRealVector78.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector86);
        double double88 = openMapRealVector86.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = openMapRealVector72.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector86);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector90 = openMapRealVector86.copy();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor91 = openMapRealVector90.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(entryItor71);
        org.junit.Assert.assertNotNull(openMapRealVector72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(openMapRealVector79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(openMapRealVector86);
        org.junit.Assert.assertNotNull(openMapRealVector87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0d + "'", double88 == 1.0d);
        org.junit.Assert.assertNotNull(openMapRealVector89);
        org.junit.Assert.assertNotNull(openMapRealVector90);
        org.junit.Assert.assertNotNull(entryItor91);
    }
}

