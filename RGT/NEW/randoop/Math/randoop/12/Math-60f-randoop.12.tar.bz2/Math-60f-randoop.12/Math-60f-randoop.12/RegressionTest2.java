import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 17.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.0d + "'", double1 == 17.0d);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Number number6 = notStrictlyPositiveException4.getMin();
        java.lang.Number number7 = notStrictlyPositiveException4.getMin();
        java.lang.Number number8 = notStrictlyPositiveException4.getArgument();
        java.lang.Object[] objArray9 = notStrictlyPositiveException4.getArguments();
        convergenceException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Object[] objArray11 = convergenceException2.getArguments();
        java.lang.Throwable[] throwableArray12 = convergenceException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable5, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "org.apache.commons.math.MathException: convergence failed", objArray14);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5d, (java.lang.Number) 4.15912713462618d, false);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test08");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        int int14 = randomDataImpl1.nextInt((int) (short) -1, (int) 'a');
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextWeibull(0.8653943989957588d, (double) 32L);
//        int int21 = randomDataImpl1.nextInt((int) (short) 0, (int) (short) 100);
//        try {
//            int int24 = randomDataImpl1.nextSecureInt((int) ' ', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.019017747916286878d + "'", double8 == 0.019017747916286878d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.048173139692802d + "'", double18 == 10.048173139692802d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 71 + "'", int21 == 71);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
        java.lang.Class<?> wildcardClass7 = numberIsTooLargeException4.getClass();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 10);
//        double double4 = randomDataImpl0.nextChiSquare((double) 93L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6e895ed338" + "'", str2.equals("6e895ed338"));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 71.77552620230897d + "'", double4 == 71.77552620230897d);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "hi!", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray15);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { notStrictlyPositiveException21, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException18, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable0, objArray23);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(4.524077039668076d, 0.010050166663333094d);
//        try {
//            long long14 = randomDataImpl1.nextLong(72L, (long) 15);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 72 is larger than, or equal to, the maximum (15): lower bound (72) must be strictly less than upper bound (15)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1878446581681603d + "'", double6 == 1.1878446581681603d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 13L, 46.09996746528637d);
        double double4 = normalDistributionImpl2.cumulativeProbability(27.067883557646386d);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double8 = normalDistributionImpl2.cumulativeProbability(181.18516357615334d, 86.18396019367208d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6198779966141669d + "'", double4 == 0.6198779966141669d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 46.09996746528637d + "'", double5 == 46.09996746528637d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.42869161795980326d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.44194337622653207d) + "'", double1 == (-0.44194337622653207d));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test17");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        java.lang.Class<?> wildcardClass12 = randomDataImpl1.getClass();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5564973208962347d) + "'", double5 == (-0.5564973208962347d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6645558520752038d + "'", double7 == 0.6645558520752038d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 63L + "'", long9 == 63L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "b0625e3520a7703ce4a2ae5271aaff266d8a94a95456fb92ab9c147fcbdfd8e1fe1f61ca08218f677f8bcf61a92bb20f5fc0" + "'", str11.equals("b0625e3520a7703ce4a2ae5271aaff266d8a94a95456fb92ab9c147fcbdfd8e1fe1f61ca08218f677f8bcf61a92bb20f5fc0"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.010050166663333094d, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943298d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test21");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeedSecure(31L);
//        double double10 = randomDataImpl1.nextChiSquare(51.69314718055995d);
//        randomDataImpl1.reSeed((long) 26);
//        int int15 = randomDataImpl1.nextSecureInt(3, (int) (short) 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 17L + "'", long6 == 17L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 38.044100367287584d + "'", double10 == 38.044100367287584d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.0679515313825692E-25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0679515313825692E-25d + "'", double1 == 2.0679515313825692E-25d);
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test23");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(30, 0, 11);
//        try {
//            java.lang.String str14 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.9181102676706484d) + "'", double6 == (-0.9181102676706484d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        long long2 = org.apache.commons.math.util.FastMath.min(26L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        int int2 = org.apache.commons.math.util.FastMath.max(23, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test26");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        double double12 = randomDataImpl1.nextT(4.524077039668076d);
//        randomDataImpl1.reSeedSecure((long) 0);
//        double double17 = randomDataImpl1.nextBeta((double) 31L, 1.5707963267948966d);
//        java.lang.String str19 = randomDataImpl1.nextSecureHexString(17);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl22 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
//        double double24 = normalDistributionImpl22.cumulativeProbability((double) (short) 1);
//        try {
//            double double25 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl22);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.572");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5837189616848644d) + "'", double5 == (-0.5837189616848644d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.027290318399335d) + "'", double12 == (-1.027290318399335d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9897003808269962d + "'", double17 == 0.9897003808269962d);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "fa15bcb298fb6582e" + "'", str19.equals("fa15bcb298fb6582e"));
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8944827772348817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0186256522595254d + "'", double1 == 1.0186256522595254d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 108L, 6.510781221992766d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 108.0d + "'", double2 == 108.0d);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str36 = convergenceException35.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "hi!", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable39, objArray50);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, "hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable30, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray68 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException60, "hi!", objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable57, objArray68);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable30, objArray68);
        java.lang.Class<?> wildcardClass73 = localizable30.getClass();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 1324.8717503949065d, (java.lang.Number) 0.9999999988001019d, false);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "convergence failed" + "'", str36.equals("convergence failed"));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        int int14 = randomDataImpl1.nextInt((int) (short) -1, (int) 'a');
//        double double16 = randomDataImpl1.nextExponential(1.7763568394002505E-15d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.029235173949702428d + "'", double8 == 0.029235173949702428d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.1383482351542915E-15d + "'", double16 == 1.1383482351542915E-15d);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        double double5 = normalDistributionImpl2.density(0.0d);
        double double7 = normalDistributionImpl2.density((double) 31);
        double double10 = normalDistributionImpl2.cumulativeProbability(0.010473563267577948d, 45.073712698830185d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        double double2 = org.apache.commons.math.util.FastMath.pow(91.99999999999999d, (-0.9790031874208696d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011952134111961832d + "'", double2 == 0.011952134111961832d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        double double1 = org.apache.commons.math.util.FastMath.atan((-25.84505861145873d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5321235020902169d) + "'", double1 == (-1.5321235020902169d));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "hi!", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable9, objArray20);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { notStrictlyPositiveException26, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException23, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException39);
        java.lang.Number number41 = notStrictlyPositiveException39.getMin();
        java.lang.Number number42 = notStrictlyPositiveException39.getMin();
        java.lang.Object[] objArray43 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable33, objArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0 + "'", number41.equals(0));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0 + "'", number42.equals(0));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable49);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "hi!", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "org.apache.commons.math.ConvergenceException: null is smaller than, or equal to, the minimum (0)", objArray13);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.01217320523003821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.914595056080313d) + "'", double1 == (-1.914595056080313d));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable39, objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, "hi!", objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable61 = mathIllegalArgumentException60.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = mathIllegalArgumentException60.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray74 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException66, "hi!", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable65, objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable64, objArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException60, localizable63, objArray74);
        java.lang.Object[] objArray79 = mathIllegalArgumentException60.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray79);
        java.lang.Throwable[] throwableArray81 = mathIllegalArgumentException80.getSuppressed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNull(localizable61);
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(throwableArray81);
    }
}

