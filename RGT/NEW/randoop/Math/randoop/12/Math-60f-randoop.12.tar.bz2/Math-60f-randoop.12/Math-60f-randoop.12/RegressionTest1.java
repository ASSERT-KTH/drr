import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.5067171123348206d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9292666946387997d + "'", double1 == 0.9292666946387997d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.617880691207321d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2059129795337131d + "'", double1 == 1.2059129795337131d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        try {
//            double double14 = randomDataImpl1.nextBeta(0.0d, (double) 87L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.696");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03066186334790728d + "'", double8 == 0.03066186334790728d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 80L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.4093490824269389E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.69314718055995d + "'", double1 == 51.69314718055995d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        float float1 = org.apache.commons.math.util.FastMath.abs(13.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13.0f + "'", float1 == 13.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 62.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0821041362364843d + "'", double1 == 1.0821041362364843d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.0679515313825692E-25d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        try {
            double double6 = randomDataImpl1.nextF((-0.16586745267415084d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.166 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.166)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.abs(868.6688730268119d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 868.6688730268119d + "'", double1 == 868.6688730268119d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 51.0f, (-0.16511615943298497d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "hi!", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable11, objArray22);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { notStrictlyPositiveException28, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException25, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException41);
        java.lang.Number number43 = notStrictlyPositiveException41.getMin();
        java.lang.Number number44 = notStrictlyPositiveException41.getMin();
        java.lang.Object[] objArray45 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable35, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable1, objArray45);
        java.lang.Object[] objArray48 = maxIterationsExceededException47.getArguments();
        java.lang.Class<?> wildcardClass49 = objArray48.getClass();
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0 + "'", number43.equals(0));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1183.4451214873366d, (java.lang.Number) (-1.2555534351306512d), true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 62.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01625980437881211d + "'", double1 == 0.01625980437881211d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.248867972642223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8104269663372248d + "'", double1 == 0.8104269663372248d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219178334370727E26d + "'", double1 == 4.219178334370727E26d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double10 = randomDataImpl1.nextChiSquare((double) ' ');
//        try {
//            int int14 = randomDataImpl1.nextHypergeometric(0, 0, 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.02910659805413988d + "'", double8 == 0.02910659805413988d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 23.600657674224145d + "'", double10 == 23.600657674224145d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException45.getGeneralPattern();
        boolean boolean47 = numberIsTooLargeException45.getBoundIsAllowed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        double double5 = normalDistributionImpl2.density(0.0d);
        double double6 = normalDistributionImpl2.getMean();
        double double7 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        long long10 = randomDataImpl1.nextLong((long) '4', 100L);
//        try {
//            long long13 = randomDataImpl1.nextLong(22L, (long) 13);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 22 is larger than, or equal to, the maximum (13): lower bound (22) must be strictly less than upper bound (13)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 13L + "'", long7 == 13L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 90L + "'", long10 == 90L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        long long1 = org.apache.commons.math.util.FastMath.abs(19L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 19L + "'", long1 == 19L);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        double double14 = randomDataImpl1.nextCauchy(100.0d, 1.248867972642223d);
//        int int17 = randomDataImpl1.nextZipf(3, 0.03825962145251383d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.029383188459874685d + "'", double8 == 0.029383188459874685d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.9298573120319d + "'", double14 == 101.9298573120319d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 73);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 73.0f + "'", float2 == 73.0f);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 13L, 46.09996746528637d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        normalDistributionImpl14.reseedRandomGenerator(0L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1031.1242670907159d + "'", double6 == 1031.1242670907159d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 31.348043354905307d + "'", double11 == 31.348043354905307d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-25.84505861145873d) + "'", double15 == (-25.84505861145873d));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        java.lang.Number number9 = numberIsTooLargeException4.getMax();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, "org.apache.commons.math.MathException: convergence failed", objArray11);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7031839360032603E-108d + "'", double1 == 1.7031839360032603E-108d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1, "hi!", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("da87742597", objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.9116227652145885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5916043892830116d + "'", double1 == 1.5916043892830116d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "hi!", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable11, objArray22);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { notStrictlyPositiveException28, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException25, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("hi!", objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException41);
        java.lang.Number number43 = notStrictlyPositiveException41.getMin();
        java.lang.Number number44 = notStrictlyPositiveException41.getMin();
        java.lang.Object[] objArray45 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable35, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable1, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = maxIterationsExceededException47.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0 + "'", number43.equals(0));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNull(localizable48);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.2555534351306512d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9507210990297232d) + "'", double1 == (-0.9507210990297232d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str2 = convergenceException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable5, objArray16);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, "hi!", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException24.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(25, localizable21, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray40 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "hi!", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable31, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable30, objArray40);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable21, objArray40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "convergence failed" + "'", str2.equals("convergence failed"));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.log(0.02025047350832094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.89957710257601d) + "'", double1 == (-3.89957710257601d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "hi!", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable2, objArray13);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { notStrictlyPositiveException19, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException16, "", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
        java.lang.String str24 = convergenceException23.getPattern();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextBinomial(0, (double) 1.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl1.getClass();
//        double double13 = randomDataImpl1.nextF((double) (byte) 10, 11013.232920103323d);
//        double double16 = randomDataImpl1.nextCauchy(0.010050166663333094d, (double) 13);
//        int int19 = randomDataImpl1.nextZipf(2, 1.7453292519943295d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1324.8717503949065d + "'", double6 == 1324.8717503949065d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8944827772348817d + "'", double13 == 0.8944827772348817d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.5198316828628864d + "'", double16 == 1.5198316828628864d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math.util.FastMath.max(2922.084755167198d, 0.9998872015382027d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2922.084755167198d + "'", double2 == 2922.084755167198d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(6.510781221992766d, (double) 11L, 0.05519215703220057d);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        try {
//            double double12 = randomDataImpl1.nextF(0.9999776607197243d, (-7.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -7 is smaller than, or equal to, the minimum (0): degrees of freedom (-7)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.8794086982508476d + "'", double5 == 1.8794086982508476d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.17869756577632334d) + "'", double7 == (-0.17869756577632334d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 65L + "'", long9 == 65L);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.015050303523504572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.013870119658797706d, 353.9135749739193d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable7, objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable6, objArray16);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("d31d3d316b", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(10, "d31d3d316b", objArray16);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long1 = org.apache.commons.math.util.FastMath.round(1324.8717503949065d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1325L + "'", long1 == 1325L);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        double double13 = randomDataImpl1.nextT(3.141592653589793d);
//        long long16 = randomDataImpl1.nextSecureLong((long) 26, 76L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0361534970936983d + "'", double6 == 1.0361534970936983d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.026489543396040986d) + "'", double13 == (-0.026489543396040986d));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 59L + "'", long16 == 59L);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.251752586176186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextBinomial(0, (double) 1.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1282.1141413140977d + "'", double6 == 1282.1141413140977d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.140692632779267d + "'", double1 == 22.140692632779267d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 74L, number1, false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5228693839029145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4817752845260481d + "'", double1 == 0.4817752845260481d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        boolean boolean46 = numberIsTooLargeException45.getBoundIsAllowed();
        boolean boolean47 = numberIsTooLargeException45.getBoundIsAllowed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, (int) (short) 1);
//        try {
//            long long11 = randomDataImpl1.nextSecureLong((long) 100, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.085904639517138d + "'", double5 == 1.085904639517138d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double9 = normalDistributionImpl8.getMean();
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2378526745342544d + "'", double5 == 1.2378526745342544d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.012784211629091d) + "'", double7 == (-1.012784211629091d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.04335857154572866d) + "'", double10 == (-0.04335857154572866d));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) -1);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Class<?> wildcardClass3 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 99.77610183877165d, (java.lang.Number) 10, (java.lang.Number) 1.7453292519943295d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "hi!", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "95599e40bf91c136", objArray21);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 99.77610183877165d + "'", number5.equals(99.77610183877165d));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, "hi!", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException12.getSpecificPattern();
        java.lang.Object[] objArray14 = mathIllegalArgumentException12.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException12.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, "hi!", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable1, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable0, objArray10);
        java.lang.Throwable[] throwableArray14 = mathException13.getSuppressed();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, "hi!", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable1, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable0, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException13.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9080758426552533d), (-0.4108142356351678d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4108142356351678d) + "'", double2 == (-0.4108142356351678d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.341403551438799d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        long long11 = randomDataImpl1.nextSecureLong((long) 100, 1325L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7563772461278008d + "'", double5 == 0.7563772461278008d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1111L + "'", long11 == 1111L);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.248867972642223d, (double) (byte) 10);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextZipf((int) '#', 1.1102230246251565E-16d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7debb293ec" + "'", str10.equals("7debb293ec"));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(99.99999999999999d, 4.219178334370727E26d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.219178334370727E26d + "'", double2 == 4.219178334370727E26d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.041851167628339195d + "'", double1 == 0.041851167628339195d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.7694977763250068d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2095300810140903d) + "'", double1 == (-1.2095300810140903d));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        int int14 = randomDataImpl1.nextInt((int) (short) -1, (int) 'a');
//        double double17 = randomDataImpl1.nextGamma(0.8623188722876839d, (double) 62);
//        randomDataImpl1.reSeed(1111L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03610956433305299d + "'", double8 == 0.03610956433305299d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 72 + "'", int14 == 72);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 117.53740685142618d + "'", double17 == 117.53740685142618d);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) 59L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.605170185988092d + "'", double2 == 4.605170185988092d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.cos(1115.7078762887215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036907262148275d) + "'", double1 == (-0.9036907262148275d));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double10 = randomDataImpl1.nextChiSquare((double) ' ');
//        randomDataImpl1.reSeedSecure((long) 11);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03733582227858392d + "'", double8 == 0.03733582227858392d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 24.643770120411723d + "'", double10 == 24.643770120411723d);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1102230246251568E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0536712127723509E-8d + "'", double1 == 1.0536712127723509E-8d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.015050303523504572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.01516412966399d + "'", double1 == 1.01516412966399d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.338474404104274d + "'", double1 == 1.338474404104274d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.718281828459045d + "'", number4.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5430543820514286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2184106351978223d + "'", double1 == 1.2184106351978223d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.010473371793188269d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010473754765072894d + "'", double1 == 0.010473754765072894d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10L, (java.lang.Number) 74L, (java.lang.Number) 1.4093490824269389E22d);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable5, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getSpecificPattern();
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1159.698814424857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 66445.84757286958d + "'", double1 == 66445.84757286958d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', (double) '4', (-0.4365903827201383d));
        double double4 = normalDistributionImpl3.getMean();
        normalDistributionImpl3.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.4260618395428104d, (java.lang.Number) 0.7805951733159242d, false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.99822295029797d, (java.lang.Number) 1.4093490824269389E22d, false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long2 = org.apache.commons.math.util.FastMath.max(74L, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 74L + "'", long2 == 74L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray12);
        java.lang.String str16 = maxIterationsExceededException15.toString();
        java.lang.Throwable[] throwableArray17 = maxIterationsExceededException15.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException15);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str16.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        normalDistributionImpl2.reseedRandomGenerator((long) ' ');
        double double6 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(1);
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString((int) '4');
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "7" + "'", str13.equals("7"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9ba9403605a35c0d987fa540554b433f26fe6b230dc7163ee6b4" + "'", str15.equals("9ba9403605a35c0d987fa540554b433f26fe6b230dc7163ee6b4"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10L, (java.lang.Number) 74L, (java.lang.Number) 1.4093490824269389E22d);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable5, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getSpecificPattern();
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathException17);
        java.lang.Number number20 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable21 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number22 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 74L + "'", number20.equals(74L));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 74L + "'", number22.equals(74L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.max(2.4849066497880004d, 0.01745290262594996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4849066497880004d + "'", double2 == 2.4849066497880004d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.11398792868037175d, (java.lang.Number) 720.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.0683408779031875d);
        boolean boolean11 = notStrictlyPositiveException10.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.030402570497953363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03039320676287369d + "'", double1 == 0.03039320676287369d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException95 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable80, (java.lang.Number) 2.3978952727983707d, (java.lang.Number) 0.36787944117144233d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException99 = new org.apache.commons.math.exception.OutOfRangeException(localizable80, (java.lang.Number) 24, (java.lang.Number) 73.0f, (java.lang.Number) 1.0683408779031875d);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.01625980437881211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.FastMath.pow(1111.8929676559267d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 78L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8578030932449878d) + "'", double1 == (-0.8578030932449878d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.02431914772576889d, (-0.972405210425346d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1165885924036543d + "'", double2 == 3.1165885924036543d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.26807434023259d + "'", double1 == 6.26807434023259d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.4005189940491249d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        long long10 = randomDataImpl1.nextLong((long) '4', 100L);
//        double double13 = randomDataImpl1.nextCauchy(0.0d, 712.8998077502323d);
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString(20);
//        try {
//            int int18 = randomDataImpl1.nextBinomial((int) (short) 0, (-0.9507210990297232d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.951 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 51L + "'", long7 == 51L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 90L + "'", long10 == 90L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-85.11233109739828d) + "'", double13 == (-85.11233109739828d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a7c6d0a13a11c43670d6" + "'", str15.equals("a7c6d0a13a11c43670d6"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        double double5 = normalDistributionImpl2.density(0.0d);
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 0);
        double double8 = normalDistributionImpl2.cumulativeProbability(0.9291491167467972d);
        try {
            double double10 = normalDistributionImpl2.inverseCumulativeProbability(31.199494761253867d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 31.199 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.special.Erf.erf(8.339107340473126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3);
        java.lang.Number number5 = notStrictlyPositiveException3.getMin();
        java.lang.Number number6 = notStrictlyPositiveException3.getMin();
        java.lang.Number number7 = notStrictlyPositiveException3.getArgument();
        java.lang.Object[] objArray8 = notStrictlyPositiveException3.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "", objArray8);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        long long8 = randomDataImpl1.nextSecureLong(0L, 1L);
//        double double11 = randomDataImpl1.nextGamma((double) 31, 0.9999986855378105d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 37.35759758266566d + "'", double11 == 37.35759758266566d);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        int int11 = randomDataImpl1.nextZipf((int) (byte) 100, 4.401612632446982d);
//        double double14 = randomDataImpl1.nextGamma(1115.7078762887215d, (double) 25);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        try {
//            double double20 = randomDataImpl1.nextGamma(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 46L + "'", long6 == 46L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 27694.98846993187d + "'", double14 == 27694.98846993187d);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.3095891376217486d + "'", double1 == 7.3095891376217486d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        long long10 = randomDataImpl1.nextLong((long) '4', 100L);
//        double double13 = randomDataImpl1.nextCauchy(0.0d, 712.8998077502323d);
//        double double15 = randomDataImpl1.nextExponential((double) 8);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 78L + "'", long7 == 78L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 96L + "'", long10 == 96L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 86.18396019367208d + "'", double13 == 86.18396019367208d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 20.930915030813647d + "'", double15 == 20.930915030813647d);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(15.590993866931946d, (-0.16511615943298497d), 0.0d, 2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.23686107370087825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2414459816464125d + "'", double1 == 0.2414459816464125d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2998850278490102d, (double) 78L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.666293486405095E8d + "'", double2 == 7.666293486405095E8d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 732.1194120110488d, number2, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int1 = org.apache.commons.math.util.FastMath.abs(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        try {
//            double double13 = randomDataImpl1.nextF((-0.026489543396040986d), 184.8465451442466d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.026 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.026)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.089033585065111d + "'", double5 == 3.089033585065111d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.2676096092135452d, 3.970291913552122d, (double) 80, 11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9982393249923817d + "'", double4 == 0.9982393249923817d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.02664643282774387d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(18.402763647001215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1054.4006883499483d + "'", double1 == 1054.4006883499483d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 97.0d, (java.lang.Number) 51L);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("convergence failed", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable6, objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.0401167461499594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691507100306057d + "'", double1 == 6.691507100306057d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(62.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.73904728784493d + "'", double1 == 192.73904728784493d);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        double double6 = randomDataImpl1.nextChiSquare((double) 62.0f);
//        try {
//            double double9 = randomDataImpl1.nextUniform(51.69314718055995d, 0.5852543936653304d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 51.693 is larger than, or equal to, the maximum (0.585): lower bound (51.693) must be strictly less than upper bound (0.585)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 71.32570951580202d + "'", double6 == 71.32570951580202d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 99.77610183877165d, (java.lang.Number) 10, (java.lang.Number) 1.7453292519943295d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Number number8 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 99.77610183877165d + "'", number5.equals(99.77610183877165d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.7453292519943295d + "'", number7.equals(1.7453292519943295d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 99.77610183877165d + "'", number8.equals(99.77610183877165d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5707963267948966d, 1.6698676652410473d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6698676652410473d + "'", double2 == 1.6698676652410473d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        double double5 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.density(0.0d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(100.0d, 100.39649074166145d, 101.9298573120319d, 3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.03982975990590631d + "'", double4 == 0.03982975990590631d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.5916043892830116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8643782113785933d + "'", double1 == 0.8643782113785933d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 62.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2075343299958265d + "'", double1 == 3.2075343299958265d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7303757501620307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.7763568394002505E-15d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "hi!", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable3, objArray14);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { notStrictlyPositiveException20, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, "", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(0, "76ea3459a59a17400951", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = maxIterationsExceededException24.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 97.0d, (java.lang.Number) 51L);
        org.apache.commons.math.exception.util.Localizable localizable30 = outOfRangeException29.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "hi!", objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable33, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException24, localizable31, (java.lang.Object[]) throwableArray49);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getSpecificPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) convergenceException19);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "hi!", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable25, objArray36);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number41);
        java.lang.Object[] objArray44 = new java.lang.Object[] { notStrictlyPositiveException42, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException39, "", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0, "76ea3459a59a17400951", objArray44);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) maxIterationsExceededException46);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-2.707216031255932d) + "'", number2.equals((-2.707216031255932d)));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (0.01): org.apache.commons.math.MaxIterationsExceededException: ", objArray1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.03452092748520801d, (double) 100.0f, 0.424179007336997d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        try {
            double double3 = normalDistributionImpl0.inverseCumulativeProbability((double) 25L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 25 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 72);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 72.0f + "'", float1 == 72.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.341403551438799d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7107720172524542d + "'", double1 == 0.7107720172524542d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        double double5 = normalDistributionImpl2.density(0.0d);
        try {
            double[] doubleArray7 = normalDistributionImpl2.sample((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException93 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 0.010473371793188269d);
        java.lang.String str94 = notStrictlyPositiveException93.toString();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.01 is smaller than, or equal to, the minimum (0): org.apache.commons.math.MaxIterationsExceededException: " + "'", str94.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.01 is smaller than, or equal to, the minimum (0): org.apache.commons.math.MaxIterationsExceededException: "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.14012500536082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9770705184996239d + "'", double1 == 0.9770705184996239d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        java.lang.Number number50 = outOfRangeException49.getHi();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.010050166663333094d + "'", number50.equals(0.010050166663333094d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.7805951733159242d, number1, true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 52L, number5, false);
        java.lang.Number number8 = numberIsTooLargeException7.getMax();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "hi!", objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable18, objArray29);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number34);
        java.lang.Object[] objArray37 = new java.lang.Object[] { notStrictlyPositiveException35, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException32, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable42 = maxIterationsExceededException41.getGeneralPattern();
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable42, objArray43);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray70 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, "hi!", objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable59, objArray70);
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number75);
        java.lang.Object[] objArray78 = new java.lang.Object[] { notStrictlyPositiveException76, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException73, "", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("hi!", objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray78);
        org.apache.commons.math.exception.util.Localizable localizable83 = maxIterationsExceededException82.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException85 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable83, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException87 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable83, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        java.lang.Number number90 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException92 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable88, (java.lang.Number) 52L, number90, false);
        java.lang.Throwable[] throwableArray93 = numberIsTooLargeException92.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable83, (java.lang.Object[]) throwableArray93);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(86, "maximal number of iterations ({0}) exceeded", (java.lang.Object[]) throwableArray93);
        java.lang.Object[] objArray96 = maxIterationsExceededException95.getArguments();
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException("416", objArray96);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(localizable83);
        org.junit.Assert.assertNotNull(throwableArray93);
        org.junit.Assert.assertNotNull(objArray96);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double2 = org.apache.commons.math.util.FastMath.max(3.469446951953614E-18d, 1.7031839360032603E-108d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.469446951953614E-18d + "'", double2 == 3.469446951953614E-18d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4093490824269389E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4093490824269389E22d + "'", double1 == 1.4093490824269389E22d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0f, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable5, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = maxIterationsExceededException19.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        boolean boolean23 = notStrictlyPositiveException22.getBoundIsAllowed();
        maxIterationsExceededException19.addSuppressed((java.lang.Throwable) notStrictlyPositiveException22);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException22);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        long long10 = randomDataImpl1.nextLong((long) '4', 100L);
//        double double13 = randomDataImpl1.nextCauchy(0.0d, 712.8998077502323d);
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString(20);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl1.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 75L + "'", long7 == 75L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86L + "'", long10 == 86L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-251.74810378330687d) + "'", double13 == (-251.74810378330687d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "adf84851da1a64f3d038" + "'", str15.equals("adf84851da1a64f3d038"));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException45, "", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = convergenceException50.getGeneralPattern();
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException53);
        java.lang.Number number55 = notStrictlyPositiveException53.getMin();
        java.lang.Number number56 = notStrictlyPositiveException53.getMin();
        java.lang.Number number57 = notStrictlyPositiveException53.getArgument();
        java.lang.Object[] objArray58 = notStrictlyPositiveException53.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable51, objArray58);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 0 + "'", number55.equals(0));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0 + "'", number56.equals(0));
        org.junit.Assert.assertNull(number57);
        org.junit.Assert.assertNotNull(objArray58);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "hi!", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray15);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { notStrictlyPositiveException21, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException18, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.01 is smaller than, or equal to, the minimum (0): org.apache.commons.math.MaxIterationsExceededException: ", objArray23);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        int int7 = randomDataImpl1.nextSecureInt(52, (int) (short) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57 + "'", int7 == 57);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 13L, 46.09996746528637d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.351752586176186d + "'", double1 == 2.351752586176186d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextZipf((int) '#', 1.1102230246251565E-16d);
//        randomDataImpl1.reSeed();
//        try {
//            double double12 = randomDataImpl1.nextUniform(0.0d, (-1.5707963267948966d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1.571): lower bound (0) must be strictly less than upper bound (-1.571)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 14L, (-0.9507210990297232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.999999999999998d + "'", double2 == 13.999999999999998d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "hi!", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray15);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { notStrictlyPositiveException21, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException18, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable0, objArray23);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        normalDistributionImpl2.reseedRandomGenerator(51L);
        try {
            double double8 = normalDistributionImpl2.inverseCumulativeProbability(22.140692632779267d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 22.141 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 73);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.290459441148391d + "'", double1 == 4.290459441148391d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.485595060225952d, 8.881784197001252E-16d, 1.0000019012623496d, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4093490824269389E22d, 0.041851167628339195d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4093490824269386E22d + "'", double2 == 1.4093490824269386E22d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9999999988001019d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999996000339d + "'", double1 == 0.9999999996000339d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        normalDistributionImpl2.reseedRandomGenerator((long) ' ');
        try {
            double double7 = normalDistributionImpl2.inverseCumulativeProbability((double) 89L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 89 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.log1p(37.35759758266566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6469526198648987d + "'", double1 == 3.6469526198648987d);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        int int14 = randomDataImpl1.nextInt((int) (short) -1, (int) 'a');
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.03623246565571266d + "'", double8 == 0.03623246565571266d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86 + "'", int14 == 86);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4093490824269386E22d, (java.lang.Number) 78L, true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(0.0d);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long1 = org.apache.commons.math.util.FastMath.round(0.010050166663333094d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        double double14 = randomDataImpl1.nextWeibull(1594.1057216053039d, 0.037927847198291155d);
//        try {
//            int int17 = randomDataImpl1.nextInt(100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.037956247664364784d + "'", double14 == 0.037956247664364784d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 3.4855950602259513d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextZipf((int) '#', 1.1102230246251565E-16d);
//        double double11 = randomDataImpl1.nextF(2.0679515313825692E-25d, 0.018646065853057357d);
//        double double14 = randomDataImpl1.nextCauchy(0.9464256534367618d, 0.20050398057873267d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("7", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9387627317431011d + "'", double14 == 0.9387627317431011d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0378811856421893d, 6.691507100306057d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.005661023803999922d + "'", double2 == 0.005661023803999922d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        int int11 = randomDataImpl1.nextZipf((int) (byte) 100, 4.401612632446982d);
//        double double14 = randomDataImpl1.nextGamma(1115.7078762887215d, (double) 25);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int18 = randomDataImpl1.nextPascal(10, 3.1622776601683795d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.162 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 27694.98846993187d + "'", double14 == 27694.98846993187d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5312154618696312d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        int int13 = randomDataImpl1.nextHypergeometric((int) 'a', 20, (int) (byte) 1);
//        double double15 = randomDataImpl1.nextExponential(8.339107340473126d);
//        long long17 = randomDataImpl1.nextPoisson(1.0E-9d);
//        try {
//            double double20 = randomDataImpl1.nextCauchy(1.338474404104274d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-4.38300596006109d) + "'", double6 == (-4.38300596006109d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 7.4889814765035485d + "'", double15 == 7.4889814765035485d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.029383188459874685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-34.56295964364512d) + "'", double1 == (-34.56295964364512d));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double8 = randomDataImpl1.nextGamma((double) 10.0f, 0.02664643282774387d);
//        try {
//            int int11 = randomDataImpl1.nextPascal((int) (short) 1, 353.9135749739193d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 353.914 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-202.18868946352381d) + "'", double5 == (-202.18868946352381d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.17753895053953708d + "'", double8 == 0.17753895053953708d);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.9911537047097787d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        randomDataImpl1.reSeed(0L);
//        double double12 = randomDataImpl1.nextChiSquare(27.067883557646386d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 31.12506838280409d + "'", double12 == 31.12506838280409d);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 76L, (float) 86);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 76.0f + "'", float2 == 76.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 720.0742987389762d, (java.lang.Number) 86, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.4175907596101256d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3955782540977208d) + "'", double1 == (-0.3955782540977208d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 8, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        long long14 = randomDataImpl1.nextSecureLong(14L, 37L);
//        double double17 = randomDataImpl1.nextUniform(5.033740963120804d, 26.14359395454488d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.004168914615719851d + "'", double8 == 0.004168914615719851d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31L + "'", long14 == 31L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 17.89627668276568d + "'", double17 == 17.89627668276568d);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-7.460385184229578d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.898606447528955d + "'", double1 == 9.898606447528955d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 17.89627668276568d, (java.lang.Number) 1.285441400939515d, true);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int1 = org.apache.commons.math.util.FastMath.abs(80);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            int int16 = randomDataImpl1.nextInt(17, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 17 is larger than, or equal to, the maximum (0): lower bound (17) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 23 + "'", int11 == 23);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "f" + "'", str13.equals("f"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        double double5 = normalDistributionImpl2.density(0.0d);
        double double6 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.density(662.7084075185895d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.06008567103329357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', (double) '4', (-0.4365903827201383d));
        double double5 = normalDistributionImpl3.density(868.6688730268119d);
        double double6 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.672672389937051E-59d + "'", double5 == 4.672672389937051E-59d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 7.666293486405095E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
        try {
            int int8 = randomDataImpl1.nextBinomial((int) (short) 10, 181.18516357615334d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 181.185 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(0, 30, 86);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1654.900171637082d + "'", double6 == 1654.900171637082d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 26 + "'", int9 == 26);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.6944799116402525d + "'", double11 == 6.6944799116402525d);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1940688187363215d + "'", double1 == 1.1940688187363215d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        long long1 = org.apache.commons.math.util.FastMath.abs(92L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 92L + "'", long1 == 92L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        double double12 = randomDataImpl1.nextGaussian(0.0d, 1.0d);
//        try {
//            int int15 = randomDataImpl1.nextInt(73, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 73 is larger than, or equal to, the maximum (10): lower bound (73) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.7797582903870738d) + "'", double6 == (-0.7797582903870738d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.6433559400956488d) + "'", double12 == (-1.6433559400956488d));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException95 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable80, (java.lang.Number) 2.3978952727983707d, (java.lang.Number) 0.36787944117144233d, false);
        boolean boolean96 = numberIsTooSmallException95.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable97 = numberIsTooSmallException95.getSpecificPattern();
        java.lang.Number number98 = numberIsTooSmallException95.getArgument();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(localizable97);
        org.junit.Assert.assertTrue("'" + number98 + "' != '" + 2.3978952727983707d + "'", number98.equals(2.3978952727983707d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        double double5 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.getMean();
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability((double) 10, 1.6263761090469115d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.String str7 = convergenceException6.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.ConvergenceException: null is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.ConvergenceException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 64L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.85209129348869d + "'", double1 == 4.85209129348869d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "hi!", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable9, objArray20);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { notStrictlyPositiveException26, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException23, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException39);
        java.lang.Number number41 = notStrictlyPositiveException39.getMin();
        java.lang.Number number42 = notStrictlyPositiveException39.getMin();
        java.lang.Object[] objArray43 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable33, objArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException50);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray69 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException61, "hi!", objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable60, objArray69);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable58, objArray69);
        java.lang.Number number74 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException75 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number74);
        java.lang.Object[] objArray77 = new java.lang.Object[] { notStrictlyPositiveException75, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException72, "", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("hi!", objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray77);
        org.apache.commons.math.exception.util.Localizable localizable82 = maxIterationsExceededException81.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException(localizable82, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number87);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException88);
        java.lang.Number number90 = notStrictlyPositiveException88.getMin();
        java.lang.Number number91 = notStrictlyPositiveException88.getMin();
        java.lang.Object[] objArray92 = notStrictlyPositiveException88.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, localizable82, objArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.Throwable[] throwableArray96 = maxIterationsExceededException95.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable82, (java.lang.Object[]) throwableArray96);
        org.apache.commons.math.exception.util.Localizable localizable98 = mathIllegalArgumentException97.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0 + "'", number41.equals(0));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0 + "'", number42.equals(0));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(localizable82);
        org.junit.Assert.assertTrue("'" + number90 + "' != '" + 0 + "'", number90.equals(0));
        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 0 + "'", number91.equals(0));
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertNotNull(throwableArray96);
        org.junit.Assert.assertNotNull(localizable98);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.11398792868037175d, (java.lang.Number) 720.0d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 72.0f, (java.lang.Number) (-2.707216031255932d), true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 86);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86 + "'", int2 == 86);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        normalDistributionImpl2.reseedRandomGenerator(51L);
        double double8 = normalDistributionImpl2.density((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 3.4855950602259513d, (java.lang.Number) 0.9999776607197243d, (java.lang.Number) (-1.0f));
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, "hi!", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable23, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable22, objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException18, localizable21, objArray32);
        java.lang.Object[] objArray37 = mathIllegalArgumentException18.getArguments();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable5, objArray37);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.005661023803999922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1782235104557159d + "'", double1 == 0.1782235104557159d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 40L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 40.0f + "'", float1 == 40.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 76L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 76.00000000000001d + "'", double1 == 76.00000000000001d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(13);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.11398792868037175d, (-0.026489543396040986d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.039007168624966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 92L, 2.0401167461499594d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.99999999999999d + "'", double2 == 91.99999999999999d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, (java.lang.Number) (short) 10);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 52L, number4, false);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Object[] objArray8 = numberIsTooLargeException6.getArguments();
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable1, (java.lang.Object[]) throwableArray9);
        int int11 = maxIterationsExceededException10.getMaxIterations();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        try {
//            int[] intArray11 = randomDataImpl1.nextPermutation(0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.474680541495645d) + "'", double5 == (-2.474680541495645d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        int int14 = randomDataImpl1.nextInt((int) (short) 1, 3);
//        try {
//            double double17 = randomDataImpl1.nextGamma(0.012849942968156417d, (-0.16511615943298497d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.165 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.02664643282774387d, (java.lang.Number) 0.017452902625949958d, (java.lang.Number) 1183.4451214873363d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 86);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 86.0f + "'", float1 == 86.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.03135329040580097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.log1p(181.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.204006687076795d + "'", double1 == 5.204006687076795d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.log(8.504378490611614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1405811474118313d + "'", double1 == 2.1405811474118313d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0204569054404329d, (java.lang.Number) 6.678986187455083E-16d, false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException52, "hi!", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable49, objArray60);
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number65);
        java.lang.Object[] objArray68 = new java.lang.Object[] { notStrictlyPositiveException66, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException63, "", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("hi!", objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray68);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) maxIterationsExceededException72);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray68);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        try {
//            int int9 = randomDataImpl1.nextPascal(30, Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -∞ out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.0401167461499594d, 1013.3661980855965d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0401167461499594d + "'", double3 == 2.0401167461499594d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', (double) '4', (-0.4365903827201383d));
        normalDistributionImpl3.reseedRandomGenerator(62L);
        double double6 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException0.getSpecificPattern();
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "hi!", objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable12, objArray23);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { notStrictlyPositiveException29, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable36 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException42);
        java.lang.Number number44 = notStrictlyPositiveException42.getMin();
        java.lang.Number number45 = notStrictlyPositiveException42.getMin();
        java.lang.Object[] objArray46 = notStrictlyPositiveException42.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable36, objArray46);
        convergenceException0.addSuppressed((java.lang.Throwable) mathException5);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
        org.junit.Assert.assertNotNull(objArray46);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextZipf((int) '#', 1.1102230246251565E-16d);
//        double double11 = randomDataImpl1.nextF(2.0679515313825692E-25d, 0.018646065853057357d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(20);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.1281702880866439E-9d + "'", double11 == 1.1281702880866439E-9d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "66a4c7e06f5710160e94" + "'", str13.equals("66a4c7e06f5710160e94"));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.util.Localizable localizable92 = mathIllegalArgumentException91.getSpecificPattern();
        java.lang.Class<?> wildcardClass93 = mathIllegalArgumentException91.getClass();
        org.apache.commons.math.exception.util.Localizable localizable94 = mathIllegalArgumentException91.getSpecificPattern();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertNotNull(localizable92);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertNotNull(localizable94);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        long long1 = org.apache.commons.math.util.FastMath.round(2.9019282805706954d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        java.lang.String str2 = convergenceException0.getPattern();
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "hi!", objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable12, objArray23);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { notStrictlyPositiveException29, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable36 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException42);
        java.lang.Number number44 = notStrictlyPositiveException42.getMin();
        java.lang.Number number45 = notStrictlyPositiveException42.getMin();
        java.lang.Object[] objArray46 = notStrictlyPositiveException42.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable36, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "hi!", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable36, objArray56);
        java.lang.String str59 = convergenceException58.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "convergence failed" + "'", str2.equals("convergence failed"));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str59.equals("org.apache.commons.math.MaxIterationsExceededException: "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7596149213951954d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2749436564833938d) + "'", double1 == (-0.2749436564833938d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.special.Gamma.digamma(732.1194120110488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.595260527647427d + "'", double1 == 6.595260527647427d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.cos(13.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13673721820783535d + "'", double1 == 0.13673721820783535d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        try {
            double double7 = normalDistributionImpl2.cumulativeProbability((double) 23, 0.6198779966141669d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(78.64630985256925d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 263.37926039421126d + "'", double1 == 263.37926039421126d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 720.0742987389762d, (java.lang.Number) 86, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 86 + "'", number4.equals(86));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(20, "7", objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)", objArray17);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        java.lang.Class<?> wildcardClass6 = notStrictlyPositiveException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getSpecificPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException19);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.6449877746407249d, 4.401612632446982d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.94261141121936d + "'", double2 == 8.94261141121936d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.14012500536082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.044682108494308d + "'", double1 == 1.044682108494308d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
        try {
            double double7 = randomDataImpl1.nextUniform((double) 16, (-0.954282579298837d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than, or equal to, the maximum (-0.954): lower bound (16) must be strictly less than upper bound (-0.954)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long1 = org.apache.commons.math.util.FastMath.abs(93L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 93L + "'", long1 == 93L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, 100.0d);
        double double4 = normalDistributionImpl2.density(1.0683408779031875d);
        normalDistributionImpl2.reseedRandomGenerator((long) 23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.003989195143679437d + "'", double4 == 0.003989195143679437d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("convergence failed", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 52L, number6, false);
        java.lang.Number number9 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException8, localizable10, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "hi!", objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable19, objArray30);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number35);
        java.lang.Object[] objArray38 = new java.lang.Object[] { notStrictlyPositiveException36, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable43 = maxIterationsExceededException42.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException8, localizable43, objArray44);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray71 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException63, "hi!", objArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, localizable62, objArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable60, objArray71);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number76);
        java.lang.Object[] objArray79 = new java.lang.Object[] { notStrictlyPositiveException77, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException74, "", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("hi!", objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray79);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray79);
        org.apache.commons.math.exception.util.Localizable localizable84 = maxIterationsExceededException83.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable84, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable84, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        java.lang.Number number91 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException93 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable89, (java.lang.Number) 52L, number91, false);
        java.lang.Throwable[] throwableArray94 = numberIsTooLargeException93.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable84, (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, "org.apache.commons.math.MaxIterationsExceededException: ", (java.lang.Object[]) throwableArray94);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(localizable84);
        org.junit.Assert.assertNotNull(throwableArray94);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        int int13 = randomDataImpl1.nextZipf(20, 4.9E-324d);
//        double double16 = randomDataImpl1.nextGamma(8.994768593131994d, 1159.698814424857d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 9293.595263598983d + "'", double16 == 9293.595263598983d);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.4108142356351678d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4108142356351678d + "'", double1 == 0.4108142356351678d);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        double double11 = randomDataImpl1.nextBeta(4.524077039668076d, 0.010050166663333094d);
//        try {
//            double double14 = randomDataImpl1.nextWeibull(0.0d, 24.643770120411723d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.1874297711285913d) + "'", double6 == (-1.1874297711285913d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long2 = org.apache.commons.math.util.FastMath.max(93L, (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.6583720633353733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.990230535719563d + "'", double1 == 0.990230535719563d);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextBinomial(0, (double) 1.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl1.getClass();
//        double double13 = randomDataImpl1.nextF((double) (byte) 10, 11013.232920103323d);
//        double double16 = randomDataImpl1.nextCauchy(0.010050166663333094d, (double) 13);
//        try {
//            randomDataImpl1.setSecureAlgorithm("maximal number of iterations ({0}) exceeded", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 589.9576611918009d + "'", double6 == 589.9576611918009d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5311093275421228d + "'", double13 == 1.5311093275421228d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-2.0140003940119264d) + "'", double16 == (-2.0140003940119264d));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        randomDataImpl1.reSeed();
//        double double11 = randomDataImpl1.nextT((double) 74L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-4.107274748515569d) + "'", double5 == (-4.107274748515569d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.4453637049272352d) + "'", double11 == (-1.4453637049272352d));
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        randomDataImpl1.reSeedSecure((long) (short) 1);
//        double double15 = randomDataImpl1.nextT(0.6198779966141669d);
//        long long18 = randomDataImpl1.nextSecureLong(25L, (long) 26);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2412.2798017875966d + "'", double6 == 2412.2798017875966d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 27 + "'", int9 == 27);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0729246038022007d + "'", double11 == 3.0729246038022007d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.859843107115571d + "'", double15 == 6.859843107115571d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 26L + "'", long18 == 26L);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.0d);
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl0.getClass();
        double double5 = normalDistributionImpl0.inverseCumulativeProbability(2.4384498901303765E-55d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.2555534351306512d), 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2661707833578704d) + "'", double2 == (-0.2661707833578704d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.rint(732.1194120110488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 732.0d + "'", double1 == 732.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable16 = maxIterationsExceededException15.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        boolean boolean19 = notStrictlyPositiveException18.getBoundIsAllowed();
        maxIterationsExceededException15.addSuppressed((java.lang.Throwable) notStrictlyPositiveException18);
        java.lang.Throwable[] throwableArray21 = maxIterationsExceededException15.getSuppressed();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(24);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.11398792868037175d, (java.lang.Number) 720.0d, false);
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 30, (java.lang.Number) 51L, number13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException16);
        java.lang.Object[] objArray18 = notStrictlyPositiveException16.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, localizable6, objArray18);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.cosh(22.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.792456423065802E9d + "'", double1 == 1.792456423065802E9d);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double8 = randomDataImpl1.nextGamma((double) 10.0f, 0.02664643282774387d);
//        try {
//            long long10 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.545002707520611d + "'", double5 == 0.545002707520611d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.33856853904371254d + "'", double8 == 0.33856853904371254d);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 55L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.416198487095663d + "'", double1 == 7.416198487095663d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability(0.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.density(3.6469526198648987d);
        normalDistributionImpl0.reseedRandomGenerator(64L);
        double double8 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.161721423180312E-4d + "'", double5 == 5.161721423180312E-4d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.9507210990297232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5810963851505628d + "'", double1 == 0.5810963851505628d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) (-25.84505861145873d), (java.lang.Number) 55L, true);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "hi!", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable16 = maxIterationsExceededException15.getSpecificPattern();
        java.lang.Throwable[] throwableArray17 = maxIterationsExceededException15.getSuppressed();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.cumulativeProbability(4.641588833612779d, (double) 80L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        randomDataImpl1.reSeedSecure((long) (short) 1);
//        double double15 = randomDataImpl1.nextT(0.6198779966141669d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "95599e40bf91c136");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 95599e40bf91c136");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1037.1623173124126d + "'", double6 == 1037.1623173124126d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 29 + "'", int9 == 29);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.397284451335512d + "'", double11 == 12.397284451335512d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-90.49732160663554d) + "'", double15 == (-90.49732160663554d));
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.tan(353.9135749739193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9003526423456871d) + "'", double1 == (-1.9003526423456871d));
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        int int13 = randomDataImpl1.nextHypergeometric((int) 'a', 20, (int) (byte) 1);
//        double double15 = randomDataImpl1.nextExponential(8.339107340473126d);
//        long long17 = randomDataImpl1.nextPoisson(1.0E-9d);
//        double double20 = randomDataImpl1.nextGaussian(9.898606447528955d, (double) 11.0f);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.8613579989575175d + "'", double6 == 5.8613579989575175d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.8289714100984074d + "'", double15 == 3.8289714100984074d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 26.176715115350195d + "'", double20 == 26.176715115350195d);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("convergence failed", objArray1);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "hi!", objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable12, objArray23);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { notStrictlyPositiveException29, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable36 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException42);
        java.lang.Number number44 = notStrictlyPositiveException42.getMin();
        java.lang.Number number45 = notStrictlyPositiveException42.getMin();
        java.lang.Object[] objArray46 = notStrictlyPositiveException42.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable36, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "hi!", objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable53, objArray64);
        java.lang.Number number69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number69);
        java.lang.Object[] objArray72 = new java.lang.Object[] { notStrictlyPositiveException70, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException67, "", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable36, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException77);
        java.lang.Number number79 = notStrictlyPositiveException77.getMin();
        java.lang.Number number80 = notStrictlyPositiveException77.getMin();
        java.lang.Number number81 = notStrictlyPositiveException77.getArgument();
        java.lang.Object[] objArray82 = notStrictlyPositiveException77.getArguments();
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException74, "", objArray82);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0 + "'", number79.equals(0));
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 0 + "'", number80.equals(0));
        org.junit.Assert.assertNull(number81);
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, "hi!", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable1, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable0, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray28 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, "hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathIllegalArgumentException30.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = mathIllegalArgumentException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "hi!", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable35, objArray44);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable34, objArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException30, localizable33, objArray44);
        java.lang.Object[] objArray49 = mathIllegalArgumentException30.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable17, objArray49);
        java.lang.Object[] objArray51 = mathException50.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, "", objArray51);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(localizable31);
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 13L, 46.09996746528637d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int int18 = randomDataImpl1.nextZipf((int) (byte) 1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 658.8571287811709d + "'", double6 == 658.8571287811709d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.640298013655543d + "'", double11 == 6.640298013655543d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.458974738876574d + "'", double15 == 31.458974738876574d);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1065.9922391115886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.215305227082764d + "'", double1 == 10.215305227082764d);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        double double14 = randomDataImpl1.nextGaussian((double) 10, (double) '#');
//        java.lang.String str16 = randomDataImpl1.nextHexString(2);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.284615652674382d) + "'", double5 == (-2.284615652674382d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0989312282446813d + "'", double7 == 2.0989312282446813d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 46L + "'", long9 == 46L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "f861825e410ee3141c6810bdbace437a21590bc041ea4c3316448cf5392d0672c9c894877426bfd671b90a80be6cfa551edd" + "'", str11.equals("f861825e410ee3141c6810bdbace437a21590bc041ea4c3316448cf5392d0672c9c894877426bfd671b90a80be6cfa551edd"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.203897472614987d + "'", double14 == 7.203897472614987d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5e" + "'", str16.equals("5e"));
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        double double11 = randomDataImpl1.nextExponential(0.9292666946387997d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.3713126634258916d) + "'", double5 == (-2.3713126634258916d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-4.438486941994586d) + "'", double7 == (-4.438486941994586d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 56L + "'", long9 == 56L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.23541135598729118d + "'", double11 == 0.23541135598729118d);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "hi!", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException15.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathIllegalArgumentException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "hi!", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable20, objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable19, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException15, localizable18, objArray29);
        java.lang.Object[] objArray34 = mathIllegalArgumentException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((-1), "hi!", objArray34);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.log10(1183.4451214873363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.073148123703364d + "'", double1 == 3.073148123703364d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(50.83753063190289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.130044223698959d + "'", double1 == 7.130044223698959d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 0);
        double double8 = normalDistributionImpl2.cumulativeProbability(0.9291491167467972d);
        double double10 = normalDistributionImpl2.cumulativeProbability(35.0d);
        double double11 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        randomDataImpl1.reSeed((long) 2);
//        int int16 = randomDataImpl1.nextZipf(15, 0.02664643282774387d);
//        try {
//            int[] intArray19 = randomDataImpl1.nextPermutation((int) (short) 0, 20);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 20 is larger than the maximum (0): permutation size (20) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.6274421540090078d) + "'", double6 == (-1.6274421540090078d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.7694977763250068d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 92L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 92 + "'", int1 == 92);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(20, "7", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9999986855378105d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.11398792868037175d, (java.lang.Number) 720.0d, false);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 52L, number14, false);
        java.lang.Number number17 = numberIsTooLargeException16.getMax();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException16, localizable18, objArray19);
        java.lang.Number number21 = numberIsTooLargeException16.getMax();
        java.lang.Object[] objArray22 = numberIsTooLargeException16.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(3, localizable5, objArray22);
        int int24 = maxIterationsExceededException23.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        randomDataImpl1.reSeedSecure((long) (short) -1);
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation((int) ' ', 57);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 57 is larger than the maximum (32): permutation size (57) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 92L + "'", long7 == 92L);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.5595106570525964d), (-0.07074101207510715d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.071 is smaller than, or equal to, the minimum (0): standard deviation (-0.071)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int[] intArray9 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 673.8018388234307d + "'", double6 == 673.8018388234307d);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 11L, (float) 46L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.564348191467836d + "'", double1 == 4.564348191467836d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        int int14 = randomDataImpl1.nextZipf(3, 0.5228693839029145d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.6413064574792458d) + "'", double6 == (-3.6413064574792458d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 41257.21825358575d, (java.lang.Number) 2.638030454942342d, true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.26807434023259d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7971341386199956d + "'", double1 == 0.7971341386199956d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.11209273836431936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.993724184321317d + "'", double1 == 0.993724184321317d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        java.lang.Class<?> wildcardClass6 = notStrictlyPositiveException1.getClass();
        java.lang.Object[] objArray7 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 2.6881171418161356E43d, number51, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 0.010473754765072894d, (java.lang.Number) 6218835.190380572d, true);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        double double14 = randomDataImpl1.nextCauchy(100.0d, 1.248867972642223d);
//        double double17 = randomDataImpl1.nextGaussian(0.8623188722876839d, (double) 20);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.010265952828977139d + "'", double8 == 0.010265952828977139d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.35213759492454d + "'", double14 == 101.35213759492454d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.8108458817050535d) + "'", double17 == (-1.8108458817050535d));
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 2.718281828459045d);
//        try {
//            long long11 = randomDataImpl1.nextLong((long) 23, (long) 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 23 is larger than, or equal to, the maximum (23): lower bound (23) must be strictly less than upper bound (23)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.852663881738288d) + "'", double5 == (-2.852663881738288d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.552713678800501E-15d);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        randomDataImpl1.reSeedSecure(52L);
        try {
            double double7 = randomDataImpl1.nextT(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        try {
//            double double11 = randomDataImpl1.nextF(0.0d, 4.641588833612779d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.01109904425414188d + "'", double8 == 0.01109904425414188d);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable8, objArray19);
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { notStrictlyPositiveException25, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException22, "", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(86, "org.apache.commons.math.exception.OutOfRangeException: 0 out of [1.745, 100] range: org.apache.commons.math.MaxIterationsExceededException: ", objArray27);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray27);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(30, 0, 11);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.0482114022552778d) + "'", double6 == (-3.0482114022552778d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.util.Localizable localizable33 = notStrictlyPositiveException32.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (byte) -1, (java.lang.Number) 0.8427007929497151d, (java.lang.Number) 100.0f);
        java.lang.Number number38 = outOfRangeException37.getHi();
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 100.0f + "'", number38.equals(100.0f));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
        try {
            int int8 = randomDataImpl1.nextHypergeometric(15, (int) ' ', 72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (15): number of successes (32) must be less than or equal to population size (15)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.7031839360032603E-108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.447282664438742E215d + "'", double1 == 3.447282664438742E215d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.23843310278896238d, (-2.3713126634258916d), (-1.9003526423456871d), 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number8, (java.lang.Number) 0.5810963851505628d, (java.lang.Number) 1325L);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.006947391689586584d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20720.03873186302d + "'", double1 == 20720.03873186302d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double2 = org.apache.commons.math.util.FastMath.max(91.99999999999999d, (double) 40.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.99999999999999d + "'", double2 == 91.99999999999999d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        try {
            double double3 = normalDistributionImpl0.inverseCumulativeProbability(7.130044223698959d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7.13 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.041851167628339195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0427392738421426d + "'", double1 == 1.0427392738421426d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.010328580628179911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01032894793456419d + "'", double1 == 0.01032894793456419d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 359.1342053695754d, (java.lang.Number) 51L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 51L + "'", number4.equals(51L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        long long1 = org.apache.commons.math.util.FastMath.abs(3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.atan(1183.4451214873363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5699513363987723d + "'", double1 == 1.5699513363987723d);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (short) 100, 0, 0);
//        double double8 = randomDataImpl1.nextBeta(3.141592653589793d, 0.3989422804014327d);
//        double double11 = randomDataImpl1.nextBeta(720.0742987389762d, 1.7453292519943298d);
//        double double13 = randomDataImpl1.nextT(6.859843107115571d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9482427710194895d + "'", double8 == 0.9482427710194895d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9962211983962753d + "'", double11 == 0.9962211983962753d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.6878923467070479d) + "'", double13 == (-0.6878923467070479d));
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 31L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        java.lang.Number number92 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException93 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number92);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException93);
        java.lang.Number number95 = notStrictlyPositiveException93.getMin();
        java.lang.Number number96 = notStrictlyPositiveException93.getMin();
        java.lang.Number number97 = notStrictlyPositiveException93.getArgument();
        java.lang.Object[] objArray98 = notStrictlyPositiveException93.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException99 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray98);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertTrue("'" + number95 + "' != '" + 0 + "'", number95.equals(0));
        org.junit.Assert.assertTrue("'" + number96 + "' != '" + 0 + "'", number96.equals(0));
        org.junit.Assert.assertNull(number97);
        org.junit.Assert.assertNotNull(objArray98);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        java.lang.Number number46 = numberIsTooLargeException45.getMax();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.010473371793188269d + "'", number46.equals(0.010473371793188269d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0683408779031875d, 0.5852543936653304d, (double) 29L, 23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6951551520053487d + "'", double4 == 0.6951551520053487d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        double double9 = randomDataImpl1.nextT((double) 31L);
//        try {
//            int int13 = randomDataImpl1.nextHypergeometric(0, (-1), 17);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 42L + "'", long7 == 42L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4048003286968162d) + "'", double9 == (-0.4048003286968162d));
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.special.Erf.erf(1177.8813928959773d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5852543936653304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.53260669851145d + "'", double1 == 33.53260669851145d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.6583720633353733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4020419881287145d + "'", double1 == 0.4020419881287145d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(22.140692632779267d, (double) 0, 0.9999986855378105d, 2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.9080758426552533d), 4.650679867556336E-4d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 64L, (java.lang.Number) 0.8616935587324228d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
        randomDataImpl1.reSeed();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 99.77610183877165d, (java.lang.Number) 10, (java.lang.Number) 1.7453292519943295d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Throwable throwable6 = null;
        try {
            outOfRangeException4.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.792456423065802E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-25.84505861145873d), 1.338474404104274d, 20277.75415839241d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 52L, number4, false);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Object[] objArray8 = numberIsTooLargeException6.getArguments();
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable1, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "hi!", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable39, objArray50);
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number55);
        java.lang.Object[] objArray58 = new java.lang.Object[] { notStrictlyPositiveException56, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException53, "", objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("hi!", objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable63 = maxIterationsExceededException62.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray80 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException72, "hi!", objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, localizable71, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable69, objArray80);
        java.lang.Number number85 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number85);
        java.lang.Object[] objArray88 = new java.lang.Object[] { notStrictlyPositiveException86, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException83, "", objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable63, objArray88);
        org.apache.commons.math.exception.util.Localizable localizable91 = null;
        java.lang.Number number93 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException95 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable91, (java.lang.Number) 52L, number93, false);
        java.lang.Throwable[] throwableArray96 = numberIsTooLargeException95.getSuppressed();
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable30, (java.lang.Object[]) throwableArray96);
        java.lang.Class<?> wildcardClass98 = mathException97.getClass();
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray96);
        org.junit.Assert.assertNotNull(wildcardClass98);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(12.17048300280018d, 4329928.223921462d, (double) (byte) 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable8, objArray19);
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { notStrictlyPositiveException25, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException22, "", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, "76ea3459a59a17400951", objArray27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("416", objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, "org.apache.commons.math.MaxIterationsExceededException: ", objArray27);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray27);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test373");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextZipf((int) '#', 1.1102230246251565E-16d);
//        randomDataImpl1.reSeed();
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation(11, 92);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 92 is larger than the maximum (11): permutation size (92) exceeds permuation domain (11)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double2 = org.apache.commons.math.util.FastMath.atan2(263.37926039421126d, 1.792456423065802E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.469376086386121E-7d + "'", double2 == 1.469376086386121E-7d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        double double5 = normalDistributionImpl2.sample();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1, "hi!", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable0, objArray9);
        java.lang.Throwable throwable12 = null;
        try {
            convergenceException11.addSuppressed(throwable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.FastMath.min(0.03610956433305299d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03610956433305299d + "'", double2 == 0.03610956433305299d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4342944819032518d + "'", double1 == 0.4342944819032518d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl2.sample();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 47L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double2 = org.apache.commons.math.util.FastMath.min(3.970291913552122d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.atanh(51.69314718055995d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.3169578969248166d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.23843310278896238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.02856009277347d + "'", double1 == 1.02856009277347d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 29L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 23);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (short) 100, 0, 0);
//        double double8 = randomDataImpl1.nextF((double) ' ', 1721.1843091420576d);
//        randomDataImpl1.reSeed(55L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3456453969930526d + "'", double8 == 1.3456453969930526d);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 73);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 73 + "'", int1 == 73);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (short) 100, 0, 0);
//        double double8 = randomDataImpl1.nextBeta(3.141592653589793d, 0.3989422804014327d);
//        double double11 = randomDataImpl1.nextBeta(720.0742987389762d, 1.7453292519943298d);
//        java.lang.Class<?> wildcardClass12 = randomDataImpl1.getClass();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9999985241359128d + "'", double8 == 0.9999985241359128d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9988259017587731d + "'", double11 == 0.9988259017587731d);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        long long8 = randomDataImpl1.nextPoisson((double) (short) 100);
//        long long10 = randomDataImpl1.nextPoisson((double) 37L);
//        randomDataImpl1.reSeed();
//        int int14 = randomDataImpl1.nextInt(57, 72);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 27L + "'", long6 == 27L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 112L + "'", long8 == 112L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 65 + "'", int14 == 65);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.041851167628339195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-24.40459835022893d) + "'", double1 == (-24.40459835022893d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double3 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double5 = normalDistributionImpl2.inverseCumulativeProbability(0.8285514085307449d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.829");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.01625980437881211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        long long14 = randomDataImpl1.nextSecureLong(14L, 37L);
//        randomDataImpl1.reSeed((long) 13);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.026576316921976793d + "'", double8 == 0.026576316921976793d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.log(26.176715115350195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.264870279551681d + "'", double1 == 3.264870279551681d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.cosh(74.20994852478785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.471126184643004E31d + "'", double1 == 8.471126184643004E31d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 89L, (float) 76L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 76.0f + "'", float2 == 76.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.4108142356351678d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 25L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9124227656412556d + "'", double1 == 3.9124227656412556d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03773137331632698d + "'", double1 == 0.03773137331632698d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 2.617880691207321d);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 3.4855950602259513d, (java.lang.Number) 0.9999776607197243d, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 17, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) (byte) 100);
//        long long10 = randomDataImpl1.nextLong((long) '4', 100L);
//        double double13 = randomDataImpl1.nextGaussian((double) 51L, 0.7805951733159242d);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric(12, (int) '4', 80);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (12): number of successes (52) must be less than or equal to population size (12)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 87L + "'", long7 == 87L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 90L + "'", long10 == 90L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 50.03898957468698d + "'", double13 == 50.03898957468698d);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.FastMath.min(2.021173844556448d, (double) 64L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.021173844556448d + "'", double2 == 2.021173844556448d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.0989312282446813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5039232426494689d) + "'", double1 == (-0.5039232426494689d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.707216031255932d));
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(23);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed((long) 5);
        randomDataImpl1.reSeedSecure(1325L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7303757501620307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8188718988981628d + "'", double1 == 0.8188718988981628d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.String str35 = outOfRangeException34.toString();
        java.lang.Number number36 = outOfRangeException34.getLo();
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0 out of [1.745, 100] range: org.apache.commons.math.MaxIterationsExceededException: " + "'", str35.equals("org.apache.commons.math.exception.OutOfRangeException: 0 out of [1.745, 100] range: org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.7453292519943295d + "'", number36.equals(1.7453292519943295d));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test414");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        double double8 = randomDataImpl1.nextChiSquare(3.4855950602259513d);
//        int int11 = randomDataImpl1.nextZipf(86, 0.7805951733159242d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 942.1031573769328d + "'", double6 == 942.1031573769328d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.522576975369882d + "'", double8 == 7.522576975369882d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 27 + "'", int11 == 27);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.006923369759603934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.1596824732033353d) + "'", double1 == (-2.1596824732033353d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "hi!", objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathIllegalArgumentException20.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathIllegalArgumentException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable25, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable24, objArray34);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException20, localizable23, objArray34);
        java.lang.Object[] objArray39 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "416", objArray39);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)"));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray39);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString(16);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(27);
//        try {
//            double double8 = randomDataImpl1.nextUniform(0.02025047350832094d, 1.7763568394002505E-15d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.02 is larger than, or equal to, the maximum (0): lower bound (0.02) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14fef0fa2290a0ec" + "'", str3.equals("14fef0fa2290a0ec"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "73d5126d8875ad8df278932e681" + "'", str5.equals("73d5126d8875ad8df278932e681"));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed((long) 5);
        double double9 = randomDataImpl1.nextUniform(7.416198487095663d, 2412.2798017875966d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1764.2168299815828d + "'", double9 == 1764.2168299815828d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(10);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test421");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        randomDataImpl1.reSeed((long) (byte) 100);
//        double double13 = randomDataImpl1.nextExponential(4.85209129348869d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.3027128327735182d) + "'", double5 == (-0.3027128327735182d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.9790031874208696d) + "'", double7 == (-0.9790031874208696d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 54L + "'", long9 == 54L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5804074931708232d + "'", double13 == 1.5804074931708232d);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int1 = org.apache.commons.math.util.FastMath.abs(20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        int int6 = randomDataImpl1.nextZipf((int) '4', (double) '4');
        try {
            double double9 = randomDataImpl1.nextGamma((double) 80, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        randomDataImpl1.reSeedSecure((long) 30);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 892.9466736440057d + "'", double6 == 892.9466736440057d);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9999985241359128d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "hi!", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, "hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException0.getGeneralPattern();
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 1.9205429234508569d, (java.lang.Number) 91.99999999999999d, number23);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 80L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0989312282446813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0989312282446817d + "'", double1 == 2.0989312282446817d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(263.37926039421126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 263.3792603942113d + "'", double1 == 263.3792603942113d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.FastMath.min(62, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test431");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        try {
//            int int12 = randomDataImpl1.nextPascal(100, (double) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.4588085360398245d) + "'", double5 == (-0.4588085360398245d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.7000947413742896d) + "'", double7 == (-0.7000947413742896d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43L + "'", long9 == 43L);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.718863221535756d + "'", double1 == 3.718863221535756d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "hi!", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable5, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(20, "7", objArray16);
        java.lang.Class<?> wildcardClass22 = maxIterationsExceededException21.getClass();
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        float float2 = org.apache.commons.math.util.FastMath.min(35.0f, (float) 44L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.012849942968156417d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(72);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, "hi!", objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable13, objArray24);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { notStrictlyPositiveException30, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException27, "", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException36.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 0, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 100.0f);
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException43);
        java.lang.Number number45 = notStrictlyPositiveException43.getMin();
        java.lang.Number number46 = notStrictlyPositiveException43.getMin();
        java.lang.Object[] objArray47 = notStrictlyPositiveException43.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable37, objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable3, objArray47);
        java.lang.Object[] objArray50 = maxIterationsExceededException49.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable0, "org.apache.commons.math.MathException: null is smaller than, or equal to, the minimum (0)", objArray50);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0 + "'", number46.equals(0));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7596149213951954d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9953040688641185d + "'", double1 == 0.9953040688641185d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        java.lang.Class<?> wildcardClass3 = normalDistributionImpl2.getClass();
        try {
            double double5 = normalDistributionImpl2.inverseCumulativeProbability(0.03453464682400093d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.035");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability(1.0d);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 1);
        double double8 = normalDistributionImpl2.cumulativeProbability((double) 100);
        double double9 = normalDistributionImpl2.sample();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 97.0d, (java.lang.Number) 51L);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97.0d + "'", number5.equals(97.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 97.0d + "'", number6.equals(97.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 51L + "'", number7.equals(51L));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextBinomial(0, (double) 1.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl1.getClass();
//        long long13 = randomDataImpl1.nextSecureLong((long) (byte) 0, 52L);
//        try {
//            int int16 = randomDataImpl1.nextZipf((-1), 0.03825028807204822d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1122.3470699456013d + "'", double6 == 1122.3470699456013d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 26L + "'", long13 == 26L);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.2059129795337131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08131596960191864d + "'", double1 == 0.08131596960191864d);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        try {
//            double double14 = randomDataImpl1.nextBeta(0.5403023058681398d, 3.447282664438742E215d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Continued fraction diverged to NaN for value 0.5");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1142.0263918724684d + "'", double6 == 1142.0263918724684d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8635603391428197d + "'", double11 == 0.8635603391428197d);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test447");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextChiSquare(0.010473371793188269d);
//        try {
//            int int8 = randomDataImpl1.nextSecureInt(2, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (0): lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.321355178420736E-9d + "'", double5 == 1.321355178420736E-9d);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextZipf((int) (short) 1, 2.251752586176186d);
        try {
            int int8 = randomDataImpl1.nextHypergeometric(30, 30, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (30): sample size (52) must be less than or equal to population size (30)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9999938834766104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.540307452734993d + "'", double1 == 0.540307452734993d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, "hi!", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException13.getSpecificPattern();
        java.lang.Object[] objArray15 = mathIllegalArgumentException13.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("convergence failed", objArray15);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.abs(673.8018388234307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 673.8018388234307d + "'", double1 == 673.8018388234307d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1115.7078762887215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.966937503373062E-4d + "'", double1 == 8.966937503373062E-4d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.util.FastMath.sin(34.19868852603545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3511796143229664d + "'", double1 == 0.3511796143229664d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.util.FastMath.cos(2922.084755167198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9196580988801253d + "'", double1 == 0.9196580988801253d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.ulp(263.3792603942113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double3 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double6 = normalDistributionImpl2.getMean();
        double[] doubleArray8 = normalDistributionImpl2.sample(52);
        double double9 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "hi!", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray17);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException23, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "hi!", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable39, objArray50);
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number55);
        java.lang.Object[] objArray58 = new java.lang.Object[] { notStrictlyPositiveException56, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException53, "", objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("hi!", objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable63 = maxIterationsExceededException62.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray80 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException72, "hi!", objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, localizable71, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable69, objArray80);
        java.lang.Number number85 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number85);
        java.lang.Object[] objArray88 = new java.lang.Object[] { notStrictlyPositiveException86, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException83, "", objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable63, objArray88);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException92 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) 1721.1843091420576d);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.11398792868037175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.37074673649307d + "'", double1 == 78.37074673649307d);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test459");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double11 = randomDataImpl1.nextGaussian(1.4093490824269389E22d, 0.8342233605065102d);
//        int int14 = randomDataImpl1.nextInt((int) (short) -1, (int) 'a');
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextWeibull(0.8653943989957588d, (double) 32L);
//        int int21 = randomDataImpl1.nextInt((int) (short) 0, (int) (short) 100);
//        double double24 = randomDataImpl1.nextCauchy((-1.4794073528781455d), 22.000000000000004d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.030048879444856517d + "'", double8 == 0.030048879444856517d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4093490824269389E22d + "'", double11 == 1.4093490824269389E22d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 28.192413955277427d + "'", double18 == 28.192413955277427d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 27 + "'", int21 == 27);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-10.63348657130766d) + "'", double24 == (-10.63348657130766d));
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGamma((double) 10.0f, (double) 100);
//        int int9 = randomDataImpl1.nextPascal((int) 'a', 0.7773466788783218d);
//        double double11 = randomDataImpl1.nextExponential((double) 11L);
//        randomDataImpl1.reSeedSecure((long) (short) 1);
//        int int16 = randomDataImpl1.nextZipf(23, 0.20050398057873267d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1041.769569996403d + "'", double6 == 1041.769569996403d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.348519843203608d + "'", double11 == 10.348519843203608d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "hi!", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException15.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathIllegalArgumentException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "hi!", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable20, objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable19, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException15, localizable18, objArray29);
        java.lang.Object[] objArray34 = mathIllegalArgumentException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(26, "5", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException36.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable37);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1721.1843091420576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test463");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        try {
//            double double14 = randomDataImpl1.nextUniform((double) 57L, (double) 27L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 57 is larger than, or equal to, the maximum (27): lower bound (57) must be strictly less than upper bound (27)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5542788731795683d + "'", double6 == 0.5542788731795683d);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException59, "hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable56, objArray67);
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { notStrictlyPositiveException73, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException70, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 52L, number87, false);
        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable80, (java.lang.Object[]) throwableArray90);
        java.lang.Number number93 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException95 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable80, (java.lang.Number) 0.9998872015382027d, number93, false);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(throwableArray90);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 99.77610183877165d, (java.lang.Number) 10, (java.lang.Number) 1.7453292519943295d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.7453292519943295d + "'", number7.equals(1.7453292519943295d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test468");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        try {
//            int int14 = randomDataImpl1.nextBinomial(73, 4.524077039668076d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4.524 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.9524271036307344d) + "'", double6 == (-2.9524271036307344d));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) 59L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 59.0f + "'", float2 == 59.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 72.0f, (-7.0d), 868.6688730268119d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -7 is smaller than, or equal to, the minimum (0): standard deviation (-7)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 24.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4188790204786391d + "'", double1 == 0.4188790204786391d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.16511615943298497d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16664173330839177d) + "'", double1 == (-0.16664173330839177d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 26);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 26L + "'", long1 == 26L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.564348191467836d, (double) 108L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.6951551520053487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26681145894537517d + "'", double1 == 0.26681145894537517d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) 100, (java.lang.Number) 1721.0d, (java.lang.Number) 0.010050166663333094d);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 2.6881171418161356E43d, number51, false);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, number54);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test477");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long5 = randomDataImpl1.nextPoisson(0.013870119658797706d);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) -1, 0);
//        int int11 = randomDataImpl1.nextInt(5, 25);
//        try {
//            long long14 = randomDataImpl1.nextLong(80L, 54L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 80 is larger than, or equal to, the maximum (54): lower bound (80) must be strictly less than upper bound (54)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4, "hi!", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable3, objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable2, objArray12);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("95599e40bf91c136", objArray12);
        java.lang.Class<?> wildcardClass18 = objArray12.getClass();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1031.1242670907159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1031.124267090716d + "'", double1 == 1031.124267090716d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 72);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 72L + "'", long1 == 72L);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test481");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        long long6 = randomDataImpl1.nextLong((-1L), (long) '4');
//        randomDataImpl1.reSeed(1L);
//        int int11 = randomDataImpl1.nextZipf((int) (byte) 100, 4.401612632446982d);
//        double double14 = randomDataImpl1.nextGamma(1115.7078762887215d, (double) 25);
//        try {
//            int int17 = randomDataImpl1.nextPascal(57, 49.136388792011836d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 49.136 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 17L + "'", long6 == 17L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 27694.98846993187d + "'", double14 == 27694.98846993187d);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.010473563267577948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21879202448390034d + "'", double1 == 0.21879202448390034d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 64L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 64.0f + "'", float1 == 64.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 73.0f, (-34.56295964364512d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -34.563 is smaller than, or equal to, the minimum (0): standard deviation (-34.563)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test486");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        try {
//            long long10 = randomDataImpl1.nextSecureLong(78L, 72L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 78 is larger than, or equal to, the maximum (72): lower bound (78) must be strictly less than upper bound (72)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.46391489531060787d) + "'", double5 == (-0.46391489531060787d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.13561184928836165d) + "'", double7 == (-0.13561184928836165d));
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test487");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double6 = randomDataImpl1.nextGaussian((double) 0, 2.99822295029797d);
//        randomDataImpl1.reSeedSecure((long) (byte) 1);
//        int int12 = randomDataImpl1.nextHypergeometric(30, 0, 11);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5294702919857353d) + "'", double6 == (-0.5294702919857353d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.9911537047097787d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52L, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable15, objArray26);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { notStrictlyPositiveException32, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException29, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.MaxIterationsExceededException: ", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 10, (java.lang.Number) 0.010473371793188269d, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { (short) 1, true, 0.0d, 1L, '#', 1 };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException52, "hi!", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable49, objArray60);
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number65);
        java.lang.Object[] objArray68 = new java.lang.Object[] { notStrictlyPositiveException66, (byte) 0 };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException63, "", objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(0, "76ea3459a59a17400951", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable39, objArray68);
        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException71.getSpecificPattern();
        java.lang.String str73 = convergenceException71.toString();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNull(localizable72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: " + "'", str73.equals("org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: "));
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        randomDataImpl1.reSeedSecure(52L);
//        double double8 = randomDataImpl1.nextBeta(2.99822295029797d, (double) (byte) 100);
//        double double10 = randomDataImpl1.nextChiSquare((double) ' ');
//        randomDataImpl1.reSeedSecure();
//        int int14 = randomDataImpl1.nextInt(2, (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.021647088823576584d + "'", double8 == 0.021647088823576584d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 17.663178695133233d + "'", double10 == 17.663178695133233d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, (double) 'a');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.getMean();
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability((-0.9790031874208696d), (-75.1353432068657d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Class<?> wildcardClass7 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test495");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        double double5 = randomDataImpl1.nextT((double) 1);
//        double double7 = randomDataImpl1.nextT(1.5707963267948966d);
//        long long9 = randomDataImpl1.nextPoisson((double) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        double double14 = randomDataImpl1.nextGaussian((double) 10, (double) '#');
//        try {
//            double double17 = randomDataImpl1.nextCauchy(1111.8929676559267d, (-24.40459835022893d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -24.405 is smaller than, or equal to, the minimum (0): scale (-24.405)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.7009800086995741d) + "'", double5 == (-0.7009800086995741d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.183954262325525d) + "'", double7 == (-2.183954262325525d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 57L + "'", long9 == 57L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "33daaa133195141bf214e1176c70d9de95e54303d4a633ba3e5d6808727df9ee4a457747f58ce2e3ad2f1b6215840daed422" + "'", str11.equals("33daaa133195141bf214e1176c70d9de95e54303d4a633ba3e5d6808727df9ee4a457747f58ce2e3ad2f1b6215840daed422"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 48.23447515836442d + "'", double14 == 48.23447515836442d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.6951551520053487d, (java.lang.Number) 27, true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0E-9d, (java.lang.Number) 1721.1843091420576d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (1,721.184)"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.6881171418161356E43d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 59L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 59.0f + "'", float1 == 59.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (byte) 100);
        double double5 = randomDataImpl1.nextChiSquare(0.010473371793188269d);
        try {
            int int8 = randomDataImpl1.nextZipf(62, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-323d + "'", double5 == 1.0E-323d);
    }
}

