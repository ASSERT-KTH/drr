import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7071067811865475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7675231451261162d + "'", double1 == 0.7675231451261162d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 0.0f);
        double[] doubleArray10 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0.0f);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray18);
        double[] doubleArray24 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 0.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-2147453857) + "'", int31 == (-2147453857));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double2 = org.apache.commons.math.util.MathUtils.log((-9899.999999999998d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.232920103324d, 1.8198192184425595E27d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103324d + "'", double2 == 11013.232920103324d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 10, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 530L + "'", long2 == 530L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.019230769230769232d, (java.lang.Number) 100.0f, 2, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-11) + "'", int2 == (-11));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long1 = org.apache.commons.math.util.FastMath.abs(9100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9100L + "'", long1 == 9100L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693280, 1001);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-97), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 9L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.605551275463989d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06292874110632765d + "'", double1 == 0.06292874110632765d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 970000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 970000.0f + "'", float1 == 970000.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.732511156817248d + "'", number11.equals(3.732511156817248d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7716133340725972d + "'", double1 == 0.7716133340725972d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013707783890401887d) + "'", double1 == (-0.013707783890401887d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1100, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(90L, 4720970605666256849L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.log(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1851160204964712d + "'", double1 == 1.1851160204964712d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.log10(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.302190676759448d + "'", double1 == 3.302190676759448d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-65), (-101L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (-31));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.sinh(6283429.007424238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-940899));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray19 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 0.0f);
        double[] doubleArray25 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 0.0f);
        double[] doubleArray31 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 0.0f);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int1 = org.apache.commons.math.util.FastMath.abs(1000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1000 + "'", int1 == 1000);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int1 = org.apache.commons.math.util.MathUtils.hash(89.99999999999999d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1079410688) + "'", int1 == (-1079410688));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.562453851238174d), 2.2182652975384294E156d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long2 = org.apache.commons.math.util.FastMath.min(530L, 1072693280L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 530L + "'", long2 == 530L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.2204032943178235E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2204032943178236E39d + "'", double1 == 1.2204032943178236E39d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.2204032943178235E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1300055688031423E37d + "'", double1 == 2.1300055688031423E37d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.1771122663712068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17618775239352946d + "'", double1 == 0.17618775239352946d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1509505313, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 530L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.499726279454946E229d + "'", double1 == 7.499726279454946E229d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(36, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1872 + "'", int2 == 1872);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.asin(21.49206902968473d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(11.849805778474547d, (double) (-2147453857));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1077805056);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10272986741866949d + "'", double2 == 0.10272986741866949d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double[] doubleArray30 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray32);
        double[] doubleArray44 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double[] doubleArray56 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 0.0f);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray58);
        double[] doubleArray64 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 0.0f);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray66);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1528444521L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double[] doubleArray30 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray32);
        java.lang.Class<?> wildcardClass41 = doubleArray32.getClass();
        double[] doubleArray45 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 0.0f);
        double[] doubleArray51 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 0.0f);
        double[] doubleArray57 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 0.0f);
        double[] doubleArray63 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 0.0f);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray65);
        double[] doubleArray71 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 0.0f);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray73);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73, orderDirection75, false);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray73);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray47);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray84 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) 0.0f);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-2147453857) + "'", int80 == (-2147453857));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 5.58351893845611d + "'", double87 == 5.58351893845611d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.298292365610485d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7005619261544304d + "'", double2 == 0.7005619261544304d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 9L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 940900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.754593205806493d + "'", double1 == 13.754593205806493d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.015269573507533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7007529698288765d + "'", double1 == 0.7007529698288765d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-2147453857L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number19 = nonMonotonousSequenceException16.getArgument();
        boolean boolean20 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (byte) 100 + "'", number19.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(36, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 1219518760, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(52, 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3679075400L + "'", long2 == 3679075400L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-65));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        float float1 = org.apache.commons.math.util.FastMath.abs(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray11 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray13 = new int[] { (short) 0 };
        int[] intArray18 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray18);
        int[] intArray24 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray26 = new int[] { (short) 0 };
        int[] intArray31 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray31);
        int[] intArray36 = new int[] { (short) 0 };
        int[] intArray41 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray41);
        int[] intArray47 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray49 = new int[] { (short) 0 };
        int[] intArray54 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray54);
        int[] intArray60 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray62 = new int[] { (short) 0 };
        int[] intArray67 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray67);
        int[] intArray74 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray76 = new int[] { (short) 0 };
        int[] intArray81 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray81);
        int[] intArray85 = new int[] { (short) 0 };
        int[] intArray90 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray90);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray81);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray81);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray41);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 36 + "'", int20 == 36);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 36 + "'", int33 == 36);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 36 + "'", int34 == 36);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 36 + "'", int56 == 36);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 36 + "'", int69 == 36);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 36 + "'", int70 == 36);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 36 + "'", int83 == 36);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long1 = org.apache.commons.math.util.FastMath.abs((-152460036613L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 152460036613L + "'", long1 == 152460036613L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1972245773362196d + "'", double1 == 2.1972245773362196d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2147453857, (-940899));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.MathUtils.log(6.877296071497429d, 0.019230769230769232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.049160532250158d) + "'", double2 == (-2.049160532250158d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(21.49206902968473d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1231.4048484047612d + "'", double1 == 1231.4048484047612d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 11.0f, (double) 1001, 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.5395564933646284d, 1100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5395564933646284d + "'", double2 == 1.5395564933646284d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.2836910914864728d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29169168098031323d) + "'", double1 == (-0.29169168098031323d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2155590500493187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1072693280);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.tanh(9.306852821501208d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999835107712d + "'", double1 == 0.9999999835107712d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.942624315E-315d, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.450148305539266E-308d + "'", double2 == 4.450148305539266E-308d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.4152925665684205d, (double) (byte) 10, 1.8198192184425592E27d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 10);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 10);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger37);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger28);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) (byte) 10);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 10);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger44);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger47);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 970000);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double2 = org.apache.commons.math.util.FastMath.max(2005.3522829578812d, 1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2005.3522829578812d + "'", double2 == 2005.3522829578812d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8517779466253769d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 3679075400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1543.759214377844d + "'", double1 == 1543.759214377844d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 10);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 10);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 10);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger25);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 10);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) 10);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger38);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger29);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (byte) 10);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 0L);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 10);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, bigInteger45);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger48);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 0L);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, 10);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 10);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, (long) 10);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger61);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, 10);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger67);
        java.math.BigInteger bigInteger69 = null;
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, 0L);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 10);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, (long) 10);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (int) 'a');
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) 53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger68, (java.lang.Number) 53, 0, orderDirection81, false);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger68);
        try {
            java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(bigInteger84);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.5d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1071644672 + "'", int1 == 1071644672);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-101L), 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10201L + "'", long2 == 10201L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2147453857) + "'", int13 == (-2147453857));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double[] doubleArray22 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 0.0f);
        double[] doubleArray28 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0.0f);
        double[] doubleArray34 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 0.0f);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray36);
        double[] doubleArray42 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 0.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray36);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double[] doubleArray56 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 0.0f);
        double[] doubleArray62 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        double[] doubleArray68 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 0.0f);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray70);
        double[] doubleArray76 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) 0.0f);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray78);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78, orderDirection80, false);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray78);
        double[] doubleArray87 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, (double) 0.0f);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray87);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray87);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1219518760 + "'", int92 == 1219518760);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double2 = org.apache.commons.math.util.MathUtils.log(5.558945533197085E83d, (-98.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-940899), (-31));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(11, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 70162759680L, (int) (byte) 100, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.8872709503576206d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.999999999999998d + "'", double1 == 8.999999999999998d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean10 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        boolean boolean12 = nonMonotonousSequenceException9.getStrict();
        java.lang.String str13 = nonMonotonousSequenceException9.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection14, false);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        java.lang.Number number18 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number18, (java.lang.Number) 5.267884728309446d, (-97), orderDirection21, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection21, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2147453857) + "'", int17 == (-2147453857));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.843257760045314d, (java.lang.Number) 1.5707963267948966d, 90);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10201L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8103.08392757537d + "'", double1 == 8103.08392757537d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1078591488, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 4L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1079410688));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray12 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray14 = new int[] { (short) 0 };
        int[] intArray19 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray25 = new int[] { (short) 0 };
        int[] intArray30 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray30);
        int[] intArray35 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray37 = new int[] { (short) 0 };
        int[] intArray42 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray42);
        int[] intArray46 = new int[] { (short) 0 };
        int[] intArray51 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray51);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray51);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray30);
        int[] intArray59 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray61 = new int[] { (short) 0 };
        int[] intArray66 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        try {
            int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 36 + "'", int21 == 36);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 36 + "'", int44 == 36);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 36 + "'", int68 == 36);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 530L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1L, (float) 4720970605666256849L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.7209709E18f + "'", float2 == 4.7209709E18f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 940900000L, (int) (byte) 1, (-10000));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.7629044111929628d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0004447709181594d + "'", double1 == 3.0004447709181594d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4782959598355583d + "'", double1 == 2.4782959598355583d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1077805056L, (long) 1079427072);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23669676834816L + "'", long2 == 23669676834816L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(89.83515197002036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5147.175059798529d + "'", double1 == 5147.175059798529d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.asin((-15.653559774527022d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(359.99999999999994d, (double) 90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.rint(Double.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray19 = new double[] {};
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray19);
        double[] doubleArray25 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 0.0f);
        double[] doubleArray31 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 0.0f);
        double[] doubleArray37 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 0.0f);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray27);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5707963267948966d, 90, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-9900.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.1344640137963142d), (double) (-97), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.log10(50.005000000000024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6990134316128818d + "'", double1 == 1.6990134316128818d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 9.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 1872);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.298342365610589d, 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5284445220460029E9d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-615237829) + "'", int1 == (-615237829));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 13);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int10 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024458752 + "'", int1 == 1024458752);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2147453856L), 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147453854L) + "'", long2 == (-2147453854L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 130, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 162L + "'", long2 == 162L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-31), 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 65, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(13.754593205806493d, 32.48537739999097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.754593205806495d + "'", double2 == 13.754593205806495d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.942624315E-315d, 1.2204032943178235E39d, (double) 10000.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4204293198443133E54d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.336660761424351d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.336660761424352d + "'", double1 == 4.336660761424352d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 10);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11, (java.lang.Number) bigInteger7, (int) (short) -1);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1 >= 11)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1 >= 11)"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-11), (-615237829));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-65));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.113943352306837d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1641996403 + "'", int1 == 1641996403);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1071644672, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', (-615237829));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 615237881 + "'", int2 == 615237881);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 93648.04747608298d + "'", double2 == 93648.04747608298d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int[] intArray3 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray5 = new int[] { (short) 0 };
        int[] intArray10 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray16 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray18 = new int[] { (short) 0 };
        int[] intArray23 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int[] intArray27 = new int[] { (short) 0 };
        int[] intArray32 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray32);
        int[] intArray36 = new int[] { (short) 0 };
        int[] intArray41 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray41);
        int[] intArray46 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray48 = new int[] { (short) 0 };
        int[] intArray53 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        int[] intArray57 = new int[] { (short) 0 };
        int[] intArray62 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray62);
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray53);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray41);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray32);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 36 + "'", int55 == 36);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-9900));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7456758186655819d + "'", double1 == 0.7456758186655819d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.562453851238174d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5925822725601262d) + "'", double1 == (-0.5925822725601262d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.math.util.FastMath.max(940900000, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101120 + "'", int2 == 1076101120);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(52L, (long) 940900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-940848L) + "'", long2 == (-940848L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1661992960);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.231283297510288d + "'", double1 == 21.231283297510288d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1001);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 11L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076232192 + "'", int1 == 1076232192);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int int1 = org.apache.commons.math.util.MathUtils.sign(130);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1641996403, 90, 36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10201L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5706963267952299d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5706963267952299d + "'", double2 == 1.5706963267952299d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1077805056L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray5 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray7 = new int[] { (short) 0 };
        int[] intArray12 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        try {
            int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1072693280, (float) 970L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 970.0f + "'", float2 == 970.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4443055.260253896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 162L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20648222933781113d + "'", double1 == 0.20648222933781113d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        boolean boolean11 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.acosh(350.64726522133026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.552925923048147d + "'", double1 == 6.552925923048147d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        int int10 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number11 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        java.lang.Number number22 = nonMonotonousSequenceException15.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException15.getDirection();
        java.lang.String str24 = nonMonotonousSequenceException15.toString();
        java.lang.String str25 = nonMonotonousSequenceException15.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean30 = nonMonotonousSequenceException29.getStrict();
        java.lang.Number number31 = nonMonotonousSequenceException29.getArgument();
        boolean boolean32 = nonMonotonousSequenceException29.getStrict();
        java.lang.String str33 = nonMonotonousSequenceException29.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException29.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 3.732511156817248d + "'", number9.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) 100 + "'", number22.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (byte) 100 + "'", number31.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-65));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 65L + "'", long1 == 65L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-615237829), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.0d, 0.5669767943827975d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8186384061289723d) + "'", double2 == (-0.8186384061289723d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.17453292519943295d, number1, 1001);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double[] doubleArray21 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 0.0f);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray23);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray31);
        double[] doubleArray40 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 0.0f);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray40);
        try {
            double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1072693280, (-0.2836910914864728d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int1 = org.apache.commons.math.util.FastMath.abs(1872);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1872 + "'", int1 == 1872);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.369491427691418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.499726279454946E229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0772758326371069E214d + "'", double1 == 1.0772758326371069E214d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 1509505313);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1543.759214377844d, 4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        long long1 = org.apache.commons.math.util.FastMath.abs(1346274334462890625L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1346274334462890625L + "'", long1 == 1346274334462890625L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100, (-11));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-97));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4650188248182272d + "'", double1 == 1.4650188248182272d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-19327084713L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.29155488864262596d), (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1076101120, 10000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1072693280, (float) 130);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 130.0f + "'", float2 == 130.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147453857L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147453824) + "'", int1 == (-2147453824));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2147453854L), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147453854L) + "'", long2 == (-2147453854L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double[] doubleArray22 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 0.0f);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray24);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double[] doubleArray35 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 0.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray37);
        double[] doubleArray42 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 0.0f);
        double[] doubleArray48 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 0.0f);
        double[] doubleArray54 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 0.0f);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray56);
        double[] doubleArray62 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection66, false);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray64);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray64);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1078591488L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int1 = org.apache.commons.math.util.FastMath.abs(1020264448);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1020264448 + "'", int1 == 1020264448);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double[] doubleArray30 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray32);
        try {
            double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 30);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, 1077805056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-940848L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 1079574528, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-35L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.0d) + "'", double1 == (-35.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 36, (-152460036613L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.2710663101885897d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2710663101885897d + "'", double2 == 3.2710663101885897d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.519563740158435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1496694046963674d + "'", double1 == 1.1496694046963674d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.300044115027049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.037438448373982d + "'", double1 == 5.037438448373982d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1071644672, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(14300, 350000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.641588833612779d, (double) 1001);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean10 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        boolean boolean12 = nonMonotonousSequenceException9.getStrict();
        java.lang.String str13 = nonMonotonousSequenceException9.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection14, false);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 4L, (int) (short) 100, 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6204290412244261d + "'", double1 == 0.6204290412244261d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(100.0d, 970000, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) 0, (-10000));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4650188248182272d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1020264448, 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray12 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray14 = new int[] { (short) 0 };
        int[] intArray19 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray27 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray29 = new int[] { (short) 0 };
        int[] intArray34 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray34);
        java.lang.Class<?> wildcardClass37 = intArray34.getClass();
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray34);
        int[] intArray40 = new int[] { (short) 0 };
        int[] intArray45 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray51 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray53 = new int[] { (short) 0 };
        int[] intArray58 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray51);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray51);
        int[] intArray64 = new int[] { (short) 0 };
        int[] intArray69 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray69);
        int[] intArray74 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray76 = new int[] { (short) 0 };
        int[] intArray81 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray81);
        int[] intArray85 = new int[] { (short) 0 };
        int[] intArray90 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray90);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray90);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray69);
        try {
            double double95 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 36 + "'", int21 == 36);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 36 + "'", int36 == 36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 36 + "'", int60 == 36);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 36 + "'", int83 == 36);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.sin(11.591953275521519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8273747768554852d) + "'", double1 == (-0.8273747768554852d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9985244042029922d, (-0.0d), 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 970000, (-101L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97970000L) + "'", long2 == (-97970000L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1024458752);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1001, 1001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1002001 + "'", int2 == 1002001);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.NaN, 11.0f);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.FastMath.exp(16.484848484848484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4430412041523065E7d + "'", double1 == 1.4430412041523065E7d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.log(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.151292546497023d + "'", double1 == 1.151292546497023d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1024458752, (-1818178099463154899L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4204293198443133E54d, (java.lang.Number) 1.0f, 36);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long2 = org.apache.commons.math.util.FastMath.min(97L, (long) (-9900));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9900L) + "'", long2 == (-9900L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1020264448);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.FastMath.max(65, (-9900));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.15596473606112943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1565978125554256d + "'", double1 == 0.1565978125554256d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number13 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.1681469282041377d), (java.lang.Number) 10.067661995777765d, (-9900), orderDirection14, true);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException16.getClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(9.619275968248924E151d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.809637984124462E151d + "'", double2 == 4.809637984124462E151d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double[] doubleArray21 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 0.0f);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray23);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray31);
        double[] doubleArray40 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 0.0f);
        double[] doubleArray46 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double[] doubleArray52 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 0.0f);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray54);
        double[] doubleArray60 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 0.0f);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray62);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-2147453857) + "'", int64 == (-2147453857));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-2147453857) + "'", int66 == (-2147453857));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 970L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(30, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5707963267948967d + "'", double1 == 0.5707963267948967d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long1 = org.apache.commons.math.util.FastMath.round(Double.NaN);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long2 = org.apache.commons.math.util.FastMath.min(15095053130L, (long) (-31));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31L) + "'", long2 == (-31L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2147453857) + "'", int13 == (-2147453857));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2147453857) + "'", int14 == (-2147453857));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 0.0f);
        double[] doubleArray10 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0.0f);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray18);
        double[] doubleArray24 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 0.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        try {
            double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2147453857) + "'", int28 == (-2147453857));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1891746405) + "'", int1 == (-1891746405));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 31000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31000.0f + "'", float2 == 31000.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-940899));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-9899.999999999998d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1), 3395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int[] intArray3 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray5 = new int[] { (short) 0 };
        int[] intArray10 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray16 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray18 = new int[] { (short) 0 };
        int[] intArray23 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int[] intArray27 = new int[] { (short) 0 };
        int[] intArray32 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray32);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray23);
        int[] intArray37 = new int[] { (short) 0 };
        int[] intArray42 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray48 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray50 = new int[] { (short) 0 };
        int[] intArray55 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray48);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray48);
        try {
            int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 36 + "'", int57 == 36);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 70162759680L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.66723069889022d + "'", double1 == 25.66723069889022d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 980.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.932883883792687d + "'", double1 == 9.932883883792687d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(44L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, 1.6789966805471279E-9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = org.apache.commons.math.util.MathUtils.pow(940900, 1509505313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.809637984124462E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double[] doubleArray35 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 0.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray37);
        double[] doubleArray44 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double[] doubleArray56 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 0.0f);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray58);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection62, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1774819148, 1661992960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double2 = org.apache.commons.math.util.MathUtils.log(5.298292365610484d, (double) 1219518760);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.547628478571346d + "'", double2 == 12.547628478571346d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5403023058681398d, 1.5706963267952299d, 1.8198192184425595E27d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 0, 13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4430412041523065E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.15596473606112943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15471826434892666d + "'", double1 == 0.15471826434892666d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException8.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.732511156817248d + "'", number11.equals(3.732511156817248d));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.2737367544323206E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1024458752, 350000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1368683772161603E-13d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1661992960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long1 = org.apache.commons.math.util.MathUtils.sign(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException3.getClass();
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        java.lang.String str12 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 3.732511156817248d + "'", number9.equals(3.732511156817248d));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(65, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.tan(179.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.338690210351075d + "'", double1 == 1.338690210351075d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double2 = org.apache.commons.math.util.FastMath.min(3.732511156817248d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.732511156817248d + "'", double2 == 3.732511156817248d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1072693248, 2147453857);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2147453857));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1002001, (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2130532941206642d + "'", double1 == 1.2130532941206642d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1078591487, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591487 + "'", int2 == 1078591487);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, 65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException3.getClass();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 940900000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2147453824), 1072693280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074760544) + "'", int2 == (-1074760544));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 'a', (-101L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double[] doubleArray22 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 0.0f);
        double[] doubleArray28 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0.0f);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray30);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        double[] doubleArray47 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        double[] doubleArray53 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 0.0f);
        double[] doubleArray59 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 0.0f);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray61);
        double[] doubleArray67 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray69);
        double[] doubleArray74 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 0.0f);
        double[] doubleArray80 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 0.0f);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray76);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray76);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-2147453857) + "'", int85 == (-2147453857));
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-2147453857) + "'", int87 == (-2147453857));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.0004447709181594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14209276336587512d) + "'", double1 == (-0.14209276336587512d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray6 = new int[] { (short) 0 };
        int[] intArray11 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        try {
            int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36 + "'", int13 == 36);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-2147453857), 1.1752011936438014d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long1 = org.apache.commons.math.util.FastMath.round(267.7467614837482d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 268L + "'", long1 == 268L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.4662068599648133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.846390643708864d + "'", double1 == 5.846390643708864d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 10);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) ' ');
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger27);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 10);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 10);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 10);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger40);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 10);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger46);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 10);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) 10);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (int) ' ');
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger56);
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger47, number58, 1100);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger47);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 13);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int[] intArray3 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray5 = new int[] { (short) 0 };
        int[] intArray10 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray16 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray18 = new int[] { (short) 0 };
        int[] intArray23 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray23);
        int[] intArray30 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray32 = new int[] { (short) 0 };
        int[] intArray37 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray43 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray45 = new int[] { (short) 0 };
        int[] intArray50 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int[] intArray54 = new int[] { (short) 0 };
        int[] intArray59 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray50);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray37);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36 + "'", int26 == 36);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 36 + "'", int39 == 36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 36 + "'", int52 == 36);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 36 + "'", int63 == 36);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.942624315E-315d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 595593792 + "'", int1 == 595593792);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 53L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.877296071497429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 485.0005154639176d + "'", double1 == 485.0005154639176d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.8791212930932448d, 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 450.11010206374135d + "'", double2 == 450.11010206374135d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.8198192184425598E27d, (double) (-9900L), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(21.231283297510288d, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.0d, (double) (-2147453857), 16.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.4711276743037347d, (double) 13, 5729.577951308233d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 190L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 10);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 10);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 10);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) ' ');
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger32);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-152460036613L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1932708471300L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-152460036613L), 1.4430412041523065E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4430409920593262E7d + "'", double2 == 1.4430409920593262E7d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1072693280, (long) 2147453857);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2303559321513980960L + "'", long2 == 2303559321513980960L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(7L, (-98L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-91L) + "'", long2 == (-91L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.math.util.MathUtils.pow(16, 940900000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.signum(6.843257760045314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5000000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.127625965206381d + "'", double1 == 1.127625965206381d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1L, 268L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 268L + "'", long2 == 268L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1001);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6545913958346148d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int[] intArray3 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray5 = new int[] { (short) 0 };
        int[] intArray10 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray14 = new int[] { (short) 0 };
        int[] intArray19 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray19);
        int[] intArray23 = new int[] { (short) 0 };
        int[] intArray28 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray28);
        int[] intArray33 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray35 = new int[] { (short) 0 };
        int[] intArray40 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray40);
        int[] intArray44 = new int[] { (short) 0 };
        int[] intArray49 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray40);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray28);
        java.lang.Class<?> wildcardClass54 = intArray28.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 36 + "'", int42 == 36);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.558945533197085E83d, (-0.3209711346238147d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.558945533197084E83d + "'", double2 == 5.558945533197084E83d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 970000, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8730000L + "'", long2 == 8730000L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000001192092967d + "'", double1 == 1.0000001192092967d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.1771122663712068d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double1 = org.apache.commons.math.util.FastMath.sin(1231.4048484047612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09930784397034542d) + "'", double1 == (-0.09930784397034542d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1509505313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.135047826813487d + "'", double1 == 21.135047826813487d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray11 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray13 = new int[] { (short) 0 };
        int[] intArray18 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray18);
        int[] intArray22 = new int[] { (short) 0 };
        int[] intArray27 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray27);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray27);
        int[] intArray34 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray36 = new int[] { (short) 0 };
        int[] intArray41 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int[] intArray47 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray49 = new int[] { (short) 0 };
        int[] intArray54 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray54);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray54);
        int[] intArray60 = new int[] { (short) 0 };
        int[] intArray65 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray65);
        int[] intArray70 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray72 = new int[] { (short) 0 };
        int[] intArray77 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int[] intArray81 = new int[] { (short) 0 };
        int[] intArray86 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray77);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray77);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 36 + "'", int20 == 36);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 36 + "'", int43 == 36);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 36 + "'", int56 == 36);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 36 + "'", int57 == 36);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 36 + "'", int79 == 36);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.0d + "'", double87 == 1.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1002001, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1100, (float) 970000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1100.0f + "'", float2 == 1100.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        long long2 = org.apache.commons.math.util.MathUtils.pow(31000L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2147453857), 530);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 2147453868L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.14745382E9f + "'", float2 == 2.14745382E9f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 411469059992373313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray11 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray13 = new int[] { (short) 0 };
        int[] intArray18 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray18);
        int[] intArray22 = new int[] { (short) 0 };
        int[] intArray27 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray27);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray27);
        int[] intArray34 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray36 = new int[] { (short) 0 };
        int[] intArray41 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int[] intArray47 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray49 = new int[] { (short) 0 };
        int[] intArray54 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray54);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray54);
        int[] intArray60 = new int[] { (short) 0 };
        int[] intArray65 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray71 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray73 = new int[] { (short) 0 };
        int[] intArray78 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray78);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray71);
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray71);
        try {
            int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 36 + "'", int20 == 36);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 36 + "'", int43 == 36);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 36 + "'", int56 == 36);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 36 + "'", int57 == 36);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 36 + "'", int80 == 36);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-615237829));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.525053099849145E10d) + "'", double1 == (-3.525053099849145E10d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1071644672);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray9 = new int[] { (short) 0 };
        int[] intArray14 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray20 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray22 = new int[] { (short) 0 };
        int[] intArray27 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray20);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray20);
        try {
            int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 36 + "'", int29 == 36);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-152460036613L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.52460036614E11d) + "'", double1 == (-1.52460036614E11d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) -1, (-1074760544));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.675640048483193E7d, 2.2250738585072014E-308d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1079410688), 940900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(940900, 1774819148);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.29169168098031323d), 0.5616502280096894d, (double) 2.14745382E9f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796207585607d + "'", double1 == 1.570796207585607d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 350000, 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350970L + "'", long2 == 350970L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException3.toString();
        java.lang.Number number13 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 100 + "'", number10.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.732511156817248d + "'", number11.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        int int10 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 3.732511156817248d + "'", number9.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1079427072);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.611168162149826d + "'", double1 == 4.611168162149826d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-98L), 0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5309649148733797d + "'", double2 == 2.5309649148733797d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.FastMath.rint(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9955742875642764d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        long long1 = org.apache.commons.math.util.FastMath.round(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1509505313L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1509505280 + "'", int1 == 1509505280);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        boolean boolean10 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        boolean boolean19 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number20 = nonMonotonousSequenceException16.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean25 = nonMonotonousSequenceException24.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        java.lang.Number number31 = nonMonotonousSequenceException24.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException24.getDirection();
        int int33 = nonMonotonousSequenceException24.getIndex();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 3.732511156817248d + "'", number8.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 100 + "'", number18.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 3.732511156817248d + "'", number20.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (byte) 100 + "'", number31.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 970000, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 32, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 480L + "'", long2 == 480L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.52460036614E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-350001L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0053580125358324E7d) + "'", double1 == (-2.0053580125358324E7d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5519306407732258d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998220482235222d + "'", double1 == 0.9998220482235222d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(14300, 1661992960);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.189654742026425d + "'", double1 == 4.189654742026425d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999929d + "'", double1 == 0.9999999999999929d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.113162759502461d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double[] doubleArray30 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double[] doubleArray42 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 0.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray44);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double[] doubleArray57 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 0.0f);
        double[] doubleArray63 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 0.0f);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray59);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10000L, (-19327084713L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9998220482235222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1749266183095894d + "'", double1 == 1.1749266183095894d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.FastMath.min(970.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 100, (int) (short) 0, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-97970000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 100.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3591409142295225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.023721483951871018d + "'", double1 == 0.023721483951871018d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2, (-10000));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6495717774798732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7595289220762447d + "'", double1 == 0.7595289220762447d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 940900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, 2147453857);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.078591484784593E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1048576 + "'", int1 == 1048576);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.09930784397034542d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray19 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 0.0f);
        double[] doubleArray25 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 0.0f);
        double[] doubleArray31 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 0.0f);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray21);
        double[] doubleArray37 = null;
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1891746405), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.037438448373982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.0406644044095d + "'", double1 == 77.0406644044095d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.189654742026425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.111208823873017d + "'", double1 == 2.111208823873017d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(20.085536923187668d, 0.7007529698288765d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.830189170012751E-6d + "'", double1 == 6.830189170012751E-6d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1872, 615237881);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6934593050957494E78d) + "'", double2 == (-1.6934593050957494E78d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-152460036613L), (-940899), 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 78815638671875L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.896612399152481d + "'", double1 == 13.896612399152481d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1079427072);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 31000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.FastMath.sinh(77.0406644044095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4364993616322366E33d + "'", double1 == 1.4364993616322366E33d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 3395, (long) 14300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9709700L + "'", long2 == 9709700L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int[] intArray3 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray5 = new int[] { (short) 0 };
        int[] intArray10 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray16 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray18 = new int[] { (short) 0 };
        int[] intArray23 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray23);
        int[] intArray28 = new int[] { (short) 0 };
        int[] intArray33 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray33);
        int[] intArray39 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray41 = new int[] { (short) 0 };
        int[] intArray46 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray50 = new int[] { (short) 0 };
        int[] intArray55 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray55);
        int[] intArray61 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray63 = new int[] { (short) 0 };
        int[] intArray68 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray68);
        int[] intArray74 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray76 = new int[] { (short) 0 };
        int[] intArray81 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray81);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray81);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray81);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray55);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36 + "'", int26 == 36);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 36 + "'", int48 == 36);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 36 + "'", int70 == 36);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 36 + "'", int83 == 36);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 36 + "'", int84 == 36);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 10);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 10);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger37);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger28);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) (byte) 10);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 10);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger44);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger47);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 10);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 10);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 10);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger60);
        java.math.BigInteger bigInteger62 = null;
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 0L);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 10);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, bigInteger66);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, 10);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 10);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (int) 'a');
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (long) 53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger67, (java.lang.Number) 53, 0, orderDirection80, false);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, bigInteger67);
        java.lang.Class<?> wildcardClass84 = bigInteger67.getClass();
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, 1509505280);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(bigInteger86);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int[] intArray1 = new int[] { (short) 0 };
        int[] intArray6 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray12 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray14 = new int[] { (short) 0 };
        int[] intArray19 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray25 = new int[] { (short) 0 };
        int[] intArray30 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray30);
        int[] intArray35 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray37 = new int[] { (short) 0 };
        int[] intArray42 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray42);
        int[] intArray46 = new int[] { (short) 0 };
        int[] intArray51 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray51);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray51);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray30);
        int[] intArray59 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray61 = new int[] { (short) 0 };
        int[] intArray66 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int[] intArray72 = new int[] { (short) -1, 35, (short) -1 };
        int[] intArray74 = new int[] { (short) 0 };
        int[] intArray79 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray79);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray79);
        int[] intArray83 = new int[] { (short) 0 };
        int[] intArray88 = new int[] { (short) -1, (byte) -1, (short) -1, 'a' };
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray83, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray88);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray79);
        java.lang.Class<?> wildcardClass92 = intArray79.getClass();
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray79);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 36 + "'", int21 == 36);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 36 + "'", int44 == 36);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 36 + "'", int68 == 36);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.0d + "'", double80 == 1.0d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 36 + "'", int81 == 36);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0d + "'", double89 == 1.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10000, 53L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 190L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6402935076923352E82d + "'", double1 == 1.6402935076923352E82d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(32, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-65), (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-65L) + "'", long2 == (-65L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double[] doubleArray3 = null;
        double[] doubleArray7 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 0.0f);
        double[] doubleArray13 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 0.0f);
        double[] doubleArray19 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 0.0f);
        double[] doubleArray25 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 0.0f);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray27);
        double[] doubleArray33 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 0.0f);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray35);
        double[] doubleArray44 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray44);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray9);
        double[] doubleArray52 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 0.0f);
        double[] doubleArray58 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        double[] doubleArray64 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 0.0f);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray66);
        double[] doubleArray72 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 0.0f);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray74);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray74, orderDirection76, false);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray74);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean84 = nonMonotonousSequenceException83.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        nonMonotonousSequenceException83.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException88);
        java.lang.Number number90 = nonMonotonousSequenceException83.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = nonMonotonousSequenceException83.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray74, orderDirection91, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException95 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 9.556619453472961E-299d, 0, orderDirection91, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + number90 + "' != '" + (byte) 100 + "'", number90.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 0.0f);
        double[] doubleArray10 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0.0f);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray18);
        double[] doubleArray24 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 0.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false);
        double[] doubleArray34 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 0.0f);
        double[] doubleArray40 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 0.0f);
        double[] doubleArray46 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 0.0f);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray48);
        double[] doubleArray54 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 0.0f);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray56);
        double[] doubleArray62 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 0.0f);
        double[] doubleArray68 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 0.0f);
        double[] doubleArray74 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 0.0f);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray76);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray76);
        try {
            double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-2147453857) + "'", int79 == (-2147453857));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, 1509505313);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1077805056L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.077805056E9d + "'", double2 == 1.077805056E9d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double2 = org.apache.commons.math.util.FastMath.atan2(11013.232874703395d, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0910843005109874d + "'", double2 == 1.0910843005109874d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-97970000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double[] doubleArray21 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 0.0f);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray23);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray23);
        double[] doubleArray37 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 0.0f);
        double[] doubleArray43 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 0.0f);
        double[] doubleArray49 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 0.0f);
        double[] doubleArray55 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 0.0f);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray57);
        double[] doubleArray63 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 0.0f);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection67, false);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray65);
        double[] doubleArray74 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 0.0f);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray74);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray74);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (3.584 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1219518760 + "'", int79 == 1219518760);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 9, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1072693280L, 1000, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray16 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 0.0f);
        double[] doubleArray22 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 0.0f);
        double[] doubleArray28 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0.0f);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray30);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray38);
        double[] doubleArray47 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 0.0f);
        double[] doubleArray53 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 0.0f);
        double[] doubleArray59 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 0.0f);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray61);
        double[] doubleArray67 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 0.0f);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray69);
        double[] doubleArray74 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 0.0f);
        double[] doubleArray80 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 0.0f);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray76);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray76);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-2147453857) + "'", int85 == (-2147453857));
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 3.732511156817248d + "'", number8.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(940900000L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 940900000L + "'", long2 == 940900000L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double2 = org.apache.commons.math.util.FastMath.pow(6283429.007424238d, (-1.6934593050957494E78d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8390715290764524d + "'", double1 == 0.8390715290764524d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double[] doubleArray29 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 0.0f);
        double[] doubleArray35 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 0.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray37);
        double[] doubleArray44 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double[] doubleArray56 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 0.0f);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray58);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection62, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0 <= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double2 = org.apache.commons.math.util.FastMath.min(2.113943352306837d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 100, 940900000, 1002001);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1219518760, (-10000));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double2 = org.apache.commons.math.util.FastMath.pow(13.754593205806493d, 77.0406644044095d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.09062487310019E87d + "'", double2 == 5.09062487310019E87d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 32L, 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        long long1 = org.apache.commons.math.util.MathUtils.sign(940900L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '#', 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 100, (int) (short) 0, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass14 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number15 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 100 + "'", number15.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 3.732511156817248d + "'", number16.equals(3.732511156817248d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 0.0f);
        double[] doubleArray10 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0.0f);
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray17 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 0.0f);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray25);
        double[] doubleArray30 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 0.0f);
        double[] doubleArray36 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 0.0f);
        double[] doubleArray42 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 0.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray44);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray52);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray52);
        try {
            double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 130, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(595593792, 940900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.002877136919106072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1559274280097633d + "'", double1 == 1.1559274280097633d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1219518760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4266871467933966d) + "'", double1 == (-1.4266871467933966d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 11, (long) (-65));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 76L + "'", long2 == 76L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147453857));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147453824) + "'", int1 == (-2147453824));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        try {
            double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) (-9.463946303571861d), 90);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.1344640137963142d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1077805056);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str10 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (3.733 >= 100)"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.17154589974405432d, 53.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1002001);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1002001.0d + "'", double1 == 1002001.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.29169168098031323d), 1.151292546497023d, 6.830189170012751E-6d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        long long1 = org.apache.commons.math.util.MathUtils.sign(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 32L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(359.99999999999994d, 1231.4048484047612d, (-2.1681469282041377d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0622380389501536d + "'", double1 == 2.0622380389501536d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9894759723033013d + "'", double1 == 0.9894759723033013d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray32 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 0.0f);
        double[] doubleArray38 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 0.0f);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray40);
        double[] doubleArray45 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 0.0f);
        double[] doubleArray51 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 0.0f);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray53);
        double[] doubleArray58 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        double[] doubleArray64 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 0.0f);
        double[] doubleArray70 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) 0.0f);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray72);
        double[] doubleArray78 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 0.0f);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray80);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray80, orderDirection82, false);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray80);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray80);
        java.lang.Class<?> wildcardClass87 = doubleArray80.getClass();
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray80);
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2147453857) + "'", int28 == (-2147453857));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(89.99999999999999d, 0.6150699010154246d, 5.58351893845611d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 3.732511156817248d, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        int int10 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 3.732511156817248d + "'", number9.equals(3.732511156817248d));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.732511156817248d + "'", number11.equals(3.732511156817248d));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.09930784397034542d), (double) (-9900.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.09930784397034544d) + "'", double2 == (-0.09930784397034544d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 411469059992373313L, 7.105427357601002E-15d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1100L, (long) 1509505313);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-98L), (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double[] doubleArray3 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0.0f);
        double[] doubleArray9 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 0.0f);
        double[] doubleArray15 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 0.0f);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray17);
        double[] doubleArray23 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 0.0f);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray32 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 0.0f);
        double[] doubleArray38 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 0.0f);
        double[] doubleArray44 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 0.0f);
        double[] doubleArray50 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 0.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray52);
        double[] doubleArray58 = new double[] { 3.58351893845611d, (-1.0f), (byte) 1 };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 0.0f);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray52);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2147453857) + "'", int28 == (-2147453857));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }
}

