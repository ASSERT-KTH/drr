import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(43.42944819032518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7579868632454674d + "'", double1 == 0.7579868632454674d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance((-8474271314106775063L));
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.5451880495569174d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.642451343477102d) + "'", double2 == (-2.642451343477102d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 5805985991905072931L, (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5707509268651654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999989694232d + "'", double1 == 0.9999999989694232d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8658666377179232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.610503962420054d + "'", double1 == 49.610503962420054d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.99718475f + "'", float4 == 0.99718475f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999787460148778d + "'", double1 == 0.999787460148778d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.06566270191375286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06575731702515776d + "'", double1 == 0.06575731702515776d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.642451343477102d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.classify();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn10();
        dfpField6.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        java.lang.String str5 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0." + "'", str5.equals("0."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.atan2(43.042831059009366d, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5243643784234528d + "'", double2 == 1.5243643784234528d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.getOne();
        boolean boolean6 = dfp5.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.73205080756887729352744634150587236694280525381" + "'", str4.equals("1.73205080756887729352744634150587236694280525381"));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707509268651654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8102589905877733d + "'", double1 == 3.8102589905877733d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.013208695330432285d), (-0.764725154011207d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.124321896975152d) + "'", double2 == (-3.124321896975152d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.37562457894974405d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.divide(8);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlags((int) '#');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.getLn10();
        dfpField3.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField3.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray9);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp12);
        int int14 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField2.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn10();
        dfpField13.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField21.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        boolean boolean33 = dfp32.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp19, dfp29, dfp32);
        try {
            org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp11, dfp35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1072355796));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.power10(1);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 10, (byte) -1);
        boolean boolean32 = dfp17.equals((java.lang.Object) dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn2();
        double[] doubleArray36 = dfp35.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = new org.apache.commons.math.dfp.Dfp(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.power10(52);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.newInstance(dfp42);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) (-6683256247793684953L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3383347192042695E42d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.atanh(49.610503962420054d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 10, (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 22);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22 + "'", int1 == 22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        try {
            int int3 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7174314386656349d) + "'", double1 == (-0.7174314386656349d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8801606659888926d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        boolean boolean9 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0787619161000126d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        int int24 = dfp23.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double2 = org.apache.commons.math.util.FastMath.min((-2.113235465915354d), 0.06566270191375284d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.113235465915354d) + "'", double2 == (-2.113235465915354d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        int int4 = dfp3.log10();
        int int5 = dfp3.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int[] intArray6 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextDouble();
        long long9 = mersenneTwister7.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(10L);
        double double12 = mersenneTwister11.nextGaussian();
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 2, (byte) -1 };
        mersenneTwister11.nextBytes(byteArray16);
        mersenneTwister7.nextBytes(byteArray16);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.637699948585789d + "'", double8 == 0.637699948585789d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6996356570664251883L + "'", long9 == 6996356570664251883L);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0000679992263888d) + "'", double12 == (-1.0000679992263888d));
        org.junit.Assert.assertNotNull(byteArray16);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.38905609893065d + "'", double1 == 7.38905609893065d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.remainder(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 18);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 18L + "'", long1 == 18L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        int int4 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 85);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1115063573114566E36d + "'", double1 == 4.1115063573114566E36d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9971848088551236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6917385933942419d + "'", double1 == 0.6917385933942419d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.log1p(51.11493360519108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.953451541184738d + "'", double1 == 3.953451541184738d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 2, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.45323268452949356d, (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02517427422074833d + "'", double2 == 0.02517427422074833d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8746666259370839d) + "'", double1 == (-0.8746666259370839d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.43899594558373667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47098637836994534d + "'", double1 == 0.47098637836994534d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6917385933942419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 16.0d);
        java.lang.Throwable throwable2 = null;
        try {
            notStrictlyPositiveException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        int int6 = dfp2.classify();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp16);
        boolean boolean18 = dfp2.unequal(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.negate();
        java.lang.Object obj20 = null;
        boolean boolean21 = dfp19.equals(obj20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(18);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getLn2();
        double[] doubleArray7 = dfp6.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.sqrt();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.multiply(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp16 = dfp14.remainder(dfp15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        int int7 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        double double9 = dfp8.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.rint();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.newInstance((byte) 1, (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.multiply((int) (short) 0);
        int int7 = dfp4.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-4) + "'", int7 == (-4));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.math.util.FastMath.max(8, 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Number number39 = numberIsTooSmallException37.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException37);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getLn2();
        double[] doubleArray45 = dfp44.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.sqrt();
        org.apache.commons.math.dfp.Dfp dfp47 = new org.apache.commons.math.dfp.Dfp(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.power10(52);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp46.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.getOne();
        int int53 = dfp46.getRadixDigits();
        org.apache.commons.math.random.MersenneTwister mersenneTwister56 = new org.apache.commons.math.random.MersenneTwister(0);
        double double57 = mersenneTwister56.nextGaussian();
        java.lang.Object[] objArray58 = new java.lang.Object[] { int53, 4.396829672158179d, double57 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable41, objArray58);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) 1.5707509268651654d, (java.lang.Number) 32760L, true);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 13 + "'", int53 == 13);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-0.7805794640849414d) + "'", double57 == (-0.7805794640849414d));
        org.junit.Assert.assertNotNull(objArray58);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        double double6 = dfp5.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6020599913279624d + "'", double1 == 0.6020599913279624d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 85.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5590321636451379d + "'", double1 == 1.5590321636451379d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn10();
        dfpField29.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getLn2();
        boolean boolean41 = dfp40.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance();
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp37, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.power10(1);
        boolean boolean46 = dfp11.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.negate();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.newInstance(85);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        boolean boolean5 = dfp2.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance((double) (-1L));
        double double13 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6931471805599453d + "'", double13 == 0.6931471805599453d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0000679992263886d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5402450852430379d + "'", double1 == 0.5402450852430379d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.632145573495463d), (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6321455734954629d) + "'", double2 == (-0.6321455734954629d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.466711037884725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn10();
        dfpField11.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp(dfp18);
        int int21 = dfp18.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590455d + "'", double1 == 1.7182818284590455d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        dfpField7.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp((-51931120792031348L));
        boolean boolean17 = dfp5.greaterThan(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException4.getGeneralPattern();
        java.lang.String str17 = mathIllegalArgumentException4.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str17.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        int int5 = dfpField1.getIEEEFlags();
        int int6 = dfpField1.getRadixDigits();
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 1628966203);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.1688976178093215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1688976178093215d + "'", double1 == 0.1688976178093215d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5683657275154999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6451053900449637d + "'", double1 == 0.6451053900449637d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06981317007977318d + "'", double1 == 0.06981317007977318d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 22 + "'", int7 == 22);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.multiply(18);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp15, dfp26);
        boolean boolean28 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField13.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) dfpArray16);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        boolean boolean19 = numberIsTooSmallException16.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        long long2 = org.apache.commons.math.util.FastMath.max(32760L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32760L + "'", long2 == 32760L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.027415567780803778d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02741556778080378d + "'", double2 == 0.02741556778080378d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray20 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        mersenneTwister1.setSeed(intArray20);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 10);
        float float26 = mersenneTwister25.nextFloat();
        int[] intArray29 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister(intArray29);
        mersenneTwister25.setSeed(intArray29);
        mersenneTwister23.setSeed(intArray29);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5711645f + "'", float26 == 0.5711645f);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn10();
        dfpField29.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getLn2();
        boolean boolean41 = dfp40.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance();
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp37, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.power10(1);
        boolean boolean46 = dfp11.unequal(dfp45);
        boolean boolean47 = dfp45.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getTwo();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.power10(13);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.divide((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp45.multiply(dfp56);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        boolean boolean8 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        int int12 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.remainder(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getTwo();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10(13);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.divide(dfp28);
        boolean boolean30 = dfp4.lessThan(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = null;
        try {
            boolean boolean32 = dfp4.lessThan(dfp31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) 35);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5243643784234528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.026605177403606062d + "'", double1 == 0.026605177403606062d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("0.6931471805599453094172321214581765680755001343602552");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((-0.013208695330432285d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 18);
        double double2 = mersenneTwister1.nextDouble();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        double double4 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5433766888254443d + "'", double2 == 0.5433766888254443d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.08522869067653949d) + "'", double4 == (-0.08522869067653949d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 11013.232920103323d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.exp(43.042831059009366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9347370318670264E18d + "'", double1 == 4.9347370318670264E18d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int[] intArray6 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextDouble();
        long long9 = mersenneTwister7.nextLong();
        double double10 = mersenneTwister7.nextGaussian();
        double double11 = mersenneTwister7.nextDouble();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.637699948585789d + "'", double8 == 0.637699948585789d);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6996356570664251883L + "'", long9 == 6996356570664251883L);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.113235465915354d) + "'", double10 == (-2.113235465915354d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8190834148517472d + "'", double11 == 0.8190834148517472d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.7820223734225045d, (java.lang.Number) (byte) 2, false);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField39.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) dfpArray41);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray41);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0.99718475f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5478061172573376d + "'", double1 == 1.5478061172573376d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        int int6 = dfp5.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.newDfp((byte) 100);
        double double17 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.nextAfter(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(3L);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Number number19 = numberIsTooSmallException16.getMin();
        java.lang.Number number20 = numberIsTooSmallException16.getMin();
        java.lang.String str21 = numberIsTooSmallException16.toString();
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0L + "'", number19.equals(0L));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0L + "'", number20.equals(0L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (0)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (0)"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5711645232847797d + "'", double3 == 0.5711645232847797d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.54060876f + "'", float4 == 0.54060876f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8098045977194093303L + "'", long5 == 8098045977194093303L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10((int) (byte) 1);
        int int7 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        int int5 = mersenneTwister1.nextInt(1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister9.nextBytes(byteArray15);
        mersenneTwister7.nextBytes(byteArray15);
        mersenneTwister1.nextBytes(byteArray15);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((long) 'a');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14);
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException7.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNull(localizable24);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1);
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance("100.");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.026605177403606062d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.026605177403606062d + "'", double2 == 0.026605177403606062d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        boolean boolean24 = dfp17.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.power10K(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getTwo();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.newInstance();
        boolean boolean34 = dfp26.equals((java.lang.Object) dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean9 = dfp7.equals((java.lang.Object) 100.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(3L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((-1L));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getLn10();
        dfpField15.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getLn5();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn10();
        dfpField23.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getLn5();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField23.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getLn2();
        boolean boolean35 = dfp34.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.newInstance();
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp31, dfp34);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp11.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.divide(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.1415926535897927d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14);
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        boolean boolean27 = numberIsTooSmallException7.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNull(localizable24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(13);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.divide((int) (byte) 100);
        boolean boolean24 = dfp3.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        boolean boolean28 = dfp3.lessThan(dfp27);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        int int5 = dfpField1.getRadixDigits();
        int int6 = dfpField1.getIEEEFlags();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("-0.53096491487338363080458826494409229430942078");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.681845327377341d, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.02741556778080378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027422439515644947d + "'", double1 == 0.027422439515644947d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.remainder(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.multiply(1);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn10();
        dfpField22.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getLn5();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp18.remainder(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.divide(dfp29);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException39.addSuppressed((java.lang.Throwable) numberIsTooSmallException43);
        java.lang.Number number45 = numberIsTooSmallException43.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException51.addSuppressed((java.lang.Throwable) numberIsTooSmallException55);
        java.lang.Number number57 = numberIsTooSmallException55.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException55);
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooSmallException55.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable59, objArray63);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) (-1));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException71.addSuppressed((java.lang.Throwable) numberIsTooSmallException75);
        java.lang.Number number77 = numberIsTooSmallException75.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException75);
        org.apache.commons.math.exception.util.Localizable localizable79 = numberIsTooSmallException75.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException83 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException87 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException83.addSuppressed((java.lang.Throwable) numberIsTooSmallException87);
        java.lang.Number number89 = numberIsTooSmallException87.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException90 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException87);
        org.apache.commons.math.exception.util.Localizable localizable91 = numberIsTooSmallException87.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable92 = null;
        org.apache.commons.math.exception.util.Localizable localizable93 = null;
        java.lang.Object[] objArray95 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable92, localizable93, objArray95);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable79, localizable91, objArray95);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable59, objArray95);
        java.lang.Object[] objArray99 = mathIllegalArgumentException98.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-1.0d) + "'", number45.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1.0d) + "'", number57.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + (-1.0d) + "'", number77.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + (-1.0d) + "'", number89.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable91 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable91.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray95);
        org.junit.Assert.assertNotNull(objArray99);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(35);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.1115063573114566E36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 8.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        int int6 = dfp2.classify();
        double[] doubleArray7 = dfp2.toSplitDouble();
        boolean boolean9 = dfp2.equals((java.lang.Object) 52.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        boolean boolean6 = dfp3.equals((java.lang.Object) Double.NaN);
        int int7 = dfp3.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(13);
        boolean boolean12 = dfp9.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn10();
        dfpField20.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField20.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(13);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp28.add(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getLn2();
        boolean boolean42 = dfp41.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getZero();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.rint();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeLn(dfp38, dfp41, dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp9.add(dfp41);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027415567780803774d + "'", double1 == 0.027415567780803774d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number10 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Throwable throwable19 = null;
        try {
            numberIsTooSmallException3.addSuppressed(throwable19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        int int4 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 22 + "'", int4 == 22);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        int int5 = dfpField1.getRadixDigits();
        int int6 = dfpField1.getIEEEFlags();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("-0.53096491487338363080458826494409229430942078");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed(22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000679992263888d) + "'", double2 == (-1.0000679992263888d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2, 32768.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32768.0f + "'", float2 == 32768.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(35);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn10();
        dfpField6.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField6.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance("0.6931471805599453094172321214581765680755001343602552");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.remainder(dfp9);
        boolean boolean11 = dfp2.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn10();
        dfpField13.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField21.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        boolean boolean33 = dfp32.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp19, dfp29, dfp32);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp29.power10(1);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getTwo();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.newDfp((byte) 10, (byte) -1);
        boolean boolean44 = dfp29.equals((java.lang.Object) dfp43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10(13);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.getOne();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getTwo();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getLn10();
        dfpField56.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getLn5();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField56.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp29.dotrap(13, "0.6931471805599453094172321214581765680755001343602552", dfp53, dfp63);
        boolean boolean65 = dfp2.lessThan(dfp53);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean17 = dfp3.isInfinite();
        java.lang.String str18 = dfp3.toString();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.divide((int) '4');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.73205080756887729352744634150587236694280525381" + "'", str18.equals("1.73205080756887729352744634150587236694280525381"));
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.69314718055995d + "'", double1 == 100.69314718055995d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp9);
        int int11 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray12);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 85.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 85.0d + "'", double1 == 85.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getTwo();
        int int8 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10((int) 'a');
        int int11 = dfp7.classify();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        int int15 = dfp14.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.remainder(dfp21);
        boolean boolean23 = dfp7.unequal(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp4.nextAfter(dfp24);
        int int26 = dfp4.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-4) + "'", int26 == (-4));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5998406268185329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.636464658869532d + "'", double1 == 0.636464658869532d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 51.99999999999999d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        mersenneTwister1.setSeed(10000);
        long long4 = mersenneTwister1.nextLong();
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8384595794609528779L) + "'", long4 == (-8384595794609528779L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 738155935 + "'", int5 == 738155935);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.027415567780803774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.784919240787009E-4d + "'", double1 == 4.784919240787009E-4d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.54060876f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long1 = org.apache.commons.math.util.FastMath.abs((-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7910618197763358337L + "'", long1 == 7910618197763358337L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(13);
        boolean boolean12 = dfp9.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        int int17 = dfp16.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.remainder(dfp23);
        boolean boolean25 = dfp16.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp16);
        org.apache.commons.math.dfp.Dfp dfp27 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp28 = dfp26.nextAfter(dfp27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.2686362411795196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6373924292080009d + "'", double1 == 1.6373924292080009d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        boolean boolean6 = dfp5.isNaN();
        java.lang.String str7 = dfp5.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.000000000000000000000000000000000000000000000000e400" + "'", str7.equals("1.000000000000000000000000000000000000000000000000e400"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-7910618197763358337L));
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-413079302) + "'", int2 == (-413079302));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray24 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        mersenneTwister1.setSeed(intArray24);
        mersenneTwister1.setSeed((long) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(13);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.divide((int) (byte) 100);
        boolean boolean24 = dfp3.greaterThan(dfp23);
        boolean boolean25 = dfp23.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9713101757929392d + "'", double1 == 0.9713101757929392d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        long long18 = mersenneTwister1.nextLong();
        float float19 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-7910618197763358337L) + "'", long18 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.54060876f + "'", float19 == 0.54060876f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((double) 32760L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp11.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance((-8474271314106775063L));
        org.apache.commons.math.dfp.Dfp dfp16 = dfp4.add(dfp11);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-7910618197763358337L), (float) 32760);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.9106184E18f) + "'", float2 == (-7.9106184E18f));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Number number23 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException31.addSuppressed((java.lang.Throwable) numberIsTooSmallException35);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException31.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable25, (java.lang.Object[]) throwableArray37);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        boolean boolean36 = dfp26.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getTwo();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getTwo();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.power10(13);
        boolean boolean49 = dfp46.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp43, dfp46);
        boolean boolean51 = dfp26.lessThan(dfp46);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.764725154011207d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        boolean boolean5 = dfp2.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.subtract(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0.368 is smaller than the minimum (0.368): 0.368 is smaller than the minimum (0.368)");
        boolean boolean13 = dfp12.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(16L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.getOne();
        int int6 = dfp5.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.73205080756887729352744634150587236694280525381" + "'", str4.equals("1.73205080756887729352744634150587236694280525381"));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.36787944117144233d, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException84 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable80, (java.lang.Number) 32.0d, (java.lang.Number) 8L, true);
        boolean boolean85 = numberIsTooSmallException84.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("1.73205080756887729352744634150587236694280525381");
        try {
            org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.DfpField.computeLn(dfp9, dfp10, dfp15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.3513346877207577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.041038532117079904d + "'", double1 == 0.041038532117079904d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.9971848088551237d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.newDfp((byte) 1);
        int int15 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.divide(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(97L);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.52885604f + "'", float2 == 0.52885604f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(4L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        int int13 = mersenneTwister1.nextInt(97);
        double double14 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.5542431572290581d) + "'", double14 == (-0.5542431572290581d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.pow(22026.465794806718d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1023.9999999999998d + "'", double2 == 1023.9999999999998d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn10();
        dfpField29.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getLn2();
        boolean boolean41 = dfp40.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance();
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp37, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.power10(1);
        boolean boolean46 = dfp11.unequal(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.negate();
        double double48 = dfp47.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-10.0d) + "'", double48 == (-10.0d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        double double5 = dfp4.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.7320508075688772d + "'", double5 == 1.7320508075688772d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp13.subtract(dfp16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.376727508058575d + "'", double1 == 0.376727508058575d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean9 = dfp7.equals((java.lang.Object) 100.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(3L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(11013.232920103323d);
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp7.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 8);
        mersenneTwister1.setSeed(6996356570664251883L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 1.0745954827548365d, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException33);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10(13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.power10K(85);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3287936736323291d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3287936736323291d + "'", double2 == 0.3287936736323291d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.233403117511217d + "'", double1 == 1.233403117511217d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((-0.013208311274547947d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        java.lang.Number number10 = numberIsTooSmallException7.getMin();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999103740052037d) + "'", double1 == (-0.9999103740052037d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00885165604168446d + "'", double1 == 0.00885165604168446d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 13, (java.lang.Number) 1628966203, true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn10();
        dfpField10.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp17);
        boolean boolean19 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.newInstance("0.6931471805599453094172321214581765680755001343602552");
        org.apache.commons.math.dfp.Dfp dfp22 = dfp8.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp4.divide(dfp22);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            boolean boolean13 = dfp11.greaterThan(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 18L, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.getOne();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.DfpField.computeExp(dfp24, dfp30);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Object[] objArray9 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.negate();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(18);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance(0L);
        int int13 = dfp8.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.5707963267948966d), 0.7224284372420832d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1397300321440964d) + "'", double2 == (-1.1397300321440964d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getZero();
        int int8 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.239435156654757d, (double) 8L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2394351566547572d + "'", double2 == 1.2394351566547572d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        int int5 = mersenneTwister1.nextInt(1);
        mersenneTwister1.setSeed((-8384595794609528779L));
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.multiply(18);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp15, dfp26);
        int int28 = dfp15.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-6683256247793684953L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0745954827548365d + "'", double2 == 1.0745954827548365d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.classify();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getOne();
        java.lang.String str6 = dfp5.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1." + "'", str6.equals("1."));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.remainder(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        boolean boolean13 = dfp12.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7306786685136297d + "'", double1 == 1.7306786685136297d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply(1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn10();
        dfpField10.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.remainder(dfp17);
        boolean boolean20 = dfp18.equals((java.lang.Object) 0.5711645f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn10();
        dfpField12.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        double[] doubleArray26 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.sqrt();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.negate();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp22.multiply(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getLn10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.multiply(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp8.nextAfter(dfp35);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.Number number33 = numberIsTooSmallException31.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100.0d);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField49.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField49.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField49.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, (java.lang.Object[]) dfpArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 1.5707963267948968d);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfpArray55);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int int1 = org.apache.commons.math.util.FastMath.abs(1628966203);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1628966203 + "'", int1 == 1628966203);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathIllegalArgumentException14.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14);
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException32, localizable43, localizable44, objArray45);
        mathRuntimeException27.addSuppressed((java.lang.Throwable) mathIllegalArgumentException32);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException27);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNull(localizable24);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        double double11 = dfp10.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.141592653589793d + "'", double11 == 3.141592653589793d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.Number number33 = numberIsTooSmallException31.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100.0d);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField49.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField49.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField49.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, (java.lang.Object[]) dfpArray55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField58.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, (java.lang.Object[]) dfpArray60);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfpArray60);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        boolean boolean8 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean9 = dfp7.equals((java.lang.Object) 100.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(3L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.9512437185814275d, 0.8921238883488796d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.951243718581427d + "'", double2 == 3.951243718581427d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        double double4 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((-1));
        double double7 = mersenneTwister1.nextGaussian();
        long long8 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9971848088551236d + "'", double4 == 0.9971848088551236d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1688976178093215d + "'", double7 == 0.1688976178093215d);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-7327722439656189189L) + "'", long8 == (-7327722439656189189L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double2 = org.apache.commons.math.util.FastMath.max(2.0947125472611012d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8474271466316103680L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4742715E18f) + "'", float2 == (-8.4742715E18f));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int2 = org.apache.commons.math.util.FastMath.min(10000, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        int[] intArray17 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister1.setSeed(intArray17);
        mersenneTwister1.setSeed(32768);
        double double21 = mersenneTwister1.nextGaussian();
        long long22 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.5451880495569174d) + "'", double21 == (-0.5451880495569174d));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-3890071796248581391L) + "'", long22 == (-3890071796248581391L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.784919240787009E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7837748332252647E-4d + "'", double1 == 4.7837748332252647E-4d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.power10(1);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 10, (byte) -1);
        boolean boolean32 = dfp17.equals((java.lang.Object) dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn10();
        dfpField34.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn10();
        dfpField42.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField42.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getLn2();
        boolean boolean54 = dfp53.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.newInstance();
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.DfpField.computeLn(dfp40, dfp50, dfp53);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp17.nextAfter(dfp40);
        double[] doubleArray58 = dfp17.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable10, localizable11, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        java.lang.Number number22 = numberIsTooSmallException3.getArgument();
        java.lang.String str23 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (0)" + "'", str23.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (0)"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 18);
        double double2 = mersenneTwister1.nextDouble();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5433766888254443d + "'", double2 == 0.5433766888254443d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7827505790050552871L + "'", long3 == 7827505790050552871L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray7 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister1.nextBytes(byteArray7);
        int[] intArray15 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister(intArray15);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray15);
        mersenneTwister1.setSeed(intArray15);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn2();
        boolean boolean14 = dfp13.isNaN();
        int int15 = dfp13.classify();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.multiply(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(0.9999999999999999d);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField7.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getZero();
        dfpField7.clearIEEEFlags();
        dfpField7.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField7.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn10();
        dfpField13.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        boolean boolean22 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean25 = dfp11.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp11.subtract(dfp31);
        boolean boolean35 = dfp6.unequal(dfp11);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.1115063573114566E36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9858489628818731d + "'", double1 == 0.9858489628818731d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.865657038608865d, (java.lang.Number) 0.3174364228359577d, true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.0947125472611012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        int int2 = dfpField1.getRadixDigits();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        long long18 = mersenneTwister1.nextLong();
        double double19 = mersenneTwister1.nextGaussian();
        float float20 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-7910618197763358337L) + "'", long18 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.239435156654757d + "'", double19 == 1.239435156654757d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.54060876f + "'", float20 == 0.54060876f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3174364228359577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3736019123750923d + "'", double1 == 0.3736019123750923d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray11);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException14.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.subtract(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.78911877f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.78911877f + "'", float2 == 0.78911877f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1);
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.sin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean9 = dfp7.equals((java.lang.Object) 100.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(3L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.power10K(18);
        int int16 = dfp11.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException16.getGeneralPattern();
        java.lang.Number number20 = numberIsTooSmallException16.getArgument();
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.7182818284590455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6977837230134325d + "'", double1 == 2.6977837230134325d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(11013.232920103323d, (-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.23292010332d + "'", double2 == 11013.23292010332d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getLn10();
        dfpField15.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField15.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp22);
        boolean boolean24 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean27 = dfp13.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp13.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7237368419565787d + "'", double1 == 0.7237368419565787d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        int int9 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (-2147483648));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5705654518541791d + "'", double1 == 0.5705654518541791d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("0.6931471805599453094172321214581765680755001343602552");
        java.lang.Class<?> wildcardClass15 = dfp12.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((double) 32760L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn10();
        dfpField14.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField14.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp21);
        boolean boolean23 = dfp12.isNaN();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.newInstance("0.6931471805599453094172321214581765680755001343602552");
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn10();
        dfpField29.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getLn10();
        dfpField36.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getLn5();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField36.newDfp((byte) 100);
        double double44 = dfp43.toDouble();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.rint();
        int int46 = dfp45.log10K();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp12.dotrap(32768, "", dfp34, dfp45);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp12);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp12.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed(0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.divide((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(13);
        boolean boolean14 = dfp11.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        boolean boolean18 = dfp17.isNaN();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.subtract(dfp17);
        double[] doubleArray20 = dfp19.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp6.dotrap(100, "1.73205080756887729352744634150587236694280525381", dfp19, dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getLn10();
        dfpField36.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getLn5();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField36.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp34, dfp43);
        boolean boolean45 = dfp34.isNaN();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp34.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean48 = dfp34.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp34.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getTwo();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.power10(13);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getTwo();
        int int60 = dfp59.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp59.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp63 = org.apache.commons.math.dfp.Dfp.copysign(dfp56, dfp62);
        boolean boolean64 = dfp49.equals((java.lang.Object) dfp56);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getTwo();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp67.power10(13);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp6.dotrap((-2147483648), "3.141592653589793238462643383279502884197169399375", dfp56, dfp67);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 13 + "'", int60 == 13);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn10();
        dfpField12.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.floor();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.add(dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray24 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        mersenneTwister1.setSeed(intArray24);
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.9512437185814275d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField4.getLn5();
        boolean boolean14 = dfp2.lessThan(dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0L, 0.5683657275154999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.getOne();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn10();
        dfpField42.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField42.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.Dfp.copysign(dfp40, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getTwo();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.power10(13);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp50.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp36.add(dfp50);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3, 2.6977837230134325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8383895291127912d + "'", double2 == 0.8383895291127912d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getTwo();
        int int9 = dfp8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.negate();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.nextAfter(dfp12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) 6996356570664251883L, false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        long long2 = org.apache.commons.math.util.FastMath.max(8L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.000000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0634370688955608d + "'", double1 == 2.0634370688955608d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1072355796));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 'a');
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        double double9 = dfp8.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.rint();
        boolean boolean11 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(1.5707963267948968d);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(6996356570664251883L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        int int5 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        java.lang.Class<?> wildcardClass8 = dfp7.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        boolean boolean9 = dfp8.isInfinite();
        int int10 = dfp8.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.865657038608865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        java.lang.String str6 = dfp5.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3.141592653589793238462643383279502884197169399375" + "'", str6.equals("3.141592653589793238462643383279502884197169399375"));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        boolean boolean36 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.rint();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.636464658869532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6803140642326859d + "'", double1 == 0.6803140642326859d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        long long1 = org.apache.commons.math.util.FastMath.abs(18L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 18L + "'", long1 == 18L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.764725154011207d), (java.lang.Number) 0.8813735870195429d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray25);
        java.lang.String str27 = mathIllegalArgumentException26.toString();
        numberIsTooSmallException21.addSuppressed((java.lang.Throwable) mathIllegalArgumentException26);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) mathIllegalArgumentException26);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str27.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfp2.add(dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int[] intArray2 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        boolean boolean4 = mersenneTwister3.nextBoolean();
        mersenneTwister3.setSeed(0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray20 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        mersenneTwister1.setSeed(intArray20);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        int[] intArray30 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister(intArray30);
        org.apache.commons.math.random.MersenneTwister mersenneTwister32 = new org.apache.commons.math.random.MersenneTwister(intArray30);
        mersenneTwister23.setSeed(intArray30);
        org.apache.commons.math.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math.random.MersenneTwister(0L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister37 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister39 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray45 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister39.nextBytes(byteArray45);
        mersenneTwister37.nextBytes(byteArray45);
        long long48 = mersenneTwister37.nextLong();
        int[] intArray53 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister37.setSeed(intArray53);
        mersenneTwister35.setSeed(intArray53);
        mersenneTwister23.setSeed(intArray53);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-8474271314106775063L) + "'", long48 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.remainder(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.divide(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn10();
        dfpField22.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getLn5();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField22.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField22.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn2();
        double[] doubleArray36 = dfp35.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.ceil();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.negate();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp32.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn10();
        dfpField42.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getTwo();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn10();
        dfpField50.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField50.getTwo();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField50.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getLn2();
        boolean boolean62 = dfp61.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp61.newInstance();
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeLn(dfp48, dfp58, dfp61);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp58.power10(1);
        boolean boolean67 = dfp32.unequal(dfp66);
        boolean boolean68 = dfp14.lessThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance(52.0d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(32768);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        dfpField1.setIEEEFlags((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((double) 32760L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp11.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance((-8474271314106775063L));
        org.apache.commons.math.dfp.Dfp dfp16 = dfp4.add(dfp11);
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean17 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10(13);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getTwo();
        int int29 = dfp28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        boolean boolean33 = dfp18.equals((java.lang.Object) dfp25);
        java.lang.String str34 = dfp18.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2." + "'", str34.equals("2."));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-51931120792031348L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.239435156654757d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.36787944117144233d, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException84 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable80, (java.lang.Number) 32.0d, (java.lang.Number) 8L, true);
        org.apache.commons.math.dfp.DfpField dfpField86 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode87 = dfpField86.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField86.getTwo();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField86.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray90 = dfpField86.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable80, (java.lang.Object[]) dfpArray90);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + roundingMode87 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode87.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfpArray90);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        int int6 = dfp2.classify();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp16);
        boolean boolean18 = dfp2.unequal(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.newInstance(32760);
        int int21 = dfp20.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 100);
        java.lang.String str10 = dfp9.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100." + "'", str10.equals("100."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        int int5 = mersenneTwister1.nextInt(1);
        double double6 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.847889746258903d + "'", double6 == 1.847889746258903d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        boolean boolean24 = dfp17.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.power10K(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn10();
        dfpField28.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField28.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField28.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean38 = dfp17.greaterThan(dfp37);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp9 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn10();
        dfpField17.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField17.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        boolean boolean29 = dfp28.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.DfpField.computeLn(dfp15, dfp25, dfp28);
        boolean boolean32 = dfp25.isNaN();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp25.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp7.remainder(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.52885604f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        double[] doubleArray16 = dfp15.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp7.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp7.newInstance(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(92560.48544260228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5303325.165543206d + "'", double1 == 5303325.165543206d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean9 = dfp7.equals((java.lang.Object) 100.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(3L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((-1L));
        double[] doubleArray14 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.expm1(51.11493360519108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5810063257434333E22d + "'", double1 == 1.5810063257434333E22d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, number3, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) '4');
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        dfpField17.setIEEEFlagsBits((int) (byte) 2);
        int int21 = dfpField17.getRadixDigits();
        int int22 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp6.dotrap(97, "org.apache.commons.math.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)", dfp15, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 18 + "'", int22 == 18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8414709848078966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6105647004975029d + "'", double1 == 0.6105647004975029d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        int int6 = dfp2.classify();
        double[] doubleArray7 = dfp2.toSplitDouble();
        boolean boolean9 = dfp2.equals((java.lang.Object) 52.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.power10(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp16, dfp26);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-51931120792031348L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("100.");
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((long) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(85);
        mersenneTwister1.setSeed((long) 100);
        double double4 = mersenneTwister1.nextDouble();
        float float5 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0787171938695459d + "'", double4 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.58688855f + "'", float5 == 0.58688855f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-51931120792031348L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10(13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        int int23 = dfp22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp19.add(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getTwo();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getLn10();
        dfpField33.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getLn5();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getTwo();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn10();
        dfpField41.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField41.getTwo();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField41.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getLn2();
        boolean boolean53 = dfp52.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp39, dfp49, dfp52);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp19.divide(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.getOne();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp16.subtract(dfp57);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.newInstance("0.6931471805599453094172321214581765680755001343602552");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn10();
        dfpField20.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn10();
        dfpField27.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField27.newDfp((byte) 100);
        double double35 = dfp34.toDouble();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.rint();
        int int37 = dfp36.log10K();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp3.dotrap(32768, "", dfp25, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getLn2();
        double[] doubleArray43 = dfp42.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.sqrt();
        int int45 = dfp42.getRadixDigits();
        boolean boolean46 = dfp3.greaterThan(dfp42);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.000000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341005d + "'", double1 == 1.6094379124341005d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7237368419565787d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        boolean boolean6 = dfp3.equals((java.lang.Object) Double.NaN);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        boolean boolean8 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) -1);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.multiply(18);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp15, dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.016414201182027504d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0164142011820275d + "'", double2 == 0.0164142011820275d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(13);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.divide((int) (byte) 100);
        boolean boolean24 = dfp3.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.nextAfter(dfp30);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        int int5 = mersenneTwister1.nextInt(1);
        double double6 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9325573593395109d + "'", double6 == 0.9325573593395109d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int[] intArray2 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        long long4 = mersenneTwister3.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4605733071054935415L) + "'", long4 == (-4605733071054935415L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn10();
        dfpField18.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField8.newDfp(dfp25);
        dfpField8.setIEEEFlagsBits(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField8.newDfp(0L);
        boolean boolean32 = dfp2.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getTwo();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.negate();
        boolean boolean40 = dfp2.lessThan(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp39.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfpField41);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Number number39 = numberIsTooSmallException37.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException37);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getLn2();
        double[] doubleArray45 = dfp44.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.sqrt();
        org.apache.commons.math.dfp.Dfp dfp47 = new org.apache.commons.math.dfp.Dfp(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.power10(52);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp46.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.getOne();
        int int53 = dfp46.getRadixDigits();
        org.apache.commons.math.random.MersenneTwister mersenneTwister56 = new org.apache.commons.math.random.MersenneTwister(0);
        double double57 = mersenneTwister56.nextGaussian();
        java.lang.Object[] objArray58 = new java.lang.Object[] { int53, 4.396829672158179d, double57 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable41, objArray58);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) (-0.404985220652412d));
        java.lang.Number number62 = notStrictlyPositiveException61.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 13 + "'", int53 == 13);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-0.7805794640849414d) + "'", double57 == (-0.7805794640849414d));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + (-0.404985220652412d) + "'", number62.equals((-0.404985220652412d)));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.6094379124341005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 8098045977194093303L, (double) (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0980459771940925E18d + "'", double2 == 8.0980459771940925E18d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number15 = numberIsTooSmallException12.getMin();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8474271314106775063L) + "'", long2 == (-8474271314106775063L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        boolean boolean24 = dfp17.isNaN();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.5827464389221464d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(100.69314718055995d, 0.6431396419047642d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.69314718055993d + "'", double2 == 100.69314718055993d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        long long2 = org.apache.commons.math.util.FastMath.max(5805985991905072931L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5805985991905072931L + "'", long2 == 5805985991905072931L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField6.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn10();
        dfpField12.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField12.setRoundingMode(roundingMode18);
        dfpField6.setRoundingMode(roundingMode18);
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable10, localizable11, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        java.lang.String str22 = mathRuntimeException20.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str22.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits(1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-6683256247793684953L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.6832561E18f + "'", float1 == 6.6832561E18f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        int int11 = dfp10.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.73205080756887729352744634150587236694280525381");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.newInstance(0.5998406268185329d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn10();
        dfpField18.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField8.newDfp(dfp25);
        dfpField8.setIEEEFlagsBits(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField8.newDfp(0L);
        boolean boolean32 = dfp2.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getTwo();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.negate();
        boolean boolean40 = dfp2.lessThan(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.negate();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0000679992263886d), (java.lang.Number) (-8.4742715E18f), true);
        boolean boolean46 = dfp39.equals((java.lang.Object) numberIsTooSmallException45);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags(4);
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-3326353687696163896L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3326353687696163840L) + "'", long1 == (-3326353687696163840L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        mersenneTwister1.setSeed((long) (-1));
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 93740670 + "'", int4 == 93740670);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', 16L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.Number number33 = numberIsTooSmallException31.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100.0d);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField49.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField49.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField49.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, (java.lang.Object[]) dfpArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 3.0d);
        java.lang.Number number59 = notStrictlyPositiveException58.getMin();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 0 + "'", number59.equals(0));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        int int9 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.negate();
        double[] doubleArray7 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        dfpField7.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField7.setRoundingMode(roundingMode13);
        dfpField1.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.newDfp((int) ' ');
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int int1 = org.apache.commons.math.util.FastMath.abs(85);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 85 + "'", int1 == 85);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException9.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Number number23 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable25, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException39.addSuppressed((java.lang.Throwable) numberIsTooSmallException43);
        java.lang.Number number45 = numberIsTooSmallException43.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException51.addSuppressed((java.lang.Throwable) numberIsTooSmallException55);
        java.lang.Number number57 = numberIsTooSmallException55.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException55);
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooSmallException55.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable59, objArray63);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getTwo();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField71.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray76 = dfpField71.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable59, (java.lang.Object[]) dfpArray76);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException77);
        org.apache.commons.math.exception.util.Localizable localizable79 = mathIllegalArgumentException77.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-1.0d) + "'", number45.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1.0d) + "'", number57.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfpArray76);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        java.lang.String str7 = dfp6.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.609437912434100374600759333226187639525601354268" + "'", str7.equals("1.609437912434100374600759333226187639525601354268"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.013208695330432285d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0, (java.lang.Number) 2.0f, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9971848088551237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance((-8474271314106775063L));
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(0.637699948585789d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp17);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField5.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField5.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField12.getRoundingMode();
        dfpField5.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) 0.43899584f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double2 = org.apache.commons.math.util.FastMath.pow(43.42944819032518d, (-10.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.1894487980295214E-17d + "'", double2 == 4.1894487980295214E-17d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean17 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp3.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(14.154262241479262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24703847930452583d + "'", double1 == 0.24703847930452583d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn10();
        dfpField13.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp7.newInstance(dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn10();
        dfpField11.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn10();
        dfpField19.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField19.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getLn2();
        boolean boolean31 = dfp30.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp27, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.power10(1);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp((byte) 10, (byte) -1);
        boolean boolean42 = dfp27.equals((java.lang.Object) dfp41);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getTwo();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.power10(13);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getOne();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getTwo();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn10();
        dfpField54.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField54.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp27.dotrap(13, "0.6931471805599453094172321214581765680755001343602552", dfp51, dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp9.subtract(dfp27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
    }
}

