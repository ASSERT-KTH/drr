import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 4, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.000000000000001d + "'", double2 == 4.000000000000001d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 2, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8325546111576977d + "'", double1 == 0.8325546111576977d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 'a', (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, 0.5711645f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.log(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0787619161000124d + "'", double1 == 1.0787619161000124d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466711037884725d + "'", double1 == 3.466711037884725d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int2 = org.apache.commons.math.util.FastMath.max(35, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        try {
            int int13 = mersenneTwister1.nextInt((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0787619161000124d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0787619161000126d + "'", double1 == 1.0787619161000126d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6, localizable7, localizable8, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray12);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6665119929013519d + "'", double0 == 0.6665119929013519d);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        byte[] byteArray2 = null;
        try {
            mersenneTwister1.nextBytes(byteArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0000679992263888d) + "'", double3 == (-1.0000679992263888d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 0, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        int int5 = mersenneTwister1.nextInt((int) (byte) 10);
        float float6 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5711645232847797d + "'", double3 == 0.5711645232847797d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.43899584f + "'", float6 == 0.43899584f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math.util.FastMath.max(4.000000000000001d, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32760);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32760L + "'", long1 == 32760L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable15, localizable16, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.466711037884725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.95653485476009d + "'", double1 == 1.95653485476009d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3513346877207577d + "'", double1 == 2.3513346877207577d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.8325546111576977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.681845327377341d + "'", double1 == 0.681845327377341d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.43899584f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45323268452949356d + "'", double1 == 0.45323268452949356d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.681845327377341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8801606659888926d + "'", double1 == 0.8801606659888926d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-32767));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 11013.232920103323d, (java.lang.Number) 10, false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9905373453108037d) + "'", double1 == (-0.9905373453108037d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.6665119929013519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.373400766945016d + "'", double2 == 1.373400766945016d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.764725154011207d) + "'", double1 == (-0.764725154011207d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.45323268452949356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43899583816528326d + "'", double1 == 0.43899583816528326d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10000.0f, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException12.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5998406268185329d + "'", double1 == 0.5998406268185329d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        float float2 = mersenneTwister1.nextFloat();
        try {
            int int4 = mersenneTwister1.nextInt((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5711645f + "'", float2 == 0.5711645f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32767.0d) + "'", double1 == (-32767.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int2 = org.apache.commons.math.util.FastMath.max(8, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        java.lang.String str14 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.73205080756887729352744634150587236694280525381" + "'", str14.equals("1.73205080756887729352744634150587236694280525381"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.3513346877207577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32760, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        float float2 = mersenneTwister1.nextFloat();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5711645f + "'", float2 == 0.5711645f);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5805985991905072931L + "'", long3 == 5805985991905072931L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 4, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.000000000000001d + "'", double2 == 4.000000000000001d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        java.lang.String str5 = dfp4.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0." + "'", str5.equals("0."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92560.48544260228d + "'", double1 == 92560.48544260228d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long1 = org.apache.commons.math.util.FastMath.abs(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1972245773362196d + "'", double1 == 2.1972245773362196d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 85);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.396829672158179d + "'", double1 == 4.396829672158179d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0787619161000126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.865657038608865d + "'", double1 == 1.865657038608865d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.util.FastMath.min(2.0d, (double) 0.5711645f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711644887924194d + "'", double2 == 0.5711644887924194d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 100, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 52, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.000000000000002d + "'", double1 == 8.000000000000002d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611012d + "'", double1 == 2.0947125472611012d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5711644887924194d, (double) 0.43899584f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7820223734225045d + "'", double2 == 0.7820223734225045d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn10();
        dfpField8.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(13);
        boolean boolean21 = dfp15.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = dfp3.dotrap(8, "hi!", dfp15, dfp22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.73205080756887729352744634150587236694280525381" + "'", str4.equals("1.73205080756887729352744634150587236694280525381"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number34 = numberIsTooSmallException33.getMin();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) 0 + "'", number34.equals((byte) 0));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 32760L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5707963267948966d, 2.3513346877207577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948968d + "'", double2 == 1.5707963267948968d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int[] intArray6 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-6683256247793684953L) + "'", long8 == (-6683256247793684953L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp12);
        java.lang.Object obj14 = null;
        boolean boolean15 = dfp12.equals(obj14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn10();
        dfpField11.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp(dfp18);
        dfpField1.setIEEEFlagsBits(32768);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        int int8 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        dfpField1.setIEEEFlags((int) ' ');
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.log(0.45323268452949356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7913496329903439d) + "'", double1 == (-0.7913496329903439d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 13, (-32767.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.0d + "'", double2 == 13.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.util.FastMath.max((double) ' ', 3.466711037884725d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp9);
        boolean boolean11 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray12);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        numberIsTooSmallException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException13);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number16 = numberIsTooSmallException12.getArgument();
        boolean boolean17 = numberIsTooSmallException12.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32760L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.util.FastMath.max(0.637699948585789d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 35, (java.lang.Number) 0L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5403023058681398d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 8, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        java.lang.String str3 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.6931471805599453094172321214581765680755001343602552" + "'", str3.equals("0.6931471805599453094172321214581765680755001343602552"));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.637699948585789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8921238883488796d + "'", double1 == 0.8921238883488796d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7568024953079282d) + "'", double1 == (-0.7568024953079282d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0L, (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray18 = null;
        mersenneTwister1.setSeed(intArray18);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.atan2(16.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4636476090008061d + "'", double2 == 0.4636476090008061d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3L, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.tan(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.95653485476009d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9565348547600903d + "'", double1 == 1.9565348547600903d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        double double13 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt((int) 'a');
        mersenneTwister1.setSeed((long) (short) 10);
        int[] intArray20 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        mersenneTwister1.setSeed(intArray20);
        mersenneTwister1.setSeed((long) 52);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3287936736323291d + "'", double13 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        java.lang.Throwable[] throwableArray34 = numberIsTooSmallException33.getSuppressed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        mersenneTwister1.setSeed((long) 10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 10);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32768);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32768.0f + "'", float1 == 32768.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 16, 32760L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int1 = org.apache.commons.math.util.FastMath.round(0.43899584f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06566270191375284d + "'", double1 == 0.06566270191375284d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 6996356570664251883L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9963565706642514E18d + "'", double1 == 6.9963565706642514E18d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        int int8 = dfp2.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.exp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.divide((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.power10(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.apache.commons.math.util.FastMath.min(32760L, (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-7910618197763358337L) + "'", long3 == (-7910618197763358337L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.acosh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        boolean boolean3 = dfp2.isNaN();
        boolean boolean4 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) 32768);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7615941559557649d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6881171418161356E43d, 1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.7568024953079282d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013208695330432285d) + "'", double1 == (-0.013208695330432285d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.7820223734225045d, (java.lang.Number) (byte) 2, false);
        java.lang.Number number38 = numberIsTooSmallException37.getMin();
        java.lang.Number number39 = numberIsTooSmallException37.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (byte) 2 + "'", number38.equals((byte) 2));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.7820223734225045d + "'", number39.equals(0.7820223734225045d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0000679992263888d), (-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000679992263886d) + "'", double2 == (-1.0000679992263886d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException4.getSpecificPattern();
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException4.getSuppressed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.sinh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math.util.FastMath.min(3.0d, (double) 8L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.rint(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.95653485476009d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn10();
        dfpField9.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp17, dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.power10(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.000000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.30823283601651d + "'", double1 == 27.30823283601651d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5805985991905072931L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.8059859919050732E18d + "'", double1 == 5.8059859919050732E18d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        float float2 = org.apache.commons.math.util.FastMath.min(0.5711645f, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5711645f + "'", float2 == 0.5711645f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 8L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.644298430695373d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        int int6 = dfp2.classify();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp16);
        boolean boolean18 = dfp2.unequal(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.negate();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn10();
        dfpField21.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField21.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField21.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp17.divide(dfp31);
        int int33 = dfp17.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.36787944117144233d, true);
        java.lang.String str80 = numberIsTooSmallException79.toString();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.368 is smaller than the minimum (0.368): 0.368 is smaller than the minimum (0.368)" + "'", str80.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.368 is smaller than the minimum (0.368): 0.368 is smaller than the minimum (0.368)"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.865657038608865d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9971848088551236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9971848088551237d + "'", double1 == 0.9971848088551237d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 16L, (float) (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4742715E18f) + "'", float2 == (-8.4742715E18f));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.0947125472611012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8658666377179232d + "'", double1 == 0.8658666377179232d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9565348547600903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0983021078523085d + "'", double1 == 1.0983021078523085d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-32767.0d), (java.lang.Number) 32768.0f, true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp3.newInstance("0.6931471805599453094172321214581765680755001343602552");
        boolean boolean17 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp3.getTwo();
        int int19 = dfp18.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 13, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        float float2 = org.apache.commons.math.util.FastMath.max(4.0f, (float) 85);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 85.0f + "'", float2 == 85.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.36787944117144233d, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException81 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException79);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.4161468365471424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39434810579542623d) + "'", double1 == (-0.39434810579542623d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7023867716137234d) + "'", double2 == (-0.7023867716137234d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 16);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        double[] doubleArray10 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7224284372420832d + "'", double1 == 0.7224284372420832d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0.0f, 0.9971848088551237d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable10, localizable11, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException9.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        java.lang.Object[] objArray22 = mathRuntimeException20.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.9565348547600903d, (java.lang.Number) 52, true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int[] intArray2 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        boolean boolean4 = mersenneTwister3.nextBoolean();
        double double5 = mersenneTwister3.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5683657275154999d + "'", double5 == 0.5683657275154999d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField2.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField2.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn10();
        dfpField10.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField10.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn10();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.nextAfter(dfp24);
        try {
            org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp8, dfp24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        double double9 = dfp8.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.rint();
        int int11 = dfp10.log10K();
        int int12 = dfp10.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0000679992263886d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.632145573495463d) + "'", double1 == (-0.632145573495463d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        java.lang.String str7 = dfp6.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100." + "'", str7.equals("100."));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9991050130774393d) + "'", double1 == (-0.9991050130774393d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 85);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 85.0f + "'", float1 == 85.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.max(4.000000000000001d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.000000000000001d + "'", double2 == 4.000000000000001d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        boolean boolean8 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2686362411795196d + "'", double1 == 1.2686362411795196d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.9565348547600903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.250727012762132d + "'", double1 == 1.250727012762132d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10.0d);
        int int9 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply(1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn10();
        dfpField10.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.remainder(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.multiply(1);
        java.lang.String str21 = dfp20.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-0.53096491487338363080458826494409229430942078" + "'", str21.equals("-0.53096491487338363080458826494409229430942078"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 100.0d);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) dfpArray39);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray39);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3174364228359577d + "'", double1 == 0.3174364228359577d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(13);
        boolean boolean12 = dfp9.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int2 = org.apache.commons.math.util.FastMath.max(8, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) (byte) 1);
        double[] doubleArray7 = dfp6.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0L + "'", number9.equals(0L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(13);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply(1);
        int int9 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 8);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        java.lang.Object[] objArray76 = mathIllegalArgumentException75.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int[] intArray6 = new int[] { 0, 10, 8, (byte) -1, 8, 52 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextDouble();
        int int9 = mersenneTwister7.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.637699948585789d + "'", double8 == 0.637699948585789d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1628966203 + "'", int9 == 1628966203);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32L, (java.lang.Number) 4.574710978503383d, true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.06566270191375284d, 4.000000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.016414201182027504d + "'", double2 == 0.016414201182027504d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963267948968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027415567780803778d + "'", double1 == 0.027415567780803778d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0545413460035993d + "'", double1 == 1.0545413460035993d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.acos(22026.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable15, localizable16, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathRuntimeException18.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(13);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.add(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp26, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 4.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.042831059009366d + "'", double1 == 43.042831059009366d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-6683256247793684953L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6683256247793684953L) + "'", long2 == (-6683256247793684953L));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float2 = org.apache.commons.math.util.FastMath.max(4.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int2 = org.apache.commons.math.util.FastMath.min(8, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.8059859919050732E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-8.4742715E18f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-8474271466316103680L) + "'", long1 == (-8474271466316103680L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int1 = org.apache.commons.math.util.FastMath.abs(32760);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32760 + "'", int1 == 32760);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.396829672158179d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6431396419047642d + "'", double1 == 0.6431396419047642d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2.0f, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0000000000000004d + "'", double2 == 2.0000000000000004d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 2.3513346877207577d);
        java.lang.Number number32 = notStrictlyPositiveException31.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 2.3513346877207577d + "'", number32.equals(2.3513346877207577d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, 2.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.7820223734225045d, (java.lang.Number) (byte) 2, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException41.addSuppressed((java.lang.Throwable) numberIsTooSmallException45);
        java.lang.Number number47 = numberIsTooSmallException45.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException45);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException45.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException53.addSuppressed((java.lang.Throwable) numberIsTooSmallException57);
        java.lang.Number number59 = numberIsTooSmallException57.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException57);
        org.apache.commons.math.exception.util.Localizable localizable61 = numberIsTooSmallException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable61, objArray65);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 2.3513346877207577d);
        org.apache.commons.math.random.MersenneTwister mersenneTwister71 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass72 = mersenneTwister71.getClass();
        double double73 = mersenneTwister71.nextDouble();
        java.lang.Class<?> wildcardClass74 = mersenneTwister71.getClass();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getLn2();
        double[] doubleArray79 = dfp78.toSplitDouble();
        java.lang.Object[] objArray80 = new java.lang.Object[] { wildcardClass74, (-0.7853981633974483d), doubleArray79 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable49, objArray80);
        java.lang.Throwable[] throwableArray82 = mathIllegalArgumentException81.getSuppressed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.0d) + "'", number47.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + (-1.0d) + "'", number59.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.5711645232847797d + "'", double73 == 0.5711645232847797d);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(throwableArray82);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-32767.0d), (java.lang.Number) 7.930067261567154E14d, true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54.598150033144236d + "'", double1 == 54.598150033144236d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.log1p(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.asinh(27.30823283601651d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.000670475592684d + "'", double1 == 4.000670475592684d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.sinh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        long long4 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-51931120792031348L) + "'", long4 == (-51931120792031348L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number10 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.0d) + "'", number10.equals((-1.0d)));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(52.0d, 0.5998406268185329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Object[] objArray16 = mathRuntimeException15.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        int int6 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(13);
        boolean boolean12 = dfp9.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5711645232847797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray11);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
        java.lang.Object[] objArray15 = mathIllegalArgumentException14.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5805985991905072931L, (java.lang.Number) (-1.0000679992263886d), true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.681845327377341d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.907793317242678d + "'", double1 == 6.907793317242678d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1, 7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.930067261567154E14d + "'", double2 == 7.930067261567154E14d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.013208695330432285d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013208311274547947d) + "'", double1 == (-0.013208311274547947d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 16L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister16.nextBytes(byteArray22);
        mersenneTwister14.nextBytes(byteArray22);
        long long25 = mersenneTwister14.nextLong();
        int[] intArray30 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister14.setSeed(intArray30);
        mersenneTwister1.setSeed(intArray30);
        float float33 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-8474271314106775063L) + "'", long25 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.30104005f + "'", float33 == 0.30104005f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.637699948585789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        int int3 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn10();
        dfpField5.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp12);
        boolean boolean14 = dfp3.isNaN();
        boolean boolean15 = dfp3.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.36787944117144233d, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 92560.48544260228d);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        double[] doubleArray5 = dfp3.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 97);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.4161468365471424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.404985220652412d) + "'", double1 == (-0.404985220652412d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.0000679992263888d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.39434810579542623d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.37562457894974405d) + "'", double1 == (-0.37562457894974405d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        double double9 = dfp8.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp10.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078966d + "'", double1 == 0.8414709848078966d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.asinh(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466711037884725d + "'", double1 == 3.466711037884725d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8474271466316103680L), 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4742715E18f) + "'", float2 == (-8.4742715E18f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn10();
        dfpField17.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField17.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField7.newDfp(dfp24);
        boolean boolean27 = dfp5.equals((java.lang.Object) dfp24);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.141592653589793d, 1.2686362411795196d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897927d + "'", double2 == 3.1415926535897927d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 13, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.999999999999998d + "'", double2 == 12.999999999999998d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 16.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464757906675863d + "'", double1 == 3.464757906675863d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.42944819032518d + "'", double1 == 43.42944819032518d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', 0.43899584f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.43899584f + "'", float2 == 0.43899584f);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8921238883488796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.11493360519108d + "'", double1 == 51.11493360519108d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int1 = org.apache.commons.math.util.FastMath.abs(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        dfpField1.setIEEEFlags(32760);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.atan(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707509268651654d + "'", double1 == 1.5707509268651654d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.54060876f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        double double2 = mersenneTwister1.nextGaussian();
        byte[] byteArray6 = new byte[] { (byte) 2, (byte) 2, (byte) -1 };
        mersenneTwister1.nextBytes(byteArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass10 = mersenneTwister9.getClass();
        double double11 = mersenneTwister9.nextDouble();
        java.lang.Class<?> wildcardClass12 = mersenneTwister9.getClass();
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray15 = new byte[] {};
        mersenneTwister14.nextBytes(byteArray15);
        mersenneTwister9.nextBytes(byteArray15);
        mersenneTwister1.nextBytes(byteArray15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000679992263888d) + "'", double2 == (-1.0000679992263888d));
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5711645232847797d + "'", double11 == 0.5711645232847797d);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.17190230687955d + "'", double1 == 1.17190230687955d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.6665119929013519d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn10();
        dfpField12.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp19);
        boolean boolean21 = dfp6.equals((java.lang.Object) dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass8 = mersenneTwister7.getClass();
        boolean boolean9 = dfp5.equals((java.lang.Object) wildcardClass8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance(10L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9991050130774393d + "'", double1 == 0.9991050130774393d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5998406268185329d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5998406268185329d + "'", double2 == 0.5998406268185329d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0148369064941645d + "'", double1 == 1.0148369064941645d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getTwo();
        int int8 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10((int) 'a');
        int int11 = dfp7.classify();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        int int15 = dfp14.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.remainder(dfp21);
        boolean boolean23 = dfp7.unequal(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp4.nextAfter(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.8059859919050732E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        int[] intArray17 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister1.setSeed(intArray17);
        mersenneTwister1.setSeed(32768);
        double double21 = mersenneTwister1.nextGaussian();
        float float22 = mersenneTwister1.nextFloat();
        boolean boolean23 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.5451880495569174d) + "'", double21 == (-0.5451880495569174d));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.78911877f + "'", float22 == 0.78911877f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.util.Localizable localizable76 = mathIllegalArgumentException75.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable76, (java.lang.Number) 22);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0787619161000124d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8232689068535604d + "'", double1 == 0.8232689068535604d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32768.0d + "'", double1 == 32768.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        double[] doubleArray16 = dfp15.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp7.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.907793317242678d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 395.78740282668d + "'", double1 == 395.78740282668d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        int[] intArray17 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister1.setSeed(intArray17);
        mersenneTwister1.setSeed(32768);
        double double21 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((int) (byte) 2);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.5451880495569174d) + "'", double21 == (-0.5451880495569174d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.016414201182027504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Number number23 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException29.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        java.lang.Number number35 = numberIsTooSmallException33.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException33);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable37, objArray41);
        java.lang.Object[] objArray44 = mathIllegalArgumentException43.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray44);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10(13);
        boolean boolean24 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp21);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp11.add(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0d, 1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray11 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister5.nextBytes(byteArray11);
        mersenneTwister3.nextBytes(byteArray11);
        long long14 = mersenneTwister3.nextLong();
        double double15 = mersenneTwister3.nextGaussian();
        int int17 = mersenneTwister3.nextInt((int) 'a');
        mersenneTwister3.setSeed((long) (short) 10);
        int[] intArray22 = new int[] { (byte) 1, 16 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray22);
        mersenneTwister3.setSeed(intArray22);
        mersenneTwister1.setSeed(intArray22);
        int int26 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-8474271314106775063L) + "'", long14 == (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3287936736323291d + "'", double15 == 0.3287936736323291d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 85 + "'", int17 == 85);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1072355796) + "'", int26 == (-1072355796));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(32768);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        double[] doubleArray16 = dfp15.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.sqrt();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.multiply(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp18, dfp20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance(3L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getLn2();
        dfpField2.setIEEEFlagsBits((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getTwo();
        int int10 = dfp9.getRadixDigits();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp6, dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.power10(52);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.getOne();
        int int11 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        int int8 = dfpField1.getIEEEFlags();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) -1);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.06566270191375284d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06566270191375286d + "'", double2 == 0.06566270191375286d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5557.690612768985d, 0.637699948585789d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5557.6906127689845d + "'", double2 == 5557.6906127689845d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5711645232847797d, 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711645232847797d + "'", double2 == 0.5711645232847797d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) 2);
        int int8 = dfp7.log10();
        int int9 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.ceil();
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) 100, (byte) 2, (byte) 100, (byte) 0 };
        mersenneTwister3.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        long long12 = mersenneTwister1.nextLong();
        int[] intArray17 = new int[] { 8, 35, 10000, 35 };
        mersenneTwister1.setSeed(intArray17);
        mersenneTwister1.setSeed(32768);
        double double21 = mersenneTwister1.nextGaussian();
        float float22 = mersenneTwister1.nextFloat();
        long long23 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8474271314106775063L) + "'", long12 == (-8474271314106775063L));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.5451880495569174d) + "'", double21 == (-0.5451880495569174d));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.78911877f + "'", float22 == 0.78911877f);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-3326353687696163896L) + "'", long23 == (-3326353687696163896L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn10();
        dfpField16.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.newDfp(2.0d);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField16.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn10();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getLn2();
        boolean boolean43 = dfp42.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.newInstance((-8474271314106775063L));
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.DfpField.computeExp(dfp39, dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp12.dotrap(0, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp31, dfp39);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7805794640849414d) + "'", double2 == (-0.7805794640849414d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.7568024953079282d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4292036732051034d + "'", double1 == 2.4292036732051034d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.7820223734225045d, (java.lang.Number) (byte) 2, false);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, number38);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.24450053970019d) + "'", double1 == (-57.24450053970019d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        double double3 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass4 = mersenneTwister1.getClass();
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray7 = new byte[] {};
        mersenneTwister6.nextBytes(byteArray7);
        mersenneTwister1.nextBytes(byteArray7);
        double double10 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5711645232847797d + "'", double3 == 0.5711645232847797d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.43899594558373667d + "'", double10 == 0.43899594558373667d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        double double4 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((-1));
        boolean boolean7 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9971848088551236d + "'", double4 == 0.9971848088551236d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Number number19 = numberIsTooSmallException16.getMin();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException16.getSpecificPattern();
        boolean boolean21 = numberIsTooSmallException16.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0L + "'", number19.equals(0L));
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5827464389221464d + "'", double1 == 3.5827464389221464d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-51931120792031348L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.154262241479262d + "'", double1 == 14.154262241479262d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.95653485476009d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4667110378847252d + "'", double1 == 3.4667110378847252d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        java.lang.Object[] objArray16 = mathRuntimeException15.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0L);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7853981633974483d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((int) (short) 100);
        boolean boolean6 = dfp5.isNaN();
        boolean boolean7 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-8.4742715E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(85);
        dfpField1.setIEEEFlags(35);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(13);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(dfp8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooSmallException41.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException41);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooSmallException53.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField69.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable57, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.43899594558373667d, (java.lang.Number) 0.5514266812416906d, false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        int int3 = dfp2.getRadixDigits();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.divide((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.multiply(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) 0L, true);
        numberIsTooSmallException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooSmallException19.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.7820223734225045d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray38 = numberIsTooSmallException37.getSuppressed();
        boolean boolean39 = numberIsTooSmallException37.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}

