import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1728696275, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.72869632E9f + "'", float2 == 1.72869632E9f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double[] doubleArray5 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection10, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection10, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly increasing (418,149,471 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.1814947100000334E8d + "'", double6 == 4.1814947100000334E8d);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) -1, 6.185506412422791E10d, (double) 1.41006541E9f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-418149461));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-52352406L), (float) 1068854251L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.2352408E7f) + "'", float2 == (-5.2352408E7f));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1586880496);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.1814947100000334E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1225L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 35, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 368.35449607240486d + "'", double1 == 368.35449607240486d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1601735553);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.177268708295299E10d + "'", double1 == 9.177268708295299E10d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        int int13 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.9087471254124d + "'", double1 == 43.9087471254124d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11013.232965503254d + "'", double48 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 11013.232874703393d + "'", double49 == 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1686639086) + "'", int50 == (-1686639086));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.1814947100000334E8d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6393563747406006d + "'", double2 == 1.6393563747406006d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 865.4190924615632d + "'", double1 == 865.4190924615632d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 451423506992529408L, 385);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.557398363943554E133d + "'", double2 == 3.557398363943554E133d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 3.1780538303479458d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.01700498774602796d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 418149471 + "'", int41 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2075948061 + "'", int1 == 2075948061);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1586880528L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586880628L + "'", long2 == 1586880628L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(418149471);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1225);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083384832 + "'", int1 == 1083384832);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray17 = new int[] { 52 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray17);
        int[] intArray20 = new int[] { 260 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray24 = new int[] { 52 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int[] intArray27 = new int[] {};
        int[] intArray29 = new int[] { (-1) };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray29);
        int[] intArray31 = new int[] {};
        int[] intArray33 = new int[] { 52 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray33);
        java.lang.Class<?> wildcardClass35 = intArray33.getClass();
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray33);
        int[] intArray37 = new int[] {};
        int[] intArray39 = new int[] { (-1) };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray39);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray39);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1225L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray19 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray26 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray31 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray26);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        java.lang.Number number37 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number37, 100, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException41.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection42, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11023.232874703393d + "'", double20 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.04987562112089d + "'", double21 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 418149471 + "'", int22 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 11023.232874703393d + "'", double32 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.04987562112089d + "'", double33 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.332621544395286E157d, (double) 1586880609L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1482293248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1686639086), 5, 1586880496);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23151.906933686514d + "'", double1 == 23151.906933686514d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-52352406L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3628799.9999999995d, (-740011329), 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, 418149471);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 418149471 + "'", int2 == 418149471);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int int1 = org.apache.commons.math.util.FastMath.abs(70);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 70 + "'", int1 == 70);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.cos((-5.235241E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5051074595425715d + "'", double1 == 0.5051074595425715d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1233.0686947337467d), 4.1814947100000334E8d, (double) 1076101120);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1277);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5700132415986612d + "'", double1 == 1.5700132415986612d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.8657694832396585d), (double) 200L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8657694832396585d) + "'", double2 == (-0.8657694832396585d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.MathUtils.pow(42L, 1410065408L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-740011329), 1774819148L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-968798463) + "'", int2 == (-968798463));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, (-1), orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (null > 1)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (null > 1)"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1586880528);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 4242L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 11);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 97);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (-53));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 52, (long) (-1874829662));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1874832766, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963262615157d + "'", double2 == 1.5707963262615157d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Throwable throwable13 = null;
        try {
            nonMonotonousSequenceException10.addSuppressed(throwable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 0, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.774819148E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999460104248876d) + "'", double1 == (-0.9999460104248876d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 52352405);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.032346173484105234d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.032351814277636726d) + "'", double1 == (-0.032351814277636726d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5403081748293445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5169709710148089d + "'", double1 == 0.5169709710148089d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2026446434256L, (double) 25, (double) (-740011329L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        long long2 = org.apache.commons.math.util.MathUtils.pow(418149461L, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7458438569712853321L + "'", long2 == 7458438569712853321L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.rint(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.0d + "'", double1 == 156.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.log((-7.40011329E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-52), 2.9152594835507023E130d, 2.465190328815662E-32d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 0, 11013.0d, (double) 418149471);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 52352405);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52352405L + "'", long1 == 52352405L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5851764690934534d) + "'", double1 == (-0.5851764690934534d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1083384832, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, 87278427280L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 260, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.970291913552122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9702919135521224d + "'", double1 == 3.9702919135521224d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9745543359155d), 1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray9 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 0);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray22 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray29 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray34 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray41);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray41);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray55 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray60 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray55);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray17);
        try {
            double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11023.232874703393d + "'", double10 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.04987562112089d + "'", double13 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 11023.232874703393d + "'", double23 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 418149471 + "'", int25 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 11023.232874703393d + "'", double35 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.04987562112089d + "'", double36 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.04987562112089d + "'", double48 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 418149471 + "'", int51 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 11023.232874703393d + "'", double61 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.04987562112089d + "'", double62 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection16, false);
        int int19 = nonMonotonousSequenceException18.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException18.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection20, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (10 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 418149471 + "'", int12 == 418149471);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int1 = org.apache.commons.math.util.MathUtils.sign(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(32.01562118716425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.010307002767921E13d + "'", double1 == 4.010307002767921E13d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int1 = org.apache.commons.math.util.FastMath.round(1.72869632E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1728696320 + "'", int1 == 1728696320);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(156.3608363030788d, 865.4190924615632d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156.36083630307883d + "'", double2 == 156.36083630307883d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 418149461L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.18149472E8f + "'", float1 == 4.18149472E8f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18866643501183092d + "'", double1 == 0.18866643501183092d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = org.apache.commons.math.util.FastMath.max(1277, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1277 + "'", int2 == 1277);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1482293248);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 11);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 97);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (byte) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 11);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 97);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger30);
        java.lang.Class<?> wildcardClass32 = bigInteger30.getClass();
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger4, (java.lang.Number) bigInteger30, 260);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.41006541E9f, 1.570796326757849d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02143564852533441d + "'", double2 == 0.02143564852533441d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(25, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, (float) 1586880609L);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1586880628L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.max(0.85040391727511d, (double) 1225);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1225.0d + "'", double2 == 1225.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1586880512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8170176069297290577L + "'", long2 == 8170176069297290577L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(11013.232874703393d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3960931264071025E34d + "'", double2 == 1.3960931264071025E34d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1277, (long) 1312);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2589L + "'", long2 == 2589L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5700132415986612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1276.9999999998224d + "'", double1 == 1276.9999999998224d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1874832766, 1586880496);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 25, 385);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5570403450886400999L) + "'", long2 == (-5570403450886400999L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.513382642544002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3811165073255887d + "'", double1 == 2.3811165073255887d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 418149461);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3958199320970215E10d + "'", double1 == 2.3958199320970215E10d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray69 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double[] doubleArray76 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray81 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray76);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray64);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray53);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11013.232965503254d + "'", double48 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 11013.232874703393d + "'", double49 == 11013.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.04987562112089d + "'", double60 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11023.232874703393d + "'", double70 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.04987562112089d + "'", double71 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 418149471 + "'", int72 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 11023.232874703393d + "'", double82 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 10.04987562112089d + "'", double83 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 418149471 + "'", int87 == 418149471);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 10.04987562112089d + "'", double88 == 10.04987562112089d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1068859392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray53);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray41);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.04987562112089d + "'", double60 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 418149471 + "'", int61 == 418149471);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.04987562112089d + "'", double64 == 10.04987562112089d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1410065408);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.066901929622237d + "'", double1 == 21.066901929622237d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 18100281502158275L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9971213268799871d + "'", double1 == 0.9971213268799871d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3043045862358962d + "'", double1 == 1.3043045862358962d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-4.18149472E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.18149472E8d) + "'", double1 == (-4.18149472E8d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1, (-1312));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number1, 100, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 41L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 1080623104);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection53, false);
        int int56 = nonMonotonousSequenceException55.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException55.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection57, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (10 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11013.232965503254d + "'", double48 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 11013.232874703393d + "'", double49 == 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 35 + "'", int56 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double[] doubleArray5 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray15 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0);
        double[] doubleArray22 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray27 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray22);
        double[] doubleArray35 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray40 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray47 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray52 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray47);
        double[] doubleArray59 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray64 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray71 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray76 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray71);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray59);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray47);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray22);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.1814947100000334E8d + "'", double6 == 4.1814947100000334E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11023.232874703393d + "'", double16 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 11023.232874703393d + "'", double28 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.04987562112089d + "'", double29 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 418149471 + "'", int30 == 418149471);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 11023.232874703393d + "'", double41 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.04987562112089d + "'", double42 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 418149471 + "'", int43 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 11023.232874703393d + "'", double53 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.04987562112089d + "'", double54 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 11023.232874703393d + "'", double65 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.04987562112089d + "'", double66 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 418149471 + "'", int67 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 11023.232874703393d + "'", double77 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.04987562112089d + "'", double78 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-783666336) + "'", int83 == (-783666336));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1076101120, (double) 2589L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2591.9064581394196d + "'", double2 == 2591.9064581394196d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10660, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076111780 + "'", int2 == 1076111780);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.sin(114.0342117814617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8057118143807932d + "'", double1 == 0.8057118143807932d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Class<?> wildcardClass14 = nonMonotonousSequenceException10.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1774819148L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2075948061);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.45368378363266d + "'", double1 == 21.45368378363266d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 11);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 11);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 97);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger21);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger21);
        java.lang.Number number25 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number32, 100, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = nonMonotonousSequenceException36.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection37, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number25, (java.lang.Number) 6.040372884E10d, 1079574528, orderDirection37, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.01700498774602796d, (java.lang.Number) bigInteger21, 1728696275, orderDirection37, false);
        java.lang.Number number47 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number47, (-1), orderDirection49, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.01700498774602796d, (java.lang.Number) 0.9999930253396107d, 1874832766, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException53.getDirection();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.sin(43.9087471254124d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07348373000085313d) + "'", double1 == (-0.07348373000085313d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1125));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1903521261) + "'", int1 == (-1903521261));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 52.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 572 + "'", int2 == 572);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1586880512, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.307059979368067E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.307059979368067E43d + "'", double1 == 7.307059979368067E43d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { (-1) };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray10 = new int[] { (-1) };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray13 = new int[] {};
        int[] intArray15 = new int[] { (-1) };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray19 = new int[] { (-1) };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray13);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray13);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11013.232965503254d + "'", double10 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11013.232965503254d + "'", double11 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray19 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray26 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray31 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray26);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        double[] doubleArray36 = null;
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray51 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray56 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray63 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray68 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray51);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray51);
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11023.232874703393d + "'", double20 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.04987562112089d + "'", double21 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 418149471 + "'", int22 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 11023.232874703393d + "'", double32 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.04987562112089d + "'", double33 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 11023.232874703393d + "'", double57 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 10.04987562112089d + "'", double58 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 418149471 + "'", int59 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 11023.232874703393d + "'", double69 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.04987562112089d + "'", double70 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.360618552413709E20d + "'", double1 == 3.360618552413709E20d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549018d + "'", double1 == 1.5574077246549018d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1774819148L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 572, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.acos(51.30685281944005d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1601735553, (long) 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.18866643501183092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19095402223285962d + "'", double1 == 0.19095402223285962d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3104, 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.abs((-3036.676314193363d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3036.676314193363d + "'", double1 == 3036.676314193363d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.225973768125749E86d, 1.3960931264071025E34d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(22161921433L, 2026446434256L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2048608355689L + "'", long2 == 2048608355689L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1083384832, 1277);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.722803597046246E-224d) + "'", double2 == (-8.722803597046246E-224d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.30287248553168283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5503385190332245d + "'", double1 == 0.5503385190332245d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 3.1780538303479458d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 418149471 + "'", int10 == 418149471);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1686639086));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long long2 = org.apache.commons.math.util.MathUtils.pow(39672012800L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray42 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray47 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray42);
        double[] doubleArray50 = null;
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 418149471 + "'", int38 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11023.232874703393d + "'", double48 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1803428.2262614027d + "'", double1 == 1803428.2262614027d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 11);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 97);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 97);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1078591488);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1078591488L + "'", long1 == 1078591488L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int[] intArray5 = new int[] { 1079574528, 41, 418149461, 1, 1080623104 };
        int[] intArray6 = new int[] {};
        int[] intArray8 = new int[] { 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray8);
        int[] intArray11 = new int[] { 260 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray15 = new int[] { 52 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray18 = new int[] {};
        int[] intArray20 = new int[] { (-1) };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] {};
        int[] intArray25 = new int[] { 52 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray25);
        int[] intArray28 = new int[] { 260 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray32 = new int[] { 52 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray30);
        int[] intArray35 = new int[] {};
        int[] intArray37 = new int[] { (-1) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray35);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray35);
        try {
            int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079574528, 385);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574913 + "'", int2 == 1079574913);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1601735553, 1277);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1874832766, (long) 1728696320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray21 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray40);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray54 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray59 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray16);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.04987562112089d + "'", double12 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 11023.232874703393d + "'", double22 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.04987562112089d + "'", double23 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 418149471 + "'", int24 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 418149471 + "'", int50 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 11023.232874703393d + "'", double60 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.04987562112089d + "'", double61 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 418149471 + "'", int64 == 418149471);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-783666336), (-1686639086));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.01700498774602796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2571533034687321d + "'", double1 == 0.2571533034687321d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.9152594835507023E130d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.10686226145001441d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47454214266813266d + "'", double1 == 0.47454214266813266d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 25.0f, (double) 418149471L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9999999958776927d, 26.009615384615387d, 1225);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6622572447554149d, 0.9999999958776927d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1022.4455582031416d), (double) (-3052L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.8183353206860575d) + "'", double2 == (-2.8183353206860575d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.732511156817248d) + "'", double1 == (-3.732511156817248d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-53), 11, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 371080922 + "'", int1 == 371080922);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1586880492, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586880493 + "'", int2 == 1586880493);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double[] doubleArray52 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray57 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray69 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray64);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray52);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray40);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 11023.232874703393d + "'", double58 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 10.04987562112089d + "'", double59 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 418149471 + "'", int60 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11023.232874703393d + "'", double70 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.04987562112089d + "'", double71 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 418149471 + "'", int75 == 418149471);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 10.04987562112089d + "'", double76 == 10.04987562112089d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 371080922);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.73193071538569d + "'", double1 == 19.73193071538569d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        int int14 = nonMonotonousSequenceException10.getIndex();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException10.getSuppressed();
        boolean boolean16 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 10L, (int) (byte) -1, orderDirection21, false);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1);
        try {
            java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (-783666336));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double[] doubleArray5 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray15 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0);
        double[] doubleArray22 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray27 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray22);
        double[] doubleArray35 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray40 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray47 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray52 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray47);
        double[] doubleArray59 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray64 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray71 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray76 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray71);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray59);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray47);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray22);
        java.lang.Number number86 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number86, (java.lang.Number) (byte) 0, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection90 = nonMonotonousSequenceException89.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException92 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1482293248, (java.lang.Number) (-0.7615941559557649d), 52352405, orderDirection90, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection90, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (10 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.1814947100000334E8d + "'", double6 == 4.1814947100000334E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11023.232874703393d + "'", double16 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 11023.232874703393d + "'", double28 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.04987562112089d + "'", double29 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 418149471 + "'", int30 == 418149471);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 11023.232874703393d + "'", double41 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.04987562112089d + "'", double42 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 418149471 + "'", int43 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 11023.232874703393d + "'", double53 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.04987562112089d + "'", double54 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 11023.232874703393d + "'", double65 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.04987562112089d + "'", double66 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 418149471 + "'", int67 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 11023.232874703393d + "'", double77 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.04987562112089d + "'", double78 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + orderDirection90 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection90.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.0d), 10, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1277, 22161921433L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-636815267) + "'", int2 == (-636815267));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101120, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 418149471L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 363474445137507723L, 1728696320, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5860134523134308E15d, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1903521261), 1586880480L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2068315009 + "'", int2 == 2068315009);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 25, (double) (-1068859392));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1586880492);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.586880492E9d + "'", double1 == 1.586880492E9d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.010307002767921E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.010307002767921E13d + "'", double1 == 4.010307002767921E13d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection12, true);
        int int17 = nonMonotonousSequenceException16.getIndex();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        boolean boolean19 = nonMonotonousSequenceException16.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.String str21 = nonMonotonousSequenceException16.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0f + "'", number18.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-418149461), 418149471);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.9155040003582885E22d + "'", number8.equals(1.9155040003582885E22d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.934402560000011E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.844655666188012d) + "'", double1 == (-3.844655666188012d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(22161921433L, (long) 3201);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70940310507033L + "'", long2 == 70940310507033L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(35.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1068859392), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1068859357) + "'", int2 == (-1068859357));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1728696275);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 52352405);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 11);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 97);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 197L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0);
        java.lang.Number number29 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number29, (-1), orderDirection31, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger21, (java.lang.Number) 0.9999930253396107d, (-1), orderDirection31, true);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1079574528, 1586880493);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 'a', (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 52.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.15044407846124d + "'", double2 == 33.15044407846124d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-53L), 0, 1482293248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.017453292519943295d), (-418149461));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.110419089301405E280d) + "'", double2 == (-8.110419089301405E280d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.log1p(11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306943621360421d + "'", double1 == 9.306943621360421d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1586880479L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7696289194174733E7d + "'", double1 == 2.7696289194174733E7d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.3043045862358962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11537902136141441d + "'", double1 == 0.11537902136141441d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.451682154388385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.47454214266813266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-740011329), 41L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-740011288L) + "'", long2 == (-740011288L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 418149471 + "'", int12 == 418149471);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1903521261));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1903521261L + "'", long1 == 1903521261L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 10L, (int) (byte) -1, orderDirection21, false);
        java.lang.Class<?> wildcardClass24 = nonMonotonousSequenceException23.getClass();
        int int25 = nonMonotonousSequenceException23.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 197L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 11);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 97);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 97);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 11);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 97);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 11);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 97);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger41, (java.lang.Number) 10L, (int) (byte) -1, orderDirection45, false);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger41);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number4, 100, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Class<?> wildcardClass13 = number12.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1874829662) + "'", number12.equals((-1874829662)));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { 52 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray17 = new int[] { (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray21 = new int[] { (-1) };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray21);
        int[] intArray24 = new int[] {};
        int[] intArray26 = new int[] { 52 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray26);
        int[] intArray29 = new int[] { 260 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray29);
        int[] intArray31 = new int[] {};
        int[] intArray33 = new int[] { 52 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray31);
        int[] intArray36 = new int[] {};
        int[] intArray38 = new int[] { (-1) };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray42 = new int[] { 52 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray42);
        java.lang.Class<?> wildcardClass44 = intArray42.getClass();
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray42);
        int[] intArray46 = new int[] {};
        int[] intArray48 = new int[] { (-1) };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray48);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray48);
        int[] intArray53 = new int[] {};
        int[] intArray55 = new int[] { 52 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray55);
        int[] intArray58 = new int[] { 260 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int[] intArray60 = new int[] {};
        int[] intArray62 = new int[] { 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray60);
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray60);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray60);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2026446434256L, 518021136L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2025928413120L + "'", long2 == 2025928413120L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(7458438569712853321L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) 0, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-52L), (long) 1728696275);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        long long1 = org.apache.commons.math.util.FastMath.abs(197L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 197L + "'", long1 == 197L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(101, 1076111780);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9337643921132142d + "'", double1 == 0.9337643921132142d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.log(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1083384832);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-968798463), 260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-968798723) + "'", int2 == (-968798723));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(20.085536923187668d, 4.2399525943567024E10d, (double) (-53));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.369491427691418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8011176630413455d + "'", double1 == 2.8011176630413455d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray21 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray40);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray54 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray59 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray54);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray16);
        double[] doubleArray67 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray72 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection84, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.3383347192042695E42d, (int) (byte) 100, orderDirection84, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection84, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (10 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.04987562112089d + "'", double12 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 11023.232874703393d + "'", double22 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.04987562112089d + "'", double23 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 418149471 + "'", int24 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 418149471 + "'", int50 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 11023.232874703393d + "'", double60 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.04987562112089d + "'", double61 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 11023.232874703393d + "'", double73 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.04987562112089d + "'", double74 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 418149471 + "'", int75 == 418149471);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 418149471 + "'", int76 == 418149471);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.42280635864377986d), (java.lang.Number) 35L, 11);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.42280635864377986d) + "'", number4.equals((-0.42280635864377986d)));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.47013969440533454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43831217839887776d + "'", double1 == 0.43831217839887776d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double1 = org.apache.commons.math.util.FastMath.signum(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray39 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray44 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray39);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11013.232965503254d + "'", double10 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11013.232965503254d + "'", double11 == 11013.232965503254d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 418149471 + "'", int35 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 11023.232874703393d + "'", double45 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.04987562112089d + "'", double46 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        float float1 = org.apache.commons.math.util.FastMath.abs(25.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 25.0f + "'", float1 == 25.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2026394081851L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.030426195665967d + "'", double1 == 29.030426195665967d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-636815267), 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.932685995991968E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.966286166868763E-4d + "'", double1 == 9.966286166868763E-4d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.932651525264262d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.6978750232160897d) + "'", double1 == (-2.6978750232160897d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1125), (-740011329));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 740010204 + "'", int2 == 740010204);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.3958199320970215E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.557398363943554E133d, 4.0d, 1225);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.221255477432834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray16 = new int[] { 52 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray16);
        java.lang.Class<?> wildcardClass18 = intArray16.getClass();
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray16);
        int[] intArray20 = new int[] {};
        int[] intArray22 = new int[] { 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray22);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-636815267));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 636815267 + "'", int2 == 636815267);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double2 = org.apache.commons.math.util.FastMath.max(9.177268708295299E10d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.177268708295299E10d + "'", double2 == 9.177268708295299E10d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-9.007199254740992E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-54L), (float) 1079574913);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957491E9f + "'", float2 == 1.07957491E9f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 35, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection21, true);
        int int26 = nonMonotonousSequenceException25.getIndex();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Number number29 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 100.0f + "'", number27.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1L + "'", number29.equals(1L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1225L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.38028333693054d + "'", double1 == 21.38028333693054d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 11);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 97);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) bigInteger23, 1586880496);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0L + "'", number26.equals(0L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1068854251L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1068854251L + "'", long2 == 1068854251L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int2 = org.apache.commons.math.util.FastMath.max(1078591488, 1225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591488 + "'", int2 == 1078591488);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-7.40011329E8d), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1728696275);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.43831217839887776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47013969440533454d + "'", double1 == 0.47013969440533454d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2025928413120L, (float) (-35));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-35.0f) + "'", float2 == (-35.0f));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1068859357));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100L, 1.5440680443502757d, (-0.42280635864377986d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 54.0001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-52));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2048608355689L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267944085d + "'", double1 == 1.5707963267944085d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2068315009);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3043045862358962d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray69 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double[] doubleArray76 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray81 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray76);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray64);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray53);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 87278427280L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection89 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection89, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11013.232965503254d + "'", double48 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 11013.232874703393d + "'", double49 == 11013.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.04987562112089d + "'", double60 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11023.232874703393d + "'", double70 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.04987562112089d + "'", double71 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 418149471 + "'", int72 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 11023.232874703393d + "'", double82 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 10.04987562112089d + "'", double83 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.560895660206908d, (double) (-1903521261));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592652769789d + "'", double2 == 3.141592652769789d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 197L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection25, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.3383347192042695E42d, (int) (byte) 100, orderDirection25, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 6.040372884E10d, 1079574913, orderDirection25, true);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1482293248);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 11);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 97);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 11);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 97);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 97);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 197L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger34);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 11);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 97);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) 97);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger50);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5865385864322486117L, 1.4844415983612418d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 5955749153707236033L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9557491537072364E18d + "'", double1 == 5.9557491537072364E18d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.032346173484105234d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.032346173484105234d) + "'", double2 == (-0.032346173484105234d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        long long2 = org.apache.commons.math.util.FastMath.min(2026446434256L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1586880492);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1586880492L + "'", long1 == 1586880492L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.42280635864377986d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4511043493462384d) + "'", double1 == (-0.4511043493462384d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        boolean boolean13 = nonMonotonousSequenceException10.getStrict();
        int int14 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.017453292519943295d), (double) 1586880609L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1874829662), 1076111780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 11);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 97);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (byte) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 11);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 97);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (byte) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 11);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 97);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger40, (java.lang.Number) 10L, (int) (byte) -1, orderDirection44, false);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger47);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1482293248);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray52 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray57 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray52);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray66 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray71 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 0);
        double[] doubleArray78 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray83 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray78);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray66);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 418149471 + "'", int48 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 11023.232874703393d + "'", double58 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 10.04987562112089d + "'", double59 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.04987562112089d + "'", double62 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 11023.232874703393d + "'", double72 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 11023.232874703393d + "'", double84 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10.04987562112089d + "'", double85 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 418149471 + "'", int86 == 418149471);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray9 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray21 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray28);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray28);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray42 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray47 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray47);
        double[] doubleArray54 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray59 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray65 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray70 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray77 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray82 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray77);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray65);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray54);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 87278427280L);
        try {
            double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11023.232874703393d + "'", double10 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.04987562112089d + "'", double11 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 418149471 + "'", int12 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 11023.232874703393d + "'", double22 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.04987562112089d + "'", double23 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 418149471 + "'", int24 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 418149471 + "'", int38 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11023.232874703393d + "'", double48 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 11013.232965503254d + "'", double49 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 11013.232874703393d + "'", double50 == 11013.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 11023.232874703393d + "'", double60 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.04987562112089d + "'", double61 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 11023.232874703393d + "'", double71 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 10.04987562112089d + "'", double72 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 418149471 + "'", int73 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 11023.232874703393d + "'", double83 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 10.04987562112089d + "'", double84 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 22161921433L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148868.80611128712d + "'", double1 == 148868.80611128712d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0.0f, (double) 572, 3201);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.00000000000001d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1068859357));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 197L, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.221255477432834d + "'", double2 == 2.221255477432834d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray17 = new int[] { (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray17);
        int[] intArray20 = new int[] {};
        int[] intArray22 = new int[] { (-1) };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int[] intArray24 = new int[] {};
        int[] intArray26 = new int[] { (-1) };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray26);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 53.0d + "'", double29 == 53.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 4, 572);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double2 = org.apache.commons.math.util.FastMath.max((-1233.0686947337467d), 1.5707963262615157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963262615157d + "'", double2 == 1.5707963262615157d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.849181275689226d, 100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.849181275689228d + "'", double2 == 10.849181275689228d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1225);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double1 = org.apache.commons.math.util.FastMath.log(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7776740307447068d + "'", double1 == 1.7776740307447068d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1312), (-1903521261));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1312), (-740011329L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970894863648L + "'", long2 == 970894863648L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1586880628L, 6.719517620178169d, 41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.19095402223285962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 53);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.206879716514544E22d + "'", double1 == 5.206879716514544E22d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1586880628L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-740011288L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-1874829662));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5211141550652623d + "'", double1 == 1.5211141550652623d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) -1, 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.3383347192042695E42d, (int) (byte) 100, orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403081748293445d, (java.lang.Number) 0.8813735870195429d, 3201, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { 52 };
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        java.lang.Class<?> wildcardClass4 = intArray2.getClass();
        int[] intArray5 = new int[] {};
        int[] intArray7 = new int[] { (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray7);
        try {
            int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 41, 1083384832, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-5.2352408E7f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3628799.9999999995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.797559753635479d + "'", double1 == 15.797559753635479d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.574710978503383d, (-2.8183353206860575d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.574710978503382d + "'", double2 == 4.574710978503382d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.465190328815662E-32d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 962592768 + "'", int1 == 962592768);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179586d, number1, 20);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.FastMath.log10(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1941279846103057d + "'", double1 == 2.1941279846103057d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 52352405L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.235240475810455E7d + "'", double2 == 5.235240475810455E7d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1410065408);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double[] doubleArray5 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray15 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.1814947100000334E8d + "'", double6 == 4.1814947100000334E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11023.232874703393d + "'", double16 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.MathUtils.sign(196.7459471368471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-968798463));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.68798463E8d + "'", double1 == 9.68798463E8d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(197L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(31.999999999999996d, 0.01700498774602796d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number4, 100, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number14 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int19 = nonMonotonousSequenceException18.getIndex();
        boolean boolean20 = nonMonotonousSequenceException18.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException18.getDirection();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number22, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number27 = nonMonotonousSequenceException25.getArgument();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.String str29 = nonMonotonousSequenceException18.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection36, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection36, true);
        int int41 = nonMonotonousSequenceException40.getIndex();
        java.lang.Number number42 = nonMonotonousSequenceException40.getPrevious();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 904.5087854507779d + "'", number14.equals(904.5087854507779d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 0 + "'", number26.equals((byte) 0));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 100.0f + "'", number42.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number4, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-418149461), (java.lang.Number) 1.5620272534437418d, 1079574913, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray15);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-2147453857) + "'", int25 == (-2147453857));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.8284379027293976E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1912261570887804E8d + "'", double1 == 3.1912261570887804E8d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1774215933195176d + "'", double1 == 1.1774215933195176d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.023702952323608E17d + "'", double1 == 1.023702952323608E17d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.433780830483027d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4337808304830268d) + "'", double1 == (-1.4337808304830268d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(51.30685281944005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.30685281944006d + "'", double1 == 51.30685281944006d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1728696275);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1686639086), 39672012800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1686639086L) + "'", long2 == (-1686639086L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double2 = org.apache.commons.math.util.FastMath.min(9.332621544395286E157d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0f, (java.lang.Number) 8.065817517094494E67d, (int) (short) 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 97.0f + "'", number4.equals(97.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.065817517094494E67d + "'", number5.equals(8.065817517094494E67d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 10, 1728696320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1728696330 + "'", int2 == 1728696330);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.103676392483125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.036716079445307026d + "'", double1 == 0.036716079445307026d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        long long1 = org.apache.commons.math.util.FastMath.abs(4242L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4242L + "'", long1 == 4242L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number14 = nonMonotonousSequenceException3.getPrevious();
        int int15 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1482293248, (-968798463));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 513494785 + "'", int2 == 513494785);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 20, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.999999999999996d + "'", double2 == 19.999999999999996d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 39672012800L, 0, (-1903521261));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.6338028948879854E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6338028948879858E-5d + "'", double1 == 2.6338028948879858E-5d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-5141L), 1.570796326757849d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3544187270981638d) + "'", double2 == (-1.3544187270981638d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number4, 100, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        java.lang.Class<?> wildcardClass13 = orderDirection12.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(97L, (long) 371080922);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-371080825L) + "'", long2 == (-371080825L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.451682154388385d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-931014010) + "'", int1 == (-931014010));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.09831473751172E90d, (java.lang.Number) 1.41006541E9f, 1076101120);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3628800.0d, (double) 8170176069297290577L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4415199491681335E-13d + "'", double2 == 4.4415199491681335E-13d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(418149471, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 418149471 + "'", int2 == 418149471);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double2 = org.apache.commons.math.util.FastMath.pow(865.4190924615632d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 865.4190924615632d + "'", double2 == 865.4190924615632d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray17 = new int[] { (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray17);
        int[] intArray20 = null;
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(572, 1079574913);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1079574341) + "'", int2 == (-1079574341));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1874829662), (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.rint(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.3383347192042695E42d, (int) (byte) 100, orderDirection9, true);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.9152594835507023E130d, (java.lang.Number) 200.0d, (-418149461), orderDirection15, true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0f + "'", number14.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1586880493);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1079574528, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0578860226449684d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 1.41006541E9f, 1312);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}

