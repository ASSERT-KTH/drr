import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '4', (double) 52352405);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.932685995988703E-7d + "'", double2 == 9.932685995988703E-7d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(41, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long1 = org.apache.commons.math.util.MathUtils.sign(55540818480L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        float float2 = org.apache.commons.math.util.FastMath.max(97.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 97, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) Float.NaN, 8.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-52L), (-52352406L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 904.5087854507779d, 101);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(97.0d, 1079574528);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.acosh(904.5087854507779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.500538892822111d + "'", double1 == 7.500538892822111d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1277L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.513382642544002d + "'", double2 == 1.513382642544002d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 418149471L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1586880496, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963261647295d + "'", double2 == 1.5707963261647295d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 53);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-52), (long) (-740011329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5620272534437416d, (double) 1482293248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5620272534437418d + "'", double2 == 1.5620272534437418d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 53, (float) (-418149461));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.18149472E8f) + "'", float2 == (-4.18149472E8f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1601735553 + "'", int2 == 1601735553);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 0);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray53);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray41);
        double[] doubleArray69 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.04987562112089d + "'", double60 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 418149471 + "'", int61 == 418149471);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 4.1814947100000334E8d + "'", double70 == 4.1814947100000334E8d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long1 = org.apache.commons.math.util.MathUtils.sign(740011329L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.apache.commons.math.util.FastMath.abs(1021313024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1021313024 + "'", int1 == 1021313024);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 20 + "'", number7.equals(20));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (19,155,040,003,582,885,000,000 > 20)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (19,155,040,003,582,885,000,000 > 20)"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 25);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 25.0f + "'", float1 == 25.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 101);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (-418149461));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.451682154388385d, (-1.433780830483027d), 1312);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 8.0d, 1.7763568394002505E-15d, 11013.232874703393d, 39835.66858984546d };
        try {
            double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) ' ', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long1 = org.apache.commons.math.util.FastMath.round(3.3431851641374776E20d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.math.util.FastMath.min((-1874829662), 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1874829662) + "'", int2 == (-1874829662));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-53), 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1312);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 101L, (double) (-740011329L), (double) 1774819148);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.9E-324d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 101);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 101L + "'", long1 == 101L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1312, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1365L + "'", long2 == 1365L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1410065408, 1312);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 418149471 + "'", int12 == 418149471);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.9E-324d, (double) 25, 41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1586880512, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5865385864322486117L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-52L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (byte) -1, 53);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.007199254740992E15d) + "'", double2 == (-9.007199254740992E15d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 97.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.apache.commons.math.util.FastMath.abs(418149471);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 418149471 + "'", int1 == 418149471);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.FastMath.max((-52), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1586880496, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586880496 + "'", int2 == 1586880496);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 52, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int1 = org.apache.commons.math.util.MathUtils.sign(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(20, 101);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray2 = new double[] { 740011329L, (-2.5663706143591725d) };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (740,011,329 >= -2.566)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 385, (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.signum(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 4, (long) 1586880528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586880528L + "'", long2 == 1586880528L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1225);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(52L, (long) 3104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3052L) + "'", long2 == (-3052L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1225, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 2.225073858507202E-308d, (-418149461));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int1 = org.apache.commons.math.util.FastMath.abs((-35));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(260, 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10660 + "'", int2 == 10660);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7525988353206895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9364625436429511d + "'", double1 == 0.9364625436429511d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(11, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2915634193108996E7d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1586880480L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.154434690031884d, 156.3608363030788d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-2.5663706143591725d), 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1874829662), 2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.874829662E9d) + "'", double2 == (-1.874829662E9d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1586880528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.878183174553307d + "'", double1 == 21.878183174553307d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 177846.09960860753d + "'", double1 == 177846.09960860753d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 101);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.032346173484105234d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9681713688056214d + "'", double1 == 0.9681713688056214d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-3036.676314193363d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1586880492, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586880492 + "'", int2 == 1586880492);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(114.0342117814617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6726263306581964E49d + "'", double1 == 1.6726263306581964E49d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(260);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.002463008781085618d + "'", double1 == 0.002463008781085618d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-35), (long) 1410065408);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1410065408L + "'", long2 == 1410065408L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(100L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.932685995988703E-7d, 10.849181275689226d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 11013.232965503254d + "'", double35 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1586880480L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1586880496, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 196.7459471368471d + "'", double2 == 196.7459471368471d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.148283155648077d + "'", double1 == 2.148283155648077d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8813735870195429d, 1.2915634193108996E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1586880528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1586880496, (java.lang.Number) 385, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1586880496 + "'", number5.equals(1586880496));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1482293248);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.9155040003582885E22d + "'", number7.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1874829662));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.acos(11023.232874703393d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 418149471L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double[] doubleArray52 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray57 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray69 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray64);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray52);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray40);
        double[] doubleArray78 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray83 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray78);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 11023.232874703393d + "'", double58 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 10.04987562112089d + "'", double59 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 418149471 + "'", int60 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11023.232874703393d + "'", double70 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.04987562112089d + "'", double71 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 11023.232874703393d + "'", double84 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10.04987562112089d + "'", double85 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 418149471 + "'", int86 == 418149471);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.1814947100000334E8d, (double) 1586880528);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 10L, (int) (byte) -1, orderDirection21, false);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException23.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException23.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(number25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-3036.676314193363d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-173988.73655062242d) + "'", double1 == (-173988.73655062242d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.2399525943567024E10d, 1.5707963261647295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326757849d + "'", double2 == 1.570796326757849d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.asinh(31.999999999999996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 25.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25600.0d + "'", double2 == 25600.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11741660338413339d) + "'", double1 == (-0.11741660338413339d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-53L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1068859392) + "'", int1 == (-1068859392));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(51.84967536015833d, (double) 1, (double) 1225);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5620272534437418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02726251857847723d + "'", double1 == 0.02726251857847723d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10686226145001441d + "'", double1 == 0.10686226145001441d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 41);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 41L + "'", long1 == 41L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5515679276951895d) + "'", double1 == (-1.5515679276951895d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(4, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, (float) 1410065408L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.41006541E9f + "'", float2 == 1.41006541E9f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1601735553);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9745543359155d) + "'", double1 == (-0.9745543359155d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.307059979368067E43d + "'", double1 == 7.307059979368067E43d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.225973768125749E86d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 86.85889638065036d + "'", double1 == 86.85889638065036d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        java.lang.Number number11 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number11, 100, orderDirection13, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection16, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (11,013.233 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.144346427974586d) + "'", double1 == (-8.144346427974586d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1728696275 + "'", int1 == 1728696275);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray19 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray26 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray31 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray26);
        double[] doubleArray38 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray43 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray50 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray55 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray50);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray38);
        double[] doubleArray63 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray68 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray63);
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11013.232965503254d + "'", double10 == 11013.232965503254d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11023.232874703393d + "'", double20 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.04987562112089d + "'", double21 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 418149471 + "'", int22 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 11023.232874703393d + "'", double32 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.04987562112089d + "'", double33 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 11023.232874703393d + "'", double44 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.04987562112089d + "'", double45 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 418149471 + "'", int46 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 11023.232874703393d + "'", double56 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.04987562112089d + "'", double57 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 11023.232874703393d + "'", double69 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.04987562112089d + "'", double70 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 418149471 + "'", int71 == 418149471);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        java.lang.Number number15 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number15, 100, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection20, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException22.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection23, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (11,013.233 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 11013.232965503254d + "'", double10 == 11013.232965503254d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.acos((-8.144346427974586d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 51.84967536015833d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(20, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8675245445061999d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8675245445061999d + "'", double2 == 0.8675245445061999d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1728696275, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(5L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        float float3 = org.apache.commons.math.util.MathUtils.round((-4.18149472E8f), 1079574528, 4);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.141592653589793d, (double) 101L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1586880496, (float) 1277L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1277.0f + "'", float2 == 1277.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0E-10f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000001d + "'", double1 == 1.0000000001d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 10L, (int) (byte) -1, orderDirection21, false);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException23.getSuppressed();
        boolean boolean25 = nonMonotonousSequenceException23.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5, Double.POSITIVE_INFINITY, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.asin(51.84967536015833d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1), 0, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 20 + "'", number7.equals(20));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 20 + "'", number9.equals(20));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.2399525943567024E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.185506412422791E10d + "'", double1 == 6.185506412422791E10d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4844415983612418d + "'", double1 == 1.4844415983612418d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable throwable8 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 20 + "'", number7.equals(20));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int1 = org.apache.commons.math.util.FastMath.abs((-418149461));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 418149461 + "'", int1 == 418149461);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38535742648327137d + "'", double1 == 0.38535742648327137d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.9152594835507023E130d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 300.40602092172213d + "'", double1 == 300.40602092172213d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, (float) (-52L));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 385, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.09831473751172E90d + "'", double2 == 3.09831473751172E90d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.560895660206908d + "'", double1 == 1.560895660206908d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, 1277);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-52L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double[] doubleArray5 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray15 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 0);
        double[] doubleArray22 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray27 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray22);
        double[] doubleArray35 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray40 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray47 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray52 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray47);
        double[] doubleArray59 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray64 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray71 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray76 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray71);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray59);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray47);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray22);
        double[] doubleArray88 = new double[] { 1, 4.61512051684126d, 418149471L, (byte) 10, '4' };
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.1814947100000334E8d + "'", double6 == 4.1814947100000334E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11023.232874703393d + "'", double16 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 11023.232874703393d + "'", double28 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.04987562112089d + "'", double29 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 418149471 + "'", int30 == 418149471);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 11023.232874703393d + "'", double41 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.04987562112089d + "'", double42 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 418149471 + "'", int43 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 11023.232874703393d + "'", double53 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.04987562112089d + "'", double54 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 11023.232874703393d + "'", double65 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.04987562112089d + "'", double66 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 418149471 + "'", int67 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 11023.232874703393d + "'", double77 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.04987562112089d + "'", double78 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 4.1814947100000334E8d + "'", double89 == 4.1814947100000334E8d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1586880528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6055518643146514d) + "'", double1 == (-0.6055518643146514d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-53.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-53.0d) + "'", double1 == (-53.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.0000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1079574528, 418149461);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.2352405E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(3104, (-1874829662));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1874832766 + "'", int2 == 1874832766);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) ' ', 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 418149461, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 418149461L + "'", long2 == 418149461L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(41L, 1586880479L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 65062099639L + "'", long2 == 65062099639L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(97L, (long) 1586880512);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586880609L + "'", long2 == 1586880609L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(52352405, (-1068859392));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.0E-10f, (double) 1277.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1275.486617357556d + "'", double2 == 1275.486617357556d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 11);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 97);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100L, 6.185506412422791E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000001d + "'", double2 == 100.00000000000001d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11023.232874703393d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.38535742648327137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47013969440533454d + "'", double1 == 0.47013969440533454d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray28);
        double[] doubleArray39 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray44 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray51 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray56 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray63 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray68 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray63);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray77 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray82 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray77);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 11023.232874703393d + "'", double45 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.04987562112089d + "'", double46 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 418149471 + "'", int47 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 11023.232874703393d + "'", double57 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 10.04987562112089d + "'", double58 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 418149471 + "'", int59 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 11023.232874703393d + "'", double69 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.04987562112089d + "'", double70 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 418149471 + "'", int73 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 11023.232874703393d + "'", double83 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 10.04987562112089d + "'", double84 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        long long1 = org.apache.commons.math.util.FastMath.round((-53.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-53L) + "'", long1 == (-53L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.995732273553991d + "'", double1 == 2.995732273553991d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-740011329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.232874703393d, 196.7459471368471d, 0.7525988353206895d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 740011329L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number1, 100, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1.8748297E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5208379310729538d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.433780830483027d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 0);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray53);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 3.1780538303479458d);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray65);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (3.531 >= -0.353)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.04987562112089d + "'", double49 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.04987562112089d + "'", double62 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 6.501092764207148d + "'", double66 == 6.501092764207148d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.09831473751172E90d, (double) 55540818480L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.abs(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35, (java.lang.Number) 0L, (int) (byte) 100);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1275.486617357556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1L, (-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.04456466488635104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2111034459367043d + "'", double1 == 0.2111034459367043d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(100, 1225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1125) + "'", int2 == (-1125));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 4.61512051684126d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, 1874832766);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.11741660338413339d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11796070555080158d) + "'", double1 == (-0.11796070555080158d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 11);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 10L, (int) (byte) -1, orderDirection21, false);
        java.lang.Class<?> wildcardClass24 = nonMonotonousSequenceException23.getClass();
        java.lang.Number number25 = nonMonotonousSequenceException23.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(number25);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.log(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1851160204964712d + "'", double1 == 1.1851160204964712d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long2 = org.apache.commons.math.util.MathUtils.pow(101L, 1312);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7519339041840240513L + "'", long2 == 7519339041840240513L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1.8748297E9f), 2.995732273553991d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 3.1780538303479458d);
        double[] doubleArray44 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray49 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray56 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray61 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray56);
        double[] doubleArray68 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray73 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray80 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray85 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray80, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray80);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray68);
        double[] doubleArray90 = null;
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 11023.232874703393d + "'", double50 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.04987562112089d + "'", double51 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 418149471 + "'", int52 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 11023.232874703393d + "'", double62 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 10.04987562112089d + "'", double63 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 11023.232874703393d + "'", double74 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10.04987562112089d + "'", double75 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 418149471 + "'", int76 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 11023.232874703393d + "'", double86 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10.04987562112089d + "'", double87 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 6.501092764207148d + "'", double92 == 6.501092764207148d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(Double.NEGATIVE_INFINITY, 3.09831473751172E90d, 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1410065408, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1410065408L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1410065408 + "'", int1 == 1410065408);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.097808644425026E117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.932651525264262d) + "'", double1 == (-0.932651525264262d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(53, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 7.500538892822111d, (int) (byte) -1, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.307059979368067E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1225L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100L, (double) (-53.0f), (double) 20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-52352406L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.235241E7d) + "'", double2 == (-5.235241E7d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1774819148);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1774819148L + "'", long1 == 1774819148L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { (-1) };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray10 = new int[] { (-1) };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        try {
            int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1874832766);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (long) (-1874829662));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1586880492);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.878183151867287d + "'", double1 == 21.878183151867287d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-5141L), (long) (-1068859392));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1068854251L + "'", long2 == 1068854251L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray3 = new int[] { 52 };
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray6 = new int[] { 260 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray10 = new int[] { 52 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray8);
        int[] intArray13 = new int[] {};
        int[] intArray15 = new int[] { (-1) };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray13);
        try {
            int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(10, 418149461);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893702d) + "'", double1 == (-0.5440211108893702d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1068859392));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1022.4455582031416d) + "'", double1 == (-1022.4455582031416d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 740011329L, 0.9999930253396107d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.FastMath.min(904.5087854507779d, 4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.15912713462618d + "'", double2 == 4.15912713462618d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-53L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { (-1) };
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray6 = new int[] { 52 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
        java.lang.Class<?> wildcardClass8 = intArray6.getClass();
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray12 = new int[] { (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray17 = new int[] { 52 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray17);
        int[] intArray20 = new int[] { 260 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray24 = new int[] { 52 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        try {
            int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 20 + "'", number7.equals(20));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 385);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 385.0d + "'", double1 == 385.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 418149471 + "'", int24 == 418149471);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1586880528);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1586880528L + "'", long1 == 1586880528L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1068854251L, 3.141592653589793d, 0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11576.453488438818d + "'", double1 == 11576.453488438818d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 385);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 385.0d + "'", double1 == 385.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.307059979368067E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math.util.FastMath.min(3.141592653589793d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.util.FastMath.max(3.0d, 1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8657694832396585d) + "'", double1 == (-0.8657694832396585d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 1586880496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-1068859392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(200.0d, 4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.221255477432834d + "'", double2 == 5.221255477432834d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 11, (long) 1586880528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5955749153707236033L + "'", long2 == 5955749153707236033L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1586880528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 385);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.719517620178169d + "'", double1 == 6.719517620178169d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.3431851641374776E20d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.3431851641374776E20d + "'", double2 == 3.3431851641374776E20d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 51.30685281944005d, (java.lang.Number) 41L, (-1068859392));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.01562118716425d + "'", double1 == 32.01562118716425d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.040372884E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.040372884E10d + "'", double1 == 6.040372884E10d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int2 = org.apache.commons.math.util.FastMath.max(101, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.30287248553168283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6715627629292594d + "'", double1 == 0.6715627629292594d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5620272534437416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7615941559557649d), 8958.81600130236d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8958.81600130236d + "'", double2 == 8958.81600130236d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(15.104412573075516d, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1601735553);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 41);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 41L + "'", long1 == 41L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1874829662), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long2 = org.apache.commons.math.util.MathUtils.pow(42L, 260);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1586880528);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double2 = org.apache.commons.math.util.FastMath.max(0.6094891150149768d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) '#', Double.POSITIVE_INFINITY, 4.2399525943E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1125), 418149461);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1410065408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 'a', 6.283185307179586d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.atanh(904.5087854507779d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 10, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1586880528);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1586880528L + "'", long1 == 1586880528L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 418149461, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 418149461L + "'", long2 == 418149461L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 35L, 101);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-740011329L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int1 = org.apache.commons.math.util.FastMath.abs(41);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 41 + "'", int1 == 41);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1079574528, (int) (short) 100, 53);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(740011329L, (-1874829662));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1365L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1365L + "'", long2 == 1365L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(385.0d, 5.916079783099616d, 1225.0000000000002d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 52352405, (long) 1728696275);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18100281502158275L + "'", long2 == 18100281502158275L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.42280635864377986d) + "'", double1 == (-0.42280635864377986d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2026446434256L, (long) 52352405);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2026394081851L + "'", long2 == 2026394081851L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.47013969440533454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47013969440533454d + "'", double1 == 0.47013969440533454d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 25.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1277L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.ceil(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.0d + "'", double1 == 200.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double[] doubleArray52 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray57 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray69 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray64);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray52);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray40);
        double[] doubleArray78 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray83 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray78);
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 11023.232874703393d + "'", double58 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 10.04987562112089d + "'", double59 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 418149471 + "'", int60 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 11023.232874703393d + "'", double70 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.04987562112089d + "'", double71 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 11023.232874703393d + "'", double84 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 10.04987562112089d + "'", double85 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 418149471 + "'", int86 == 418149471);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 418149471 + "'", int88 == 418149471);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 2026394081851L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 5L, (double) (-1068859392));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 197L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        long long1 = org.apache.commons.math.util.FastMath.abs(55540818480L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 55540818480L + "'", long1 == 55540818480L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2026394081851L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5367248671227425E10d + "'", double1 == 3.5367248671227425E10d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.04456466488635104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5262168977363613d + "'", double1 == 1.5262168977363613d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NEGATIVE_INFINITY, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5955749153707236033L, (double) 97.0f, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number1, 100, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 4.9E-324d + "'", number8.equals(4.9E-324d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.1411200080598672d, (double) 0L, 3.1780538303479458d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1586880480L, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.0d), (double) (-740011329L), (double) 25.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int1 = org.apache.commons.math.util.FastMath.abs(101);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 101 + "'", int1 == 101);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double2 = org.apache.commons.math.util.FastMath.atan2(11013.232874703393d, 4.18149471E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6338028948879854E-5d + "'", double2 == 2.6338028948879854E-5d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5540437953657898d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.85040391727511d + "'", double1 == 0.85040391727511d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) 0, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray3 = new int[] { 52 };
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray6 = new int[] { 260 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray10 = new int[] { 52 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray8);
        try {
            int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.0d), 0.7525988353206895d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7525988353206895d + "'", double2 == 0.7525988353206895d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.874829662E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1233.0686947337467d) + "'", double1 == (-1233.0686947337467d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1225, (long) (-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1), 25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-5141L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5141.0f) + "'", float2 == (-5141.0f));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number1, 100, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 4.9E-324d + "'", number8.equals(4.9E-324d));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.7525988353206895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 1312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1312) + "'", int2 == (-1312));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(110L, (long) 1586880496);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 87278427280L + "'", long2 == 87278427280L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int[] intArray0 = new int[] {};
        int[] intArray2 = new int[] { 52 };
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray5 = new int[] { 260 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray9 = new int[] { 52 };
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
        int[] intArray12 = new int[] {};
        int[] intArray14 = new int[] { (-1) };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray12);
        int[] intArray17 = null;
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(177846.09960860753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 177846.09960860756d + "'", double1 == 177846.09960860756d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1586880479L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.8657694832396585d), 5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.916079783099616d + "'", double2 == 5.916079783099616d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1125));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1125.0f + "'", float1 == 1125.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-3052L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1068854251L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-35), (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-35.0d) + "'", double2 == (-35.0d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 1774819148L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1774819148L + "'", long2 == 1774819148L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1586880528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963261647295d + "'", double1 == 1.5707963261647295d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.560895660206908d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5608956602069082d + "'", double1 == 1.5608956602069082d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(25.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 52352405);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1410065408L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-52), (double) 25.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.944811378381908E42d) + "'", double2 == (-7.944811378381908E42d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1312, (double) 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.0d, (java.lang.Number) 1.5607966601082315d, (int) (byte) 1, orderDirection3, true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-52L), 2026446434256L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1312), (-740011329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 418149461, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 451423506992529408L + "'", long2 == 451423506992529408L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1728696275, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 363474445137507723L + "'", long2 == 363474445137507723L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.cos(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.773121177104694d + "'", double1 == 0.773121177104694d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int1 = org.apache.commons.math.util.MathUtils.hash(200.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1080623104 + "'", int1 == 1080623104);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1774819148L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.774819148E9d + "'", double1 == 1.774819148E9d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1586880528, (-53));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7617912995149254E-7d + "'", double2 == 1.7617912995149254E-7d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.492980025466053d + "'", double1 == 21.492980025466053d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1022.4455582031416d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray42 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray47 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray42);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 1586880609L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 418149471 + "'", int38 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 11023.232874703393d + "'", double48 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 101L, 52, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number1, 100, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(42L, (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4242L + "'", long2 == 4242L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1125.0f, 0.2111034459367043d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.586880492E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9999930253396107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403081748293445d + "'", double1 == 0.5403081748293445d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-53L), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-53.0f) + "'", float2 == (-53.0f));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-740011329), 1586880496);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1874832766, 52L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.3431851641374776E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8284379027293976E10d + "'", double1 == 1.8284379027293976E10d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.3383347192042695E42d, (int) (byte) 100, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        boolean boolean13 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0f + "'", number11.equals(0.0f));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1586880512, (float) (-53L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-53.0f) + "'", float2 == (-53.0f));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.04456466488635104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1L, (int) 'a');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection21, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (int) (byte) 1, orderDirection21, true);
        int int26 = nonMonotonousSequenceException25.getIndex();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 100.0f + "'", number27.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(8.881784197001252E-16d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.881784197001252E-16d + "'", double2 == 8.881784197001252E-16d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.11796070555080158d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.103676392483125d + "'", double1 == 2.103676392483125d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.874829662E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1068859392));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(65062099639L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 418149461, (long) (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22161921433L + "'", long2 == 22161921433L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(97.0d, (double) 101L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9999930253396107d, 2.688117141816135E43d, 7.307059979368067E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(196.7459471368471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9681713688056214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.47213327796599d + "'", double1 == 55.47213327796599d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) -1, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-54L) + "'", long2 == (-54L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1), (double) 1774819148);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1482293248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        long long2 = org.apache.commons.math.util.FastMath.max(52L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-54L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 54.0f + "'", float1 == 54.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 25, (long) 1586880512);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39672012800L + "'", long2 == 39672012800L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray53 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray58 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 0);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray53);
        double[] doubleArray67 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray72 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray67);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 156.3608363030788d);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.04987562112089d + "'", double49 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 11023.232874703393d + "'", double59 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.04987562112089d + "'", double62 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 11023.232874703393d + "'", double73 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 418149471 + "'", int74 == 418149471);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray21 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray45 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray40);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray16);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.04987562112089d + "'", double12 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 11023.232874703393d + "'", double22 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.04987562112089d + "'", double23 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 418149471 + "'", int24 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.04987562112089d + "'", double35 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 418149471 + "'", int36 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 11023.232874703393d + "'", double46 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.04987562112089d + "'", double47 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 418149471 + "'", int50 == 418149471);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-5141L), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5513473108690699d) + "'", double2 == (-1.5513473108690699d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1277);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.11796070555080158d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1312);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double2 = org.apache.commons.math.util.FastMath.max((double) ' ', 86.85889638065036d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 86.85889638065036d + "'", double2 == 86.85889638065036d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1586880528, (long) (-1068859392));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 518021136L + "'", long2 == 518021136L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.017453292519943295d), (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, (-418149461));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5, (-52L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.01700498774602796d, 385);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.002463008781085618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0024630087810856185d + "'", double1 == 0.0024630087810856185d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.932685995988703E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.932685995991968E-7d + "'", double1 == 9.932685995991968E-7d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(11, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.18149471E8d, (double) 518021136L, 1.5208379310729538d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 518021136L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.479114265678535d + "'", double1 == 0.479114265678535d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(52352405, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.atan(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray33 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 0);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray28);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 3.1780538303479458d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (3.531 >= -0.353)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.04987562112089d + "'", double24 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 11023.232874703393d + "'", double34 == 11023.232874703393d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.04987562112089d + "'", double37 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 20 + "'", number7.equals(20));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.9155040003582885E22d + "'", number9.equals(1.9155040003582885E22d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(10660);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-54L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-33.96421184743732d) + "'", double1 == (-33.96421184743732d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6622572447554149d + "'", double1 == 0.6622572447554149d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 20, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.8813735870195429d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 97);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 11);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 97);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 11);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 97);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger28, (java.lang.Number) 10L, (int) (byte) -1, orderDirection32, false);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger28);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 10660);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999997749296758d + "'", double1 == 0.9999997749296758d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) (byte) 0, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 10, 0.0d, 0.01700498774602796d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3104, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3201 + "'", int2 == 3201);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 11);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 97);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 97);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 97);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 11);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 97);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger29, (java.lang.Number) 10L, (int) (byte) -1, orderDirection33, false);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger29);
        try {
            java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20, (java.lang.Number) 1.9155040003582885E22d, 35, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 20 + "'", number8.equals(20));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) (byte) 0, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.148283155648077d, (java.lang.Number) 100.0d, 1586880512, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.Number number0 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, number7, 100, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1874829662), (java.lang.Number) 904.5087854507779d, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 6.040372884E10d, 1079574528, orderDirection12, false);
        java.lang.Number number17 = nonMonotonousSequenceException16.getArgument();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        float float3 = org.apache.commons.math.util.MathUtils.round(54.0f, 4, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 54.0001f + "'", float3 == 54.0001f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.00000000000001d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000001d + "'", double2 == 100.00000000000001d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 11);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 97);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 97);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 1586880528);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (byte) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 11);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 97);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 3104);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 1774819148L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1225L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1068859392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.47013969440533454d, 1.1851160204964712d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.22503638537740317d) + "'", double2 == (-0.22503638537740317d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double[] doubleArray3 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray8 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray15 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray20 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray27 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray32 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray27);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, (short) 10, (-1L) };
        double[] doubleArray46 = new double[] { 11013.232874703393d, 2.2250738585072014E-308d, (-1.0f), (-1.0d) };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray41);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11023.232874703393d + "'", double9 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 418149471 + "'", int11 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 11023.232874703393d + "'", double21 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.04987562112089d + "'", double22 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 418149471 + "'", int23 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11023.232874703393d + "'", double33 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.04987562112089d + "'", double34 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 418149471 + "'", int37 == 418149471);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 11023.232874703393d + "'", double47 == 11023.232874703393d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.04987562112089d + "'", double48 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 418149471 + "'", int50 == 418149471);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.00000000005d + "'", double1 == 1.00000000005d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 11);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (-1068859392));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.math.util.FastMath.max(1277, 1586880496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586880496 + "'", int2 == 1586880496);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(101, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.60598829256212d + "'", double2 == 60.60598829256212d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5403081748293445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.59984860751159d + "'", double1 == 0.59984860751159d);
    }
}

